# Build status — v1.6.0-dev11

- Android App: `1.6.0-dev11` / `160900`
- 内置核心组件: `1.6.0-dev8` / `16008`
- SnowLuma 默认扫码：FFmpeg x11grab → PNG → 原生 Compose Image；不经过 VNC/noVNC/WebView。
- 高级完整 QQ 桌面：保留 noVNC，用户显式打开时才启动。
- AstrBot/SnowLuma 管理页：简化 WebView，只依据平台加载/HTTP/渲染进程回调，不再做 DOM 空白探针与自动 host/reload 恢复。
- 本地源码门禁会校验核心清单、Shell 语法、Compose 注解、原生扫码链路与 WebView“无自动空白重载”约束。

本环境没有完整 Android SDK/Gradle Wrapper JAR，因此最终 `assembleDebug` 仍由 GitHub Actions/Android 构建环境完成。
