package com.xianaurora.astrbotcontrol.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.xianaurora.astrbotcontrol.engine.ControlCenterViewModel
import com.xianaurora.astrbotcontrol.model.ConsoleTarget
import com.xianaurora.astrbotcontrol.model.ControlCenterUiState
import com.xianaurora.astrbotcontrol.model.ControlDestination
import com.xianaurora.astrbotcontrol.model.LogCategory
import com.xianaurora.astrbotcontrol.model.LogSource
import com.xianaurora.astrbotcontrol.model.OperationsSection
import com.xianaurora.astrbotcontrol.model.RuntimeHealth
import com.xianaurora.astrbotcontrol.model.RuntimeStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

private object MotionSpec {
    val strongEaseOut = CubicBezierEasing(0.23f, 1f, 0.32f, 1f)
    val strongEaseInOut = CubicBezierEasing(0.77f, 0f, 0.175f, 1f)
    const val quick = 160
    const val page = 240
    const val fade = 120
    val spatialSpring = spring<Float>(dampingRatio = 0.84f, stiffness = 470f)
    val pressSpring = spring<Float>(dampingRatio = 0.82f, stiffness = 760f)
    val settleSpring = spring<Dp>(dampingRatio = 0.82f, stiffness = 520f)
}

private data class UiLogLine(val text: String, val occurrence: Int)
private data class SituationData(
    val label: String,
    val title: String,
    val detail: String,
    val next: String,
    val actionLabel: String = "",
    val action: String = ""
)

private fun destinationRank(destination: ControlDestination) = when (destination) {
    ControlDestination.OVERVIEW -> 0
    ControlDestination.OPERATIONS -> 1
    ControlDestination.CONSOLE -> 2
}

@Composable
fun ControlCenterApp(
    vm: ControlCenterViewModel,
    onOpenHelp: () -> Unit
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner, vm) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> vm.start()
                Lifecycle.Event.ON_STOP -> vm.stop()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) vm.start()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            vm.stop()
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 760.dp
        if (wide) {
            Row(Modifier.fillMaxSize()) {
                ControlRail(
                    destination = ui.destination,
                    attention = ui.status.health == RuntimeHealth.ATTENTION,
                    onDestination = vm::setDestination,
                    modifier = Modifier.width(108.dp).fillMaxHeight()
                )
                ControlContent(ui, vm, onOpenHelp, Modifier.weight(1f).fillMaxHeight(), true)
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                ControlContent(ui, vm, onOpenHelp, Modifier.weight(1f).fillMaxWidth(), false)
                ControlBottomBar(
                    destination = ui.destination,
                    attention = ui.status.health == RuntimeHealth.ATTENTION,
                    onDestination = vm::setDestination,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ControlContent(
    ui: ControlCenterUiState,
    vm: ControlCenterViewModel,
    onOpenHelp: () -> Unit,
    modifier: Modifier,
    wide: Boolean
) {
    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        if (ui.loading) {
            ControlCenterLoading()
        } else {
            AnimatedContent(
                targetState = ui.destination,
                transitionSpec = {
                    val forward = destinationRank(targetState) >= destinationRank(initialState)
                    val enter = if (forward) 28 else -28
                    val exit = if (forward) -14 else 14
                    (fadeIn(tween(MotionSpec.page, easing = MotionSpec.strongEaseOut)) +
                        slideInHorizontally(tween(MotionSpec.page, easing = MotionSpec.strongEaseOut)) { enter }) togetherWith
                        (fadeOut(tween(MotionSpec.fade)) +
                            slideOutHorizontally(tween(MotionSpec.quick, easing = MotionSpec.strongEaseInOut)) { exit })
                },
                label = "control-destination"
            ) { destination ->
                when (destination) {
                    ControlDestination.OVERVIEW -> OverviewScreen(ui, vm, wide)
                    ControlDestination.OPERATIONS -> OperationsScreen(ui, vm, onOpenHelp, wide)
                    ControlDestination.CONSOLE -> ConsoleScreen(ui, vm, wide)
                }
            }
        }

        ControlMessageOverlay(
            error = ui.errorMessage,
            message = ui.transientMessage,
            onDismiss = vm::clearMessages,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun ControlCenterLoading() {
    val infinite = rememberInfiniteTransition(label = "control-loading")
    val pulse by infinite.animateFloat(
        initialValue = .96f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(760, easing = MotionSpec.strongEaseInOut), repeatMode = RepeatMode.Reverse),
        label = "control-loading-pulse"
    )
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(70.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("A", fontSize = 29.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Text("正在恢复控制中心", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("读取当前状态与下一步操作", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OverviewScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val padding = if (wide) 30.dp else 18.dp
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = padding, end = padding, top = 22.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)
    ) {
        item {
            ScreenHeader(
                eyebrow = "控制中心",
                title = greetingTitle(ui.status),
                subtitle = "先看当前情况；需要操作时，界面会直接告诉你下一步。",
                refreshing = ui.refreshing,
                onRefresh = vm::refresh
            )
        }
        item { SituationCard(ui, vm, emphasize = true) }
        item {
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KeyStatusCard(Modifier.weight(1f), "A", "AstrBot", astrbotState(ui.status), ui.status.astrbotUp && ui.status.astrbotWebReady, ui.status.astrbotUp && !ui.status.astrbotWebReady, astrbotDetail(ui.status))
                    KeyStatusCard(Modifier.weight(1f), "QQ", "QQ", qqStateLabel(ui.status), ui.status.qqOnline, ui.status.qqStartingCount > 0, qqEngineLabel(ui.status))
                    KeyStatusCard(Modifier.weight(1f), "1B", "OneBot", oneBotState(ui.status), ui.status.oneBotConnected > 0, ui.status.stackStarting, oneBotDetail(ui.status))
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    KeyStatusCard(Modifier.fillMaxWidth(), "A", "AstrBot", astrbotState(ui.status), ui.status.astrbotUp && ui.status.astrbotWebReady, ui.status.astrbotUp && !ui.status.astrbotWebReady, astrbotDetail(ui.status))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        KeyStatusCard(Modifier.weight(1f), "QQ", "QQ", qqStateLabel(ui.status), ui.status.qqOnline, ui.status.qqStartingCount > 0, qqEngineLabel(ui.status))
                        KeyStatusCard(Modifier.weight(1f), "1B", "OneBot", oneBotState(ui.status), ui.status.oneBotConnected > 0, ui.status.stackStarting, oneBotDetail(ui.status))
                    }
                }
            }
        }
        item { ActivityCard(ui.status) }
    }
}

@Composable
private fun SituationCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, emphasize: Boolean) {
    val situation = situationFor(ui)
    val health = ui.status.health
    val container by animateColorAsState(
        targetValue = when (health) {
            RuntimeHealth.HEALTHY -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = if (emphasize) .62f else .42f)
            RuntimeHealth.WORKING -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .58f)
            RuntimeHealth.ATTENTION -> MaterialTheme.colorScheme.errorContainer.copy(alpha = .68f)
            else -> MaterialTheme.colorScheme.surfaceContainerHigh
        },
        animationSpec = tween(220, easing = MotionSpec.strongEaseOut),
        label = "situation-container"
    )
    Surface(
        modifier = Modifier.fillMaxWidth().animateContentSize(animationSpec = spring(dampingRatio = .9f, stiffness = 430f)),
        color = container,
        shape = RoundedCornerShape(if (emphasize) 34.dp else 28.dp)
    ) {
        BoxWithConstraints(Modifier.padding(if (emphasize) 22.dp else 18.dp)) {
            val compact = maxWidth < 520.dp
            if (compact) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    SituationText(situation)
                    SituationAction(situation, ui, vm, Modifier.fillMaxWidth())
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Box(Modifier.weight(1f)) { SituationText(situation) }
                    SituationAction(situation, ui, vm, Modifier.widthIn(min = 190.dp, max = 250.dp))
                }
            }
        }
    }
}

@Composable
private fun SituationText(situation: SituationData) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("当前情况", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        KineticText(
            text = situation.title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            label = "situation-title"
        )
        Text(situation.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
        NextStepBeacon(text = situation.next)
    }
}

@Composable
private fun NextStepBeacon(text: String, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "next-step-beacon")
    val pulse by infinite.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(920, easing = MotionSpec.strongEaseInOut), RepeatMode.Reverse),
        label = "next-step-pulse"
    )
    val shimmer by infinite.animateFloat(
        initialValue = 0.68f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1080, easing = MotionSpec.strongEaseInOut), RepeatMode.Reverse),
        label = "next-step-shimmer"
    )
    Surface(
        modifier = modifier.animateContentSize(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.88f)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(18.dp)
                        .graphicsLayer {
                            scaleX = pulse
                            scaleY = pulse
                            alpha = 0.16f + (1f - pulse.coerceAtMost(1f)) * 0.18f
                        }
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                )
                Box(
                    Modifier
                        .size(8.dp)
                        .graphicsLayer { alpha = shimmer }
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                )
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("下一步", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                KineticCharacters(
                    text = text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium,
                    label = "situation-next-beacon"
                )
            }
        }
    }
}

@Composable
private fun SituationAction(situation: SituationData, ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    if (situation.actionLabel.isBlank()) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surface.copy(alpha = .48f), modifier = modifier) {
            Text(situation.next.ifBlank { "现在无需操作" }, modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge)
        }
        return
    }
    val enabled = !ui.actionBusy && !ui.status.actionRunning
    MotionButton(situation.actionLabel, enabled, true, modifier) {
        when (situation.action) {
            "login" -> vm.openQqLogin()
            "start" -> vm.runAction("start")
            "bridge" -> vm.runAction("bridge-repair")
            "operations" -> vm.setDestination(ControlDestination.OPERATIONS)
            else -> vm.setDestination(ControlDestination.OPERATIONS)
        }
    }
}

@Composable
private fun KeyStatusCard(modifier: Modifier, glyph: String, title: String, state: String, good: Boolean, working: Boolean, detail: String) {
    val surface by animateColorAsState(
        targetValue = if (good) MaterialTheme.colorScheme.surfaceContainer else if (working) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .35f) else MaterialTheme.colorScheme.surfaceContainer,
        animationSpec = tween(180, easing = MotionSpec.strongEaseOut),
        label = "status-card"
    )
    Surface(modifier = modifier.heightIn(min = 130.dp), color = surface, shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceContainerHighest, modifier = Modifier.size(39.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text(glyph, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                }
                Spacer(Modifier.weight(1f))
                StatePill(state, good)
            }
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ActivityCard(status: RuntimeStatus) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("最近状态", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            ActivityLine("收到消息", status.lastInbound)
            ActivityLine("发出消息", status.lastOutbound)
            ActivityLine("模型响应", status.lastModelOk)
            if (status.lastEvent.isNotBlank()) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
                Text(status.lastEvent, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun ActivityLine(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        KineticText(
            text = value.ifBlank { "暂无" },
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            label = "activity-value-$label"
        )
    }
}

@Composable
private fun OperationsScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, onOpenHelp: () -> Unit, wide: Boolean) {
    var switchTarget by remember { mutableStateOf<String?>(null) }
    var confirmReboot by remember { mutableStateOf(false) }

    switchTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { switchTarget = null },
            title = { Text("切换 QQ 运行方式") },
            text = { Text("将停止当前 QQ 运行方式，再启动 ${if (target == "snowluma") "SnowLuma" else "NapCat"}。AstrBot 本身不会重启，切换完成后会自动检查 OneBot。") },
            confirmButton = {
                TextButton(onClick = {
                    switchTarget = null
                    vm.runAction(if (target == "snowluma") "engine-snowluma" else "engine-napcat")
                }) { Text("确认切换") }
            },
            dismissButton = { TextButton(onClick = { switchTarget = null }) { Text("取消") } }
        )
    }
    if (confirmReboot) {
        AlertDialog(
            onDismissRequest = { confirmReboot = false },
            title = { Text("重启设备？") },
            text = { Text("这是整台 Android 设备重启，不是重启 AstrBot 服务。正在进行的任务会被中断。") },
            confirmButton = { TextButton(onClick = { confirmReboot = false; vm.rebootDevice() }) { Text("重启设备") } },
            dismissButton = { TextButton(onClick = { confirmReboot = false }) { Text("取消") } }
        )
    }

    val padding = if (wide) 26.dp else 18.dp
    Column(Modifier.fillMaxSize().padding(start = padding, end = padding, top = 20.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenHeader("运维", "操作和日志放在一起", "做完一个动作，马上能看到对应状态与日志，不再来回找入口。", ui.refreshing, vm::refresh)
        if (wide) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                LazyColumn(
                    modifier = Modifier.weight(.88f).fillMaxHeight(),
                    contentPadding = PaddingValues(bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { SituationCard(ui, vm, emphasize = false) }
                    item { ServiceActionsCard(ui, vm) }
                    item { QqModeCard(ui, onSwitch = { switchTarget = it }) }
                    item { RepairCard(ui, vm, Modifier.fillMaxWidth()) }
                    item { DiagnosticCard(ui, vm, Modifier.fillMaxWidth()) }
                    item { DeviceHelpCard(onOpenHelp, onReboot = { confirmReboot = true }) }
                }
                LogPanel(ui, vm, Modifier.weight(1.12f).fillMaxHeight(), compact = false)
            }
        } else {
            OperationsSectionSelector(ui.operationsSection, vm::setOperationsSection)
            AnimatedContent(
                targetState = ui.operationsSection,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                transitionSpec = {
                    (fadeIn(tween(180, easing = MotionSpec.strongEaseOut)) + slideInHorizontally(tween(210, easing = MotionSpec.strongEaseOut)) { it / 10 }) togetherWith fadeOut(tween(100))
                },
                label = "operations-section"
            ) { section ->
                when (section) {
                    OperationsSection.ACTIONS -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 22.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item { SituationCard(ui, vm, emphasize = false) }
                        item { ServiceActionsCard(ui, vm) }
                        item { QqModeCard(ui, onSwitch = { switchTarget = it }) }
                        item { RepairCard(ui, vm, Modifier.fillMaxWidth()) }
                        item { DeviceHelpCard(onOpenHelp, onReboot = { confirmReboot = true }) }
                    }
                    OperationsSection.LOGS -> LogPanel(ui, vm, Modifier.fillMaxSize(), compact = true)
                    OperationsSection.DIAGNOSTICS -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 22.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item { DiagnosticCard(ui, vm, Modifier.fillMaxWidth()) }
                        item { EnvironmentCard(ui) }
                    }
                }
            }
        }
    }
}

@Composable
private fun OperationsSectionSelector(selected: OperationsSection, onSelect: (OperationsSection) -> Unit) {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(5.dp)) {
            val count = OperationsSection.entries.size
            val slot = maxWidth / count
            val index = OperationsSection.entries.indexOf(selected).coerceAtLeast(0)
            val x by animateDpAsState(slot * index, MotionSpec.settleSpring, label = "ops-tab-x")
            Surface(
                shape = RoundedCornerShape(17.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.width(slot).height(42.dp).offset(x = x)
            ) {}
            Row(Modifier.fillMaxWidth()) {
                OperationsSection.entries.forEach { section ->
                    Box(
                        Modifier.width(slot).height(42.dp).clip(RoundedCornerShape(17.dp)).clickable { onSelect(section) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(section.label, fontWeight = if (section == selected) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}

@Composable
private fun ServiceActionsCard(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val busy = ui.actionBusy || ui.status.actionRunning || ui.status.stackStarting
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("常用操作", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            if (ui.actionBusy) {
                Text(ui.actionLabel, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("正在执行并验证结果，现在不需要重复点击。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val compact = maxWidth < 500.dp
                if (compact) {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        MotionButton(if (ui.status.stackRunning) "重启全部服务" else "启动全部服务", !busy, true, Modifier.fillMaxWidth()) { vm.runAction(if (ui.status.stackRunning) "restart" else "start") }
                        MotionButton("QQ 扫码登录", !busy, false, Modifier.fillMaxWidth(), vm::openQqLogin)
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        MotionButton(if (ui.status.stackRunning) "重启全部服务" else "启动全部服务", !busy, true, Modifier.weight(1f)) { vm.runAction(if (ui.status.stackRunning) "restart" else "start") }
                        MotionButton("QQ 扫码登录", !busy, false, Modifier.weight(1f), vm::openQqLogin)
                    }
                }
            }
        }
    }
}

@Composable
private fun QqModeCard(ui: ControlCenterUiState, onSwitch: (String) -> Unit) {
    val current = ui.status.qqEngine
    val busy = ui.actionBusy || ui.status.actionRunning
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("QQ 运行方式", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("当前状态、日志和扫码都会自动跟随这里的选择。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(if (current == "snowluma") "SnowLuma" else "NapCat", good = true)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeChoice("NapCat", current == "napcat", enabled = !busy, Modifier.weight(1f)) { onSwitch("napcat") }
                ModeChoice("SnowLuma", current == "snowluma", enabled = !busy && ui.status.snowlumaReady, Modifier.weight(1f)) { onSwitch("snowluma") }
            }
            if (!ui.status.snowlumaReady) Text("SnowLuma 尚未安装时不会允许切换。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ModeChoice(text: String, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
        animationSpec = tween(170, easing = MotionSpec.strongEaseOut),
        label = "mode-bg"
    )
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .97f else 1f, MotionSpec.pressSpring, label = "mode-press")
    Surface(
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(RoundedCornerShape(18.dp)).clickable(interactionSource = interaction, indication = null, enabled = enabled && !selected, onClick = onClick),
        color = bg,
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AnimatedContent(
                targetState = selected,
                transitionSpec = {
                    (fadeIn(tween(150, easing = MotionSpec.strongEaseOut)) + scaleIn(initialScale = .72f, animationSpec = MotionSpec.spatialSpring)) togetherWith fadeOut(tween(80))
                },
                label = "mode-glyph"
            ) { active ->
                Text(if (active) "●" else "○", color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            KineticText(text = text, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, label = "mode-label-$text")
        }
    }
}

@Composable
private fun RepairCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    val busy = ui.actionBusy || ui.status.actionRunning
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = modifier) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("诊断与修复", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("只在出现异常时使用。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(5.dp))
            MaintenanceRow("自动恢复", "只重启真正退出的组件。", enabled = !busy) { vm.runAction("heal") }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
            MaintenanceRow("修复 OneBot", "检查鉴权与反向连接。", enabled = !busy) { vm.runAction("bridge-repair") }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
            MaintenanceRow("修复插件依赖", "扫描并修复 AstrBot 插件依赖。", enabled = !busy) { vm.runAction("plugin-deps") }
        }
    }
}

@Composable
private fun DiagnosticCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    var showRawConfirm by remember { mutableStateOf(false) }
    if (showRawConfirm) {
        AlertDialog(
            onDismissRequest = { showRawConfirm = false },
            title = { Text("导出完整日志包？") },
            text = { Text("完整日志包可能包含 QQ 号、Token、网络地址和账号配置。只有在你明确需要完整原始数据时再导出。") },
            confirmButton = { TextButton(onClick = { showRawConfirm = false; vm.startExport("raw") }) { Text("继续导出") } },
            dismissButton = { TextButton(onClick = { showRawConfirm = false }) { Text("取消") } }
        )
    }
    val export = ui.exportState
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = modifier.animateContentSize()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("日志与诊断", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("默认导出脱敏日志包，并附带必要的非敏感诊断信息。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (export.running) {
                LinearProgressIndicator(progress = { export.percent / 100f }, modifier = Modifier.fillMaxWidth())
                Text(export.detail.ifBlank { "正在采集" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = vm::cancelExport) { Text("取消导出") }
            } else {
                MotionButton("导出脱敏日志包", true, true, Modifier.fillMaxWidth()) { vm.startExport("redacted") }
                TextButton(onClick = { showRawConfirm = true }) { Text("需要完整原始日志包") }
            }
            if (!export.running && export.path.isNotBlank()) {
                Text(export.path, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun DeviceHelpCard(onOpenHelp: () -> Unit, onReboot: () -> Unit) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("设备与帮助", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            MaintenanceRow("安装与使用教程", "安装、恢复与常见问题。", onClick = onOpenHelp)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
            MaintenanceRow("重启设备", "重启整台 Android 设备。", critical = true, onClick = onReboot)
        }
    }
}

@Composable
private fun EnvironmentCard(ui: ControlCenterUiState) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("环境信息", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            InfoRow("核心组件", ui.status.moduleVersion.ifBlank { "未知" })
            InfoRow("设备", ui.status.device.ifBlank { "未知" })
            InfoRow("Android", ui.status.android.ifBlank { "未知" })
            InfoRow("内核", ui.status.kernel.ifBlank { "未知" })
        }
    }
}

@Composable
private fun MaintenanceRow(
    title: String,
    detail: String,
    enabled: Boolean = true,
    critical: Boolean = false,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .985f else 1f, MotionSpec.pressSpring, label = "maintenance-row")
    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = if (enabled) 1f else .45f; scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(16.dp)).clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, color = if (critical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.headlineSmall, color = if (critical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LogPanel(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier, compact: Boolean) {
    val displayText = if (ui.redactLogs) ui.redactedLogText else ui.logText
    val lines = remember(displayText) {
        val seen = HashMap<String, Int>()
        displayText.lineSequence().map { text ->
            val occurrence = seen[text] ?: 0
            seen[text] = occurrence + 1
            UiLogLine(text, occurrence)
        }.toList()
    }
    val listState = rememberLazyListState()
    var followTail by rememberSaveable { mutableStateOf(true) }
    val tailToken = lines.lastOrNull()?.let { 31 * it.text.hashCode() + it.occurrence } ?: 0

    LaunchedEffect(tailToken, followTail, ui.selectedLogId) {
        if (!followTail || lines.isEmpty()) return@LaunchedEffect
        val target = lines.lastIndex
        // Wait until LazyColumn has actually composed this source. Calling animateScrollToItem
        // during a source switch before the new item provider is measured can throw on some
        // Compose versions/devices. Cancellation from a newer log update is expected.
        snapshotFlow { listState.layoutInfo.totalItemsCount }.first { it > target }
        try {
            if (target - listState.firstVisibleItemIndex > 70) listState.scrollToItem(target)
            else listState.animateScrollToItem(target)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: IndexOutOfBoundsException) {
            // A newer log snapshot replaced this one between measurement and scrolling.
            // The next LaunchedEffect invocation will follow the new tail safely.
        }
    }

    Surface(modifier = modifier, shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.fillMaxSize()) {
            LogToolbar(ui, vm, followTail, { followTail = !followTail }, displayText, compact)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .52f))
            if (lines.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        if (ui.logLoading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.4.dp)
                        Text(if (ui.logLoading) "正在读取日志…" else "暂无日志", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                // Do not wrap LazyColumn in SelectionContainer. Compose has known crashes when
                // selected lazy-list items are disposed while scrolling. Copy is provided in the
                // toolbar instead, keeping the live log list stable.
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    items(lines, key = { "${it.occurrence}:${it.text}" }) { item ->
                        val line = item.text
                        Text(
                            line.ifEmpty { " " },
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.5.sp,
                            lineHeight = 17.sp,
                            color = if (line.contains("error", true) || line.contains("失败") || line.contains("fatal", true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LogToolbar(
    ui: ControlCenterUiState,
    vm: ControlCenterViewModel,
    followTail: Boolean,
    onToggleFollow: () -> Unit,
    displayText: String,
    compact: Boolean
) {
    val context = LocalContext.current
    val categorySources = remember(ui.logSources, ui.logCategory) { ui.logSources.filter { it.category == ui.logCategory } }
    Column(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (compact) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(LogCategory.entries, key = { it.name }) { category ->
                    LogCategoryChip(category.label, category == ui.logCategory) { vm.selectLogCategory(category) }
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                LogCategory.entries.forEach { category ->
                    LogCategoryChip(category.label, category == ui.logCategory) { vm.selectLogCategory(category) }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(categorySources.firstOrNull { it.id == ui.selectedLogId }?.label ?: ui.logCategory.label, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (ui.logLoading) CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp)
            PrivacyToggle(ui.redactLogs) { vm.setLogRedaction(it) }
            TextButton(onClick = { copyText(context, displayText); }, enabled = displayText.isNotBlank()) { Text("复制") }
            TextButton(onClick = onToggleFollow) {
                KineticText(text = if (followTail) "暂停" else "跟随", style = MaterialTheme.typography.labelLarge, label = "log-follow")
            }
        }
        if (categorySources.size > 1) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(categorySources, key = { it.id }) { source ->
                    LogSourceChip(source, source.id == ui.selectedLogId) { vm.selectLog(source.id) }
                }
            }
        }
    }
}

@Composable
private fun PrivacyToggle(redacted: Boolean, onChanged: (Boolean) -> Unit) {
    val bg by animateColorAsState(
        if (redacted) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
        tween(160, easing = MotionSpec.strongEaseOut),
        label = "privacy-bg"
    )
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable { onChanged(!redacted) }) {
        KineticCharacters(
            text = if (redacted) "已脱敏" else "原始",
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (redacted) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
            fontWeight = FontWeight.SemiBold,
            label = "privacy-state"
        )
    }
}

@Composable
private fun LogCategoryChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh, tween(150, easing = MotionSpec.strongEaseOut), label = "log-category-chip")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable(onClick = onClick)) {
        Text(text, modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun LogSourceChip(source: LogSource, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.surfaceContainerHighest else Color.Transparent, tween(150, easing = MotionSpec.strongEaseOut), label = "log-source")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable(onClick = onClick)) {
        Text(source.label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun ConsoleScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val controller = rememberConsoleWebController()
    val padding = if (wide) 24.dp else 12.dp
    Column(Modifier.fillMaxSize().padding(start = padding, end = padding, top = 14.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ConsoleToolbar(ui, vm, controller)
        when (ui.console.target) {
            ConsoleTarget.QQ_LOGIN -> QqLoginWorkspace(ui, vm, controller, Modifier.fillMaxSize(), wide)
            else -> StandardConsoleWorkspace(ui, vm, controller, Modifier.fillMaxSize(), wide)
        }
    }
}

@Composable
private fun ConsoleToolbar(ui: ControlCenterUiState, vm: ControlCenterViewModel, controller: ConsoleWebController) {
    val qqSelected = ui.console.target == ConsoleTarget.QQ || ui.console.target == ConsoleTarget.QQ_LOGIN
    val showWebNav = ui.console.target != ConsoleTarget.QQ_LOGIN || ui.status.qqEngine != "snowluma" || ui.console.qrDesktopMode
    val contextTitle = when (ui.console.target) {
        ConsoleTarget.QQ_LOGIN -> "${qqEngineLabel(ui.status)} · 扫码工作台"
        else -> ui.console.title
    }
    val contextualLabel = when (ui.console.target) {
        ConsoleTarget.QQ -> "扫码登录"
        ConsoleTarget.QQ_LOGIN -> "返回 QQ"
        else -> ""
    }
    val contextualAction: (() -> Unit)? = when (ui.console.target) {
        ConsoleTarget.QQ -> vm::openQqLogin
        ConsoleTarget.QQ_LOGIN -> ({ vm.openConsole(ConsoleTarget.QQ) })
        else -> null
    }
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            val compact = maxWidth < 640.dp
            if (compact) {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        item { ConsoleTargetChoice("AstrBot", ui.console.target == ConsoleTarget.ASTRBOT) { vm.openConsole(ConsoleTarget.ASTRBOT) } }
                        item { ConsoleTargetChoice("QQ", qqSelected) { vm.openConsole(ConsoleTarget.QQ) } }
                        if (contextualAction != null) item {
                            TextButton(onClick = contextualAction) { KineticText(contextualLabel, style = MaterialTheme.typography.labelLarge, label = "console-context-action") }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        KineticText(
                            text = contextTitle,
                            modifier = Modifier.weight(1f).padding(start = 5.dp),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            label = "console-title"
                        )
                        if (showWebNav) ConsoleNavControls(controller)
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ConsoleTargetChoice("AstrBot", ui.console.target == ConsoleTarget.ASTRBOT) { vm.openConsole(ConsoleTarget.ASTRBOT) }
                    ConsoleTargetChoice("QQ", qqSelected) { vm.openConsole(ConsoleTarget.QQ) }
                    if (contextualAction != null) {
                        TextButton(onClick = contextualAction) { KineticText(contextualLabel, style = MaterialTheme.typography.labelLarge, label = "console-context-action") }
                    }
                    KineticText(
                        text = contextTitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 7.dp),
                        label = "console-title"
                    )
                    Spacer(Modifier.weight(1f))
                    if (showWebNav) ConsoleNavControls(controller)
                }
            }
        }
    }
}

@Composable
private fun ConsoleTargetChoice(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, tween(160, easing = MotionSpec.strongEaseOut), label = "console-target")
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .96f else 1f, MotionSpec.pressSpring, label = "console-target-press")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(CircleShape).clickable(interactionSource = interaction, indication = null, onClick = onClick)) {
        Text(text, modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun StandardConsoleWorkspace(ui: ControlCenterUiState, vm: ControlCenterViewModel, controller: ConsoleWebController, modifier: Modifier, wide: Boolean) {
    Surface(modifier, shape = RoundedCornerShape(if (wide) 28.dp else 22.dp), color = MaterialTheme.colorScheme.surfaceContainer, shadowElevation = 1.dp) {
        Box(Modifier.fillMaxSize()) {
            when {
                ui.console.error.isNotBlank() -> ConsoleError(ui.console.error, vm::retryConsole, Modifier.align(Alignment.Center))
                ui.console.url.isBlank() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                else -> EmbeddedConsoleWebView(
                    url = ui.console.url,
                    controller = controller,
                    modifier = Modifier.fillMaxSize(),
                    presentation = ConsoleWebPresentation.STANDARD,
                    onLoadingChanged = vm::setConsoleLoading,
                    onError = vm::setConsoleError
                )
            }
            if (ui.console.loading && ui.console.url.isNotBlank()) {
                LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            }
        }
    }
}

@Composable
private fun QqLoginWorkspace(ui: ControlCenterUiState, vm: ControlCenterViewModel, controller: ConsoleWebController, modifier: Modifier, wide: Boolean) {
    val snowluma = ui.status.qqEngine == "snowluma"
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        QqLoginStatusStrip(ui, vm)
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(if (wide) 30.dp else 24.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            shadowElevation = 1.dp
        ) {
            val visualState = when {
                ui.console.error.isNotBlank() -> "error"
                ui.console.phase == "complete" -> "complete"
                snowluma && ui.console.qrDesktopMode && ui.console.url.isNotBlank() -> "desktop"
                snowluma && ui.console.qrImageBytes.isNotEmpty() -> "native"
                !snowluma && ui.console.url.isNotBlank() -> "web"
                else -> "preparing"
            }
            AnimatedContent(
                targetState = visualState,
                modifier = Modifier.fillMaxSize().padding(8.dp),
                transitionSpec = {
                    (fadeIn(tween(210, easing = MotionSpec.strongEaseOut)) +
                        scaleIn(initialScale = .985f, animationSpec = tween(240, easing = MotionSpec.strongEaseOut))) togetherWith
                        fadeOut(tween(105))
                },
                label = "qq-login-workspace"
            ) { state ->
                when (state) {
                    "error" -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        ConsoleError(ui.console.error, vm::retryConsole)
                    }
                    "complete" -> QqLoginComplete(Modifier.fillMaxSize())
                    "native" -> NativeQqLoginFrame(ui, vm, Modifier.fillMaxSize(), wide)
                    "desktop" -> Surface(
                        modifier = Modifier.fillMaxSize(),
                        shape = RoundedCornerShape(if (wide) 24.dp else 18.dp),
                        color = Color(0xFF171A1D)
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            EmbeddedConsoleWebView(
                                url = ui.console.url,
                                controller = controller,
                                modifier = Modifier.fillMaxSize(),
                                presentation = ConsoleWebPresentation.QR_DESKTOP,
                                onLoadingChanged = vm::setConsoleLoading,
                                onError = vm::setConsoleError
                            )
                            if (ui.console.loading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
                            Surface(
                                modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp),
                                shape = RoundedCornerShape(18.dp),
                                color = MaterialTheme.colorScheme.inverseSurface.copy(alpha = .88f)
                            ) {
                                Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("高级完整桌面 · noVNC", color = MaterialTheme.colorScheme.inverseOnSurface, style = MaterialTheme.typography.labelMedium)
                                    TextButton(onClick = vm::openQqLogin) { Text("返回原生扫码") }
                                }
                            }
                        }
                    }
                    "web" -> EmbeddedConsoleWebView(
                        url = ui.console.url,
                        controller = controller,
                        modifier = Modifier.fillMaxSize(),
                        presentation = ConsoleWebPresentation.STANDARD,
                        onLoadingChanged = vm::setConsoleLoading,
                        onError = vm::setConsoleError
                    )
                    else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        QqLoginPreparing(ui)
                    }
                }
            }
        }
    }
}

@Composable
private fun NativeQqLoginFrame(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier, wide: Boolean) {
    val image = remember(ui.console.qrImageBytes) {
        val bytes = ui.console.qrImageBytes
        if (bytes.isEmpty()) null else runCatching {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        }.getOrNull()
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(if (wide) 24.dp else 18.dp),
        color = Color(0xFF171A1D)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (image != null) {
                    Image(
                        bitmap = image,
                        contentDescription = "QQ 登录二维码",
                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    QqLoginPreparing(ui)
                }
            }
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.inverseSurface.copy(alpha = .94f)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("原生扫码画面", color = MaterialTheme.colorScheme.inverseOnSurface, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                        Text(
                            "直接读取 QQ 窗口 PNG · 不经过 VNC / noVNC / WebView",
                            color = MaterialTheme.colorScheme.inverseOnSurface.copy(alpha = .72f),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    TextButton(onClick = vm::openQqDesktop) { Text("完整桌面") }
                }
            }
        }
    }
}

@Composable
private fun QqLoginComplete(modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(28.dp)) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(72.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("✓", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
            Text("QQ 已登录", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("扫码画面已经自动收尾。QQ 与 SnowLuma 会继续运行，OneBot 会自动完成连接。", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun QqLoginStatusStrip(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val snowluma = ui.status.qqEngine == "snowluma"
    val complete = ui.console.phase == "complete"
    val nativeReady = snowluma && !ui.console.qrDesktopMode && ui.console.qrImageBytes.isNotEmpty() && ui.console.error.isBlank()
    val desktopReady = snowluma && ui.console.qrDesktopMode && ui.console.url.isNotBlank() && ui.console.error.isBlank()
    val webReady = !snowluma && ui.console.url.isNotBlank() && ui.console.error.isBlank()
    val ready = nativeReady || desktopReady || webReady
    val failed = ui.console.error.isNotBlank() || ui.console.phase == "failed"
    val glyph = when {
        failed -> "!"
        complete -> "✓"
        ready -> "✓"
        ui.console.phase == "capturing" -> "▣"
        ui.console.phase == "desktop-starting" -> "↗"
        else -> "…"
    }
    val container by animateColorAsState(
        when {
            failed -> MaterialTheme.colorScheme.errorContainer.copy(alpha = .72f)
            complete || ready -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = .58f)
            else -> MaterialTheme.colorScheme.surfaceContainerHigh
        },
        tween(180, easing = MotionSpec.strongEaseOut),
        label = "login-strip"
    )
    Surface(shape = RoundedCornerShape(24.dp), color = container, modifier = Modifier.fillMaxWidth().animateContentSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                shape = CircleShape,
                color = when {
                    failed -> MaterialTheme.colorScheme.error
                    complete || ready -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.surface
                },
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    AnimatedContent(
                        targetState = glyph,
                        transitionSpec = {
                            (fadeIn(tween(145, easing = MotionSpec.strongEaseOut)) + scaleIn(initialScale = .58f, animationSpec = spring(dampingRatio = .66f, stiffness = 560f))) togetherWith fadeOut(tween(70))
                        },
                        label = "qr-state-glyph"
                    ) { value ->
                        Text(value, fontWeight = FontWeight.Bold, color = when {
                            failed -> MaterialTheme.colorScheme.onError
                            complete || ready -> MaterialTheme.colorScheme.onPrimary
                            else -> MaterialTheme.colorScheme.onSurface
                        })
                    }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                KineticCharacters(
                    text = when {
                        complete -> "QQ 已登录"
                        nativeReady -> "二维码画面已就绪"
                        desktopReady -> "完整 QQ 桌面已就绪"
                        webReady -> "登录页面已就绪"
                        else -> loginPhaseTitle(ui.console.phase)
                    },
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    label = "qr-status-title"
                )
                KineticText(
                    text = ui.console.detail.ifBlank {
                        when {
                            nativeReady -> "SnowLuma 正在直接提供 QQ 登录窗口截图。"
                            complete -> "登录已完成。"
                            else -> "正在准备 QQ 登录环境"
                        }
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    label = "qr-status-detail"
                )
                KineticText(
                    text = when {
                        complete -> "下一步 · 等待 OneBot 自动连接"
                        nativeReady || webReady -> "下一步 · 使用手机 QQ 扫描二维码"
                        desktopReady -> "下一步 · 在完整桌面中完成 QQ 登录"
                        else -> "下一步 · ${loginNextStep(ui.console.phase)}"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium,
                    label = "qr-status-next"
                )
            }
            if (snowluma && nativeReady) TextButton(onClick = vm::openQqDesktop) { Text("完整桌面") }
            else if (snowluma && desktopReady) TextButton(onClick = vm::openQqLogin) { Text("原生扫码") }
            else if (ready && !complete) TextButton(onClick = vm::openQqLogin) { Text("重新打开") }
        }
    }
}

@Composable
private fun QqLoginPreparing(ui: ControlCenterUiState, modifier: Modifier = Modifier) {
    Column(modifier.padding(24.dp).widthIn(max = 480.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        val infinite = rememberInfiniteTransition(label = "qr-preparing")
        val scale by infinite.animateFloat(1f, 1.05f, infiniteRepeatable(tween(720, easing = MotionSpec.strongEaseInOut), RepeatMode.Reverse), label = "qr-preparing-scale")
        Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(78.dp).graphicsLayer { scaleX = scale; scaleY = scale }) {
            Box(contentAlignment = Alignment.Center) { Text("QQ", fontWeight = FontWeight.Bold, fontSize = 22.sp) }
        }
        KineticCharacters(
            text = loginPhaseTitle(ui.console.phase),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            label = "qr-preparing-title"
        )
        KineticText(
            text = ui.console.detail.ifBlank { "正在准备 QQ 登录画面" },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            label = "qr-preparing-detail"
        )
        Text(
            if (ui.status.qqEngine == "snowluma") "检测到 QQ 登录窗口后会直接读取 PNG 截图，不再经过 VNC、WebSocket 和 WebView。"
            else "登录页面准备完成后会在此显示。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ConsoleNavControls(controller: ConsoleWebController) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        CompactTool("‹", controller.canGoBack, controller::back)
        CompactTool("›", controller.canGoForward, controller::forward)
        CompactTool("↻", true, controller::refresh)
    }
}

@Composable
private fun CompactTool(text: String, enabled: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 5.dp)) {
        Text(text, fontSize = 19.sp)
    }
}

@Composable
private fun ConsoleError(message: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.padding(24.dp).widthIn(max = 440.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("页面暂不可用", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        Button(onClick = onRetry, shape = RoundedCornerShape(16.dp)) { Text("重新连接") }
    }
}

@Composable
private fun MotionButton(text: String, enabled: Boolean, primary: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .97f else 1f, MotionSpec.pressSpring, label = "motion-button")
    val alpha by animateFloatAsState(if (enabled) 1f else .62f, tween(120), label = "motion-button-alpha")
    if (primary) {
        Button(
            onClick = onClick,
            enabled = enabled,
            interactionSource = interaction,
            modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale; this.alpha = alpha },
            shape = RoundedCornerShape(17.dp)
        ) { KineticText(text = text, style = MaterialTheme.typography.labelLarge, label = "motion-button-label") }
    } else {
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            interactionSource = interaction,
            modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale; this.alpha = alpha },
            shape = RoundedCornerShape(17.dp)
        ) { KineticText(text = text, style = MaterialTheme.typography.labelLarge, label = "motion-button-label") }
    }
}

@Composable
private fun ScreenHeader(eyebrow: String, title: String, subtitle: String, refreshing: Boolean, onRefresh: () -> Unit) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(eyebrow, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            KineticText(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
                label = "screen-header-title"
            )
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        PressableCircleButton(refreshing, onRefresh)
    }
}

@Composable
private fun PressableCircleButton(refreshing: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .92f else 1f, MotionSpec.pressSpring, label = "refresh-scale")
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.size(46.dp).graphicsLayer { scaleX = scale; scaleY = scale }.clip(CircleShape).clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (refreshing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("↻", fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun ControlBottomBar(destination: ControlDestination, attention: Boolean, onDestination: (ControlDestination) -> Unit, modifier: Modifier) {
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .96f)) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 7.dp)) {
            val items = ControlDestination.entries
            val slot = maxWidth / items.size
            val index = items.indexOf(destination).coerceAtLeast(0)
            val x by animateDpAsState(slot * index + 4.dp, MotionSpec.settleSpring, label = "bottom-indicator-x")
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.width(slot - 8.dp).height(44.dp).offset(x = x)
            ) {}
            Row(Modifier.fillMaxWidth()) {
                items.forEach { item ->
                    BottomNavigationSlot(item, item == destination, attention && item == ControlDestination.OPERATIONS, { onDestination(item) }, Modifier.width(slot))
                }
            }
        }
    }
}

@Composable
private fun BottomNavigationSlot(item: ControlDestination, selected: Boolean, attention: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Box(modifier.height(44.dp).clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(item.shortLabel, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
            if (attention) Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.error, CircleShape))
        }
    }
}

@Composable
private fun ControlRail(destination: ControlDestination, attention: Boolean, onDestination: (ControlDestination) -> Unit, modifier: Modifier) {
    val slotHeight = 76.dp
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .92f)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(52.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("A", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
            Spacer(Modifier.height(24.dp))
            val items = ControlDestination.entries
            Box(Modifier.fillMaxWidth().height(slotHeight * items.size)) {
                val index = items.indexOf(destination).coerceAtLeast(0)
                val y by animateDpAsState(slotHeight * index + 4.dp, MotionSpec.settleSpring, label = "rail-indicator-y")
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth().height(slotHeight - 8.dp).offset(y = y)
                ) {}
                Column(Modifier.fillMaxSize()) {
                    items.forEach { item ->
                        RailNavigationSlot(item, item == destination, attention && item == ControlDestination.OPERATIONS, { onDestination(item) }, Modifier.fillMaxWidth().height(slotHeight))
                    }
                }
            }
        }
    }
}

@Composable
private fun RailNavigationSlot(item: ControlDestination, selected: Boolean, attention: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .96f else 1f, MotionSpec.pressSpring, label = "rail-press")
    Column(
        modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(RoundedCornerShape(20.dp)).clickable(interactionSource = interaction, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box {
            AnimatedContent(
                targetState = selected,
                transitionSpec = {
                    (fadeIn(tween(150, easing = MotionSpec.strongEaseOut)) + scaleIn(initialScale = .72f, animationSpec = MotionSpec.spatialSpring)) togetherWith fadeOut(tween(70))
                },
                label = "rail-glyph"
            ) { active ->
                Text(navGlyph(item, active), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            if (attention) Box(Modifier.align(Alignment.TopEnd).size(6.dp).background(MaterialTheme.colorScheme.error, CircleShape))
        }
        Spacer(Modifier.height(4.dp))
        Text(item.shortLabel, style = MaterialTheme.typography.labelSmall, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun StatePill(text: String, good: Boolean) {
    Surface(shape = CircleShape, color = if (good) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest) {
        KineticCharacters(
            text = text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (good) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
            label = "state-pill"
        )
    }
}

@Composable
private fun KineticText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
    textAlign: TextAlign? = null,
    label: String
) {
    AnimatedContent(
        targetState = text,
        modifier = modifier,
        transitionSpec = {
            (fadeIn(tween(170, easing = MotionSpec.strongEaseOut)) +
                slideInVertically(tween(190, easing = MotionSpec.strongEaseOut)) { it.coerceAtLeast(1) / 4 }) togetherWith
                (fadeOut(tween(85)) + slideOutVertically(tween(115, easing = MotionSpec.strongEaseInOut)) { -it.coerceAtLeast(1) / 5 })
        },
        label = label
    ) { value ->
        Text(
            text = value,
            style = style,
            color = color,
            fontWeight = fontWeight,
            maxLines = maxLines,
            overflow = overflow,
            textAlign = textAlign
        )
    }
}

@Composable
private fun KineticCharacters(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    label: String
) {
    var settled by remember(text) { mutableStateOf(false) }
    LaunchedEffect(text) {
        settled = false
        delay(12)
        settled = true
    }
    Row(modifier, horizontalArrangement = Arrangement.Center) {
        text.forEachIndexed { index, char ->
            val stagger = (index * 13).coerceAtMost(84)
            val alpha by animateFloatAsState(
                targetValue = if (settled) 1f else .32f,
                animationSpec = tween(150, delayMillis = stagger, easing = MotionSpec.strongEaseOut),
                label = "$label-alpha-$index"
            )
            val y by animateDpAsState(
                targetValue = if (settled) 0.dp else 5.dp,
                animationSpec = spring(dampingRatio = .68f, stiffness = 620f),
                label = "$label-y-$index"
            )
            Text(
                text = char.toString(),
                modifier = Modifier.offset(y = y).graphicsLayer { this.alpha = alpha },
                style = style,
                color = color,
                fontWeight = fontWeight,
                textAlign = textAlign
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 460.dp))
    }
}

@Composable
private fun ControlMessageOverlay(error: String, message: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    val text = error.ifBlank { message }
    val critical = error.isNotBlank()
    LaunchedEffect(text) {
        if (text.isNotBlank() && !text.startsWith("状态读取失败") && !text.contains("已保存：")) {
            delay(4600)
            onDismiss()
        }
    }
    AnimatedContent(
        targetState = text,
        modifier = modifier.padding(horizontal = 18.dp, vertical = 16.dp),
        transitionSpec = {
            (fadeIn(tween(180, easing = MotionSpec.strongEaseOut)) + scaleIn(initialScale = .97f, animationSpec = tween(180, easing = MotionSpec.strongEaseOut))) togetherWith fadeOut(tween(100))
        },
        label = "message-overlay"
    ) { current ->
        if (current.isNotBlank()) {
            Surface(shape = RoundedCornerShape(20.dp), color = if (critical) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.inverseSurface, shadowElevation = 5.dp) {
                Row(Modifier.padding(horizontal = 15.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(current, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = if (critical) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.inverseOnSurface, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    TextButton(onClick = onDismiss) { Text("知道了") }
                }
            }
        } else {
            Spacer(Modifier.size(1.dp))
        }
    }
}

private fun copyText(context: Context, text: String) {
    if (text.isBlank()) return
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("AstrBot log", text))
}

private fun situationFor(ui: ControlCenterUiState): SituationData {
    val s = ui.status
    if (ui.actionBusy || s.actionRunning || s.stackStarting) {
        return SituationData(
            label = "处理中",
            title = ui.actionLabel.ifBlank { "服务正在变化" },
            detail = "控制中心正在等待核心组件完成操作并重新检查状态。",
            next = when {
                s.qqEngine == "snowluma" && (s.mainQqState == "starting" || s.qqNeedsLogin) -> "等待 QQ 登录窗口准备完成"
                s.stackStarting -> "等待服务启动完成"
                else -> "等待当前操作完成"
            }
        )
    }
    return when {
        s.qqNeedsLogin -> SituationData(
            label = "需操作",
            title = "QQ 等待登录",
            detail = "${qqEngineLabel(s)} 已经准备好，但 QQ 还没有完成登录。",
            next = "打开扫码桌面并完成登录",
            actionLabel = "QQ 扫码登录",
            action = "login"
        )
        s.oneBotAuthFailed -> SituationData(
            label = "需修复",
            title = "OneBot 鉴权异常",
            detail = "AstrBot 与当前 QQ 运行方式的 OneBot 配置没有正确建立连接。",
            next = "修复 OneBot 连接",
            actionLabel = "修复 OneBot",
            action = "bridge"
        )
        s.qqStalledCount > 0 || s.snowlumaQqExited -> SituationData(
            label = "需检查",
            title = "QQ 运行状态异常",
            detail = s.qqAlertReason.ifBlank { s.mainQqReason.ifBlank { "QQ 进程没有处于预期状态。" } },
            next = "前往运维查看日志并处理",
            actionLabel = "打开运维",
            action = "operations"
        )
        s.qqEngine == "snowluma" && s.stackRunning && s.oneBotConnected == 0 &&
            (s.mainQqState == "starting" || s.mainQqReason.contains("登录") || normalizedOneBotReason(s).contains("登录")) -> SituationData(
            label = "待确认",
            title = "SnowLuma 已运行，QQ 等待登录",
            detail = normalizedOneBotReason(s),
            next = "打开扫码桌面，确认 QQ 登录状态",
            actionLabel = "QQ 扫码登录",
            action = "login"
        )
        !s.stackRunning && s.coreReady -> SituationData(
            label = "待启动",
            title = "运行环境已就绪",
            detail = "核心组件和运行资源已经准备完成，目前服务处于停止状态。",
            next = "启动全部服务",
            actionLabel = "启动全部服务",
            action = "start"
        )
        s.stackRunning && s.oneBotConnected > 0 -> SituationData(
            label = "正常",
            title = "所有关键服务已连接",
            detail = "${qqEngineLabel(s)} 在线，OneBot 已建立 ${s.oneBotConnected} 个连接。",
            next = "现在无需操作"
        )
        s.stackRunning -> SituationData(
            label = "等待连接",
            title = "服务已启动",
            detail = normalizedOneBotReason(s),
            next = if (s.qqEngine == "snowluma") "等待 SnowLuma 建立 OneBot 连接" else "等待 NapCat 建立 OneBot 连接"
        )
        else -> SituationData(
            label = "检查中",
            title = "正在检查运行环境",
            detail = "控制中心正在确认 AstrBot、QQ 与 OneBot 的状态。",
            next = "等待状态刷新"
        )
    }
}

private fun greetingTitle(status: RuntimeStatus): String = when (status.health) {
    RuntimeHealth.HEALTHY -> "运行正常"
    RuntimeHealth.WORKING -> "正在准备服务"
    RuntimeHealth.ATTENTION -> if (status.qqNeedsLogin) "等待 QQ 登录" else "有一项需要处理"
    RuntimeHealth.STOPPED -> "服务已停止"
    RuntimeHealth.UNKNOWN -> "正在读取状态"
}

private fun normalizedOneBotReason(status: RuntimeStatus): String {
    val raw = status.oneBotReason.trim()
    if (status.qqEngine == "snowluma" && raw.contains("NapCat", ignoreCase = true)) {
        return when {
            !status.snowlumaUp -> "SnowLuma 未运行"
            status.qqNeedsLogin -> "SnowLuma 已运行，等待 QQ 登录"
            status.snowlumaQqExited -> "SnowLuma 已运行，但 QQ 进程已退出"
            else -> "SnowLuma 已运行，正在等待 OneBot 连接"
        }
    }
    if (status.qqEngine == "napcat" && raw.contains("SnowLuma", ignoreCase = true)) {
        return when {
            !status.napcatUp -> "NapCat 未运行"
            status.qqNeedsLogin -> "NapCat 已运行，等待 QQ 登录"
            else -> "NapCat 已运行，正在等待 OneBot 连接"
        }
    }
    return raw.ifBlank {
        when {
            status.oneBotConnected > 0 -> "OneBot 已连接"
            status.activeQqUp -> "${qqEngineLabel(status)} 已运行，正在等待 OneBot 连接"
            else -> "等待 QQ 运行方式启动"
        }
    }
}

private fun astrbotState(status: RuntimeStatus): String = when {
    status.astrbotUp && status.astrbotWebReady -> "正常"
    status.astrbotUp -> "启动中"
    status.astrbotReady -> "已停止"
    else -> "未就绪"
}

private fun astrbotDetail(status: RuntimeStatus): String = if (status.astrbotPort > 0) "WebUI 端口 ${status.astrbotPort}" else "机器人主服务"
private fun oneBotState(status: RuntimeStatus): String = when {
    status.oneBotConnected > 0 -> "已连接"
    status.oneBotAuthFailed -> "鉴权异常"
    status.oneBotListen -> "等待连接"
    else -> "未连接"
}
private fun oneBotDetail(status: RuntimeStatus): String = if (status.oneBotConnected > 0) "${status.oneBotConnected} 个反向连接" else normalizedOneBotReason(status)
private fun qqEngineLabel(status: RuntimeStatus): String = if (status.qqEngine == "snowluma") "SnowLuma" else "NapCat"
private fun qqStateLabel(status: RuntimeStatus): String = when {
    status.qqOnline -> "在线"
    status.qqNeedsLogin -> "需要登录"
    status.qqEngine == "snowluma" && status.oneBotConnected == 0 &&
        (status.mainQqReason.contains("登录") || normalizedOneBotReason(status).contains("登录")) -> "待登录"
    status.qqStartingCount > 0 -> "启动中"
    status.qqStalledCount > 0 || status.snowlumaQqExited -> "异常"
    status.mainQqState == "stopped" -> "已停止"
    else -> status.mainQqState.replace('_', ' ').ifBlank { "未知" }
}

private fun navGlyph(destination: ControlDestination, selected: Boolean): String = when (destination) {
    ControlDestination.OVERVIEW -> if (selected) "◉" else "◎"
    ControlDestination.OPERATIONS -> if (selected) "≈" else "⌁"
    ControlDestination.CONSOLE -> if (selected) "▣" else "▢"
}

private fun loginPhaseTitle(phase: String): String = when (phase) {
    "installing" -> "正在准备原生截图组件"
    "starting" -> "正在唤醒 QQ 登录窗口"
    "capturing" -> "正在读取 QQ 二维码画面"
    "ready" -> "二维码画面已就绪"
    "desktop-starting" -> "正在启动完整 QQ 桌面"
    "desktop" -> "完整 QQ 桌面已就绪"
    "rendering" -> "正在启动完整 QQ 桌面"
    "complete" -> "QQ 登录已完成"
    "failed" -> "QQ 登录画面准备失败"
    else -> "正在准备 QQ 登录画面"
}

private fun loginNextStep(phase: String): String = when (phase) {
    "installing" -> "等待原生截图组件安装完成"
    "starting" -> "等待 QQ 登录窗口出现"
    "capturing" -> "等待第一张二维码截图"
    "desktop-starting" -> "等待完整 QQ 桌面启动"
    "rendering" -> "等待完整 QQ 桌面启动"
    "complete" -> "返回 QQ 控制台"
    "failed" -> "查看原因后重新连接"
    else -> "等待 QQ 登录画面准备完成"
}
