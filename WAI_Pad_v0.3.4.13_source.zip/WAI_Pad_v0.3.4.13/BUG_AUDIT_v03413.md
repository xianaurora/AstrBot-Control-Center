# WAI Pad v0.3.4.13 - stuck bootstrap audit

Observed runtime symptom:
- tunnel connected
- companion remains in background initialization
- bootstrap log repeats `channel request: timeout`, `channel is not opened`, `session is down`

Root cause:
v0.3.4.12 detached bootstrap from the monitor thread, but still passed the same long-lived JSch `Session` that owns local port forwards into `RemoteBootstrap` and remote probes. A failed/slow exec channel could leave that Session half-alive: forwarding state appeared connected while later channel opens failed. Reusing the poisoned Session caused repeated bootstrap failures.

Fix:
1. Forwarding Session is forwarding-only.
2. Bootstrap, remote API probe and Jupyter detection use disposable control Sessions.
3. Only one extra control Session runs at a time.
4. Control Sessions have a whole-transaction watchdog and are always disconnected.
5. Repeated control failures back off; after repeated failures only the SSH tunnel is recycled, never ComfyUI.
6. Manual reinitialize is blocked only while a bootstrap is actually busy, not merely because phase=repairing.
