# WAI Pad v0.3.4.13 验证

- TunnelService forwarding session 不再传入 `SshClient.exec` / SFTP / `RemoteBootstrap.installAndStart`。
- bootstrap / remote health / Jupyter traffic 均使用独立短连接并 finally disconnect。
- 控制通道使用单线程 executor，管理连接不会并发挤压 SSH gateway。
- repairing 且 bootstrapBusy=false 时，手动“重新初始化”会真正发起新控制连接。
- Kotlin 语言级检查、Python py_compile、Shell bash -n、JS node --check 通过。
- server 与 APK assets 五个 companion 文件逐字节一致。
- 真实 Android SDK/Gradle 编译仍以 GitHub Actions `:app:assembleDebug` 为最终验证。
