package com.waipad.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.jcraft.jsch.Session
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

class TunnelService : Service() {
    companion object {
        const val CHANNEL_ID = "wai_pad_tunnel"
        @Volatile var connected = false
        @Volatile var bridgeReady = false
        @Volatile var stackReady = false
        @Volatile var bootstrapBusy = false
        @Volatile var phase = "idle"
        @Volatile var message = "未连接"
        @Volatile var lastBootstrapOutput = ""
        @Volatile var lastConnectedAt = 0L
        @Volatile var jupyterForwarded = false
        @Volatile var jupyterRemotePort = 0
        @Volatile private var activeSession: Session? = null
        @Volatile private var serviceInstance: TunnelService? = null
        private val sessionGuard = Any()

        fun forceReconnect(reason: String = "请求重建连接") {
            bridgeReady = false; stackReady = false
            phase = "reconnecting"; message = reason
            serviceInstance?.cancelControlSession()
            val s = synchronized(sessionGuard) { activeSession }
            try { s?.disconnect() } catch (_: Exception) {}
        }

        fun start(context: Context) {
            val i = Intent(context, TunnelService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
        fun stop(context: Context) = context.stopService(Intent(context, TunnelService::class.java))
    }

    private val running = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()
    // One serialized control executor: at most one extra SSH TCP connection besides the forwarding
    // session. This avoids hitting provider/gateway connection limits during recovery storms.
    private val controlExec = Executors.newSingleThreadExecutor()
    private val bootstrapRunning = AtomicBoolean(false)
    private val remoteProbeRunning = AtomicBoolean(false)
    private val jupyterProbeRunning = AtomicBoolean(false)
    @Volatile private var ownedSession: Session? = null
    @Volatile private var currentControlSession: Session? = null
    @Volatile private var bootstrapRetryNeeded = true
    @Volatile private var lastBootstrapAttempt = 0L
    @Volatile private var nextBootstrapAttemptAt = 0L
    @Volatile private var bootstrapFailureCount = 0

    override fun onCreate() {
        super.onCreate()
        serviceInstance = this
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "WAI Pad 服务器连接", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        startForeground(17, notification("准备连接 AutoDL…"))
    }

    private fun notification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("WAI Pad").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).build()
    }

    private fun notifyStatus(text: String) {
        try { getSystemService(NotificationManager::class.java).notify(17, notification(text)) } catch (_: Exception) {}
    }

    private data class Health(val api: Boolean, val stack: Boolean, val detail: String = "")

    private fun localHealth(): Health {
        return try {
            val c = URL("http://127.0.0.1:16027/v1/health").openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 2200; c.readTimeout = 2200; c.setRequestProperty("Connection", "close")
                val code = c.responseCode
                if (code !in 200..299) {
                    Health(false, false, "HTTP $code")
                } else {
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    val o = JSONObject(text)
                    Health(true, o.optBoolean("ready", false), o.optString("detail", ""))
                }
            } finally { c.disconnect() }
        } catch (e: Exception) { Health(false, false, e.message ?: "") }
    }

    /**
     * The forwarding session is intentionally NEVER used for exec/SFTP. Some SSH gateways can
     * leave a JSch session half-alive after an exec channel request times out: local forwards keep
     * looking connected while every later channel fails with "channel is not opened/session is
     * down". All control-plane work therefore gets its own short-lived SSH TCP session.
     */
    private fun cancelControlSession() {
        val s = currentControlSession
        currentControlSession = null
        try { s?.disconnect() } catch (_: Exception) {}
    }

    private fun <T> withControlSession(maxLifetimeMs: Long = 120_000L, block: (Session) -> T): T {
        val control = SshClient.connect(SecurePrefs(this))
        currentControlSession = control
        // JSch SFTP has no reliable per-transfer timeout. A disposable-session watchdog makes the
        // whole control transaction bounded even if an SFTP/exec channel stalls inside JSch.
        val watchdog = Thread({
            try {
                Thread.sleep(maxLifetimeMs)
                if (currentControlSession === control) {
                    try { control.disconnect() } catch (_: Exception) {}
                }
            } catch (_: InterruptedException) {}
        }, "wai-control-watchdog").apply { isDaemon = true; start() }
        return try { block(control) }
        finally {
            watchdog.interrupt()
            if (currentControlSession === control) currentControlSession = null
            try { control.disconnect() } catch (_: Exception) {}
        }
    }

    private fun scheduleRemoteApiProbe(tunnel: Session) {
        if (!remoteProbeRunning.compareAndSet(false, true)) return
        controlExec.submit {
            try {
                val remoteReady = withControlSession(30_000L) { control ->
                    SshClient.exec(control, "curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health >/dev/null 2>&1", 8_000).first == 0
                }
                if (remoteReady && running.get() && ownedSession === tunnel && tunnel.isConnected && !localHealth().api) {
                    forceReconnect("16027 本地转发失效，自动重建 SSH 隧道")
                }
            } catch (_: Exception) {
                // A failed control connection must never poison or tear down a healthy forward.
            } finally { remoteProbeRunning.set(false) }
        }
    }

    private fun scheduleJupyterProbe(tunnel: Session) {
        if (!jupyterProbeRunning.compareAndSet(false, true)) return
        controlExec.submit {
            try {
                val jp = withControlSession(35_000L) { control ->
                    val cmd = "for p in 8888 8889 8890 8891 8080; do if curl -fsS --max-time 1 http://127.0.0.1:\$p/ >/dev/null 2>&1 || curl -fsS --max-time 1 http://127.0.0.1:\$p/lab >/dev/null 2>&1; then echo \$p; exit 0; fi; done; exit 1"
                    val r = SshClient.exec(control, cmd, 12_000)
                    r.second.trim().lineSequence().firstOrNull()?.toIntOrNull() ?: 0
                }
                if (jp > 0 && running.get() && ownedSession === tunnel && tunnel.isConnected) {
                    jupyterRemotePort = jp
                    try { tunnel.setPortForwardingL(18888, "127.0.0.1", jp); jupyterForwarded = true }
                    catch (_: Exception) { jupyterForwarded = false }
                }
            } catch (_: Exception) {
                jupyterRemotePort = 0; jupyterForwarded = false
            } finally { jupyterProbeRunning.set(false) }
        }
    }

    private fun publishSession(s: Session) {
        ownedSession = s
        synchronized(sessionGuard) { activeSession = s }
    }

    private fun disconnectOwned() {
        val s = ownedSession
        ownedSession = null
        synchronized(sessionGuard) { if (activeSession === s) activeSession = null }
        try { s?.disconnect() } catch (_: Exception) {}
    }

    /**
     * Server installation/recovery is deliberately detached from the tunnel monitor.  A slow
     * service lock, SFTP update, or Panel/Comfy repair must never freeze the SSH connection state.
     */
    private fun triggerBootstrap(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && (now < nextBootstrapAttemptAt || now - lastBootstrapAttempt < 5_000L)) return
        if (!bootstrapRunning.compareAndSet(false, true)) return
        lastBootstrapAttempt = now
        bootstrapBusy = true
        controlExec.submit {
            try {
                // Never reuse ownedSession here. RemoteBootstrap may open several exec/SFTP
                // channels; a timeout is isolated to this disposable control connection.
                val out = withControlSession(130_000L) { control -> RemoteBootstrap.installAndStart(this, control) }
                lastBootstrapOutput = out.takeLast(16_000)
                bootstrapRetryNeeded = out.contains("WAI_PAD_UPDATE_BUSY=1") || out.contains("WAI_PAD_UPDATE_DEFERRED_ACTIVE_JOB=1")
                bootstrapFailureCount = 0
                nextBootstrapAttemptAt = if (bootstrapRetryNeeded) System.currentTimeMillis() + 20_000L else Long.MAX_VALUE
            } catch (e: Exception) {
                bootstrapRetryNeeded = true
                bootstrapFailureCount = (bootstrapFailureCount + 1).coerceAtMost(8)
                val delay = min(120_000L, 10_000L * (1L shl min(3, bootstrapFailureCount - 1)))
                nextBootstrapAttemptAt = System.currentTimeMillis() + delay
                val detail = e.message ?: e.javaClass.simpleName
                lastBootstrapOutput = (lastBootstrapOutput + "\n后台初始化控制通道失败（${bootstrapFailureCount}）：$detail；${delay / 1000}s 后重试").takeLast(16_000)
                // If the companion is still unavailable and several independent SSH control
                // connections have failed, recycle only the forwarding SSH TCP session. This
                // clears gateway half-open state without touching any remote Comfy process.
                if (!bridgeReady && bootstrapFailureCount >= 3) {
                    forceReconnect("后台 SSH 控制通道连续失败，重建隧道连接")
                }
            } finally {
                bootstrapBusy = false
                bootstrapRunning.set(false)
            }
        }
    }

    private fun publishHealth(h: Health) {
        bridgeReady = h.api
        stackReady = h.stack
        when {
            h.api && h.stack -> { phase = "ready"; message = if (jupyterForwarded) "已连接 · WAI/Comfy/Jupyter 正常" else "已连接 · WAI/Comfy 正常" }
            h.api -> { phase = "degraded"; message = "已连接 · companion 正常，Comfy/Panel 后台恢复中" }
            else -> { phase = "repairing"; message = "隧道已连接 · companion 后台启动中" }
        }
        notifyStatus(message)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running.compareAndSet(false, true)) exec.submit { loop() }
        return START_STICKY
    }

    private fun loop() {
        var reconnectFailures = 0
        while (running.get()) {
            val p = SecurePrefs(this)
            if (!p.hasServer()) {
                connected = false; bridgeReady = false; stackReady = false; phase = "setup"
                message = "首次使用：请在设置里填写一次 SSH 密码"
                notifyStatus("等待首次连接设置")
                Thread.sleep(3000); continue
            }
            try {
                phase = "connecting"; message = "正在连接 AutoDL…"; connected = false; bridgeReady = false; stackReady = false
                notifyStatus(message)
                disconnectOwned()
                val s = SshClient.connect(p)
                publishSession(s)
                // Only publish a connection after all required local forwards succeeded.
                s.setPortForwardingL(16017, "127.0.0.1", 6017)
                s.setPortForwardingL(16006, "127.0.0.1", 6006)
                s.setPortForwardingL(16027, "127.0.0.1", 6027)
                connected = true; lastConnectedAt = System.currentTimeMillis(); reconnectFailures = 0
                jupyterRemotePort = 0; jupyterForwarded = false
                bootstrapFailureCount = 0; nextBootstrapAttemptAt = 0L

                // FIRST publish whatever is already reachable.  Never wait synchronously for install.
                publishHealth(localHealth())
                bootstrapRetryNeeded = true
                triggerBootstrap(force = true)

                var nextRemoteProbeAt = 0L
                var jupyterChecked = false
                while (running.get() && s.isConnected) {
                    val h = localHealth()
                    if (!h.api) {
                        bridgeReady = false; stackReady = false
                        phase = "repairing"
                        message = when {
                            bootstrapBusy -> "隧道已连接 · companion 正在后台初始化"
                            bootstrapFailureCount > 0 -> "隧道已连接 · 后台 SSH 控制通道重试中"
                            else -> "隧道已连接 · companion 后台启动中"
                        }
                        notifyStatus(message)

                        val now = System.currentTimeMillis()
                        // Probe remote API at a controlled cadence.  Remote healthy + local dead means
                        // the port forward itself is stale; only that condition warrants SSH rebuild.
                        if (now >= nextRemoteProbeAt) {
                            nextRemoteProbeAt = now + 12_000L
                            scheduleRemoteApiProbe(s)
                        }
                        triggerBootstrap()
                    } else {
                        nextRemoteProbeAt = 0L
                        bridgeReady = true; stackReady = h.stack
                        if (!jupyterChecked && h.stack && !bootstrapBusy) {
                            jupyterChecked = true
                            scheduleJupyterProbe(s)
                        }
                        publishHealth(h)
                        // Retry only deferred/busy APK updates. Core degradation is guard.sh's job.
                        if (bootstrapRetryNeeded) triggerBootstrap()
                    }
                    Thread.sleep(3500)
                }
            } catch (e: Exception) {
                disconnectOwned()
                connected = false; bridgeReady = false; stackReady = false; jupyterForwarded = false; phase = "reconnecting"
                message = "连接中断，正在自动重连：${e.message ?: "未知错误"}"
                notifyStatus("连接中断 · 自动重连中")
                reconnectFailures++
                val delay = min(30_000L, 2_500L * (1L shl min(3, reconnectFailures - 1)))
                Thread.sleep(delay)
            }
        }
    }

    override fun onDestroy() {
        running.set(false)
        cancelControlSession()
        disconnectOwned()
        connected = false; bridgeReady = false; stackReady = false; bootstrapBusy = false; jupyterForwarded = false; phase = "stopped"; message = "已停止"
        exec.shutdownNow(); controlExec.shutdownNow()
        if (serviceInstance === this) serviceInstance = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
