#!/usr/bin/env bash
set -Eeuo pipefail
BASE=/root/WAI_Pad
RUNTIME="$BASE/runtime"
mkdir -p "$RUNTIME"
log(){ echo "[$(date '+%F %T')] $*"; }
health(){ curl -fsS --max-time 3 "$1" >/dev/null 2>&1; }
active_job(){
  if curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health 2>/dev/null | grep -Eq '"current"[[:space:]]*:[[:space:]]*"[^" ]+'; then return 0; fi
  [ -f "$RUNTIME/jobs_state.json" ] && grep -Eq '"status"[[:space:]]*:[[:space:]]*"(claimed|submitting|running|repairing)"' "$RUNTIME/jobs_state.json" 2>/dev/null
}
PY="/root/venv/bin/python"; [ -x "$PY" ] || PY="$(command -v python3 || command -v python)"

# All file/service mutations share the same lock. RemoteBootstrap may already own fd 9.
if [ "${WAI_PAD_LOCK_HELD:-0}" != "1" ]; then
  exec 9>"$RUNTIME/service.lock"
  flock -w 20 9 || { log '[WARN] 服务器维护锁繁忙；companion 初始化交给后台重试'; exit 75; }
fi

log '=== WAI Pad v0.3.4.13 快速初始化 ==='
if ! command -v wai >/dev/null 2>&1; then
  log '[ERROR] 找不到 wai 命令；不会改动你的现有环境。'; exit 2
fi

# IMPORTANT: make the companion API available first. Panel/Comfy recovery must never block the
# tablet for minutes. The guard repairs the core asynchronously after this script returns.
"$PY" -m py_compile "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py"
bash -n "$BASE/bootstrap.sh" "$BASE/guard.sh"
CODE_HASH="$(cat "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py" "$BASE/guard.sh" "$BASE/bootstrap.sh" | sha256sum | awk '{print $1}')"
OLD_HASH="$(cat "$RUNTIME/code.sha256" 2>/dev/null || true)"
API_UP=0; health http://127.0.0.1:6027/v1/health && API_UP=1

if [ "$API_UP" -eq 1 ] && [ "$CODE_HASH" = "$OLD_HASH" ]; then
  log '[任务服务] 已运行且代码未变化，保留当前任务/队列。'
elif [ "$API_UP" -eq 1 ] && active_job; then
  log '[任务服务] 仍有活动任务；延后 companion 重启。'
else
  if pgrep -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1; then
    log '[任务服务] 安全重启 companion（不触碰 ComfyUI）'
    pkill -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' || true
    sleep 1
  fi
  nohup "$PY" "$BASE/job_api.py" 9>&- >>"$RUNTIME/job_api.nohup.log" 2>&1 </dev/null &
  for _ in $(seq 1 14); do health http://127.0.0.1:6027/v1/health && break; sleep 1; done
  if ! health http://127.0.0.1:6027/v1/health; then
    log '[ERROR] WAI Pad companion 未启动；不会重启 ComfyUI。'
    tail -60 "$RUNTIME/job_api.nohup.log" 2>/dev/null || true; exit 3
  fi
  printf '%s' "$CODE_HASH" > "$RUNTIME/code.sha256"
fi

# A running shell never reloads a replaced guard.sh. Stop only the old guard if its script changed.
GUARD_HASH="$(sha256sum "$BASE/guard.sh" | awk '{print $1}')"
OLD_GUARD_HASH="$(cat "$RUNTIME/guard.sha256" 2>/dev/null || true)"
if pgrep -f '^bash /root/WAI_Pad/guard.sh daemon$' >/dev/null 2>&1 && [ "$GUARD_HASH" != "$OLD_GUARD_HASH" ]; then
  log '[守护] guard 脚本已更新，仅重启 guard 自身'
  pkill -f '^bash /root/WAI_Pad/guard.sh daemon$' || true
  sleep 1
fi
printf '%s' "$GUARD_HASH" > "$RUNTIME/guard.sha256"

# Release the maintenance lock BEFORE spawning any long-lived/background shell. Otherwise fd 9 can
# be inherited and make the lock look permanently busy on some shells/process trees.
flock -u 9 2>/dev/null || true
exec 9>&- 2>/dev/null || true

if ! pgrep -f '^bash /root/WAI_Pad/guard.sh daemon$' >/dev/null 2>&1; then
  log '[守护] 启动自动检测与修复'
  nohup bash "$BASE/guard.sh" daemon >>"$BASE/guard.nohup.log" 2>&1 </dev/null &
fi

panel_ok=0; comfy_ok=0
health http://127.0.0.1:6017/api/health && panel_ok=1
health http://127.0.0.1:6006/system_stats && comfy_ok=1
if [ "$panel_ok" -eq 0 ] || [ "$comfy_ok" -eq 0 ]; then
  if active_job; then
    log "[核心] 检测到活动任务；Panel=$panel_ok Comfy=$comfy_ok，后台守护只做安全恢复。"
  else
    log "[核心] Panel=$panel_ok Comfy=$comfy_ok；已交给 guard daemon 后台恢复，不阻塞平板启动。"
  fi
fi

printf '[状态] Panel: '; [ "$panel_ok" -eq 1 ] && echo OK || echo DEGRADED
printf '[状态] ComfyUI: '; [ "$comfy_ok" -eq 1 ] && echo OK || echo DEGRADED
printf '[状态] Qwen: '; health http://127.0.0.1:8011/v1/models && echo OK || echo '休眠/离线（生成时可回退轻量模式）'
printf '[状态] WAI Pad API: '; curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health || true; echo
log '[隐私] 参考图由任务所有权管理；成图仅在本机确认后清理远端，清理失败会持续重试。'
log '[完成] companion 已可用；Panel/Comfy 如为 DEGRADED，会在后台恢复，不再卡住 App 启动。'
