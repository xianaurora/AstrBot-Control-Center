# WAI Pad v0.3.4.13

## SSH 控制通道隔离与初始化重试修复

- 长连接 SSH session 现在只做本地端口转发，不再执行 exec/SFTP。
- 自动 bootstrap、远端 6027 探测、Jupyter 探测全部使用独立短生命周期 SSH 控制连接。
- 控制连接失败只影响本次后台维护，不再拖死仍可用的转发隧道。
- 控制连接失败采用退避重试；连续失败时只重建 SSH TCP 隧道，不触碰 ComfyUI。
- 控制类 SSH 操作串行化，避免恢复风暴同时创建多条额外 SSH 连接。
- “重新初始化”仅在 bootstrap 真正运行时抑制重复；repairing 但后台任务已失败/退避时可立即手动重试。
- Jupyter 探测延后到核心 stack ready 且 bootstrap 空闲。

版本：0.3.4.13 / versionCode 19
