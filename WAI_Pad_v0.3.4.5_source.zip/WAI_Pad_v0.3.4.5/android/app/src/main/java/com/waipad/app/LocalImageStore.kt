package com.waipad.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LocalImageStore(private val context: Context) {
    private val dir = File(context.filesDir, "wai_images").apply { mkdirs() }
    private val metaDir = File(context.filesDir, "wai_images_meta").apply { mkdirs() }

    private fun atomicWrite(file: File, bytes: ByteArray) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        FileOutputStream(tmp).use { out ->
            out.write(bytes)
            out.flush()
            out.fd.sync()
        }
        if (!tmp.renameTo(file)) {
            file.delete()
            if (!tmp.renameTo(file)) throw IllegalStateException("本地文件落盘失败: ${file.name}")
        }
    }

    private fun atomicWriteText(file: File, text: String) = atomicWrite(file, text.toByteArray(Charsets.UTF_8))

    private fun findByJobId(jobId: String): JSONObject? {
        if (jobId.isBlank()) return null
        metaDir.listFiles()?.filter { it.isFile && it.name.endsWith(".json") }?.forEach { mf ->
            try {
                val m = JSONObject(mf.readText(Charsets.UTF_8))
                if (m.optString("job_id") == jobId) {
                    val name = m.optString("name")
                    val f = resolve(name)
                    if (f != null) return decorate(f, m).put("deduplicated", true)
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun exportDurable(bytes: ByteArray, mime: String, displayName: String): JSONObject {
        // Android 10+ uses MediaStore, so the image lives in the tablet's local Pictures/WAI Pad album
        // and survives uninstall/reinstall. Nothing is uploaded to any cloud service.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Images.Media.MIME_TYPE, mime)
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WAI Pad")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建本机相册文件")
            try {
                context.contentResolver.openOutputStream(uri, "w")?.use { out ->
                    out.write(bytes); out.flush()
                } ?: throw IllegalStateException("无法写入本机相册")
                values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                return JSONObject().put("durable_local", true).put("durable_uri", uri.toString()).put("album", "Pictures/WAI Pad")
            } catch (e: Exception) {
                try { context.contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                throw e
            }
        }

        // Android 8/9 fallback. If shared storage is not writable, app-private storage is still kept.
        return try {
            val album = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "WAI Pad").apply { mkdirs() }
            val out = File(album, displayName)
            FileOutputStream(out).use { f -> f.write(bytes); f.flush(); f.fd.sync() }
            JSONObject().put("durable_local", true).put("durable_path", out.absolutePath).put("album", "Pictures/WAI Pad")
        } catch (e: Exception) {
            JSONObject().put("durable_local", false).put("durable_error", e.message ?: "shared storage unavailable")
        }
    }

    fun saveBytes(bytes: ByteArray, mime: String, suggested: String = "wai", metadata: JSONObject = JSONObject()): JSONObject {
        require(bytes.isNotEmpty()) { "图片内容为空" }
        val existing = findByJobId(metadata.optString("job_id"))
        if (existing != null) {
            if (existing.optBoolean("durable_local", false)) return existing
            val existingFile = resolve(existing.optString("name"))
            if (existingFile != null) {
                val fixed = try { exportDurable(existingFile.readBytes(), mime, existingFile.name) }
                    catch (e: Exception) { JSONObject().put("durable_local", false).put("durable_error", e.message ?: "album export failed") }
                val m = readMeta(existingFile)
                    .put("durable_local", fixed.optBoolean("durable_local", false))
                    .put("album", fixed.optString("album", ""))
                    .put("durable_uri", fixed.optString("durable_uri", ""))
                    .put("durable_path", fixed.optString("durable_path", ""))
                    .put("durable_error", fixed.optString("durable_error", ""))
                atomicWriteText(File(metaDir, existingFile.name + ".json"), m.toString())
                return decorate(existingFile, m).put("deduplicated", true)
            }
            return existing
        }
        val ext = when {
            mime.contains("jpeg", true) -> "jpg"
            mime.contains("webp", true) -> "webp"
            else -> "png"
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val safe = suggested.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(48).ifBlank { "wai" }
        val f = File(dir, "${safe}_${stamp}.$ext")
        atomicWrite(f, bytes)

        val durable = try { exportDurable(bytes, mime, f.name) }
        catch (e: Exception) { JSONObject().put("durable_local", false).put("durable_error", e.message ?: "album export failed") }

        val m = JSONObject(metadata.toString())
            .put("name", f.name)
            .put("size", f.length())
            .put("time", f.lastModified())
            .put("favorite", metadata.optBoolean("favorite", false))
            .put("storage", "app_private_plus_local_album")
            .put("cloud_sync", false)
            .put("durable_local", durable.optBoolean("durable_local", false))
            .put("album", durable.optString("album", ""))
            .put("durable_uri", durable.optString("durable_uri", ""))
            .put("durable_path", durable.optString("durable_path", ""))
            .put("durable_error", durable.optString("durable_error", ""))
        atomicWriteText(File(metaDir, f.name + ".json"), m.toString())
        return decorate(f, m)
    }

    fun saveDataUrl(dataUrl: String, suggested: String = "wai", metadata: JSONObject = JSONObject()): JSONObject {
        val comma = dataUrl.indexOf(',')
        require(comma > 0) { "图片数据无效" }
        val header = dataUrl.substring(0, comma)
        val mime = when {
            header.contains("image/jpeg") -> "image/jpeg"
            header.contains("image/webp") -> "image/webp"
            else -> "image/png"
        }
        val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
        return saveBytes(bytes, mime, suggested, metadata)
    }

    private fun readMeta(f: File): JSONObject {
        val mf = File(metaDir, f.name + ".json")
        return try { if (mf.exists()) JSONObject(mf.readText(Charsets.UTF_8)) else JSONObject() } catch (_: Exception) { JSONObject() }
    }

    private fun decorate(f: File, m: JSONObject = readMeta(f)): JSONObject {
        return JSONObject(m.toString())
            .put("name", f.name)
            .put("size", f.length())
            .put("time", f.lastModified())
            .put("url", "https://app.local/local-images/${f.name}")
    }

    fun list(): JSONArray {
        val a = JSONArray()
        dir.listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") }?.sortedByDescending { it.lastModified() }?.take(2000)?.forEach { f ->
            a.put(decorate(f))
        }
        return a
    }

    fun resolve(name: String): File? {
        val clean = File(name).name
        if (clean != name || clean.endsWith(".tmp")) return null
        val f = File(dir, clean)
        return if (f.exists() && f.isFile && f.parentFile == dir) f else null
    }

    fun metadata(name: String): JSONObject {
        val f = resolve(name) ?: return JSONObject().put("error", "not found")
        return decorate(f)
    }

    fun toggleFavorite(name: String): JSONObject {
        val f = resolve(name) ?: return JSONObject().put("error", "not found")
        val m = readMeta(f)
        m.put("favorite", !m.optBoolean("favorite", false))
        atomicWriteText(File(metaDir, f.name + ".json"), m.toString())
        return decorate(f, m)
    }

    fun hasJob(jobId: String): Boolean {
        if (jobId.isBlank()) return false
        return dir.listFiles()?.filter { it.isFile }?.any { f ->
            try {
                val m = readMeta(f)
                m.optString("job_id", "") == jobId && m.optBoolean("durable_local", false)
            } catch (_: Exception) { false }
        } ?: false
    }

    fun delete(name: String): Boolean {
        val f = resolve(name) ?: return false
        File(metaDir, f.name + ".json").delete()
        // Deleting in WAI Pad removes only the app copy. The durable Pictures/WAI Pad copy remains
        // unless the user deletes it from the system gallery/file manager, preventing accidental loss.
        return f.delete()
    }

    private fun safeImportedName(displayName: String): String {
        val clean = File(displayName).name.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(120).ifBlank { "recovered.png" }
        val base = clean.substringBeforeLast('.', clean)
        val ext = clean.substringAfterLast('.', "png")
        var candidate = clean
        var n = 1
        while (File(dir, candidate).exists()) {
            candidate = "${base}_imported_${n++}.$ext"
        }
        return candidate
    }

    /**
     * Rebuild the app-private gallery from the tablet's durable local album.
     * This is intentionally local-only: MediaStore/Pictures -> app private files.
     * It is used after a signing migration or reinstall and never uploads anything.
     */
    fun importFromAlbum(limit: Int = 2000): JSONObject {
        var imported = 0
        var skipped = 0
        var failed = 0
        val errors = JSONArray()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE,
                MediaStore.Images.Media.RELATIVE_PATH,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED
            )
            val selection = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?"
            val args = arrayOf("${Environment.DIRECTORY_PICTURES}/WAI Pad%")
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, selection, args,
                "${MediaStore.Images.Media.DATE_ADDED} ASC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val pathCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                while (c.moveToNext() && imported + skipped + failed < limit) {
                    val displayName = c.getString(nameCol) ?: continue
                    val id = c.getLong(idCol)
                    val uri = android.content.ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    val already = metaDir.listFiles()?.any { mf ->
                        try { JSONObject(mf.readText(Charsets.UTF_8)).optString("durable_uri") == uri.toString() }
                        catch (_: Exception) { false }
                    } ?: false
                    if (already) { skipped++; continue }
                    try {
                        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: throw IllegalStateException("无法读取 $displayName")
                        if (bytes.isEmpty()) throw IllegalStateException("$displayName 内容为空")
                        val targetName = safeImportedName(displayName)
                        val f = File(dir, targetName)
                        atomicWrite(f, bytes)
                        val m = JSONObject()
                            .put("name", targetName)
                            .put("size", f.length())
                            .put("time", f.lastModified())
                            .put("favorite", false)
                            .put("storage", "app_private_plus_local_album")
                            .put("cloud_sync", false)
                            .put("durable_local", true)
                            .put("durable_uri", uri.toString())
                            .put("album", c.getString(pathCol) ?: "Pictures/WAI Pad")
                            .put("source_display_name", displayName)
                            .put("source_mime", c.getString(mimeCol) ?: "image/png")
                            .put("source_size", c.getLong(sizeCol))
                            .put("imported_from_album", true)
                            .put("recovered", true)
                        atomicWriteText(File(metaDir, targetName + ".json"), m.toString())
                        imported++
                    } catch (e: Exception) {
                        failed++
                        if (errors.length() < 20) errors.put("$displayName: ${e.message ?: "读取失败"}")
                    }
                }
            }
        } else {
            val album = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "WAI Pad")
            val all = if (album.exists()) album.walkTopDown().filter { it.isFile && it.extension.lowercase() in setOf("png","jpg","jpeg","webp") }.take(limit).toList() else emptyList()
            for (src in all) {
                try {
                    if (File(dir, src.name).exists()) { skipped++; continue }
                    val f = File(dir, safeImportedName(src.name))
                    atomicWrite(f, src.readBytes())
                    val m = JSONObject().put("name", f.name).put("size", f.length()).put("time", f.lastModified())
                        .put("favorite", false).put("storage", "app_private_plus_local_album").put("cloud_sync", false)
                        .put("durable_local", true).put("durable_path", src.absolutePath).put("album", "Pictures/WAI Pad")
                        .put("source_display_name", src.name).put("imported_from_album", true).put("recovered", true)
                    atomicWriteText(File(metaDir, f.name + ".json"), m.toString())
                    imported++
                } catch (e: Exception) { failed++; if (errors.length() < 20) errors.put("${src.name}: ${e.message}") }
            }
        }
        return JSONObject()
            .put("ok", failed == 0)
            .put("imported", imported)
            .put("skipped", skipped)
            .put("failed", failed)
            .put("errors", errors)
            .put("source", "Pictures/WAI Pad")
            .put("cloud_sync", false)
    }

    fun stats(): JSONObject {
        val files = dir.listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") }.orEmpty()
        val used = files.sumOf { it.length() }
        return JSONObject()
            .put("count", files.size)
            .put("used_bytes", used)
            .put("bytes", used)
            .put("free_bytes", context.filesDir.usableSpace)
            .put("path_hint", "本机 Pictures/WAI Pad + App 私有索引")
            .put("cloud_sync", false)
            .put("survives_uninstall", Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
    }
}
