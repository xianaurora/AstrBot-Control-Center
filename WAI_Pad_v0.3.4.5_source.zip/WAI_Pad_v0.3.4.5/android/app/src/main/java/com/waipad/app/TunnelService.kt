package com.waipad.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.jcraft.jsch.Session
import java.net.HttpURLConnection
import java.net.URL
import java.io.IOException
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class TunnelService : Service() {
    companion object {
        const val CHANNEL_ID = "wai_pad_tunnel"
        @Volatile var connected = false
        @Volatile var bridgeReady = false
        @Volatile var phase = "idle"
        @Volatile var message = "未连接"
        @Volatile var lastBootstrapOutput = ""
        @Volatile var lastConnectedAt = 0L
        @Volatile var jupyterForwarded = false
        @Volatile var jupyterRemotePort = 0
        private var session: Session? = null
        private val running = AtomicBoolean(false)

        fun forceReconnect(reason: String = "请求重建连接") {
            bridgeReady = false
            phase = "reconnecting"
            message = reason
            try { session?.disconnect() } catch (_: Exception) {}
        }

        fun start(context: Context) {
            val i = Intent(context, TunnelService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
        fun stop(context: Context) = context.stopService(Intent(context, TunnelService::class.java))
    }

    private val exec = Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "WAI Pad 服务器连接", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        startForeground(17, notification("准备连接 AutoDL…"))
    }

    private fun notification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("WAI Pad")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentIntent(pi)
            .setOngoing(true).setOnlyAlertOnce(true).build()
    }

    private fun notifyStatus(text: String) {
        try { getSystemService(NotificationManager::class.java).notify(17, notification(text)) } catch (_: Exception) {}
    }

    private fun localApiReady(): Boolean = try {
        val c = URL("http://127.0.0.1:16027/v1/health").openConnection() as HttpURLConnection
        c.connectTimeout = 2200; c.readTimeout = 2200; c.setRequestProperty("Connection", "close")
        val ok = c.responseCode in 200..299; c.disconnect(); ok
    } catch (_: Exception) { false }


    private fun remoteApiReady(session: Session): Boolean = try {
        val r = SshClient.exec(session, "curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health >/dev/null 2>&1", 8_000)
        r.first == 0
    } catch (_: Exception) { false }

    private fun waitLocalApi(ms: Long = 12_000): Boolean {
        val until = System.currentTimeMillis() + ms
        while (running.get() && System.currentTimeMillis() < until) {
            if (localApiReady()) return true
            Thread.sleep(700)
        }
        return false
    }

    private fun detectJupyter(session: Session): Int {
        val cmd = "for p in 8888 8889 8890 8891 8080; do if curl -fsS --max-time 1 http://127.0.0.1:\$p/ >/dev/null 2>&1 || curl -fsS --max-time 1 http://127.0.0.1:\$p/lab >/dev/null 2>&1; then echo \$p; exit 0; fi; done; exit 1"
        val r = SshClient.exec(session, cmd, 12_000)
        return r.second.trim().lineSequence().firstOrNull()?.toIntOrNull() ?: 0
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running.compareAndSet(false, true)) exec.submit { loop() }
        return START_STICKY
    }

    private fun loop() {
        val p = SecurePrefs(this)
        while (running.get()) {
            if (!p.hasServer()) {
                connected = false; bridgeReady = false; phase = "setup"
                message = "首次使用：请在设置里填写一次 SSH 密码"
                notifyStatus("等待首次连接设置")
                Thread.sleep(3000); continue
            }
            try {
                phase = "connecting"; message = "正在连接 AutoDL…"; bridgeReady = false
                notifyStatus(message)
                try { session?.disconnect() } catch (_: Exception) {}
                val s = SshClient.connect(p)
                s.setPortForwardingL(16017, "127.0.0.1", 6017)
                s.setPortForwardingL(16006, "127.0.0.1", 6006)
                s.setPortForwardingL(16027, "127.0.0.1", 6027)
                val jp = detectJupyter(s)
                jupyterRemotePort = jp; jupyterForwarded = false
                if (jp > 0) {
                    try { s.setPortForwardingL(18888, "127.0.0.1", jp); jupyterForwarded = true } catch (_: Exception) {}
                }
                session = s; connected = true; lastConnectedAt = System.currentTimeMillis()
                phase = "bootstrap"; message = "隧道已连接，自动启动和检查服务…"
                notifyStatus(message)

                var bootstrapFailures = 0
                while (running.get() && s.isConnected && !bridgeReady) {
                    try {
                        lastBootstrapOutput = RemoteBootstrap.installAndStart(this, s).takeLast(16_000)
                        bridgeReady = waitLocalApi(15_000)
                        if (!bridgeReady) {
                            // If the remote API is alive but 16027 is not, the JSch local forward itself is stale.
                            if (remoteApiReady(s)) throw IOException("SSH 本地转发已失效，正在重建隧道")
                            throw IllegalStateException("WAI Pad API 尚未就绪")
                        }
                        bootstrapFailures = 0
                        phase = "ready"
                        message = if (jupyterForwarded) "已连接 · WAI/Comfy/Jupyter 正常" else "已连接 · WAI/Comfy 正常"
                        notifyStatus(message)
                    } catch (e: Exception) {
                        bootstrapFailures++
                        lastBootstrapOutput = (lastBootstrapOutput + "\n" + (e.message ?: "初始化失败")).takeLast(16_000)
                        if (!s.isConnected || e is IOException || bootstrapFailures >= 2) {
                            throw IOException("初始化连接异常，重建 SSH 隧道：${e.message ?: "未知错误"}", e)
                        }
                        phase = "repairing"; message = "检测到服务异常，正在安全修复…"
                        notifyStatus("服务器异常 · WAI Pad 正在自动修复")
                        Thread.sleep(3500)
                    }
                }

                var localFailures = 0
                while (running.get() && s.isConnected) {
                    if (!localApiReady()) {
                        localFailures++
                        bridgeReady = false
                        // Distinguish a dead remote service from a dead local forwarding socket.
                        if (remoteApiReady(s)) {
                            throw IOException("16027 本地转发 Connection reset，自动重建 SSH 隧道")
                        }
                        phase = "repairing"; message = "远端任务服务异常，正在自动恢复…"
                        try {
                            lastBootstrapOutput = RemoteBootstrap.installAndStart(this, s).takeLast(16_000)
                            bridgeReady = waitLocalApi(12_000)
                            if (!bridgeReady && localFailures >= 2) throw IOException("服务修复后隧道仍不可用，重建连接")
                        } catch (e: Exception) {
                            lastBootstrapOutput = (lastBootstrapOutput + "\n" + (e.message ?: "恢复失败")).takeLast(16_000)
                            if (!s.isConnected || e is IOException || localFailures >= 2) throw e
                        }
                    } else {
                        localFailures = 0
                        bridgeReady = true; phase = "ready"; message = "已连接"
                    }
                    Thread.sleep(5000)
                }
            } catch (e: Exception) {
                try { session?.disconnect() } catch (_: Exception) {}
                session = null
                connected = false; bridgeReady = false; jupyterForwarded = false; phase = "reconnecting"
                message = "连接中断，正在自动重连：${e.message ?: "未知错误"}"
                notifyStatus("连接中断 · 自动重连中")
                Thread.sleep(2500)
            }
        }
    }

    override fun onDestroy() {
        running.set(false); connected = false; bridgeReady = false; jupyterForwarded = false; phase = "stopped"; message = "已停止"
        try { session?.disconnect() } catch (_: Exception) {}
        exec.shutdownNow(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
