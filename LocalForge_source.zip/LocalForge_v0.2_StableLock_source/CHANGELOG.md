# Changelog

## 0.2.0 — Stable Lock

- Added per-project Stable Lock JSON and automatic verification before builds.
- Added preflight checks for JDK, Gradle, `compileSdk` platform, executable `aapt2`, offline artifact cache and disk space.
- Moved build dependency state to isolated `~/.localforge/gradle-home`.
- Added content fingerprints/SHA-256 for JDK, Gradle distribution, `android.jar`, `aapt2`, Gradle module artifacts and generated APKs.
- Added transactional toolchain and Gradle-cache imports with validation and previous-copy retention.
- Added proxy-variable stripping and fixed locale/timezone for child Gradle builds.
- Added lock state and APK hash to build history.
- Fixed Release artifact selection so a stale Debug APK is not chosen as the latest Release artifact.
- Added host-side regression test covering success paths and deliberate toolchain/cache drift.

## 0.1.0

- Initial local repository, offline build, build history, artifact install/export and ZIP import prototype.
