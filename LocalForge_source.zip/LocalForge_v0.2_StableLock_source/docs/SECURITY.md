# Security model

LocalForge assumes imported projects are trusted private source code.

Gradle build files and plugins are executable code. They run as the normal Termux UID, not root. Root is used only for integration, staging, artifact install/export and selected OS allowances.

ZIP import rejects path traversal, ignores symlink entries, and discards embedded `.git` directories so an imported archive cannot smuggle Git hooks/config into the newly created local repository.

Do not place signing passwords, Git tokens or other secrets in `.localforge.yml` or build logs. Stable Lock JSON contains versions, local paths and hashes only; it must not contain signing passwords or tokens.

Release signing should eventually move to a dedicated LocalForge keystore store with secrets supplied at build time.
