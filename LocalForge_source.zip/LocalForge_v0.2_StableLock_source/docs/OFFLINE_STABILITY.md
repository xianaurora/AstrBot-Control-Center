# Offline stability rules — v0.2

1. Normal Gradle resolution is always `--offline`; LocalForge does not clone/fetch/pull a remote repository.
2. LocalForge uses an isolated `~/.localforge/gradle-home` rather than the general Termux `~/.gradle`.
3. Required Gradle distributions are selected from the imported local toolchain. Missing versions fail before the build.
4. `compileSdk` is checked before Gradle starts; the selected platform `android.jar` must exist.
5. The selected native `aapt2` must execute before the build.
6. For AGP 8.x/9.x the v0.2 preflight requires JDK 17; known older AGP 7.x profiles require JDK 11.
7. A per-project Stable Lock fingerprints JDK, Gradle distribution, `android.jar`, `aapt2`, and immutable Gradle module artifacts.
8. If a Stable Lock exists and any fingerprint drifts, the build is refused before Gradle starts.
9. Machine-local `local.properties` is restored after each build, including failures.
10. Gradle runs with no daemon and no VFS watching to reduce stale process state.
11. Proxy environment variables are removed from the Gradle child process. This does not sandbox arbitrary networking performed by a custom project task; for hard offline testing, disable device networking.
12. Build artifacts are copied into a per-build record and the selected APK gets a SHA-256.
13. Artifact selection prefers the active build variant (`debug`/`release`) so a stale Debug APK is not selected after a Release build.
14. Toolchain and Gradle-cache imports are staged and validated before replacing the active copy.
15. Generated build outputs and local machine files remain excluded through `.git/info/exclude`.
