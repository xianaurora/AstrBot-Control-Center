# Stable Lock design

LocalForge v0.2 adds a per-project environment lock. It is intended to prevent the most common cause of “it built last month but not today” on a phone: silent toolchain drift.

For each project, `lfctl lock-project` records:

- detected Android Gradle Plugin version;
- `compileSdk`;
- required and current Java major version;
- exact Java version string and Java executable SHA-256;
- selected Gradle version and a content fingerprint of its distribution directory;
- SHA-256 of the selected platform `android.jar`;
- SHA-256 of the executable ARM64 `aapt2`;
- a content fingerprint of `gradle-home/caches/modules-2/files-2.1`.

The lock is stored outside the source repository at:

```text
~/.localforge/locks/<project-slug>.json
```

Normal builds do a preflight first. If no lock exists, LocalForge warns and permits the build so a new installation can be bootstrapped. If a lock exists and any locked value differs, the build fails before Gradle is launched.

Updating a lock is explicit. Use the app's **创建 / 更新 Stable Lock** action only after you intentionally changed the toolchain/cache and verified that the project still builds correctly.

## Why the Gradle cache has its own home

v0.1 reused `~/.gradle`. v0.2 uses:

```text
~/.localforge/gradle-home
```

This isolates LocalForge from unrelated Termux Gradle usage. Normal builds set `GRADLE_USER_HOME` to that directory and run with `--offline`.

## What the lock does not promise

Stable Lock locks the build environment, not necessarily byte-for-byte APK reproducibility. Android packaging, signing metadata, timestamps, or project build logic may still make two APK byte streams differ. v0.2 records each generated APK's SHA-256 so differences are visible in build history.
