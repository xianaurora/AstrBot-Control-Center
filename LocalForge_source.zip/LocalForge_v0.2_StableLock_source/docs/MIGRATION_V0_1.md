# Migrating from LocalForge v0.1

v0.2 changes the Gradle cache location from Termux's shared `~/.gradle` to LocalForge's private `~/.localforge/gradle-home`.

Recommended migration:

1. Keep your v0.1 repositories under `~/.localforge/repos`; v0.2 reads them unchanged.
2. Create a cache ZIP from a known-good warmed Gradle home using `tools/make_gradle_cache_bundle.sh`.
3. Import it with **导入 Gradle 离线缓存 ZIP**.
4. Import/verify the offline SDK + Gradle + ARM64 aapt2 toolchain.
5. Run **构建前检查**.
6. Build Debug/Release once while still intentionally unlocked.
7. After the real device build is known-good, press **创建 / 更新 Stable Lock**.
8. Turn off Wi-Fi/mobile data and build again.

Do not simply copy a half-populated cache and immediately lock it. The lock should represent a cache that has already completed a successful offline build for the target project revision.
