# LocalForge v0.2 — Stable Lock

LocalForge is a local-only Android project forge for a rooted Android device: conceptually **local GitHub repositories + local build history + local artifacts**, with no GitHub dependency during normal operation.

v0.2 focuses on one thing: **repeatable offline builds without silent toolchain drift**.

## New in v0.2

- Per-project **Stable Lock** with SHA-256/fingerprints for the effective build environment.
- Automatic preflight before every build.
- Locked builds refuse to start if JDK, Gradle, Android platform, ARM64 `aapt2`, or offline Gradle artifacts changed.
- Isolated `~/.localforge/gradle-home` instead of sharing Termux `~/.gradle`.
- Transactional toolchain/cache imports: validate a staging directory before replacing the active copy.
- Build records include lock state and APK SHA-256.
- Proxy variables are removed from the Gradle process, and Gradle runs with `--offline --no-daemon --no-watch-fs`.
- `LANG/LC_ALL` and `TZ` are fixed for the build process to reduce environment variation.

## Main flow

```text
Source ZIP
   |
   v
safe extract -> local Git repository -> commit/history
   |
   v
Preflight
   |-- JDK version
   |-- exact Gradle distribution
   |-- Android platform android.jar
   |-- executable ARM64 aapt2
   |-- isolated offline Gradle/Maven artifact cache
   |-- disk-space check
   |-- Stable Lock verification (if present)
   v
Gradle --offline
   v
APK artifact + SHA-256 + immutable build record
   v
root pm install / export
```

## Storage layout

```text
~/.localforge/
├── repos/          local source repositories
├── projects/       LocalForge project metadata
├── builds/         logs + copied APK artifacts + hashes
├── jobs/           UI task status/logs
├── toolchain/      pinned SDK / Gradle / ARM64 aapt2
├── gradle-home/    LocalForge-only offline Gradle/Maven cache
└── locks/          per-project Stable Lock JSON
```

Gradle itself runs as the **normal Termux UID**, not root. Root is used only to install the controller into Termux private storage, stage imported files, grant local command/background permissions, install APKs, and export artifacts.

## Offline policy

A normal v0.2 build launches Gradle approximately as:

```text
GRADLE_USER_HOME=~/.localforge/gradle-home
Gradle --offline --no-daemon --no-watch-fs ...
```

HTTP/HTTPS/ALL proxy environment variables are removed from the child process. LocalForge does not clone/fetch a remote repository or bootstrap the toolchain from the internet.

If a dependency is absent from the isolated offline cache, the build fails explicitly instead of silently downloading it.

## Stable Lock workflow

On a new phone/project:

1. Import source ZIP.
2. Import a known-good offline toolchain ZIP.
3. Import a warmed Gradle cache ZIP.
4. Run **构建前检查（Preflight）**.
5. Build once or twice while unlocked.
6. When the real device environment is known-good, press **创建 / 更新 Stable Lock**.
7. Subsequent builds verify the lock before Gradle starts.

The lock records AGP, compileSdk, JDK version/hash, selected Gradle distribution fingerprint, platform `android.jar` hash, ARM64 `aapt2` hash, and Gradle module artifact-cache fingerprint.

Changing a toolchain/cache intentionally is allowed, but you must explicitly update the project's Stable Lock afterwards.

## Offline toolchain ZIP

Expected shape:

```text
toolchain/
├── bin/
│   └── aapt2
├── android-sdk/
│   └── platforms/
│       └── android-35/
│           └── android.jar
└── gradle/
    └── gradle-8.9/
        ├── bin/gradle
        └── lib/...
```

The v0.2 importer extracts to a staging directory, verifies that `aapt2` executes, verifies at least one `android.jar` and one Gradle distribution exist, then swaps the staged toolchain into place. The previous copy is retained as `toolchain.previous` until the next import.

## Offline Gradle cache ZIP

v0.2 expects an import containing either `gradle-home/`, `.gradle/`, or Gradle-home contents at the root. It validates that `caches/modules-2/files-2.1` contains artifacts before activation.

Use:

```bash
GRADLE_USER_HOME=/path/to/known-good/gradle-home \
  tools/make_gradle_cache_bundle.sh localforge-gradle-cache.zip
```

## WAI Pad profile

The current target profile for the supplied sample remains:

```text
Android project directory: android/
AGP:                       8.7.3
Kotlin:                    2.1.0
Java:                      17
compileSdk:                35
Preferred Gradle:          8.9
```

The goal on the real rooted device is: after the toolchain and dependency cache are prepared and locked, disable Wi-Fi and mobile data and repeatedly generate the APK from the same local source without any external service.

## Important limitation

This source package can validate the LocalForge orchestration logic on the current host, but the host is not your rooted Android/Termux ARM64 device. A real ARM64 `aapt2` + Android SDK + warmed WAI Pad dependency cache still has to be exercised on your phone before claiming a real WAI Pad build is stable.

See `docs/STABLE_LOCK.md`, `docs/MIGRATION_V0_1.md`, and `TEST_REPORT.md`.
