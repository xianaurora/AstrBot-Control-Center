# LocalForge v0.2 Stable Lock — Test Report

## Scope

This package was tested on the current Linux execution host with a simulated Android/Termux build toolchain. The tests validate LocalForge orchestration, lock behavior, artifact selection and source syntax. They do **not** claim that a real ARM64 Android SDK/aapt2 build of WAI Pad was completed on this host.

## Static checks

- `bash -n` on the shipped `lfctl`: PASS
- All embedded Python heredocs extracted and compiled: PASS (10 blocks)
- Android Java source compiled with minimal Android API stubs using Java 17 syntax: PASS
- Backend scan for its own `git clone/fetch/pull`, `curl`, `wget`, or HTTP(S) bootstrap: PASS
- Gradle `--offline` flag present: PASS

## End-to-end simulated build flow

A nested Android project with the target profile was used:

```text
projectDir: android/
AGP:        8.7.3
Kotlin:     2.1.0
compileSdk: 35
Gradle:     8.9
JDK:        simulated 17.0.12
```

Results:

```text
PASS transactional toolchain import
PASS isolated Gradle cache import
PASS project ZIP import
PASS project starts unlocked
PASS unlocked preflight
PASS unlocked preflight warning
PASS create Stable Lock
PASS verify Stable Lock
PASS locked debug build
PASS debug artifact selection
PASS locked release build
PASS release artifact preferred over stale debug APK
PASS APK SHA-256 recorded
PASS invalid toolchain rejected
PASS failed import preserves active toolchain
PASS aapt2 drift blocks build
PASS aapt2 drift identified
PASS Gradle not run after aapt2 drift
PASS restored toolchain verifies original lock
PASS offline cache drift blocks build
PASS cache drift identified
PASS Gradle not run after cache drift
PASS restored cache verifies original lock
PASS build history contains lock and artifact hash
PASS project list shows locked state
PASS no network bootstrap command in lfctl
PASS Gradle offline flag present
```

Final result: **ALL TESTS PASSED**.

## Deliberate drift tests

After a valid lock was created, the test modified the active `aapt2` while keeping it executable. The next build returned a lock mismatch and the fake Gradle backend was never started.

The test then restored the exact toolchain and verified the original lock successfully.

Next, the content of one cached Maven/Gradle artifact under `caches/modules-2/files-2.1` was changed. Again, the next build was rejected before Gradle started. Re-importing the exact cache restored lock verification.

## Artifact regression fixed during v0.2 development

An initial run showed that a broad artifact glob could select an old Debug APK during a Release build. v0.2 now sorts artifacts so APKs matching the active build variant (`/debug/` or `/release/`) are preferred. A fresh regression run verified that Release selects `app-release.apk` even when `app-debug.apk` already exists.

## Remaining real-device validation

The important next validation is on the user's rooted Android device with the actual ARM64 environment:

1. JDK 17
2. known-good ARM64 `aapt2`
3. Android API 35 platform
4. Gradle 8.9 distribution
5. fully warmed WAI Pad Gradle/Maven cache
6. Wi-Fi and mobile data disabled
7. repeated Debug/Release builds under a created Stable Lock

Only after that test should the project be described as proven stable for real WAI Pad builds.
