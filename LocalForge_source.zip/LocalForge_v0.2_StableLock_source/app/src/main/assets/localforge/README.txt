LocalForge 0.2 Stable Lock controller.

lfctl runs as the normal Termux UID. Root is only used by the Android UI bridge for setup,
staging, APK install/export and Android background allowances.

Normal builds are network-offline and use an isolated Gradle home:
  ~/.localforge/gradle-home

Per-project Stable Locks live in:
  ~/.localforge/locks/<project>.json

A lock fingerprints JDK, selected Gradle distribution, Android platform android.jar,
ARM64 aapt2 and the immutable Gradle module artifact cache. If a locked component drifts,
builds stop before Gradle runs until the lock is explicitly updated.
