package com.localforge.app;

import android.content.Context;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

public final class RootBridge {
    private RootBridge() {}

    public static Result exec(String command, long timeoutSeconds) {
        Process process = null;
        try {
            process = new ProcessBuilder("su", "-c", command).redirectErrorStream(true).start();
            final Process active = process;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            Thread reader = new Thread(() -> {
                try {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = active.getInputStream().read(buf)) >= 0) out.write(buf, 0, n);
                } catch (Exception ignored) {}
            });
            reader.start();
            boolean done = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
            if (!done) {
                process.destroyForcibly();
                return new Result(false, -1, "root command timed out");
            }
            reader.join(1500);
            int code = process.exitValue();
            return new Result(code == 0, code, out.toString(StandardCharsets.UTF_8.name()));
        } catch (Exception e) {
            return new Result(false, -1, e.toString());
        } finally {
            if (process != null) process.destroy();
        }
    }


    public static Result check() { return exec("id", 8); }

    public static Result installLfctl(Context context, File script, int termuxUid) {
        String home = TermuxBridge.HOME;
        String bin = home + "/.localforge/bin";
        String props = home + "/.termux/termux.properties";
        String command = "mkdir -p " + q(bin) + " " + q(home + "/.termux")
                + " && cp " + q(script.getAbsolutePath()) + " " + q(bin + "/lfctl")
                + " && chmod 755 " + q(bin + "/lfctl")
                + " && chown -R " + termuxUid + ":" + termuxUid + " " + q(home + "/.localforge")
                + " && touch " + q(props)
                + " && (grep -q '^allow-external-apps=true$' " + q(props)
                + " || printf '\\nallow-external-apps=true\\n' >> " + q(props) + ")"
                + " && chown -R " + termuxUid + ":" + termuxUid + " " + q(home + "/.termux")
                + " && chmod 700 " + q(home + "/.termux")
                + " && chmod 600 " + q(props)
                + " && (pm grant " + q(context.getPackageName()) + " com.termux.permission.RUN_COMMAND >/dev/null 2>&1 || true)"
                + " && (cmd deviceidle whitelist +com.termux >/dev/null 2>&1 || true)"
                + " && (cmd deviceidle whitelist +" + context.getPackageName() + " >/dev/null 2>&1 || true)"
                + " && (appops set com.termux RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true)";
        return exec(command, 20);
    }

    public static Result stageFile(File source, String target, int termuxUid) {
        String parent = new File(target).getParent();
        String command = "mkdir -p " + q(parent)
                + " && cp " + q(source.getAbsolutePath()) + " " + q(target)
                + " && chown " + termuxUid + ":" + termuxUid + " " + q(target)
                + " && chmod 600 " + q(target);
        return exec(command, 30);
    }

    public static String readFile(String path) {
        Result r = exec("cat " + q(path) + " 2>/dev/null", 8);
        return r.ok() ? r.output() : "";
    }

    public static String tailFile(String path, int lines) {
        int safeLines = Math.max(1, Math.min(lines, 1000));
        Result r = exec("tail -n " + safeLines + " " + q(path) + " 2>/dev/null", 8);
        return r.ok() ? r.output() : "";
    }

    public static Result installApk(String apkPath) {
        return exec("pm install -r -d " + q(apkPath), 180);
    }

    public static Result exportApk(String apkPath, String displayName) {
        String safe = displayName.replaceAll("[^0-9A-Za-z._-]", "_");
        if (safe.isEmpty()) safe = "localforge.apk";
        String out = "/sdcard/Download/LocalForge/" + safe;
        Result r = exec("mkdir -p /sdcard/Download/LocalForge && cp " + q(apkPath) + " " + q(out)
                + " && chmod 644 " + q(out), 30);
        if (!r.ok()) return r;
        return new Result(true, 0, out);
    }

    public static String latestApk(String slug) {
        String file = TermuxBridge.HOME + "/.localforge/builds/" + slug + "/latest.env";
        String cmd = "[ -f " + q(file) + " ] || exit 2; . " + q(file)
                + "; [ \"${RESULT:-}\" = SUCCESS ] || exit 3; [ -f \"${APK:-}\" ] || exit 4; printf '%s' \"$APK\"";
        Result r = exec(cmd, 8);
        return r.ok() ? r.output().trim() : "";
    }

    public static String gitStatus(String slug) {
        String repo = TermuxBridge.HOME + "/.localforge/repos/" + slug;
        String git = TermuxBridge.PREFIX + "/bin/git";
        Result r = exec(git + " -C " + q(repo) + " status --short --branch 2>&1", 8);
        return r.output();
    }

    private static String q(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    public static final class Result {
        private final boolean ok;
        private final int code;
        private final String output;
        public Result(boolean ok, int code, String output) { this.ok = ok; this.code = code; this.output = output; }
        public boolean ok() { return ok; }
        public int code() { return code; }
        public String output() { return output; }
    }
}
