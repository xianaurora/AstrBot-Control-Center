package com.localforge.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class TermuxBridge {
    public static final String PACKAGE = "com.termux";
    private static final String SERVICE = "com.termux.app.RunCommandService";
    public static final String HOME = "/data/data/com.termux/files/home";
    public static final String PREFIX = "/data/data/com.termux/files/usr";

    private TermuxBridge() {}

    public static boolean isInstalled(Context context) {
        try {
            context.getPackageManager().getPackageInfo(PACKAGE, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public static int getUid(Context context) throws PackageManager.NameNotFoundException {
        return context.getPackageManager().getApplicationInfo(PACKAGE, 0).uid;
    }

    public static void runLfctl(Context context, String command, String job, String... args) {
        List<String> cmd = new ArrayList<>();
        cmd.add(HOME + "/.localforge/bin/lfctl");
        cmd.add(command);
        if (job != null && !job.isEmpty()) cmd.add(job);
        if (args != null) cmd.addAll(Arrays.asList(args));

        Intent intent = new Intent();
        intent.setClassName(PACKAGE, SERVICE);
        intent.setAction("com.termux.RUN_COMMAND");
        intent.putExtra("com.termux.RUN_COMMAND_PATH", PREFIX + "/bin/bash");
        intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", cmd.toArray(new String[0]));
        intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME);
        intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
        intent.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent);
        } else {
            context.startService(intent);
        }
    }
}
