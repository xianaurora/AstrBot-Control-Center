package com.localforge.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_PROJECT = 101;
    private static final int PICK_TOOLCHAIN = 102;
    private static final int PICK_CACHE = 103;

    private final List<String> projectSlugs = new ArrayList<>();
    private final List<String> projectLabels = new ArrayList<>();
    private Spinner projectSpinner;
    private ArrayAdapter<String> projectAdapter;
    private EditText importName;
    private EditText commitMessage;
    private TextView statusView;
    private TextView logView;
    private volatile String activeJob = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(makeUi());
        setStatus("LocalForge 0.2 Stable Lock · 本地仓库 / 锁定离线构建");
        checkEnvironment();
    }

    private View makeUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = text("LocalForge", 28);
        root.addView(title);
        TextView subtitle = text("像本地 GitHub：Repository · Builds · Artifacts", 14);
        root.addView(subtitle);

        statusView = text("", 14);
        statusView.setPadding(0, dp(10), 0, dp(10));
        root.addView(statusView);

        root.addView(section("环境"));
        root.addView(button("初始化 / 修复 LocalForge", v -> initializeLocalForge()));
        root.addView(button("环境诊断", v -> runJob("doctor", "环境诊断", null)));
        root.addView(button("导入离线工具链 ZIP", v -> pickZip(PICK_TOOLCHAIN)));
        root.addView(button("导入 Gradle 离线缓存 ZIP", v -> pickZip(PICK_CACHE)));

        root.addView(section("Repositories"));
        importName = edit("项目名称（留空则使用 ZIP 文件名）");
        root.addView(importName);
        root.addView(button("导入源码 ZIP → 本地 Git 仓库", v -> pickZip(PICK_PROJECT)));
        root.addView(button("刷新项目列表", v -> refreshProjects()));

        projectSpinner = new Spinner(this);
        projectAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, projectLabels);
        projectSpinner.setAdapter(projectAdapter);
        root.addView(projectSpinner, new LinearLayout.LayoutParams(-1, -2));

        root.addView(section("当前项目"));
        root.addView(button("构建前检查（Preflight）", v -> preflightCurrent()));
        root.addView(button("创建 / 更新 Stable Lock", v -> lockCurrent()));
        root.addView(button("验证 Stable Lock", v -> verifyLockCurrent()));
        root.addView(button("Build Debug（离线 + 锁验证）", v -> build("debug")));
        root.addView(button("Build Release（离线 + 锁验证）", v -> build("release")));
        commitMessage = edit("Commit message");
        root.addView(commitMessage);
        root.addView(button("Commit 当前修改", v -> commitCurrent()));
        root.addView(button("查看 Commit History", v -> historyCurrent()));
        root.addView(button("查看 Build History", v -> buildHistoryCurrent()));
        root.addView(button("查看 Git Status", v -> gitStatusCurrent()));

        root.addView(section("Artifacts"));
        root.addView(button("root 安装最新成功 APK", v -> installLatest()));
        root.addView(button("导出最新 APK 到 Download/LocalForge", v -> exportLatest()));

        root.addView(section("任务日志"));
        logView = text("尚无任务。", 12);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(8), dp(8), dp(8), dp(8));
        root.addView(logView, new LinearLayout.LayoutParams(-1, -2));

        return scroll;
    }

    private void checkEnvironment() {
        new Thread(() -> {
            RootBridge.Result root = RootBridge.check();
            boolean termux = TermuxBridge.isInstalled(this);
            runOnUiThread(() -> setStatus("root=" + (root.ok() ? "OK" : "FAIL")
                    + " · Termux=" + (termux ? "OK" : "未安装")
                    + " · Build 网络策略=OFFLINE"));
            if (root.ok() && termux) refreshProjects();
        }).start();
    }

    private void initializeLocalForge() {
        if (!TermuxBridge.isInstalled(this)) {
            toast("需要本机 Termux 作为 ARM64 构建工具链；不需要 GitHub。请先安装 Termux APK。");
            return;
        }
        new Thread(() -> {
            try {
                int uid = TermuxBridge.getUid(this);
                File script = copyAsset("localforge/lfctl", "lfctl");
                RootBridge.Result r = RootBridge.installLfctl(this, script, uid);
                runOnUiThread(() -> {
                    logView.setText(r.output());
                    if (r.ok()) {
                        toast("LocalForge 已写入 Termux 私有目录");
                        runJob("doctor", "初始化后诊断", null);
                    } else {
                        toast("初始化失败");
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> logView.setText("初始化失败：\n" + e));
            }
        }).start();
    }

    private void pickZip(int requestCode) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/zip");
        String[] mime = {"application/zip", "application/x-zip-compressed", "application/octet-stream"};
        i.putExtra(Intent.EXTRA_MIME_TYPES, mime);
        startActivityForResult(i, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        final int code = requestCode;
        final String typedProjectName = (requestCode == PICK_PROJECT) ? importName.getText().toString().trim() : "";
        new Thread(() -> handlePickedZip(code, uri, typedProjectName)).start();
    }

    private void handlePickedZip(int requestCode, Uri uri, String typedProjectName) {
        if (!TermuxBridge.isInstalled(this)) {
            runOnUiThread(() -> toast("Termux 未安装"));
            return;
        }
        try {
            String original = displayName(uri);
            File local = copyUriToCache(uri, original);
            int uid = TermuxBridge.getUid(this);
            String job = newJobId();
            String target = TermuxBridge.HOME + "/.localforge/inbox/" + job + "-" + safeName(original);
            RootBridge.Result stage = RootBridge.stageFile(local, target, uid);
            if (!stage.ok()) {
                runOnUiThread(() -> logView.setText("导入文件暂存失败：\n" + stage.output()));
                return;
            }

            if (requestCode == PICK_PROJECT) {
                String name = typedProjectName.isEmpty() ? stripZip(original) : typedProjectName;
                runOnUiThread(() -> runJobWithId(job, "import-zip", "导入项目 " + name,
                        () -> refreshProjects(), target, name));
            } else if (requestCode == PICK_TOOLCHAIN) {
                runOnUiThread(() -> runJobWithId(job, "import-toolchain", "导入离线工具链", null, target));
            } else if (requestCode == PICK_CACHE) {
                runOnUiThread(() -> runJobWithId(job, "import-gradle-home", "导入 Gradle 离线缓存", null, target));
            }
        } catch (Exception e) {
            runOnUiThread(() -> logView.setText("读取 ZIP 失败：\n" + e));
        }
    }

    private void refreshProjects() {
        String job = newJobId();
        runJobWithId(job, "list", "刷新项目", () -> {
            String log = RootBridge.readFile(jobLog(job));
            parseProjectList(log);
        });
    }

    private void parseProjectList(String text) {
        List<String> slugs = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        String[] lines = text.split("\\r?\\n");
        for (String line : lines) {
            if (line.trim().isEmpty() || line.startsWith("slug\t")) continue;
            String[] p = line.split("\\t", -1);
            if (p.length < 6) continue;
            slugs.add(p[0]);
            String lock = p.length >= 7 ? p[6] : "UNLOCKED";
            labels.add(p[1] + "  [" + p[2] + " @ " + p[3] + "]  build=" + p[4] + "  " + lock);
        }
        runOnUiThread(() -> {
            projectSlugs.clear(); projectSlugs.addAll(slugs);
            projectLabels.clear(); projectLabels.addAll(labels);
            projectAdapter.notifyDataSetChanged();
            setStatus("本地项目：" + projectSlugs.size() + " · Build 网络策略=OFFLINE");
        });
    }

    private void preflightCurrent() {
        String slug = currentSlug();
        if (slug == null) return;
        runJob("preflight", "Preflight " + slug, null, slug, "debug");
    }

    private void lockCurrent() {
        String slug = currentSlug();
        if (slug == null) return;
        runJob("lock-project", "Stable Lock " + slug, () -> refreshProjects(), slug);
    }

    private void verifyLockCurrent() {
        String slug = currentSlug();
        if (slug == null) return;
        runJob("lock-status", "Verify Lock " + slug, null, slug);
    }

    private void build(String variant) {
        String slug = currentSlug();
        if (slug == null) return;
        runJob("build", "Build " + slug + " / " + variant, () -> refreshProjects(), slug, variant);
    }

    private void commitCurrent() {
        String slug = currentSlug();
        if (slug == null) return;
        String msg = commitMessage.getText().toString().trim();
        if (msg.isEmpty()) msg = "LocalForge commit";
        runJob("commit", "Commit " + slug, () -> refreshProjects(), slug, msg);
    }

    private void historyCurrent() {
        String slug = currentSlug();
        if (slug == null) return;
        runJob("history", "History " + slug, null, slug);
    }

    private void buildHistoryCurrent() {
        String slug = currentSlug();
        if (slug == null) return;
        runJob("builds", "Build History " + slug, null, slug);
    }

    private void gitStatusCurrent() {
        String slug = currentSlug();
        if (slug == null) return;
        new Thread(() -> {
            String out = RootBridge.gitStatus(slug);
            runOnUiThread(() -> logView.setText(out.isEmpty() ? "工作区干净或无法读取。" : out));
        }).start();
    }

    private void installLatest() {
        String slug = currentSlug();
        if (slug == null) return;
        new Thread(() -> {
            String apk = RootBridge.latestApk(slug);
            if (apk.isEmpty()) {
                runOnUiThread(() -> toast("没有可安装的成功构建"));
                return;
            }
            RootBridge.Result r = RootBridge.installApk(apk);
            runOnUiThread(() -> {
                logView.setText("APK: " + apk + "\n\n" + r.output());
                toast(r.ok() ? "安装完成" : "安装失败");
            });
        }).start();
    }

    private void exportLatest() {
        String slug = currentSlug();
        if (slug == null) return;
        new Thread(() -> {
            String apk = RootBridge.latestApk(slug);
            if (apk.isEmpty()) {
                runOnUiThread(() -> toast("没有可导出的成功构建"));
                return;
            }
            String name = slug + "-latest.apk";
            RootBridge.Result r = RootBridge.exportApk(apk, name);
            runOnUiThread(() -> {
                logView.setText(r.ok() ? "已导出：\n" + r.output() : "导出失败：\n" + r.output());
                toast(r.ok() ? "已导出到 Download/LocalForge" : "导出失败");
            });
        }).start();
    }

    private String currentSlug() {
        int pos = projectSpinner.getSelectedItemPosition();
        if (pos < 0 || pos >= projectSlugs.size()) {
            toast("先导入并选择项目");
            return null;
        }
        return projectSlugs.get(pos);
    }

    private void runJob(String command, String title, Runnable onSuccess, String... args) {
        runJobWithId(newJobId(), command, title, onSuccess, args);
    }

    private void runJobWithId(String job, String command, String title, Runnable onSuccess, String... args) {
        if (!TermuxBridge.isInstalled(this)) {
            toast("Termux 未安装");
            return;
        }
        activeJob = job;
        logView.setText(title + "\n任务：" + job + "\n");
        try {
            TermuxBridge.runLfctl(this, command, job, args);
        } catch (Exception e) {
            logView.setText("无法启动 Termux 构建任务：\n" + e
                    + "\n\n若刚初始化，请先打开一次 Termux 后返回重试。");
            return;
        }
        pollJob(job, title, onSuccess);
    }

    private void pollJob(String job, String title, Runnable onSuccess) {
        new Thread(() -> {
            String statusPath = jobStatus(job);
            String logPath = jobLog(job);
            long started = System.currentTimeMillis();
            long deadline = started + 60L * 60L * 1000L;
            String status = "";
            while (System.currentTimeMillis() < deadline) {
                status = RootBridge.readFile(statusPath).trim();
                if (status.isEmpty() && System.currentTimeMillis() - started > 20000L) {
                    status = "NOT_STARTED";
                    break;
                }
                String tail = RootBridge.tailFile(logPath, 180);
                String shownStatus = status.isEmpty() ? "WAITING" : status;
                runOnUiThread(() -> {
                    if (job.equals(activeJob)) {
                        logView.setText(title + "\n状态：" + shownStatus + "\n\n" + tail);
                    }
                });
                if (status.startsWith("SUCCESS") || status.startsWith("FAILED")) break;
                try { Thread.sleep(1000); } catch (InterruptedException ignored) { break; }
            }
            final String done = status;
            runOnUiThread(() -> {
                if (done.startsWith("SUCCESS")) {
                    toast(title + "：完成");
                    if (onSuccess != null) onSuccess.run();
                } else if (done.startsWith("FAILED")) {
                    toast(title + "：失败，查看日志");
                } else if (done.startsWith("NOT_STARTED")) {
                    toast(title + "：Termux 任务未启动");
                    if (job.equals(activeJob)) logView.append("\n\n任务没有在 20 秒内启动。首次初始化后可先打开一次 Termux，再返回重试。 ");
                } else {
                    toast(title + "：任务状态超时");
                }
            });
        }).start();
    }

    private File copyAsset(String assetName, String outputName) throws Exception {
        File out = new File(getFilesDir(), outputName);
        try (InputStream in = getAssets().open(assetName); FileOutputStream fos = new FileOutputStream(out)) {
            byte[] buf = new byte[8192]; int n;
            while ((n = in.read(buf)) >= 0) fos.write(buf, 0, n);
        }
        out.setExecutable(true, true);
        return out;
    }

    private File copyUriToCache(Uri uri, String name) throws Exception {
        File dir = new File(getCacheDir(), "imports");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("cannot create cache dir");
        File out = new File(dir, System.currentTimeMillis() + "-" + safeName(name));
        ContentResolver cr = getContentResolver();
        try (InputStream in = cr.openInputStream(uri); FileOutputStream fos = new FileOutputStream(out)) {
            if (in == null) throw new IllegalStateException("cannot open uri");
            byte[] buf = new byte[1024 * 128]; int n;
            while ((n = in.read(buf)) >= 0) fos.write(buf, 0, n);
        }
        return out;
    }

    private String displayName(Uri uri) {
        String name = "import.zip";
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && c.getString(i) != null) name = c.getString(i);
            }
        } catch (Exception ignored) {}
        return name;
    }

    private String stripZip(String s) {
        return s.toLowerCase(Locale.ROOT).endsWith(".zip") ? s.substring(0, s.length() - 4) : s;
    }

    private String safeName(String s) {
        String x = s.replaceAll("[^0-9A-Za-z._-]", "_");
        return x.isEmpty() ? "file.zip" : x;
    }

    private String newJobId() { return System.currentTimeMillis() + "-" + Long.toHexString(System.nanoTime()); }
    private String jobStatus(String job) { return TermuxBridge.HOME + "/.localforge/jobs/" + job + "/status"; }
    private String jobLog(String job) { return TermuxBridge.HOME + "/.localforge/jobs/" + job + "/log"; }

    private TextView section(String s) {
        TextView t = text(s, 18);
        t.setPadding(0, dp(18), 0, dp(6));
        return t;
    }

    private TextView text(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        return t;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(6);
        e.setLayoutParams(lp);
        return e;
    }

    private Button button(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(6);
        b.setLayoutParams(lp);
        return b;
    }

    private void setStatus(String s) { statusView.setText(s); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
