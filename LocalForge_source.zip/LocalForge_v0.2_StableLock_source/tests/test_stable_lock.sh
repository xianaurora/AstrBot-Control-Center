#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="${1:-$(mktemp -d)}"
KEEP="${KEEP_TEST_ROOT:-0}"
[ "$KEEP" = 1 ] || trap 'rm -rf "$ROOT"' EXIT
SRC_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CTL="$SRC_ROOT/app/src/main/assets/localforge/lfctl"

pass() { printf 'PASS %s\n' "$1"; }
fail() { printf 'FAIL %s\n' "$1" >&2; exit 1; }
assert_grep() { grep -qE -- "$1" "$2" || fail "$3"; pass "$3"; }
assert_rc_nonzero() { [ "$1" -ne 0 ] || fail "$2"; pass "$2"; }

bash -n "$CTL"
pass 'lfctl bash syntax'

python - "$CTL" <<'PY'
import re,sys
text=open(sys.argv[1],encoding='utf-8').read().splitlines()
i=0; n=0
while i<len(text):
    m=re.search(r"<<'PY'",text[i])
    if not m: i+=1; continue
    j=i+1; body=[]
    while j<len(text) and text[j] != 'PY': body.append(text[j]); j+=1
    if j==len(text): raise SystemExit(f'unclosed Python heredoc near line {i+1}')
    compile('\n'.join(body),f'lfctl-heredoc-{n}','exec'); n+=1; i=j+1
print(f'PASS embedded Python syntax ({n} blocks)')
PY

rm -rf "$ROOT"
mkdir -p "$ROOT/home/bin" "$ROOT/bundles/toolchain/bin" \
  "$ROOT/bundles/toolchain/android-sdk/platforms/android-35" \
  "$ROOT/bundles/toolchain/gradle/gradle-8.9/bin" \
  "$ROOT/bundles/toolchain/gradle/gradle-8.9/lib" \
  "$ROOT/cache/gradle-home/caches/modules-2/files-2.1/com.example/dummy/1.0/abc" \
  "$ROOT/src/WAI_Test/android/app"

cat > "$ROOT/home/bin/java" <<'SH'
#!/usr/bin/env bash
if [ "${1:-}" = "-version" ]; then
  echo 'openjdk version "17.0.12" 2024-07-16' >&2
  echo 'OpenJDK Runtime Environment' >&2
  exit 0
fi
exec /usr/bin/java "$@"
SH
chmod +x "$ROOT/home/bin/java"

cat > "$ROOT/bundles/toolchain/bin/aapt2" <<'SH'
#!/usr/bin/env bash
echo 'Android Asset Packaging Tool (aapt) 2.19-test'
SH
chmod +x "$ROOT/bundles/toolchain/bin/aapt2"

cat > "$ROOT/bundles/toolchain/gradle/gradle-8.9/bin/gradle" <<'SH'
#!/usr/bin/env bash
set -Eeuo pipefail
if [[ " $* " == *" --version "* ]]; then echo 'Gradle 8.9'; exit 0; fi
variant=debug
[[ " $* " == *"assembleRelease"* ]] && variant=release
out="app/build/outputs/apk/$variant/app-$variant.apk"
mkdir -p "$(dirname "$out")"
printf 'fake-apk-%s\n' "$variant" > "$out"
echo "FAKE_GRADLE_BUILT=$out"
SH
chmod +x "$ROOT/bundles/toolchain/gradle/gradle-8.9/bin/gradle"
printf 'gradle-lib-stable\n' > "$ROOT/bundles/toolchain/gradle/gradle-8.9/lib/dummy.jar"
printf 'android-35-stable\n' > "$ROOT/bundles/toolchain/android-sdk/platforms/android-35/android.jar"
printf 'cached-aar\n' > "$ROOT/cache/gradle-home/caches/modules-2/files-2.1/com.example/dummy/1.0/abc/dummy-1.0.aar"
(cd "$ROOT/bundles" && zip -qr "$ROOT/toolchain.zip" toolchain)
(cd "$ROOT/cache" && zip -qr "$ROOT/cache.zip" gradle-home)

cat > "$ROOT/src/WAI_Test/android/settings.gradle.kts" <<'KTS'
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
rootProject.name = "WAI-Test"
include(":app")
KTS
cat > "$ROOT/src/WAI_Test/android/build.gradle.kts" <<'KTS'
plugins {
    id("com.android.application") version "8.7.3" apply false
    kotlin("android") version "2.1.0" apply false
}
KTS
cat > "$ROOT/src/WAI_Test/android/app/build.gradle.kts" <<'KTS'
plugins { id("com.android.application") }
android { namespace = "test.localforge"; compileSdk = 35 }
KTS
cat > "$ROOT/src/WAI_Test/.localforge.yml" <<'YML'
android:
  projectDir: android
builds:
  debug: :app:assembleDebug
  release: :app:assembleRelease
artifacts:
  - android/app/build/outputs/apk/**/*.apk
YML
(cd "$ROOT/src" && zip -qr "$ROOT/wai.zip" WAI_Test)

export HOME="$ROOT/home"
export LF_HOME="$ROOT/home/.localforge"
export PATH="$ROOT/home/bin:/usr/bin:/bin"
run_ctl() { bash "$CTL" "$@"; }
joblog() { cat "$LF_HOME/jobs/$1/log"; }
jobstatus() { cat "$LF_HOME/jobs/$1/status"; }

run_ctl import-toolchain t1 "$ROOT/toolchain.zip"
[ "$(jobstatus t1)" = SUCCESS ] || fail 'transactional toolchain import'; pass 'transactional toolchain import'
run_ctl import-gradle-home c1 "$ROOT/cache.zip"
[ "$(jobstatus c1)" = SUCCESS ] || fail 'isolated Gradle cache import'; pass 'isolated Gradle cache import'
run_ctl import-zip i1 "$ROOT/wai.zip" 'WAI Test'
[ "$(jobstatus i1)" = SUCCESS ] || fail 'project ZIP import'; pass 'project ZIP import'
run_ctl list l1
assert_grep 'wai-test.*UNLOCKED' "$LF_HOME/jobs/l1/log" 'project starts unlocked'
run_ctl preflight p1 wai-test debug
[ "$(jobstatus p1)" = SUCCESS ] || fail 'unlocked preflight'; pass 'unlocked preflight'
assert_grep 'WARN project has no Stable Lock' "$LF_HOME/jobs/p1/log" 'unlocked preflight warning'
run_ctl lock-project lock1 wai-test
[ "$(jobstatus lock1)" = SUCCESS ] || fail 'create Stable Lock'; pass 'create Stable Lock'
run_ctl lock-status verify1 wai-test
assert_grep 'LOCK=VERIFIED' "$LF_HOME/jobs/verify1/log" 'verify Stable Lock'

run_ctl build bdebug wai-test debug
assert_grep 'RESULT=SUCCESS' "$LF_HOME/jobs/bdebug/log" 'locked debug build'
assert_grep 'artifacts/app-debug.apk' "$LF_HOME/jobs/bdebug/log" 'debug artifact selection'
run_ctl build brelease wai-test release
assert_grep 'RESULT=SUCCESS' "$LF_HOME/jobs/brelease/log" 'locked release build'
assert_grep 'artifacts/app-release.apk' "$LF_HOME/jobs/brelease/log" 'release artifact preferred over stale debug APK'
assert_grep 'APK_SHA256=[0-9a-f]{64}' "$LF_HOME/jobs/brelease/log" 'APK SHA-256 recorded'

# Transactional import failure must not replace the active toolchain.
AAPT_BEFORE="$(sha256sum "$LF_HOME/toolchain/bin/aapt2" | awk '{print $1}')"
mkdir -p "$ROOT/bad/toolchain/gradle/gradle-8.9/bin"
printf '#!/bin/sh\nexit 0\n' > "$ROOT/bad/toolchain/gradle/gradle-8.9/bin/gradle"
chmod +x "$ROOT/bad/toolchain/gradle/gradle-8.9/bin/gradle"
(cd "$ROOT/bad" && zip -qr "$ROOT/bad-toolchain.zip" toolchain)
set +e; run_ctl import-toolchain badt "$ROOT/bad-toolchain.zip"; rc=$?; set -e
assert_rc_nonzero "$rc" 'invalid toolchain rejected'
AAPT_AFTER="$(sha256sum "$LF_HOME/toolchain/bin/aapt2" | awk '{print $1}')"
[ "$AAPT_BEFORE" = "$AAPT_AFTER" ] || fail 'failed import preserves active toolchain'; pass 'failed import preserves active toolchain'

# Deliberate aapt2 drift must block before fake Gradle runs.
printf '\n# drift\n' >> "$LF_HOME/toolchain/bin/aapt2"
set +e; run_ctl build drift-aapt wai-test debug; rc=$?; set -e
assert_rc_nonzero "$rc" 'aapt2 drift blocks build'
assert_grep 'MISMATCH aapt2Sha256' "$LF_HOME/jobs/drift-aapt/log" 'aapt2 drift identified'
! grep -q 'FAKE_GRADLE_BUILT' "$LF_HOME/jobs/drift-aapt/log" || fail 'Gradle not run after aapt2 drift'; pass 'Gradle not run after aapt2 drift'
run_ctl import-toolchain t2 "$ROOT/toolchain.zip"
run_ctl lock-status verify2 wai-test
assert_grep 'LOCK=VERIFIED' "$LF_HOME/jobs/verify2/log" 'restored toolchain verifies original lock'

# Deliberate dependency artifact drift must also block before Gradle.
printf 'drift\n' >> "$LF_HOME/gradle-home/caches/modules-2/files-2.1/com.example/dummy/1.0/abc/dummy-1.0.aar"
set +e; run_ctl build drift-cache wai-test debug; rc=$?; set -e
assert_rc_nonzero "$rc" 'offline cache drift blocks build'
assert_grep 'MISMATCH gradleCacheArtifactsSha256' "$LF_HOME/jobs/drift-cache/log" 'cache drift identified'
! grep -q 'FAKE_GRADLE_BUILT' "$LF_HOME/jobs/drift-cache/log" || fail 'Gradle not run after cache drift'; pass 'Gradle not run after cache drift'
run_ctl import-gradle-home c2 "$ROOT/cache.zip"
run_ctl lock-status verify3 wai-test
assert_grep 'LOCK=VERIFIED' "$LF_HOME/jobs/verify3/log" 'restored cache verifies original lock'

run_ctl builds hist wai-test
assert_grep 'VERIFIED.*[0-9a-f]{16}.*app-release.apk' "$LF_HOME/jobs/hist/log" 'build history contains lock and artifact hash'
run_ctl list l2
assert_grep 'wai-test.*LOCKED' "$LF_HOME/jobs/l2/log" 'project list shows locked state'

# Shipped controller should not contain its own network bootstrap commands.
if grep -nE 'git[[:space:]]+(clone|fetch|pull)|(^|[[:space:]])(curl|wget)([[:space:]]|$)|https?://' "$CTL" >/dev/null; then
  fail 'lfctl contains network bootstrap command'
fi
pass 'no network bootstrap command in lfctl'
assert_grep '--offline' "$CTL" 'Gradle offline flag present'

echo 'ALL TESTS PASSED'
