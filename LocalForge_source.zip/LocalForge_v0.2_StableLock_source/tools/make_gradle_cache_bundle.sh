#!/usr/bin/env bash
set -Eeuo pipefail
OUT="${1:-localforge-gradle-cache.zip}"
OUT="$(python -c 'import os,sys; print(os.path.abspath(sys.argv[1]))' "$OUT")"
# For v0.2, point GRADLE_USER_HOME at LocalForge's isolated cache when packaging on-device,
# e.g. ~/.localforge/gradle-home. A normal ~/.gradle also works as a source bundle.
GH="${GRADLE_USER_HOME:-$HOME/.gradle}"
[ -d "$GH" ] || { echo "Gradle home missing: $GH"; exit 2; }
[ -d "$GH/caches/modules-2/files-2.1" ] || { echo "Gradle module artifact cache missing: $GH/caches/modules-2/files-2.1"; exit 3; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/gradle-home"
for d in caches wrapper jdks; do [ -e "$GH/$d" ] && cp -a "$GH/$d" "$TMP/gradle-home/"; done
(cd "$TMP" && zip -qr "$OUT" gradle-home)
echo "$OUT"
