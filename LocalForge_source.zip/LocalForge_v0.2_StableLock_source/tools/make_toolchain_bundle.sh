#!/usr/bin/env bash
set -Eeuo pipefail
# Run this on a machine/Termux installation that already has the required files.
# It does not download anything. It only packages existing offline assets.
OUT="${1:-localforge-toolchain.zip}"
OUT="$(python -c 'import os,sys; print(os.path.abspath(sys.argv[1]))' "$OUT")"
SDK="${ANDROID_HOME:-${2:-}}"
GRADLE_DIR="${3:-}"
AAPT2="${4:-$(command -v aapt2 2>/dev/null || true)}"
[ -n "$SDK" ] && [ -d "$SDK" ] || { echo 'ANDROID_HOME / SDK path required'; exit 2; }
[ -n "$GRADLE_DIR" ] && [ -x "$GRADLE_DIR/bin/gradle" ] || { echo 'Gradle distribution directory required'; exit 3; }
[ -n "$AAPT2" ] && [ -x "$AAPT2" ] || { echo 'ARM64 aapt2 path required'; exit 4; }
GV="$($GRADLE_DIR/bin/gradle --version | sed -nE 's/^Gradle ([0-9.]+).*/\1/p' | head -1)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/toolchain/bin" "$TMP/toolchain/gradle/gradle-$GV" "$TMP/toolchain/android-sdk/platforms"
cp -f "$AAPT2" "$TMP/toolchain/bin/aapt2"; chmod 755 "$TMP/toolchain/bin/aapt2"
cp -a "$GRADLE_DIR"/. "$TMP/toolchain/gradle/gradle-$GV"/
# Copy platforms only. Add other SDK folders if your project needs them.
cp -a "$SDK/platforms"/. "$TMP/toolchain/android-sdk/platforms"/
if [ -d "$SDK/licenses" ]; then cp -a "$SDK/licenses" "$TMP/toolchain/android-sdk/"; fi
(cd "$TMP" && zip -qr "$OUT" toolchain)
echo "$OUT"
