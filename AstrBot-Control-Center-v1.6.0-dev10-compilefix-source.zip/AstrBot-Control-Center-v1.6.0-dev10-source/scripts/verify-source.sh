#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

expected="$(awk 'NR==1{print $1}' "$ASSETS/engine.sha256")"
actual="$(sha256sum "$ASSETS/engine.zip" | awk '{print $1}')"
[[ "$expected" == "$actual" ]] || { echo "engine.zip SHA mismatch" >&2; exit 20; }
unzip -t "$ASSETS/engine.zip" >/dev/null
unzip -q "$ASSETS/engine.zip" -d "$TMP/engine"

# The installer verifies the same file manifest on-device. Catch a stale manifest
# before Gradle spends time compiling the APK.
(
  cd "$TMP/engine"
  sha256sum -c manifest/module-files.sha256 >/dev/null
)

grep -qx 'version=1.6.0-dev7' "$TMP/engine/module.prop" || { echo "unexpected embedded core version" >&2; exit 24; }
grep -qx 'versionCode=16007' "$TMP/engine/module.prop" || { echo "unexpected embedded core versionCode" >&2; exit 25; }
grep -q 'wait_and_raise_qq_window' "$TMP/engine/guest/run-snowluma.sh" || { echo "QQ-window readiness gate missing" >&2; exit 26; }
grep -q 'astrbot_qr.html' "$TMP/engine/guest/run-snowluma.sh" || { echo "custom QR desktop missing" >&2; exit 27; }
grep -q 'QQ_ENGINE' "$TMP/engine/astrctl" || { echo "active QQ engine status missing" >&2; exit 28; }

count=0
while IFS= read -r file; do
  case "$file" in
    *.sh|*/astrctl|*/service.sh|*/post-fs-data.sh|*/action.sh)
      if head -n 1 "$file" | grep -q 'bash'; then bash -n "$file"; else sh -n "$file"; fi
      count=$((count+1))
      ;;
  esac
done < <(find "$TMP/engine" -type f -print | sort)

python3 - "$ROOT" <<'PY'
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
root = Path(sys.argv[1])
for f in root.rglob('*.xml'):
    ET.parse(f)
PY

CONTROL="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/ui/ControlCenterApp.kt"
MODELS="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/model/ControlCenterModels.kt"
PARSER="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlStatusParser.kt"

# The dev4 build failure came from an implicit ColumnScope.AnimatedVisibility call
# inside a Box. The rewritten control center deliberately avoids that overload.
if grep -q 'AnimatedVisibility' "$CONTROL"; then
  echo "ControlCenterApp.kt unexpectedly reintroduced AnimatedVisibility; review DSL receiver scope" >&2
  exit 21
fi

# A SelectionContainer around a lazy log list has caused real-world Compose crashes.
# Logs use a stable LazyColumn plus an explicit Copy action instead.
if grep -Eq 'SelectionContainer[[:space:]]*[{(]' "$CONTROL"; then
  echo "ControlCenterApp.kt must not wrap live logs in SelectionContainer" >&2
  exit 29
fi

# Old four-destination identifiers must not leak into the new three-destination shell.
if grep -R -E 'ControlDestination\.(SERVICES|LOGS|MORE|MAINTENANCE)' "$ROOT/app/src/main/java"; then
  echo "legacy control-center destination found" >&2
  exit 22
fi

grep -q 'OPERATIONS("运维"' "$MODELS" || { echo "operations destination missing" >&2; exit 30; }
grep -q 'CONSOLE("控制台"' "$MODELS" || { echo "console destination missing" >&2; exit 31; }
grep -q 'qqEngine == "snowluma"' "$PARSER" || { echo "active-engine parser fallback missing" >&2; exit 32; }

# Guard against accidentally shipping the old app target after changing the embedded core.
grep -q 'versionName = "1.6.0-dev10"' "$ROOT/app/build.gradle.kts" || { echo "app version mismatch" >&2; exit 33; }
grep -q 'TARGET_ENGINE_VERSION = "1.6.0-dev7"' "$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/EngineRepository.kt" || { echo "core target mismatch" >&2; exit 34; }

# QR/rendering contract: keep software rendering available while making automatic recovery non-destructive.
if grep -q -- '--disable-software-rasterizer' "$TMP/engine/guest/run-snowluma.sh"; then
  echo "SnowLuma runtime must not disable the software rasterizer" >&2
  exit 35
fi
grep -q '1024x640x24' "$TMP/engine/guest/run-snowluma.sh" || { echo "SnowLuma Xvfb must use 24-bit color" >&2; exit 36; }
grep -q 'snowluma-login-compat' "$TMP/engine/astrctl" || { echo "SnowLuma compatibility login recovery missing" >&2; exit 37; }
sh "$TMP/engine/tests/test-control-center-v1604-qr-rendering.sh" "$TMP/engine" >/dev/null

WEBVIEW="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/ui/EmbeddedConsoleWebView.kt"
# QR login is contextual under QQ, not a third console destination chip.
if grep -q 'ConsoleTargetChoice("扫码登录"' "$CONTROL"; then
  echo "duplicate scan-login console chip reintroduced" >&2
  exit 38
fi
# File export has a single home in diagnostics, not a duplicate live-log toolbar action.
if grep -q 'Text("导出")' "$CONTROL"; then
  echo "duplicate bare log export action reintroduced" >&2
  exit 39
fi
grep -q 'QR_FRAME_PROBE_JS' "$WEBVIEW" || { echo "QR black-frame probe missing" >&2; exit 40; }
grep -q 'onQrBlankDetected = vm::recoverBlankQqLogin' "$CONTROL" || { echo "QR compatibility recovery is not wired" >&2; exit 41; }
grep -q 'KineticCharacters' "$CONTROL" || { echo "dev6 kinetic microinteraction layer missing" >&2; exit 42; }
grep -B1 -F 'private fun SituationAction(' "$CONTROL" | grep -q '@Composable' || { echo "SituationAction lost @Composable annotation" >&2; exit 55; }


# dev7 ground-truth rendering contract.
if grep -q -- 'openbox --display' "$TMP/engine/guest/run-snowluma.sh"; then
  echo "unsupported openbox --display invocation reintroduced" >&2
  exit 43
fi
grep -q 'SNOWLUMA_QQ_WINDOW_PLACED' "$TMP/engine/guest/run-snowluma.sh" || { echo "QQ window centering/raise step missing" >&2; exit 44; }
grep -q 'STANDARD_PAGE_PROBE_JS' "$WEBVIEW" || { echo "standard console blank-page probe missing" >&2; exit 45; }
grep -q 'brightRatio' "$WEBVIEW" || { echo "QR center-ROI framebuffer probe missing" >&2; exit 46; }
grep -q 'situation.next.ifBlank' "$CONTROL" || { echo "passive next-step label is not data-driven" >&2; exit 47; }

# dev9 hardware compositor, non-destructive QR recovery and version-ground-truth contract.
grep -q 'awaitTargetEngineTakeover' "$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/InstallerViewModel.kt" || { echo "engine takeover grace missing" >&2; exit 48; }
if grep -q 'LAYER_TYPE_SOFTWARE' "$WEBVIEW"; then
  echo "forced software WebView compositor reintroduced" >&2
  exit 49
fi
grep -q 'RENDERER_PRIORITY_IMPORTANT' "$WEBVIEW" || { echo "important WebView renderer policy missing" >&2; exit 52; }
grep -q 'snowluma-login-refresh' "$TMP/engine/astrctl" || { echo "non-destructive SnowLuma display recovery missing" >&2; exit 53; }
grep -q 'VERSION=v1.6.0-dev7' "$TMP/engine/astrctl" || { echo "astrctl release string does not match module release" >&2; exit 54; }
grep -q 'getBoundingClientRect' "$WEBVIEW" || { echo "visible-canvas geometry probe missing" >&2; exit 50; }
if grep -q 'visible >= 4' "$WEBVIEW"; then
  echo "weak blank-page DOM heuristic reintroduced" >&2
  exit 51
fi

# dev10 runtime/readiness/fallback contract.
grep -q 'onRenderProcessGone' "$WEBVIEW" || { echo "WebView renderer termination recovery missing" >&2; exit 55; }
grep -q 'qrDesktopFallbackUrl' "$WEBVIEW" || { echo "QR vnc.html fallback missing" >&2; exit 56; }
grep -q 'waitUntilConsoleReady' "$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlCenterViewModel.kt" || { echo "console readiness gate missing" >&2; exit 57; }
grep -q 'NextStepBeacon' "$CONTROL" || { echo "animated next-step beacon missing" >&2; exit 58; }
grep -q -- '-nowf -wait 10 -defer 10 -nowait_bog -nonap' "$TMP/engine/guest/run-snowluma.sh" || { echo "SnowLuma VNC responsiveness tuning missing" >&2; exit 59; }
grep -q 'SNOWLUMA_QR_FALLBACK' "$TMP/engine/guest/run-snowluma.sh" || { echo "runtime QR fallback missing" >&2; exit 60; }

# dev10 console/QR/performance contract.
grep -q 'qrDesktopFallbackUrl' "$WEBVIEW" || { echo "QR stock-noVNC fallback missing" >&2; exit 55; }
grep -q 'sameQrDesktopSession' "$WEBVIEW" || { echo "QR fallback equivalence guard missing" >&2; exit 56; }
grep -q 'WebSettings.LOAD_NO_CACHE' "$WEBVIEW" || { echo "QR no-cache policy missing" >&2; exit 57; }
grep -q 'queryPairs\["compression"\].*= "0"' "$WEBVIEW" || { echo "stock noVNC compression tuning missing" >&2; exit 58; }
grep -q 'compressionLevel=0' "$TMP/engine/guest/run-snowluma.sh" || { echo "custom noVNC compression tuning missing" >&2; exit 59; }
grep -q -- '-nowf -wait 10 -defer 10' "$TMP/engine/guest/run-snowluma.sh" || { echo "x11vnc latency tuning missing" >&2; exit 60; }
grep -q 'compat-manual' "$TMP/engine/guest/run-snowluma.sh" || { echo "stale compatibility-state cleanup missing" >&2; exit 61; }
grep -q -- '--use-gl=swiftshader' "$TMP/engine/guest/run-snowluma.sh" || { echo "explicit SwiftShader compatibility renderer missing" >&2; exit 62; }
grep -q 'NextStepBeacon' "$CONTROL" || { echo "overview next-step beacon missing" >&2; exit 63; }
grep -q 'phase = "warming"' "$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlCenterViewModel.kt" || { echo "console readiness gate missing" >&2; exit 64; }

echo "SOURCE_GATE_OK engine_sha=$actual shell_files=$count"
