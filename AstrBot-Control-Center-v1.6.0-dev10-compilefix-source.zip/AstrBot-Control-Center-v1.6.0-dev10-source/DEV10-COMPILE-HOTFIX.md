# dev10 compile hotfix

GitHub Actions failed in `:app:compileDebugKotlin` because `SituationAction()` invokes Compose UI (`Surface`, `Text`, `MotionButton`) but lost its `@Composable` annotation when the new animated “下一步” beacon was inserted above it.

Fix:

```kotlin
@Composable
private fun SituationAction(...)
```

The source gate now also checks that `SituationAction` keeps `@Composable`, so this exact packaging regression is caught before Gradle compilation in future builds.

No Engine behavior or runtime data format changed in this hotfix. App version remains `1.6.0-dev10`; embedded Core remains `1.6.0-dev7`.
