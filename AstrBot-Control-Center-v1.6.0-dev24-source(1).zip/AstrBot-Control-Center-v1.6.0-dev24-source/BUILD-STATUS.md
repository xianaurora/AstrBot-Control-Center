# Build status — dev24

- Android App: `1.6.0-dev24` / `162400`
- Embedded core: `1.6.0-dev15` / `16015`
- Stable development signing key unchanged from dev17.
- Source gate: passed before packaging.
- Embedded core manifest/hash and targeted regression tests: passed.
- Pure Kotlin model/parser compilation and Kotlin/KTS lexical scan: passed.
- Full Android `assembleDebug`: not runnable here because this source snapshot has no Gradle wrapper and the environment has no complete Android build chain; GitHub Actions remains the final build check.
