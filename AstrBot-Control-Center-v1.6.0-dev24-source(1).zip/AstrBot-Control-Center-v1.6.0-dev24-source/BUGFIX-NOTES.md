# dev24

Response-speed and visual-polish pass:

- restore the previous control status immediately instead of showing a blocking startup screen on every launch
- same verified core release opens without a repeated root version probe
- remove the second `su` cleanup process from every root command
- batch ordinary staged settings into one privileged session
- maintenance jobs release the global busy UI once queued and verify completion in the background
- AstrBot/SnowLuma workspace URLs open without an unnecessary root lookup
- AstrBot opens immediately in the proven classic WebView Activity
- custom rounded AstrBot overflow menu, rounder dialogs, save surface and Compose workspace menus
- embedded core dev15 adds bounded fast NapCat shutdown specifically for explicit engine switching
