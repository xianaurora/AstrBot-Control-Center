# Android Studio 快速构建 — v1.6.0-dev18

1. 安装 JDK 17，并在 SDK Manager 安装 Android Platform 37、Build-Tools 36.0.0、Platform-Tools。
2. 解压源码，打开包含 `settings.gradle.kts` 的项目根目录。
3. 若缺 Gradle wrapper JAR，先用 Gradle 9.5.0 执行 `gradle wrapper --gradle-version 9.5.0`。
4. 构建：`./gradlew :app:testDebugUnitTest :app:assembleDebug`（Windows 使用 `gradlew.bat`）。
5. APK 位于 `app/build/outputs/apk/debug/app-debug.apk`。
6. 安装：`adb install -r app/build/outputs/apk/debug/app-debug.apk`。

## 固定开发签名

dev18 和 dev17 使用同一固定开发更新证书，所以 dev17 → dev18 可以直接覆盖。若 Android 报 `INSTALL_FAILED_UPDATE_INCOMPATIBLE`，说明设备上的旧版本不是这把证书签名；确认 Control Center 的 App 本地数据可丢弃后，卸载包名 `com.xianaurora.astrbotcontrol` 再安装。独立 root/core 数据不在这个 APK 的应用数据目录里，但操作前仍应确认卸载的是 App 而不是 root 管理器中的模块。

## dev18 真机首测

优先验证：

- 桌面名称是否显示为 `AstrBot CC`，图标在当前 launcher 蒙版下是否完整；
- 工作台是否只有 AstrBot / 当前 QQ 引擎 / QQ 登录三个工作区；
- 所有 QQ 登录快捷入口是否最终进入同一个登录工作区；
- 更改下载源、自动功能、QQ 运行方式后是否先显示“未保存”，点保存后才实际应用；
- 有未保存更改时切页/退出是否提醒；
- AstrBot 左上角返回和系统返回是否一次回到控制中心，网页历史是否只在 `⋮` 中；
- AstrBot 页面仍能正常显示，不能因外壳重构重新出现白屏。
