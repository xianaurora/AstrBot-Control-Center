# AstrBot CC v1.6.0-dev18

这是 AstrBot Control Center 的 dev18 源码。Android App 版本为 `1.6.0-dev18 / 161600`，内嵌 core 继续固定为 `1.6.0-dev11 / 16011`，本次不修改已验证可用的 core 包。

## dev18 重点

- “控制台”重构为 **工作台**：固定分为 AstrBot、当前 QQ 引擎、QQ 登录三个工作区。
- QQ 登录只保留一个目标；主页/状态提示需要登录时都进入同一工作区。
- 自动运行、依赖来源、QQ 引擎改成 **先选择 → 未保存 → 保存/取消**；有未保存更改时离开会确认。
- AstrBot 继续使用已经解决白屏的经典 Activity WebView；系统返回/左上角返回直接退出，网页历史放进右上角 `⋮`。
- SnowLuma 横屏扫码页改为二维码与登录状态双栏；确认登录由手机 QQ 完成，App 自动识别。
- Launcher 名称缩短为 **AstrBot CC**；用户指定图标缩入 Android 自适应图标安全区。
- dev17 固定开发更新证书保持不变，避免 GitHub Actions 每次使用不同 debug 签名。

更完整的交互说明见 `DEV18-WORKBENCH-SETTINGS-UX.md`。

## 构建

推荐直接运行仓库内 GitHub Actions：**Build dev18 APK**。它会运行源码门禁、完整 Compose/Kotlin 编译、Debug APK 构建与签名指纹校验。

本地有 Android Studio/SDK 时也可按 `ANDROID-STUDIO-QUICKSTART.md` 或 `BUILD-APK.md` 构建。

## 源码门禁

```bash
bash ./scripts/verify-source.sh
```

门禁通过并不等于 APK 已编译；完整 Android 编译仍以 Gradle/GitHub Actions 结果为准。

## 签名升级说明

若设备当前已经安装 dev17 固定证书签名的 APK，dev18 应能直接覆盖安装。若设备上的版本来自 dev16 或更早的随机 debug key，Android 会拒绝跨证书覆盖，需要先卸载旧 Control Center App 再安装一次固定证书版本。
