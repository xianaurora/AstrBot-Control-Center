# v1.6.0-dev18 静态验证报告

当前生成环境已验证：

- `engine.zip` SHA-256 与 `engine.sha256` 一致；
- 内嵌 core 仍为 `1.6.0-dev11 / 16011`，其 `manifest/module-files.sha256` 全量通过；
- core Shell 文件语法通过；
- Android XML / JSON 可解析，Kotlin 源无重复 import；
- App / catalog / CI 版本均为 dev18；
- dev17 固定开发 keystore 可读取，证书指纹保持不变；
- Manifest launcher 名称为 `AstrBot CC`，普通/圆形/自适应图标资源齐全；
- 工作台三个固定目标、QQ 登录去重、设置草稿、保存/取消、未保存导航保护均有源码门禁；
- AstrBot 仍使用独立 classic Activity WebView，系统返回直接 `finish()`，网页历史转移到 `⋮` 菜单；
- PixelCopy 真白屏探针、console/HTTP/renderer 诊断及 `app-webview.log` 保留；
- 旧的日志轮询、RootShell 超时清理、native QR 等回归门禁继续通过。

最终门禁输出：

```text
SOURCE_GATE_OK ... workbench_v2=1 staged_settings=1 login_dedup=1 astrbot_classic_webview=1 astrbot_direct_exit=1 ... stable_signing=1 launcher_icon_safezone=1
```

## 未在当前环境验证

当前容器没有完整 Android SDK/Gradle Android 编译链，因此没有执行 `assembleDebug`，也没有生成并声称本地 APK 可安装。完整 Kotlin/Compose 编译、Android resource linking、APK 打包与 `apksigner` 校验由附带的 GitHub Actions 完成。
