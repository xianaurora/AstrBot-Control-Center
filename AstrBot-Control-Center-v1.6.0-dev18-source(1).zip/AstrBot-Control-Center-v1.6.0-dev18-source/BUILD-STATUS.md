# Build status — v1.6.0-dev18

- Android App: `1.6.0-dev18` / `161600`
- Embedded Core: `1.6.0-dev11` / `16011`（保持不变）
- Launcher: `AstrBot CC`
- Signing: dev17 起固定开发更新证书，dev18 沿用同一证书

## 已在当前环境完成

运行：

```bash
bash ./scripts/verify-source.sh
```

当前结果为 `SOURCE_GATE_OK`。另外 `ControlCenterModels.kt + ControlStatusParser.kt` 已用本机 `kotlinc` 独立编译通过（`PURE_KOTLIN_OK`）。门禁覆盖：内嵌 core SHA/manifest、Shell 语法、版本一致性、固定签名文件、launcher 资源、工作台三分区、QQ 登录去重、设置草稿保存/取消、未保存离开提醒、AstrBot 独立 WebView 返回策略、PixelCopy 白屏检测及此前稳定性回归项。

## 当前环境未完成

当前容器没有完整 Android SDK / `android.jar` / Gradle Android 构建链，因此这里**没有宣称 APK 已编译成功**。源码附带的 GitHub Actions 会安装 Android SDK，并执行：

```text
:app:testDebugUnitTest :app:assembleDebug
```

随后用 `apksigner` 校验 APK 证书指纹；任一步失败都会使 workflow 失败。
