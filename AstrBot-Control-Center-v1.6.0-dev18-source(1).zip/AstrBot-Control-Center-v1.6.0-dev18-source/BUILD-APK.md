# 构建 AstrBot CC v1.6.0-dev18

## 推荐：GitHub Actions

仓库自带 `.github/workflows/build-apk.yml`。手动运行 **Build dev18 APK** 后会：

1. 运行 `scripts/verify-source.sh`；
2. 校验固定开发更新 keystore；
3. 安装 Android SDK Platform 37 / Build-Tools 36.0.0；
4. 执行 `:app:testDebugUnitTest :app:assembleDebug`；
5. 使用 `apksigner` 验证生成 APK 的 SHA-256 证书指纹；
6. 上传 `AstrBot-Control-Center-v1.6.0-dev18-stable-signed` artifact。

预期 APK：`app/build/outputs/apk/debug/app-debug.apk`。

## 本机 Android Studio

工程参数：AGP 9.3.1、Gradle 9.5.0、JDK 17、compileSdk 37、targetSdk 36、minSdk 28。

源码包没有 wrapper JAR。如需命令行构建，先用本机 Gradle 9.5.0 执行：

```bash
gradle wrapper --gradle-version 9.5.0
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

Windows 使用 `gradlew.bat`。

## 签名与覆盖安装

dev18 继续使用 dev17 引入的固定开发更新证书，不再依赖 GitHub runner 临时生成的随机 debug key。证书 SHA-256：

`3D:EC:D0:53:61:E0:D6:A2:6A:92:66:88:20:4A:71:F9:3A:C3:AC:E2:3A:75:9D:0D:5C:58:D4:85:32:77:BB:2B`

如果设备上已经安装 dev17 固定证书版本，可以直接 `adb install -r` 覆盖。若设备上的旧 APK 来自 dev16 或更早的另一把随机 debug key，Android 仍会拒绝跨签名覆盖；确认 App 本地数据无需保留后，只卸载 `com.xianaurora.astrbotcontrol` 再安装即可，不会主动卸载 `/data/adb` 下的独立 core 模块。
