#!/usr/bin/env bash
set -u
BASE=/root/WAI_Pad
RUNTIME="$BASE/runtime"
LOCKFILE="$RUNTIME/service.lock"
LOG="$BASE/guard.log"
mkdir -p "$RUNTIME"
PY="/root/venv/bin/python"; [ -x "$PY" ] || PY="$(command -v python3 || command -v python)"
log(){
  [ -f "$LOG" ] && [ "$(stat -c%s "$LOG" 2>/dev/null || echo 0)" -gt 5242880 ] && mv -f "$LOG" "$LOG.1" 2>/dev/null || true
  echo "[$(date '+%F %T')] $*" >> "$LOG"
}
health(){ curl -fsS --max-time 4 "$1" >/dev/null 2>&1; }
active_job(){
  if curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health 2>/dev/null | grep -Eq '"current"[[:space:]]*:[[:space:]]*"[^" ]+'; then return 0; fi
  # If companion itself crashed, its durable state still owns the Comfy prompt. Protect core
  # restart until the restarted companion gets a chance to reattach/resolve that prompt.
  [ -f "$RUNTIME/jobs_state.json" ] && grep -Eq '"status"[[:space:]]*:[[:space:]]*"(claimed|submitting|running|repairing)"' "$RUNTIME/jobs_state.json" 2>/dev/null
}

lock_mutation(){
  exec 9>"$LOCKFILE"
  if ! flock -w 2 9; then exec 9>&-; return 1; fi
  return 0
}
unlock_mutation(){ flock -u 9 2>/dev/null || true; exec 9>&-; }

start_api_locked(){
  if ! health http://127.0.0.1:6027/v1/health; then
    if pgrep -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1; then
      # A single slow health request must not churn the companion in the middle of a prompt.
      sleep 2; health http://127.0.0.1:6027/v1/health && return 0
      sleep 2; health http://127.0.0.1:6027/v1/health && return 0
    fi
    log 'WAI Pad API 持续离线，单独恢复 companion（不触碰 ComfyUI）'
    pkill -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1 || true
    nohup "$PY" "$BASE/job_api.py" >>"$RUNTIME/job_api.nohup.log" 2>&1 </dev/null &
    for _ in $(seq 1 8); do health http://127.0.0.1:6027/v1/health && return 0; sleep 1; done
    log 'companion 恢复后仍未通过健康检查'
    return 1
  fi
  return 0
}
start_api(){
  lock_mutation || { log '服务器维护锁繁忙，延后 companion 检查'; return 0; }
  start_api_locked || true
  unlock_mutation
}

repair_core(){
  lock_mutation || { log '已有 bootstrap/repair/rollback 正在运行，本轮核心修复跳过'; return 0; }
  local panel=1 comfy=1
  health http://127.0.0.1:6017/api/health || panel=0
  health http://127.0.0.1:6006/system_stats || comfy=0

  if active_job; then
    if [ "$comfy" -eq 1 ]; then
      log "检测到活动任务且 ComfyUI 正常（panel=$panel）；延后任何全量 wai restart。"
      start_api_locked || true; unlock_mutation; return 0
    fi
    # The companion may retain an active id for a short API hiccup. Require repeated proof that
    # Comfy itself is gone before declaring the prompt unrecoverable and restarting core services.
    log '活动任务存在但 ComfyUI 不可达；连续复核，避免瞬时抖动误杀任务。'
    local still_down=1
    for _ in $(seq 1 12); do sleep 5; health http://127.0.0.1:6006/system_stats && still_down=0 && break; done
    if [ "$still_down" -eq 0 ]; then
      log 'ComfyUI 已自行恢复，不执行重启。'; start_api_locked || true; unlock_mutation; return 0
    fi
    log 'ComfyUI 在活动任务保护窗口内持续约 60 秒不可达；允许受控恢复核心服务。'
  fi

  log "核心服务持续异常 panel=$panel comfy=$comfy，执行 wai restart"
  wai restart >>"$LOG" 2>&1 || true
  sleep 8
  if ! health http://127.0.0.1:6017/api/health || ! health http://127.0.0.1:6006/system_stats; then
    local ctl=''
    for c in /root/WAI_v31/WAI_ctl.sh /root/WAI_v3/WAI_ctl.sh /root/WAI_v34_fullfix/WAI_ctl.sh; do
      [ -x "$c" ] && ctl="$c" && break
    done
    if [ -n "$ctl" ]; then
      log "常规重启未恢复，执行一次受控 repair: $ctl"
      "$ctl" repair >>"$LOG" 2>&1 || true
      sleep 10
    fi
  fi
  start_api_locked || true
  unlock_mutation
}

case "${1:-daemon}" in
  once)
    if ! health http://127.0.0.1:6017/api/health || ! health http://127.0.0.1:6006/system_stats; then repair_core; else start_api; fi
    ;;
  daemon)
    log 'WAI Pad v0.3.4.8 守护开始'
    fail=0
    while true; do
      panel=1; comfy=1
      health http://127.0.0.1:6017/api/health || panel=0
      health http://127.0.0.1:6006/system_stats || comfy=0
      if [ "$panel" -eq 1 ] && [ "$comfy" -eq 1 ]; then
        fail=0
      else
        fail=$((fail+1)); log "核心健康检查失败 #$fail panel=$panel comfy=$comfy"
        if [ "$fail" -ge 2 ]; then repair_core; fail=0; fi
      fi
      start_api
      sleep 20
    done
    ;;
esac
