#!/usr/bin/env python3
"""WAI Pad async companion API.

Runs only on 127.0.0.1:6027 and is reached through WAI Pad's SSH tunnel.
It imports the user's stable v3.4 engine without replacing the old panel.
"""
import base64
import hashlib
import json
import os
import queue as queue_mod
import re
import socket
import struct
import subprocess
import threading
import time
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib import parse, request

BASE = Path('/root/WAI_Pad')
RUNTIME = BASE / 'runtime'
RUNTIME.mkdir(parents=True, exist_ok=True)
HISTORY = RUNTIME / 'jobs.jsonl'
STATE = RUNTIME / 'jobs_state.json'
LOG = RUNTIME / 'job_api.log'
PORT = int(os.environ.get('WAI_PAD_API_PORT', '6027'))
VERSION = '0.3.4.8'

import sys
sys.path.insert(0, str(BASE))
import engine_v34 as eng  # noqa: E402
import maintenance  # noqa: E402

JOBS = {}
JOBS_LOCK = threading.RLock()
WORK_Q = queue_mod.Queue()
CURRENT = {'id': None, 'pid': None}
STATE_WRITE_LOCK = threading.Lock()
WORKER = {'thread': None}
WORKER_LOCK = threading.Lock()
UPLOAD_DIR = RUNTIME / 'uploads'
JOB_UPLOAD_DIR = RUNTIME / 'job_uploads'
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
JOB_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_TTL = 3600
OUTPUT_TTL = 72 * 3600
UPLOAD_LOCKS = {}
UPLOAD_LOCKS_GUARD = threading.Lock()
SUBMIT_LOCK = threading.Lock()
STATE_DIRTY = threading.Event()


def log(msg):
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {msg}"
    try:
        with LOG.open('a', encoding='utf-8') as f:
            f.write(line + '\n')
        if LOG.stat().st_size > 5 * 1024 * 1024:
            old = LOG.with_suffix('.log.1')
            try: old.unlink()
            except FileNotFoundError: pass
            LOG.replace(old)
    except Exception:
        pass


def now():
    return time.time()


def has_active_job():
    """Use durable job state, not only the transient CURRENT pointer."""
    with JOBS_LOCK:
        return any((j.get('status') in ('claimed','submitting','running','repairing')) for j in JOBS.values())


def clamp(v, lo, hi, default):
    try: return max(lo, min(hi, float(v)))
    except Exception: return default


def safe_int(v, lo, hi, default):
    try: return max(lo, min(hi, int(v)))
    except Exception: return default


def _state_job(job):
    x = dict(job)
    req = dict(x.get('request') or {})
    # Never persist uploaded reference-image bytes/base64 to disk. Text metadata is enough for
    # history/recovery and keeps the remote companion privacy-friendly.
    for k in ('image','person','pose'):
        if k in req:
            req[k] = '<ephemeral-upload-removed>'
    x['request'] = req
    return x


def persist_jobs():
    try:
        with STATE_WRITE_LOCK:
            with JOBS_LOCK:
                data = [_state_job(j) for j in JOBS.values()]
            tmp = STATE.with_suffix('.json.tmp')
            payload=json.dumps({'version': VERSION, 'jobs': data}, ensure_ascii=False).encode('utf-8')
            with tmp.open('wb') as f:
                f.write(payload); f.flush(); os.fsync(f.fileno())
            os.replace(tmp, STATE)
            try:
                dfd=os.open(str(STATE.parent),os.O_RDONLY); os.fsync(dfd); os.close(dfd)
            except Exception: pass
    except Exception as e:
        log(f'persist jobs failed: {e}')



def _decode_data_url(data_url):
    if not isinstance(data_url, str) or ',' not in data_url:
        raise ValueError('图片数据无效')
    head, payload = data_url.split(',', 1)
    m = re.match(r'data:([^;]+);base64$', head.strip(), re.I)
    if not m or not m.group(1).lower().startswith('image/'):
        raise ValueError('只接受 base64 图片')
    mime = m.group(1).lower()
    ext = 'jpg' if 'jpeg' in mime else ('webp' if 'webp' in mime else 'png')
    raw = base64.b64decode(payload, validate=False)
    if not raw or len(raw) > 40 * 1024 * 1024:
        raise ValueError('图片为空或超过 40MB')
    return raw, mime, ext


def _save_upload(data_url, kind='image'):
    raw, mime, ext = _decode_data_url(data_url)
    uid = uuid.uuid4().hex
    path = UPLOAD_DIR / f'{uid}.{ext}'
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('wb') as f:
        f.write(raw); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
    meta = {'id':uid, 'path':str(path), 'mime':mime, 'kind':str(kind or 'image')[:32], 'created_at':now(), 'size':len(raw)}
    _atomic_write_json(UPLOAD_DIR / f'{uid}.json', meta)
    return meta



def _session_path(uid):
    return UPLOAD_DIR / f'{uid}.session.json'


def _part_path(uid):
    # Kept for cleanup/backward compatibility with v0.3.4.6 interrupted sessions.
    return UPLOAD_DIR / f'{uid}.part'


def _chunk_path(uid, index):
    return UPLOAD_DIR / f'{uid}.chunk{int(index):04d}.b64'


def _upload_lock(uid):
    with UPLOAD_LOCKS_GUARD:
        return UPLOAD_LOCKS.setdefault(uid, threading.RLock())


def _drop_upload_lock(uid):
    with UPLOAD_LOCKS_GUARD:
        UPLOAD_LOCKS.pop(uid, None)


def _atomic_write_json(path, obj):
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False)
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)


def _init_chunk_upload(kind='image', mime='image/png', total_chunks=1, total_chars=0):
    mime = str(mime or 'image/png').split(';',1)[0].strip().lower()
    if not mime.startswith('image/'):
        raise ValueError('只接受图片上传')
    total_chunks = safe_int(total_chunks, 1, 512, 1)
    total_chars = safe_int(total_chars, 1, 64 * 1024 * 1024, 1)
    uid = uuid.uuid4().hex
    session = {
        'id':uid, 'kind':str(kind or 'image')[:32], 'mime':mime,
        'upload_format':2,
        'total_chunks':total_chunks, 'total_chars':total_chars,
        'next_index':0, 'chars_received':0, 'raw_size':0,
        'created_at':now(), 'updated_at':now(),
    }
    _atomic_write_json(_session_path(uid), session)
    return session


def _reconcile_upload_session(session):
    """Rebuild progress from atomically committed chunk files.

    v0.3.4.6 appended bytes before persisting next_index, so a crash/retry could append
    the same chunk twice. v0.3.4.8 stores every Base64 slice as its own atomic file;
    progress is derived from those files, making both concurrent retries and process
    crashes idempotent.
    """
    uid = str(session.get('id') or '')
    total = safe_int(session.get('total_chunks'), 1, 512, 1)
    chars = 0
    raw_size = 0
    next_index = 0
    for i in range(total):
        cp = _chunk_path(uid, i)
        if not cp.is_file():
            break
        payload = cp.read_bytes()
        if not payload or len(payload) > 1024 * 1024:
            raise ValueError(f'上传分片 {i} 已损坏，请重新选择图片')
        try:
            raw = base64.b64decode(payload, validate=True)
        except Exception as e:
            raise ValueError(f'上传分片 {i} 校验失败: {e}')
        if not raw:
            raise ValueError(f'上传分片 {i} 为空')
        chars += len(payload)
        raw_size += len(raw)
        next_index = i + 1
    if chars > int(session.get('total_chars', 0)) or raw_size > 40 * 1024 * 1024:
        raise ValueError('参考图上传大小校验失败，请重新选择图片')
    session['next_index'] = next_index
    session['chars_received'] = chars
    session['raw_size'] = raw_size
    session['updated_at'] = now()
    return session


def _load_upload_session(uid):
    if not re.fullmatch(r'[a-f0-9]{32}', str(uid or '')):
        return None
    sp = _session_path(uid)
    if not sp.exists():
        return None
    try:
        session = json.loads(sp.read_text('utf-8'))
        # Old v0.3.4.6 .part sessions are deliberately not resumed because their
        # append-before-metadata crash boundary cannot be proven corruption-free.
        if int(session.get('upload_format') or 1) < 2:
            raise ValueError('旧版上传会话无法安全续传，请重新选择图片')
        return _reconcile_upload_session(session)
    except ValueError:
        raise
    except Exception:
        return None


def _append_upload_chunk(uid, index, payload):
    lock = _upload_lock(uid)
    with lock:
        session = _load_upload_session(uid)
        if not session:
            raise ValueError('上传会话已失效，请重新选择图片')
        index = int(index)
        expected = int(session.get('next_index', 0))
        total = int(session.get('total_chunks', 0))
        if index < 0 or index >= total:
            raise ValueError('上传分片序号无效')
        if not isinstance(payload, str) or not payload or len(payload) > 1024 * 1024:
            raise ValueError('上传分片为空或过大')
        # Every non-final slice must be independently decodable. The app uses 256 KiB,
        # which is divisible by 4; enforcing this also prevents ambiguous recovery.
        if index < total - 1 and len(payload) % 4:
            raise ValueError('非末尾分片长度必须为 4 的倍数')
        try:
            raw = base64.b64decode(payload, validate=True)
        except Exception as e:
            raise ValueError(f'上传分片解码失败: {e}')
        if not raw:
            raise ValueError('上传分片为空')

        cp = _chunk_path(uid, index)
        payload_bytes = payload.encode('ascii')
        if index < expected:
            # Lost responses are safe: acknowledge only if the committed chunk is byte-identical.
            if not cp.is_file() or cp.read_bytes() != payload_bytes:
                raise ValueError(f'分片 {index} 重试内容不一致，请重新选择图片')
            return {'id':uid, 'next_index':expected, 'raw_size':int(session.get('raw_size',0)), 'duplicate':True}
        if index != expected:
            raise ValueError(f'分片顺序错误：期望 {expected}，收到 {index}')

        tmp = UPLOAD_DIR / f'{uid}.chunk{index:04d}.{uuid.uuid4().hex}.tmp'
        try:
            with tmp.open('wb') as f:
                f.write(payload_bytes); f.flush(); os.fsync(f.fileno())
            os.replace(tmp, cp)
        finally:
            try: tmp.unlink(missing_ok=True)
            except Exception: pass

        session = _reconcile_upload_session(session)
        if int(session.get('raw_size', 0)) > 40 * 1024 * 1024:
            cp.unlink(missing_ok=True)
            session = _reconcile_upload_session(session)
            _atomic_write_json(_session_path(uid), session)
            raise ValueError('图片超过 40MB')
        _atomic_write_json(_session_path(uid), session)
        return {'id':uid, 'next_index':session['next_index'], 'raw_size':session['raw_size']}


def _finalize_chunk_upload(uid):
    lock = _upload_lock(uid)
    try:
        with lock:
            session = _load_upload_session(uid)
            if not session:
                meta = _load_upload(uid)
                if meta:
                    return meta
                raise ValueError('上传会话已失效，请重新选择图片')
            session = _reconcile_upload_session(session)
            if int(session.get('next_index',0)) != int(session.get('total_chunks',0)):
                raise ValueError('参考图尚未上传完整')
            if int(session.get('chars_received',0)) != int(session.get('total_chars',0)):
                raise ValueError('参考图上传字符数校验失败，请重试')

            mime = str(session.get('mime') or 'image/png').lower()
            ext = 'jpg' if 'jpeg' in mime else ('webp' if 'webp' in mime else 'png')
            path = UPLOAD_DIR / f'{uid}.{ext}'
            tmp = UPLOAD_DIR / f'{uid}.{ext}.{uuid.uuid4().hex}.tmp'
            raw_size = 0
            digest = hashlib.sha256()
            try:
                with tmp.open('wb') as out:
                    for i in range(int(session['total_chunks'])):
                        payload = _chunk_path(uid, i).read_bytes()
                        raw = base64.b64decode(payload, validate=True)
                        raw_size += len(raw)
                        if raw_size > 40 * 1024 * 1024:
                            raise ValueError('图片超过 40MB')
                        digest.update(raw); out.write(raw)
                    out.flush(); os.fsync(out.fileno())
                if raw_size <= 0:
                    raise ValueError('图片为空')
                if raw_size != int(session.get('raw_size', raw_size)):
                    raise ValueError('参考图原始字节数校验失败，请重试')
                os.replace(tmp, path)
            finally:
                try: tmp.unlink(missing_ok=True)
                except Exception: pass

            meta = {
                'id':uid, 'path':str(path), 'mime':mime,
                'kind':str(session.get('kind') or 'image')[:32],
                'created_at':now(), 'size':raw_size, 'sha256':digest.hexdigest(),
            }
            _atomic_write_json(UPLOAD_DIR / f'{uid}.json', meta)
            try: _session_path(uid).unlink(missing_ok=True)
            except Exception: pass
            for i in range(int(session['total_chunks'])):
                try: _chunk_path(uid, i).unlink(missing_ok=True)
                except Exception: pass
            try: _part_path(uid).unlink(missing_ok=True)
            except Exception: pass
            return meta
    finally:
        _drop_upload_lock(uid)

def _load_upload(uid):
    if not re.fullmatch(r'[a-f0-9]{32}', str(uid or '')): return None
    mp = UPLOAD_DIR / f'{uid}.json'
    if not mp.exists(): return None
    try:
        meta=json.loads(mp.read_text('utf-8')); path=Path(meta['path'])
        return meta if path.exists() and path.is_file() else None
    except Exception: return None


def _delete_upload(uid):
    if not re.fullmatch(r'[a-f0-9]{32}', str(uid or '')): return
    lock = _upload_lock(uid)
    try:
        with lock:
            meta=_load_upload(uid)
            if meta:
                try: Path(meta['path']).unlink(missing_ok=True)
                except Exception: pass
            for fp in list(UPLOAD_DIR.glob(f'{uid}*')):
                try:
                    if fp.is_file(): fp.unlink(missing_ok=True)
                except Exception: pass
    finally:
        _drop_upload_lock(uid)


def _cleanup_stale_uploads(cutoff=None):
    cutoff = now() - UPLOAD_TTL if cutoff is None else float(cutoff)
    stale_uids = set()
    for fp in list(UPLOAD_DIR.iterdir()):
        try:
            if not fp.is_file() or fp.stat().st_mtime >= cutoff:
                continue
            m = re.match(r'^([a-f0-9]{32})(?:\.|$)', fp.name)
            if m:
                stale_uids.add(m.group(1))
            else:
                fp.unlink(missing_ok=True)
        except Exception as e:
            log(f'upload janitor inspect failed {fp.name}: {e}')
    for uid in stale_uids:
        try:
            _delete_upload(uid)
        except Exception as e:
            log(f'upload janitor cleanup failed {uid}: {e}')
    return len(stale_uids)


def _copy_upload_to_job(uid, jid, key):
    meta=_load_upload(uid)
    if not meta: raise ValueError(f'上传图片已失效，请重新选择图片 ({key})')
    src=Path(meta['path']); dst=JOB_UPLOAD_DIR / f'{jid}_{key}{src.suffix.lower() or ".png"}'
    import shutil; shutil.copyfile(src, dst)
    return str(dst), meta.get('mime','image/png')


def _materialize_job_uploads(req, jid):
    req=dict(req); created=[]
    try:
        for token_key,file_key,mime_key in (('image_id','image_file','image_mime'),('person_id','person_file','person_mime'),('pose_id','pose_file','pose_mime')):
            uid=req.pop(token_key, None)
            if uid:
                path,mime=_copy_upload_to_job(uid,jid,file_key.replace('_file',''))
                created.append(path); req[file_key]=path; req[mime_key]=mime
        return req
    except Exception:
        for path in created:
            try: Path(path).unlink(missing_ok=True)
            except Exception: pass
        raise


def _file_data_url(path, mime='image/png'):
    p=Path(str(path or '')).resolve(); base=JOB_UPLOAD_DIR.resolve()
    if base not in p.parents or not p.is_file(): raise ValueError('任务参考图临时文件不存在')
    return f'data:{mime};base64,' + base64.b64encode(p.read_bytes()).decode('ascii')


def _cleanup_job_uploads(req):
    for key in ('image_file','person_file','pose_file'):
        val=(req or {}).get(key)
        if not val: continue
        try:
            p=Path(str(val)).resolve(); base=JOB_UPLOAD_DIR.resolve()
            if base in p.parents: p.unlink(missing_ok=True)
        except Exception: pass

def load_jobs():
    if not STATE.exists():
        return
    try:
        data = json.loads(STATE.read_text('utf-8')).get('jobs', [])
        with JOBS_LOCK:
            for j in data[-160:]:
                if not isinstance(j, dict) or not j.get('id'):
                    continue
                # A queued image-reference task cannot be rebuilt after a process crash because its
                # upload bytes are intentionally never persisted. Fail clearly instead of guessing.
                req = j.get('request') or {}
                mode = req.get('mode', 'txt')
                age = max(0, now() - float(j.get('created_at') or now()))
                if j.get('status') == 'queued' and mode in ('img','ref','pp'):
                    needed = ('image_file',) if mode in ('img','ref') else ('person_file','pose_file')
                    refs_ok = all((j.get('request') or {}).get(k) and Path((j.get('request') or {}).get(k)).is_file() for k in needed)
                    if not refs_ok:
                        j['status'] = 'failed'; j['stage'] = 'failed'; j['error'] = '任务服务重启时参考图临时文件已不可用'
                        j['suggestion'] = '请重新选择本地参考图后重试；WAI Pad 不会把参考图长期留在 AutoDL。'; j['completed_at'] = now()
                if j.get('status') == 'claimed' and not j.get('prompt_id') and not j.get('comfy_client_id'):
                    j['status']='queued'; j['stage']='queued'; j['detail']='服务重启后重新进入安全队列'
                if j.get('status') == 'queued' and age > OUTPUT_TTL:
                    j['status'] = 'failed'; j['stage'] = 'failed'; j['error'] = '超过 72 小时仍未开始的旧排队任务已释放'
                    j['suggestion'] = '请重新提交。参考图临时文件不会无限期保留。'; j['completed_at'] = now()
                JOBS[j['id']] = j
        log(f'restored {len(JOBS)} jobs from state')
    except Exception as e:
        log(f'load jobs state failed: {e}')


def append_history(job):
    clean = public_job(job, include_request=True)
    clean.pop('result', None)
    try:
        with HISTORY.open('a', encoding='utf-8') as f:
            f.write(json.dumps(clean, ensure_ascii=False) + '\n')
    except Exception:
        pass


def update_job(job_id, transient=False, **kw):
    with JOBS_LOCK:
        j = JOBS.get(job_id)
        if not j: return
        j.update(kw); j['updated_at'] = now()
    if transient:
        STATE_DIRTY.set()
    else:
        persist_jobs()


def state_flush_loop():
    while True:
        STATE_DIRTY.wait(2.0)
        STATE_DIRTY.clear()
        persist_jobs()


def public_job(j, include_request=False):
    keys = ['id','status','stage','progress','detail','error','suggestion','created_at','started_at','updated_at','completed_at','prompt_id','result','attempt','acked_local','local_saved','remote_cleanup_pending','remote_deleted','remote_expired','positive','negative','seed','steps','cfg','note']
    out = {k:j.get(k) for k in keys if k in j}
    if include_request:
        req = dict(j.get('request') or {})
        for k in ('image','person','pose'):
            if k in req: req[k] = '<local-image-upload>'
        for k in ('image_file','person_file','pose_file','image_mime','person_mime','pose_mime'):
            req.pop(k, None)
        out['request'] = req
    return out


def json_req(url, method='GET', data=None, timeout=20):
    body = None
    headers = {'Content-Type':'application/json'}
    if data is not None:
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
    req = request.Request(url, data=body, method=method, headers=headers)
    with request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def raw_req(url, method='GET', data=None, timeout=30, headers=None):
    req = request.Request(url, data=data, method=method, headers=headers or {})
    with request.urlopen(req, timeout=timeout) as r:
        return r.read(), r.headers.get('Content-Type','application/octet-stream'), r.status


def is_up(url):
    try:
        raw_req(url, timeout=3)
        return True
    except Exception:
        return False


def shell(cmd, timeout=120):
    try:
        p = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout + p.stderr)[-8000:]
    except Exception as e:
        return 124, str(e)


def repair_services(reason='health check', level='safe'):
    log(f'repair requested level={level}: {reason}')
    result = maintenance.repair(eng, level=level, active_job=bool(CURRENT.get('pid')), reason=reason)
    actions = result.get('actions') or []
    text = result.get('summary','')
    for a in actions:
        text += f"\n[{a.get('action','repair')}] {'OK' if a.get('ok') else 'WARN'}\n{a.get('output','')[-1200:]}"
    return bool(result.get('ok')), text


def ensure_ready():
    if is_up(eng.COMFY + '/system_stats'):
        return True, 'ComfyUI 在线'
    return repair_services('ComfyUI offline before job')


def classify_error(text):
    low = (text or '').lower()
    if 'out of memory' in low or 'cuda oom' in low:
        return '显存不足。WAI Pad 已停止当前任务；建议减小尺寸或一次只生成 1 张。'
    if 'ipadapter' in low and ('not found' in low or 'missing' in low):
        return '人物参考模型缺失。自动修复未能补齐时，请在“控制台 → 依赖检查”查看缺失项。'
    if 'dwpose' in low or 'pose' in low and 'not found' in low:
        return '动作预处理依赖异常。WAI Pad 会调用现有受控 repair；仍失败再查看控制台日志。'
    if 'lora' in low and ('not found' in low or '没有安装' in low):
        return '固定画风 LoRA 缺失。为避免画风错乱，WAI Pad 不会偷偷换成未知模型。'
    if 'timed out' in low or 'timeout' in low:
        return '任务超时。可直接重试；后台守护会持续检查 ComfyUI。'
    if 'cancel' in low or '取消' in low or 'interrupted' in low:
        return '任务已取消。'
    return '已记录错误并保持旧 WAI 环境不被破坏。可点“自动修复”后重试。'


def model_exists(name, folder):
    if not name: return False
    return eng.model_file(name, folder)


def apply_advanced(wf, req):
    sampler = wf.get('3',{}).get('inputs',{})
    seed = safe_int(req.get('seed', -1), -1, 999999999999999, -1)
    if seed < 0: seed = int(time.time_ns() % 10**15)
    sampler['seed'] = seed
    default_steps = int(sampler.get('steps',28))
    sampler['steps'] = safe_int(req.get('steps', default_steps), 8, 80, default_steps)
    sampler['cfg'] = clamp(req.get('cfg', sampler.get('cfg',4.8)), 1.0, 15.0, float(sampler.get('cfg',4.8)))
    model = str(req.get('model') or '').strip()
    if model and model_exists(model,'checkpoints') and '4' in wf:
        wf['4']['inputs']['ckpt_name'] = model
    lora = str(req.get('lora') or '').strip()
    if lora and model_exists(lora,'loras') and '40' in wf:
        wf['40']['inputs']['lora_name'] = lora
    return seed, sampler['steps'], sampler['cfg']


def build_workflow(req, inputs):
    mode = req.get('mode','txt')
    rawp = str(req.get('prompt','')).strip()
    if not rawp: raise ValueError('请输入提示词/描述')
    prepare_mode = 'person_pose' if mode == 'pp' else mode
    p, neg, note = eng.prompt_prepare(rawp, req.get('negative',''), prepare_mode, req.get('prompt_mode','qwen'))
    if not eng.style_lora_ready():
        raise RuntimeError('固定画风 LoRA 还没有安装')
    if mode == 'txt':
        wf = eng.txt_wf(p, neg, safe_int(req.get('width',1024),512,2048,1024), safe_int(req.get('height',1344),512,2048,1344))
    elif mode == 'img':
        if not req.get('image') and not req.get('image_file'): raise ValueError('请上传原图')
        src = req.get('image') or _file_data_url(req.get('image_file'), req.get('image_mime','image/png'))
        name = eng.upload_dataurl(src); inputs.append(name)
        wf = eng.img_wf(p, neg, name, clamp(req.get('denoise',.58),.20,.90,.58))
    elif mode == 'ref':
        if not req.get('image') and not req.get('image_file'): raise ValueError('请上传人物参考图')
        if not eng.nodes_ready('IPAdapterUnifiedLoader','IPAdapterAdvanced','PrepImageForClipVision') or not eng.ip_models_ready():
            raise RuntimeError('人物参考依赖不完整')
        src = req.get('image') or _file_data_url(req.get('image_file'), req.get('image_mime','image/png'))
        name = eng.upload_dataurl(src); inputs.append(name)
        wf = eng.ref_wf(p, neg, name, safe_int(req.get('width',1024),512,2048,1024), safe_int(req.get('height',1344),512,2048,1344), bool(req.get('style_lock', True)))
    elif mode == 'pp':
        if (not req.get('person') and not req.get('person_file')) or (not req.get('pose') and not req.get('pose_file')): raise ValueError('人物图和动作图都要上传')
        if not eng.nodes_ready('IPAdapterUnifiedLoader','IPAdapterAdvanced','IPAdapterModelLoader','CLIPVisionLoader','PrepImageForClipVision','DWPreprocessor','DepthAnythingV2Preprocessor','ControlNetLoader','ControlNetApplyAdvanced') or not eng.ip_models_ready() or not eng.model_file(eng.OPENPOSE_NAME,'controlnet') or not eng.depth_ready() or not eng.composition_ready():
            raise RuntimeError('人物+动作增强依赖不完整')
        person_src = req.get('person') or _file_data_url(req.get('person_file'), req.get('person_mime','image/png'))
        pose_src = req.get('pose') or _file_data_url(req.get('pose_file'), req.get('pose_mime','image/png'))
        person = eng.upload_dataurl(person_src); pose = eng.upload_dataurl(pose_src); inputs.extend([person,pose])
        w,h = eng.fit_pose_dims(req.get('pose_width'), req.get('pose_height'))
        wf = eng.person_pose_wf(p, neg, person, pose, w, h, bool(req.get('strict',False)), bool(req.get('style_lock', True)))
    else:
        raise ValueError('未知生成模式')
    seed, steps, cfg = apply_advanced(wf, req)
    return wf, p, neg, note, seed, steps, cfg


def queue_prompt(wf, client_id):
    return eng.jreq(eng.COMFY + '/prompt','POST',{'prompt':wf,'client_id':client_id},30)['prompt_id']


def _recv_exact(sock, n):
    b = bytearray()
    while len(b) < n:
        x = sock.recv(n-len(b))
        if not x: raise ConnectionError('websocket closed')
        b.extend(x)
    return bytes(b)


def _send_ws_frame(sock, opcode, payload=b''):
    # Client frames must be masked.
    mask = os.urandom(4); n = len(payload); head = bytearray([0x80 | opcode])
    if n < 126: head.append(0x80 | n)
    elif n < 65536: head.extend([0x80 | 126]); head.extend(struct.pack('!H',n))
    else: head.extend([0x80 | 127]); head.extend(struct.pack('!Q',n))
    masked = bytes(payload[i] ^ mask[i%4] for i in range(n))
    sock.sendall(bytes(head)+mask+masked)


def _prompt_id_from_record(record):
    if isinstance(record, (list, tuple)) and len(record) > 1:
        return str(record[1])
    if isinstance(record, dict) and record.get('prompt_id'):
        return str(record['prompt_id'])
    return None


def comfy_prompt_state(pid):
    """Return running/pending/finished/not_found/unknown without mutating ComfyUI."""
    if not pid: return 'not_found'
    pid=str(pid)
    try:
        q=eng.jreq(eng.COMFY + '/queue', timeout=10)
        running={_prompt_id_from_record(x) for x in (q.get('queue_running') or [])}
        pending={_prompt_id_from_record(x) for x in (q.get('queue_pending') or [])}
        if pid in running: return 'running'
        if pid in pending: return 'pending'
        try:
            h=eng.jreq(eng.COMFY + f'/history/{pid}',timeout=8).get(pid)
            if h: return 'finished'
        except Exception:
            if not is_up(eng.COMFY + '/system_stats'): return 'unknown'
        return 'not_found'
    except Exception as e:
        log(f'prompt state {pid} failed: {e}')
        return 'unknown'


def cancel_comfy_prompt(pid):
    """Cancel exactly one prompt, with an atomic Comfy endpoint when available.

    New ComfyUI releases expose /api/jobs/{id}/cancel, whose server-side implementation
    atomically verifies the running id before interrupting.  Older installations fall back
    to queue deletion for pending prompts and a narrowly guarded legacy interrupt.
    """
    if not pid: return 'missing'
    pid=str(pid)
    # Preferred path: atomic inside ComfyUI, avoiding the queue-snapshot -> /interrupt race.
    try:
        out=eng.jreq(eng.COMFY + f'/api/jobs/{parse.quote(pid, safe="")}/cancel','POST',{},8)
        if isinstance(out,dict):
            return 'cancelled' if out.get('cancelled') else 'finished_or_missing'
    except Exception as e:
        # 404/unsupported is expected on older ComfyUI versions. Keep compatibility.
        log(f'atomic cancel unavailable for {pid}, using legacy-safe fallback: {e}')
    try:
        q=eng.jreq(eng.COMFY + '/queue', timeout=10)
        running={_prompt_id_from_record(x) for x in (q.get('queue_running') or [])}
        pending={_prompt_id_from_record(x) for x in (q.get('queue_pending') or [])}
        if pid in pending:
            eng.jreq(eng.COMFY + '/queue','POST',{'delete':[pid]},10)
            # It may have moved from pending to running between snapshot and delete. Recheck.
            q2=eng.jreq(eng.COMFY + '/queue', timeout=6)
            running2={_prompt_id_from_record(x) for x in (q2.get('queue_running') or [])}
            if pid not in running2: return 'dequeued'
            running=running2
        if pid in running:
            # Legacy ComfyUI has only a global interrupt. Recheck immediately before firing;
            # this cannot be perfectly atomic, but makes the fallback as narrow as possible.
            q2=eng.jreq(eng.COMFY + '/queue', timeout=6)
            running2={_prompt_id_from_record(x) for x in (q2.get('queue_running') or [])}
            if pid not in running2: return 'finished_or_moved'
            eng.raw(eng.COMFY + '/interrupt','POST',b'',5)
            return 'interrupted_legacy'
        try:
            h=eng.jreq(eng.COMFY + f'/history/{pid}',timeout=8).get(pid)
            if h: return 'finished'
        except Exception: pass
        return 'not_found'
    except Exception as e:
        log(f'targeted cancel {pid} failed: {e}')
        return 'unknown'


def cleanup_prompt_outputs(pid):
    """Best-effort privacy cleanup when a cancel races with prompt completion."""
    if not pid: return
    try:
        h=eng.jreq(eng.COMFY + f'/history/{pid}',timeout=10).get(str(pid)) or {}
        for out in (h.get('outputs') or {}).values():
            for m in (out.get('images') or []):
                cleanup_output({'filename':m.get('filename',''),'subfolder':m.get('subfolder',''),'type':m.get('type','output')})
    except Exception as e:
        log(f'cancel output cleanup deferred {pid}: {e}')


class ComfyUnavailable(RuntimeError):
    pass


def websocket_monitor(client_id, job_id, stop_evt, ready_evt):
    sock = None
    try:
        key = base64.b64encode(os.urandom(16)).decode()
        sock = socket.create_connection(('127.0.0.1', int(eng.CFG.get('comfy_port',6006))), timeout=5)
        req = (f'GET /ws?clientId={parse.quote(client_id)} HTTP/1.1\r\nHost: 127.0.0.1\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n')
        sock.sendall(req.encode('ascii'))
        header = b''
        while b'\r\n\r\n' not in header and len(header)<8192: header += sock.recv(1024)
        if b' 101 ' not in header.split(b'\r\n',1)[0]: raise ConnectionError('websocket handshake failed')
        sock.settimeout(2)
        ready_evt.set()
        while not stop_evt.is_set():
            try:
                h = _recv_exact(sock,2)
            except socket.timeout:
                continue
            b1,b2 = h; opcode=b1 & 0x0f; n=b2 & 0x7f
            if n==126: n=struct.unpack('!H',_recv_exact(sock,2))[0]
            elif n==127: n=struct.unpack('!Q',_recv_exact(sock,8))[0]
            masked=bool(b2 & 0x80); mask=_recv_exact(sock,4) if masked else None
            payload=_recv_exact(sock,n) if n else b''
            if masked and mask: payload=bytes(payload[i]^mask[i%4] for i in range(len(payload)))
            if opcode==8: break
            if opcode==9: _send_ws_frame(sock,10,payload); continue
            if opcode!=1: continue
            try: msg=json.loads(payload.decode('utf-8'))
            except Exception: continue
            typ=msg.get('type'); data=msg.get('data') or {}
            pid=data.get('prompt_id')
            with JOBS_LOCK:
                j=JOBS.get(job_id)
                expected=j.get('prompt_id') if j else None
            if pid and expected and pid != expected: continue
            if typ=='progress':
                value=safe_int(data.get('value'),0,100000,0); maximum=max(1,safe_int(data.get('max'),1,100000,1))
                pct=min(92, 18 + int(72*value/maximum))
                update_job(job_id,transient=True,status='running',stage='sampling',progress=pct,detail=f'采样 {value}/{maximum}')
            elif typ=='executing':
                node=str(data.get('node')) if data.get('node') is not None else ''
                if node=='3': update_job(job_id,transient=True,status='running',stage='sampling',progress=max(18,JOBS.get(job_id,{}).get('progress',18)),detail='开始采样')
                elif node=='8': update_job(job_id,transient=True,status='running',stage='decoding',progress=94,detail='VAE 解码')
                elif node=='9': update_job(job_id,transient=True,status='running',stage='saving',progress=97,detail='生成结果准备中')
                elif node in ('31','34'): update_job(job_id,transient=True,status='running',stage='preprocessing',progress=12,detail='动作骨架 / Depth 预处理')
            elif typ in ('execution_error','execution_interrupted'):
                update_job(job_id,transient=True,detail='ComfyUI 返回执行异常')
    except Exception as e:
        log(f'ws monitor {job_id}: {e}')
        ready_evt.set()
    finally:
        try:
            if sock: sock.close()
        except Exception: pass


def wait_result(pid, job_id, timeout=900):
    start=now(); history_failures=0
    while now()-start < timeout:
        with JOBS_LOCK:
            j=JOBS.get(job_id) or {}
            cancel_requested=bool(j.get('cancel_requested'))
        if cancel_requested:
            action=cancel_comfy_prompt(pid)
            if action=='unknown':
                update_job(job_id,transient=True,stage='cancelling',detail='取消请求已记录；ComfyUI 暂不可达，保留任务并等待确认')
                if not is_up(eng.COMFY + '/system_stats'):
                    raise ComfyUnavailable('取消请求等待 ComfyUI 恢复确认')
                time.sleep(1.0); continue
            if action in ('finished','finished_or_missing','finished_or_moved'):
                cleanup_prompt_outputs(pid)
            raise RuntimeError('任务已取消')
        try:
            h=eng.jreq(eng.COMFY + f'/history/{pid}',timeout=15).get(pid)
            history_failures=0
        except Exception as e:
            history_failures += 1
            if history_failures in (1,4,8):
                update_job(job_id,transient=True,stage='recovering',detail=f'ComfyUI 状态查询暂时失败，自动等待恢复 ({history_failures})')
                log(f'history transient {job_id}/{pid} #{history_failures}: {e}')
            # Do not kill a possibly healthy sampler because one HTTP request failed. Only when
            # the history endpoint repeatedly fails AND Comfy's own health endpoint is also down
            # do we declare the prompt unrecoverable and permit core repair.
            if history_failures >= 8 and not is_up(eng.COMFY + '/system_stats'):
                raise ComfyUnavailable('ComfyUI 连续不可达，活动 prompt 已无法继续')
            time.sleep(min(3.0, 0.6 + history_failures * 0.25)); continue
        if h:
            err=eng.extract_error(h)
            if err: raise RuntimeError(err)
            for out in h.get('outputs',{}).values():
                for m in out.get('images',[]) or []:
                    return {'filename':m['filename'],'subfolder':m.get('subfolder',''),'type':m.get('type','output')}
            if h.get('status',{}).get('completed'): raise RuntimeError('任务完成但没有返回图片')
        time.sleep(1)
    cancel_comfy_prompt(pid)
    raise TimeoutError('生成超过 15 分钟，已定向停止当前 WAI prompt')


def safe_remote_path(root, subfolder, filename):
    root=root.resolve(); sub=(subfolder or '').replace('\\','/').strip('/')
    if '..' in sub.split('/'): return None
    target=(root / sub / Path(filename).name).resolve()
    try: target.relative_to(root)
    except ValueError: return None
    return target


def cleanup_output(meta):
    if not meta or not meta.get('filename'): return True
    candidates=[]; failed=False
    for root in [Path('/root/ComfyUI/output'),Path('/root/autodl-tmp/ComfyUI/output')]:
        p=safe_remote_path(root,meta.get('subfolder',''),meta.get('filename',''))
        if p: candidates.append(p)
    if not candidates: return False
    for p in candidates:
        if p.is_file():
            try: p.unlink(); log(f'purged remote output {p}')
            except Exception as e: failed=True; log(f'purge output failed {p}: {e}')
    if failed: return False
    return not any(p.is_file() for p in candidates)


def cleanup_inputs(names):
    """Delete only WAI-owned Comfy input filenames and report whether cleanup is complete."""
    failed=False
    for name in names or []:
        for root in [Path('/root/ComfyUI/input'),Path('/root/autodl-tmp/ComfyUI/input')]:
            p=safe_remote_path(root,'',name)
            if p and p.is_file():
                try: p.unlink(); log(f'purged remote input {p.name}')
                except Exception as e: failed=True; log(f'purge input failed: {e}')
    if failed: return False
    for name in names or []:
        for root in [Path('/root/ComfyUI/input'),Path('/root/autodl-tmp/ComfyUI/input')]:
            p=safe_remote_path(root,'',name)
            if p and p.is_file(): return False
    return True


def result_bytes(meta):
    qs=parse.urlencode({'filename':meta['filename'],'subfolder':meta.get('subfolder',''),'type':meta.get('type','output')})
    return eng.raw(eng.COMFY + '/view?' + qs, timeout=120)


def run_job(job_id):
    with JOBS_LOCK:
        j=JOBS[job_id]
        req=dict(j.get('request') or {})
        if j.get('cancel_requested'):
            update_job(job_id,status='cancelled',stage='cancelled',progress=0,completed_at=now())
            _cleanup_job_uploads(req)
            append_history(JOBS[job_id])
            return
        j['status']='running'; j['stage']='preparing'; j['progress']=3; j['started_at']=now(); j['attempt']=1
    CURRENT['id']=job_id; inputs=[]; stop_evt=threading.Event(); ready_evt=threading.Event(); ws_thread=None
    try:
        good,note=ensure_ready()
        if not good: raise RuntimeError(note or 'ComfyUI 无法恢复')
        update_job(job_id,detail='环境正常，正在准备提示词',progress=6)
        wf,pos,neg,pnote,seed,steps,cfg=build_workflow(req,inputs)
        # Once ComfyUI input files exist, the WAI Pad staging copies are no longer needed even if
        # the companion later crashes. This reduces privacy exposure without touching Comfy inputs
        # that a pending/running prompt still owns.
        _cleanup_job_uploads(req)
        # Reference uploads are ephemeral: after ComfyUI input files are created, release the huge
        # base64 strings from job memory immediately.
        with JOBS_LOCK:
            stored_req = JOBS[job_id].get('request') or {}
            for _k in ('image','person','pose'):
                if _k in stored_req: stored_req[_k] = '<ephemeral-upload-removed>'
        persist_jobs()
        # Cancellation during prompt preparation must not enqueue a prompt just to cancel it later.
        with JOBS_LOCK:
            if (JOBS.get(job_id) or {}).get('cancel_requested'):
                raise RuntimeError('任务已取消')
        client_id='waipad-'+uuid.uuid4().hex
        # Persist the Comfy client id and uploaded input names BEFORE /prompt. If this
        # process dies after Comfy accepts the prompt but before prompt_id is saved,
        # startup can rediscover the exact prompt instead of duplicating or orphaning it.
        update_job(job_id,stage='submitting',progress=10,detail='工作流已准备，正在提交 ComfyUI',positive=pos,negative=neg,comfy_client_id=client_id,comfy_inputs=list(inputs))
        ws_thread=threading.Thread(target=websocket_monitor,args=(client_id,job_id,stop_evt,ready_evt),daemon=True); ws_thread.start(); ready_evt.wait(2.5)
        pid=queue_prompt(wf,client_id); CURRENT['pid']=pid
        update_job(job_id,prompt_id=pid,status='running',stage='queued',progress=15,detail='已进入 ComfyUI 队列',seed=seed,steps=steps,cfg=cfg)
        meta=wait_result(pid,job_id)
        update_job(job_id,status='completed',stage='completed',progress=100,detail='生成完成，等待保存到平板本机',completed_at=now(),result=meta,positive=pos,negative=neg,seed=seed,steps=steps,cfg=cfg,note=pnote)
        eng.hist({'time':datetime.now().isoformat(),'mode':req.get('mode'),'prompt_mode':req.get('prompt_mode'),'raw':req.get('prompt'),'positive':pos,'negative':neg,'file':meta.get('filename'),'seed':seed,'source':'wai-pad'})
        append_history(JOBS[job_id])
    except Exception as e:
        text=f'{type(e).__name__}: {e}'; cancelled='取消' in text or 'interrupted' in text.lower(); preserve_prompt=False
        if cancelled:
            update_job(job_id,status='cancelled',stage='cancelled',progress=0,error='任务已取消',suggestion='可以重新提交。',completed_at=now())
        elif isinstance(e, ComfyUnavailable):
            # Do not restart ComfyUI from the job worker while prompt ownership still exists.
            # Persist/requeue it; guard.sh owns slow, locked core recovery after sustained failure.
            preserve_prompt=True
            update_job(job_id,status='repairing',stage='recovering',detail='ComfyUI 持续不可达；保留活动任务与输入，等待守护安全恢复后重新接管',error=text)
            time.sleep(1.5); WORK_Q.put(job_id)
        else:
            # /prompt may have been accepted even if its HTTP response was lost.  If we have a
            # persisted client_id, defer the decision to recover_job, which searches Comfy's queue
            # and history. Never delete Comfy input files while ownership is uncertain.
            with JOBS_LOCK:
                cur=dict(JOBS.get(job_id) or {})
            pid=CURRENT.get('pid') or cur.get('prompt_id')
            client_id=cur.get('comfy_client_id')
            if not pid and client_id:
                pid=_find_prompt_id_by_client_id(client_id)
                if pid:
                    CURRENT['pid']=pid; update_job(job_id,prompt_id=pid)
            state=comfy_prompt_state(pid) if pid else ('unknown' if client_id else 'not_found')
            if client_id and state in ('running','pending','unknown'):
                preserve_prompt=True
                update_job(job_id,status='running',stage='recovering',detail='提交/状态响应中断，保留输入并重新接管 ComfyUI 任务',error=None,suggestion=None)
                WORK_Q.put(job_id)
                log(f'job {job_id} preserved after transient error: {text}; prompt={pid} state={state}')
            elif client_id and not pid:
                # Give recover_job one authoritative client_id lookup cycle before declaring a
                # missing prompt. This covers a lost /prompt response with delayed queue visibility.
                preserve_prompt=True
                update_job(job_id,status='submitting',stage='recovering',detail='提交响应丢失，正在按 client_id 查找 ComfyUI 任务',error=None,suggestion=None)
                WORK_Q.put(job_id)
            else:
                update_job(job_id,status='failed',stage='failed',progress=0,error=text,suggestion=classify_error(text),completed_at=now())
        if not preserve_prompt:
            append_history(JOBS[job_id]); log(f'job {job_id} failed: {text}')
    finally:
        stop_evt.set()
        # Preserve Comfy input files if a prompt may still be queued/running. recover_job owns
        # their eventual cleanup. Staging JOB_UPLOAD files are always safe to remove after build.
        try:
            with JOBS_LOCK: final_status=(JOBS.get(job_id) or {}).get('status')
            if final_status not in ('running','submitting','repairing'):
                if cleanup_inputs(inputs): update_job(job_id,comfy_inputs=[])
        finally:
            _cleanup_job_uploads(req); CURRENT['id']=None; CURRENT['pid']=None


def _prompt_record_client_id(record):
    """Extract ComfyUI client_id from queue/history prompt records across versions."""
    if isinstance(record, dict):
        cid = record.get('client_id')
        if isinstance(cid, str) and cid:
            return cid
        extra = record.get('extra_data')
        if isinstance(extra, dict):
            cid = extra.get('client_id')
            if isinstance(cid, str) and cid:
                return cid
        prompt = record.get('prompt')
        if prompt is not None:
            found = _prompt_record_client_id(prompt)
            if found: return found
    elif isinstance(record, (list, tuple)):
        # Current ComfyUI queue/history records normally keep extra_data at index 3.
        if len(record) > 3 and isinstance(record[3], dict):
            cid = record[3].get('client_id')
            if isinstance(cid, str) and cid:
                return cid
        for item in record:
            if isinstance(item, (dict, list, tuple)):
                found = _prompt_record_client_id(item)
                if found: return found
    return None


def _find_prompt_id_by_client_id(client_id):
    if not client_id:
        return None
    try:
        q = eng.jreq(eng.COMFY + '/queue', timeout=10)
        for key in ('queue_running','queue_pending'):
            for rec in q.get(key, []) or []:
                if _prompt_record_client_id(rec) == client_id:
                    if isinstance(rec, (list, tuple)) and len(rec) > 1:
                        return str(rec[1])
                    if isinstance(rec, dict) and rec.get('prompt_id'):
                        return str(rec['prompt_id'])
    except Exception as e:
        log(f'prompt recovery queue lookup failed: {e}')
    try:
        hist = eng.jreq(eng.COMFY + '/history', timeout=15)
        if isinstance(hist, dict):
            # Newest first where insertion order is preserved; cap work for long histories.
            for pid, rec in list(hist.items())[-300:][::-1]:
                if _prompt_record_client_id(rec) == client_id:
                    return str(pid)
    except Exception as e:
        log(f'prompt recovery history lookup failed: {e}')
    return None


def recover_job(job_id):
    """Recover a prompt that ComfyUI accepted before companion/network restarted."""
    with JOBS_LOCK:
        j = dict(JOBS.get(job_id) or {})
        pid = j.get('prompt_id')
        client_id = j.get('comfy_client_id')
        req = dict(j.get('request') or {})
        comfy_inputs = list(j.get('comfy_inputs') or [])
    CURRENT['id'] = job_id
    preserve=False
    try:
        # Cancellation is a transaction too: never delete inputs while ComfyUI's answer is
        # uncertain. Reattach by prompt/client id, confirm cancellation, then clean up.
        if j.get('cancel_requested'):
            if not pid and client_id:
                pid=_find_prompt_id_by_client_id(client_id)
                if pid: update_job(job_id,prompt_id=pid)
            if pid:
                action=cancel_comfy_prompt(pid)
                if action=='unknown':
                    preserve=True
                    update_job(job_id,status='repairing',stage='cancelling',detail='取消已记录；等待 ComfyUI 恢复后确认，不会丢失任务所有权')
                    time.sleep(2.0); WORK_Q.put(job_id); return
                if action in ('finished','finished_or_missing','finished_or_moved'):
                    cleanup_prompt_outputs(pid)
            elif client_id and not is_up(eng.COMFY + '/system_stats'):
                preserve=True
                update_job(job_id,status='repairing',stage='cancelling',detail='取消已记录；ComfyUI 暂不可达，等待恢复后确认')
                time.sleep(2.0); WORK_Q.put(job_id); return
            update_job(job_id,status='cancelled',stage='cancelled',progress=0,error='任务已取消',suggestion='可以重新提交。',completed_at=now())
            append_history(JOBS[job_id]); return

        if not pid and client_id:
            update_job(job_id,status='running',stage='recovering',detail='正在按 client_id 从 ComfyUI 队列/历史恢复任务',progress=max(12,int(j.get('progress') or 12)))
            for _ in range(8):
                pid = _find_prompt_id_by_client_id(client_id)
                if pid: break
                if not is_up(eng.COMFY + '/system_stats'):
                    time.sleep(2.0); continue
                time.sleep(1.2)
            if pid:
                update_job(job_id,prompt_id=pid,detail='已找回 ComfyUI 任务，继续等待结果')
        if not pid:
            if client_id and not is_up(eng.COMFY + '/system_stats'):
                preserve=True
                update_job(job_id,status='running',stage='recovering',detail='ComfyUI 暂不可达；保留任务输入，等待守护恢复后继续接管')
                time.sleep(2.5); WORK_Q.put(job_id); return
            update_job(job_id,status='failed',stage='failed',error='任务服务重启后未能在 ComfyUI 队列/历史中找回任务',suggestion='请重新生成；未知状态任务不会被重复提交。',completed_at=now())
            append_history(JOBS[job_id]); return
        CURRENT['pid'] = pid
        state=comfy_prompt_state(pid)
        if state=='not_found':
            update_job(job_id,status='failed',stage='failed',error='ComfyUI 中已不存在该任务',suggestion='请重新生成；WAI Pad 没有重复提交旧请求。',completed_at=now())
            append_history(JOBS[job_id]); return
        update_job(job_id,status='running',stage='recovering',detail='WAI Pad 已重新接管 AutoDL 上的生成任务',progress=max(15,int(j.get('progress') or 15)))
        meta = wait_result(pid, job_id, timeout=900)
        update_job(job_id,status='completed',stage='completed',progress=100,detail='生成完成，等待保存到平板本机',completed_at=now(),result=meta)
        append_history(JOBS[job_id])
    except Exception as e:
        text=f'{type(e).__name__}: {e}'
        if isinstance(e, ComfyUnavailable):
            preserve=True
            update_job(job_id,status='repairing',stage='recovering',detail='ComfyUI 持续不可达；保留任务所有权与输入，等待守护安全恢复',error=text)
            time.sleep(1.5); WORK_Q.put(job_id)
        else:
            state=comfy_prompt_state(CURRENT.get('pid') or pid) if (CURRENT.get('pid') or pid) else 'unknown'
            if client_id and state in ('running','pending','unknown'):
                preserve=True
                update_job(job_id,status='running',stage='recovering',detail='恢复查询暂时中断；任务输入保留，稍后继续接管',error=None,suggestion=None)
                time.sleep(1.5); WORK_Q.put(job_id)
                log(f'recover {job_id} transient: {text}; state={state}')
            else:
                update_job(job_id,status='failed',stage='failed',progress=0,error=text,suggestion=classify_error(text),completed_at=now())
                append_history(JOBS[job_id])
    finally:
        if not preserve:
            if cleanup_inputs(comfy_inputs): update_job(job_id,comfy_inputs=[])
            _cleanup_job_uploads(req)
        CURRENT['id']=None; CURRENT['pid']=None

def queue_position(job_id):
    with JOBS_LOCK:
        waiting=sorted([x for x in JOBS.values() if x.get('status')=='queued'],key=lambda x:x.get('created_at',0))
    ids=[x.get('id') for x in waiting]
    try: return ids.index(job_id)
    except ValueError: return -1


def start_worker_if_needed(reason='startup'):
    with WORKER_LOCK:
        t=WORKER.get('thread')
        if t is not None and t.is_alive(): return False
        t=threading.Thread(target=worker_loop,daemon=True,name='wai-job-worker')
        WORKER['thread']=t; t.start(); log(f'job worker started: {reason}'); return True


def worker_watchdog():
    while True:
        try:
            start_worker_if_needed('watchdog')
            with JOBS_LOCK:
                queued=sorted([x for x in JOBS.values() if x.get('status')=='queued'],key=lambda x:x.get('created_at',0))
            if queued and CURRENT.get('id') is None and WORK_Q.qsize()==0:
                WORK_Q.put(queued[0]['id']); log(f"watchdog requeued stranded job {queued[0]['id']}")
            if queued and CURRENT.get('id') is None:
                age=now()-float(queued[0].get('created_at') or now())
                if age>45:
                    update_job(queued[0]['id'],detail='队列等待异常，守护程序正在重新唤醒任务 worker')
        except Exception as e:
            log(f'worker watchdog error: {e}')
        time.sleep(3)


def worker_loop():
    while True:
        jid=WORK_Q.get()
        try:
            action=None
            with JOBS_LOCK:
                j=JOBS.get(jid)
                if not j: action='skip'
                elif j.get('status')=='queued':
                    # Atomic claim before any expensive work. Duplicate queue wakeups can no longer
                    # run a completed/claimed job twice.
                    j['status']='claimed'; j['stage']='claimed'; j['detail']='任务已领取，正在准备'; j['updated_at']=now()
                    CURRENT['id']=jid; action='run'
                elif j.get('status') in ('running','repairing','submitting'):
                    CURRENT['id']=jid; action='recover'
                else:
                    action='skip'
            if action=='run':
                persist_jobs(); run_job(jid)
            elif action=='recover':
                recover_job(jid)
        except Exception as e: log(f'worker fatal {jid}: {e}')
        finally:
            if CURRENT.get('id')==jid:
                CURRENT['id']=None; CURRENT['pid']=None
            WORK_Q.task_done()


def janitor_loop():
    while True:
        cutoff=now()-OUTPUT_TTL
        with JOBS_LOCK:
            jobs=list(JOBS.values())
        for j in jobs:
            if j.get('status')!='completed': continue
            meta=j.get('result')
            if meta and (j.get('remote_cleanup_pending') or j.get('local_saved') or j.get('acked_local')):
                if cleanup_output(meta):
                    update_job(j['id'],result=None,remote_cleanup_pending=False,remote_deleted=True,detail='本机已保存；远端临时输出已清理')
            elif meta and not j.get('local_saved') and float(j.get('completed_at') or now()) < cutoff:
                if cleanup_output(meta):
                    update_job(j['id'],result=None,remote_deleted=True,remote_expired=True,detail='未确认本机保存；远端临时输出已按 72 小时隐私 TTL 清理')
        # A process can die after persisting a terminal status but before its finally block deletes
        # Comfy input files. Keep the ownership record and retry that privacy cleanup here.
        for j in jobs:
            if j.get('status') in ('completed','failed','cancelled') and j.get('comfy_inputs'):
                if cleanup_inputs(j.get('comfy_inputs')):
                    update_job(j['id'],comfy_inputs=[])
        with JOBS_LOCK:
            # Bound ordinary terminal history, but never discard a record that still owns a remote
            # result, pending cleanup transaction, or Comfy input cleanup.
            droppable=[j for j in JOBS.values() if j.get('status') in ('completed','failed','cancelled') and not j.get('result') and not j.get('remote_cleanup_pending') and not j.get('comfy_inputs')]
            if len(droppable)>120:
                for j in sorted(droppable,key=lambda x:x.get('created_at',0))[:-120]: JOBS.pop(j['id'],None)
            owned=set()
            for j in JOBS.values():
                if j.get('status') in ('queued','claimed','running','repairing','submitting'):
                    for key in ('image_file','person_file','pose_file'):
                        val=(j.get('request') or {}).get(key)
                        if val:
                            try: owned.add(str(Path(val).resolve()))
                            except Exception: pass
        _cleanup_stale_uploads()
        for fp in list(JOB_UPLOAD_DIR.glob('*')):
            try:
                if fp.is_file() and str(fp.resolve()) not in owned and fp.stat().st_mtime < now()-6*3600:
                    fp.unlink(missing_ok=True)
            except Exception: pass
        persist_jobs(); time.sleep(300)


def gpu_status():
    rc,out=shell("nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu,temperature.gpu --format=csv,noheader,nounits | head -1",10)
    if rc!=0 or not out.strip(): return {'ok':False}
    parts=[x.strip() for x in out.strip().split(',')]
    try: return {'ok':True,'name':parts[0],'memory_used_mb':int(parts[1]),'memory_total_mb':int(parts[2]),'utilization':int(parts[3]),'temperature':int(parts[4])}
    except Exception: return {'ok':True,'raw':out.strip()}


def scan_models(folder):
    items=[]; seen=set()
    for base in [Path('/root/ComfyUI/models')/folder,Path('/root/autodl-tmp/AI_Models')/folder]:
        if not base.exists(): continue
        for p in base.rglob('*.safetensors'):
            if p.name in seen: continue
            seen.add(p.name); items.append({'name':p.name,'size_mb':round(p.stat().st_size/1024/1024,1)})
    return sorted(items,key=lambda x:x['name'].lower())


def logs_tail(lines=160):
    parts=[]
    for p in [LOG, BASE/'guard.log', Path('/root/autodl-tmp/WAI_App_v33/panel.log')]:
        if not p.exists(): continue
        try:
            txt=p.read_text('utf-8',errors='replace').splitlines()[-lines:]
            parts.append(f'===== {p.name} =====\n'+'\n'.join(txt))
        except Exception: pass
    return '\n'.join(parts)[-40000:]


class Handler(BaseHTTPRequestHandler):
    server_version='WAIPadAPI/0.3'
    def log_message(self,fmt,*args): log(fmt % args)
    def _json(self,obj,code=200):
        b=json.dumps(obj,ensure_ascii=False).encode('utf-8'); self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(b)
    def _body(self):
        n=int(self.headers.get('Content-Length','0') or 0)
        if n>80*1024*1024: raise ValueError('请求过大')
        return json.loads(self.rfile.read(n).decode('utf-8')) if n else {}
    def do_GET(self):
        path=parse.urlparse(self.path).path; qs=parse.parse_qs(parse.urlparse(self.path).query)
        if path=='/v1/health':
            panel=is_up('http://127.0.0.1:6017/api/health'); comfy=is_up(eng.COMFY+'/system_stats'); ready=panel and comfy
            return self._json({'ok':True,'ready':ready,'detail':('核心服务正常' if ready else f'Panel={panel} ComfyUI={comfy}'),'version':VERSION,'port':PORT,'queue':WORK_Q.qsize(),'current':CURRENT['id'],'worker_alive':bool(WORKER.get('thread') and WORKER['thread'].is_alive())})
        if path=='/v1/system/status':
            try: free,total=eng.disk()
            except Exception: free=total=0
            return self._json({'ok':True,'gpu':gpu_status(),'services':{'panel':is_up('http://127.0.0.1:6017/api/health'),'comfy':is_up(eng.COMFY+'/system_stats'),'qwen':bool(eng.qwen_model()),'job_api':True},'models':{'checkpoint':eng.MODEL,'style_lora':eng.active_style_lora(),'style_ready':eng.style_lora_ready(),'style_v3':eng.style_v3_ready(),'ipadapter':eng.ip_models_ready(),'pose':eng.model_file(eng.OPENPOSE_NAME,'controlnet'),'depth':eng.depth_ready(),'composition':eng.composition_ready()},'disk':{'free_gb':free,'total_gb':total},'queue':{'waiting':WORK_Q.qsize(),'current':CURRENT['id']},'privacy':{'remote_inputs_auto_purge':True,'remote_outputs_purge_after_local_ack':True}})
        if path=='/v1/system/models': return self._json({'checkpoints':scan_models('checkpoints'),'loras':scan_models('loras'),'active':{'checkpoint':eng.MODEL,'lora':eng.active_style_lora()}})
        if path=='/v1/system/diagnose': return self._json(maintenance.diagnose(eng))
        if path=='/v1/system/repairs': return self._json({'items':maintenance.repair_history(safe_int((qs.get('limit')or['20'])[0],1,100,20))})
        if path=='/v1/logs': return self._json({'text':logs_tail(safe_int((qs.get('lines')or['160'])[0],20,500,160))})
        if path=='/v1/jobs':
            limit=safe_int((qs.get('limit')or['40'])[0],1,120,40)
            client_id=str((qs.get('client_request_id')or[''])[0] or '')[:96]
            with JOBS_LOCK:
                values=sorted(JOBS.values(),key=lambda x:x['created_at'],reverse=True)
                if client_id: values=[x for x in values if x.get('client_request_id')==client_id]
                arr=[public_job(x,True) for x in values[:limit]]
            return self._json({'items':arr})
        m=re.fullmatch(r'/v1/jobs/([A-Za-z0-9_-]+)(/image)?',path)
        if m:
            jid=m.group(1)
            with JOBS_LOCK: j=JOBS.get(jid)
            if not j: return self._json({'error':'job not found'},404)
            if m.group(2):
                meta=j.get('result')
                if j.get('status')!='completed' or not meta: return self._json({'error':'image not available'},409)
                try:
                    b,ctype,_=result_bytes(meta); self.send_response(200); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(b); return
                except Exception as e: return self._json({'error':str(e)},500)
            out=public_job(j,True)
            if j.get('status')=='queued':
                pos=max(0,queue_position(jid)); out['queue_position']=pos; out['detail']=f'等待 GPU · 前面 {pos} 个任务'
            return self._json(out)
        return self._json({'error':'not found'},404)
    def do_POST(self):
        path=parse.urlparse(self.path).path
        try: d=self._body()
        except Exception as e: return self._json({'error':str(e)},400)
        if path=='/v1/images/init':
            try:
                session=_init_chunk_upload(d.get('kind','image'),d.get('mime','image/png'),d.get('total_chunks',1),d.get('total_chars',1))
                return self._json({'id':session['id'],'next_index':0,'expires_in':UPLOAD_TTL},201)
            except Exception as e:return self._json({'error':str(e)},400)
        cm=re.fullmatch(r'/v1/images/([a-f0-9]{32})/chunk',path)
        if cm:
            try:return self._json(_append_upload_chunk(cm.group(1),d.get('index',-1),d.get('data','')),200)
            except Exception as e:return self._json({'error':str(e)},400)
        fm=re.fullmatch(r'/v1/images/([a-f0-9]{32})/finalize',path)
        if fm:
            try:
                meta=_finalize_chunk_upload(fm.group(1))
                return self._json({'id':meta['id'],'size':meta['size'],'kind':meta['kind'],'expires_in':UPLOAD_TTL},201)
            except Exception as e:return self._json({'error':str(e)},400)
        if path=='/v1/images':
            # Legacy one-shot endpoint for older WAI Pad clients.
            try:
                meta=_save_upload(d.get('data'), d.get('kind','image'))
                return self._json({'id':meta['id'],'size':meta['size'],'kind':meta['kind'],'expires_in':UPLOAD_TTL},201)
            except Exception as e: return self._json({'error':str(e)},400)
        if path=='/v1/jobs':
            client_id=str(d.pop('client_request_id','') or '')[:96]
            # The idempotency lookup + materialization + insert is one critical section. A lost
            # HTTP response followed by an immediate retry can therefore never create two jobs.
            with SUBMIT_LOCK:
                if client_id:
                    with JOBS_LOCK:
                        existing=next((j for j in JOBS.values() if j.get('client_request_id')==client_id),None)
                    if existing: return self._json({'id':existing['id'],'status':existing.get('status','queued'),'deduplicated':True},200)
                jid=datetime.now().strftime('%Y%m%d_%H%M%S_')+uuid.uuid4().hex[:7]
                try: req=_materialize_job_uploads(d,jid)
                except Exception as e: return self._json({'error':str(e)},400)
                job={'id':jid,'client_request_id':client_id or None,'status':'queued','stage':'queued','progress':0,'detail':'等待 GPU','created_at':now(),'updated_at':now(),'request':req,'attempt':0,'acked_local':False,'local_saved':False,'remote_cleanup_pending':False,'remote_deleted':False,'cancel_requested':False}
                with JOBS_LOCK: JOBS[jid]=job
                persist_jobs(); start_worker_if_needed('job submit'); WORK_Q.put(jid)
                return self._json({'id':jid,'status':'queued'},202)
        m=re.fullmatch(r'/v1/jobs/([A-Za-z0-9_-]+)/ack-local',path)
        if m:
            jid=m.group(1)
            with JOBS_LOCK: j=JOBS.get(jid)
            if not j: return self._json({'error':'job not found'},404)
            meta=j.get('result')
            update_job(jid,acked_local=True,local_saved=True,remote_cleanup_pending=bool(meta),detail='已确认本机保存；正在清理 AutoDL 临时输出')
            deleted=cleanup_output(meta)
            if deleted:
                update_job(jid,result=None,remote_cleanup_pending=False,remote_deleted=True,detail='已保存到 WAI Pad 本机；AutoDL 临时输出已清理')
            else:
                update_job(jid,remote_cleanup_pending=True,remote_deleted=False,detail='已保存到本机；远端清理暂未完成，将自动重试')
            return self._json({'ok':True,'remote_deleted':deleted,'cleanup_pending':not deleted})
        if path=='/v1/prompts/optimize':
            try:
                mode='person_pose' if d.get('mode')=='pp' else d.get('mode','txt'); p,n,note=eng.prompt_prepare(d.get('prompt',''),d.get('negative',''),mode,d.get('prompt_mode','qwen')); return self._json({'positive':p,'negative':n,'note':note})
            except Exception as e: return self._json({'error':str(e)},500)
        if path=='/v1/pose/preview':
            pose_uid=str(d.get('pose_id') or '')
            pose_data=d.get('pose')
            if pose_uid:
                meta=_load_upload(pose_uid)
                if not meta: return self._json({'error':'动作参考图上传已失效，请重新选择'},400)
                try:
                    raw=Path(meta['path']).read_bytes()
                    pose_data=f"data:{meta.get('mime','image/png')};base64,"+base64.b64encode(raw).decode('ascii')
                except Exception as e: return self._json({'error':f'读取动作参考图失败: {e}'},400)
            if not pose_data: return self._json({'error':'请上传 B 动作图'},400)
            names=[]; metas=[]
            try:
                name=eng.upload_dataurl(pose_data); names.append(name); pid=eng.queue(eng.pose_preview_wf(name)); imgs=eng.wait_all_images(pid); items=[]
                for it in imgs:
                    label='DWPose 骨架' if it['node']=='91' else ('Depth 深度' if it['node']=='92' else '预览'); items.append({'label':label,'image':it['image']})
                    # filename is available; clean preview output after bytes are already in response.
                    metas.append({'filename':it.get('filename',''),'subfolder':'','type':'output'})
                return self._json({'items':items,'note':'骨架接近 B 图再正式生成；Depth 用于锁透视。'})
            except Exception as e: return self._json({'error':str(e)},500)
            finally:
                cleanup_inputs(names)
                for x in metas: cleanup_output(x)
                if pose_uid: _delete_upload(pose_uid)
        if path=='/v1/system/repair':
            level='deep' if str(d.get('level','safe')).lower()=='deep' else 'safe'
            result=maintenance.repair(eng,level=level,active_job=has_active_job(),reason='manual app repair')
            return self._json(result,200 if result.get('ok') else (423 if result.get('busy') else 409))
        if path=='/v1/system/rollback':
            if has_active_job(): return self._json({'ok':False,'busy':True,'summary':'当前有生图任务运行/恢复，先完成或确认取消后再回滚。'},423)
            result=maintenance.restore_latest(); return self._json(result,200 if result.get('ok') else 409)
        if path=='/v1/jobs/cleanup':
            removed=[]; deferred=[]
            with JOBS_LOCK:
                candidates=[dict(j) for j in JOBS.values() if j.get('status') in ('failed','cancelled')]
            for j in candidates:
                inputs_ok=cleanup_inputs(j.get('comfy_inputs') or [])
                _cleanup_job_uploads(j.get('request') or {})
                result_ok=True
                if j.get('result'): result_ok=cleanup_output(j.get('result'))
                if inputs_ok and result_ok:
                    with JOBS_LOCK: JOBS.pop(j['id'],None)
                    removed.append(j['id'])
                else:
                    deferred.append(j['id'])
            persist_jobs()
            return self._json({'ok':True,'removed':len(removed),'deferred':len(deferred)})
        return self._json({'error':'not found'},404)
    def do_DELETE(self):
        path=parse.urlparse(self.path).path
        im=re.fullmatch(r'/v1/images/([a-f0-9]{32})',path)
        if im:
            _delete_upload(im.group(1)); return self._json({'ok':True})
        m=re.fullmatch(r'/v1/jobs/([A-Za-z0-9_-]+)',path)
        if not m: return self._json({'error':'not found'},404)
        jid=m.group(1)
        with JOBS_LOCK:
            j=JOBS.get(jid)
            if not j: return self._json({'error':'job not found'},404)
            j['cancel_requested']=True; j['detail']='正在取消…'
            if j.get('status')=='queued':
                j['status']='cancelled'; j['stage']='cancelled'; j['completed_at']=now(); _cleanup_job_uploads(j.get('request') or {})
        persist_jobs()
        cancel_action='local'
        if j.get('prompt_id'):
            cancel_action=cancel_comfy_prompt(j.get('prompt_id'))
        return self._json({'ok':True,'status':('cancelled' if j.get('status')=='cancelled' else 'cancelling'),'action':cancel_action})


if __name__=='__main__':
    load_jobs()
    # Resume the previously active ComfyUI prompt first; then resume text-only queued jobs.
    with JOBS_LOCK:
        _restored = sorted(JOBS.values(), key=lambda x:x.get('created_at',0))
    for _j in _restored:
        if _j.get('status') in ('running','repairing','submitting','claimed'): WORK_Q.put(_j['id'])
    for _j in _restored:
        if _j.get('status') == 'queued': WORK_Q.put(_j['id'])
    start_worker_if_needed('startup')
    threading.Thread(target=worker_watchdog,daemon=True,name='wai-worker-watchdog').start()
    threading.Thread(target=janitor_loop,daemon=True,name='wai-job-janitor').start()
    threading.Thread(target=state_flush_loop,daemon=True,name='wai-state-flusher').start()
    log(f'WAI Pad API {VERSION} starting on {PORT}')
    ThreadingHTTPServer(('127.0.0.1',PORT),Handler).serve_forever()
