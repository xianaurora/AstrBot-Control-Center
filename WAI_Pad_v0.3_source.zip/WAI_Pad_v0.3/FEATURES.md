# WAI Pad v0.3 功能

WAI Pad 是面向安卓平板的 AutoDL AI 生图控制中枢。目标是日常使用零命令，同时保留高级 root SSH 终端。

## 自动化
- App 启动自动 SSH 连接与重连。
- 自动建立 WAI / ComfyUI / Jobs / Jupyter 隧道。
- 自动上传或更新 companion；代码未变化时不重启正在运行的任务服务。
- 服务器 guard 持续检查核心服务并执行有边界的安全恢复。

## 创作
- 文生图、图生图、人物参考、人物 + 动作。
- Qwen 中文智能 / 中文轻量 / 英文直输。
- Seed / Steps / CFG / 数量 / 图生图强度 / 动作严格模式。
- 人物 + 动作支持 DWPose 骨架和 Depth 预览。
- 异步任务队列、真实进度、取消、失败原因。

## 本地图库
- 最终成图写入 Android App 私有存储，不做云同步。
- 图片与 job_id / Prompt / Negative / Seed / Steps / CFG 等元数据绑定。
- 收藏、查看、删除、本地容量统计。
- 断线恢复时根据 job_id 去重，避免同一远端结果重复落盘。

## 修复中心（v0.3）
- 完整诊断：服务、GPU、端口、进程、磁盘和关键模型。
- 安全修复：只修明确异常，并在修复前自动创建恢复点。
- 深度修复：必须用户确认后才调用旧 WAI 的受控 repair。
- 恢复点：最多保留最近 5 个 companion/config 快照。
- 一键回滚最近恢复点。
- 修复历史可追踪。
- 正在生成时禁止会中断任务的修复。

## 高级管理
- 内置 root SSH 终端。
- 内嵌 AutoDL、JupyterLab、ComfyUI、ComfyUI Manager、旧 WAI 面板。
- 控制台查看 GPU / 显存 / 服务 / 模型 / 磁盘 / 日志。

## 修复安全边界
自动修复永远不会主动删除：
- Checkpoint / LoRA / ControlNet / IPAdapter 等模型；
- 训练图片或训练目录；
- 用户旧 WAI 工程；
- WAI Pad 平板本地图库。

## v0.3 新增可靠性
- [x] 完整诊断 / 安全修复 / 深度修复
- [x] 修复前自动恢复点、最近恢复点回滚
- [x] 生图中禁止破坏性核心重启
- [x] 有活动任务时 companion 更新自动延后
- [x] job 状态原子持久化、已有 ComfyUI prompt 重接管
- [x] 参考图 base64 不落任务状态盘
- [x] 本地图片 fsync + 原子落盘
- [x] job_id 本地图去重，ACK 失败重连不重复保存
