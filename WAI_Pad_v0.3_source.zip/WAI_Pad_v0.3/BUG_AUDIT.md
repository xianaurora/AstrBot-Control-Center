# WAI Pad v0.3 Bug Audit

本轮重点不是增加装饰功能，而是排查“会丢图 / 会中断任务 / 会误修复 / 会泄漏参考图”的高风险问题。

## 已定位并修复
1. **热更新会杀正在生成的 companion**：旧逻辑检测到代码变化就重启 `job_api.py`。v0.3 先读取 `/v1/health.current`，有活动任务时延后更新。
2. **守护可能因 Panel 单独掉线误重启整个 WAI**：v0.3 若 ComfyUI 健康且有活动任务，延后全量 restart。
3. **companion 重启后任务全丢**：v0.3 增加 `jobs_state.json` 原子状态文件，并重新接管已有 `prompt_id`。
4. **参考图 base64 长期占内存/可能落盘**：状态持久化始终脱敏；ComfyUI 上传完成后立即清掉 job 中的原始图数据。
5. **注释声称本地保存成功再 ACK，但实际 `writeBytes()` 没有 fsync**：v0.3 使用临时文件、`FileDescriptor.sync()`、原子重命名。
6. **本机保存成功但 ACK 网络失败会重复存图**：v0.3 按 `job_id` 去重，重连后只重试 ACK。
7. **新增 maintenance 模块若没上传会运行时报 ImportError**：v0.3 已纳入 RemoteBootstrap 文件清单。
8. **准备阶段 ComfyUI 离线却被“当前任务”判断阻止修复**：忙碌判断改为真实 `prompt_id`，未提交 ComfyUI 前仍可修复。

## 已通过的静态/本地测试
- Python `py_compile`: engine / job API / maintenance 全通过。
- Shell `bash -n`: bootstrap / guard 全通过。
- 前端 JS `node --check`: 通过。
- companion 最小启动测试：`/v1/health` 正常返回 0.3.0。
- job 创建与 `jobs_state.json` 落盘测试：通过。
- server 与 Android assets 中 companion 文件一致性：纳入打包检查。

## 仍必须在真机完成
- Android Gradle 实际编译。
- 目标平板 ROM 前台服务/后台保活。
- AutoDL 登录 WebView、JupyterLab 上传、ComfyUI Manager 页面兼容。
- 真实 RTX 3090 上四种生图工作流、取消、断网重连、App 被系统回收后的恢复测试。

这些项目不能仅靠静态检查冒充“已验证”。
