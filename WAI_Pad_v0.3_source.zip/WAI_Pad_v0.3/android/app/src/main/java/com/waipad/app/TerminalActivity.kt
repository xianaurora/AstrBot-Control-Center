package com.waipad.app

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.jcraft.jsch.ChannelShell
import com.jcraft.jsch.Session
import java.io.OutputStream
import java.util.concurrent.Executors

class TerminalActivity : AppCompatActivity() {
    private val exec = Executors.newCachedThreadPool()
    @Volatile private var session: Session? = null
    @Volatile private var channel: ChannelShell? = null
    @Volatile private var shellOut: OutputStream? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = SecurePrefs(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14,14,14,14); setBackgroundColor(Color.rgb(5,8,12)) }
        val header = TextView(this).apply {
            setTextColor(Color.rgb(200,210,230)); textSize = 13f
            text = "WAI Pad · 持久 SSH 终端   ${p.get("user","root")}@${p.get("host","connect.nmb2.seetacloud.com")}:${p.get("port","28823")}\n平时无需命令；这里只保留高级控制入口。"
        }
        val out = TextView(this).apply {
            setTextColor(Color.rgb(111,255,142)); textSize = 13f; typeface = Typeface.MONOSPACE
            setTextIsSelectable(true); text = "\n正在连接…\n"
        }
        val scroll = ScrollView(this).apply { addView(out); isFillViewport = true }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            hint = "输入命令…"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setSingleLine(true); isEnabled = false
        }
        val run = Button(this).apply { text = "发送"; isEnabled = false }
        val ctrlC = Button(this).apply { text = "Ctrl+C"; isEnabled = false }
        val clear = Button(this).apply { text = "清屏" }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(run); row.addView(ctrlC); row.addView(clear)
        root.addView(header)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(row)
        setContentView(root)

        fun append(s: String) = runOnUiThread {
            out.append(s); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
        fun send(text: String) {
            exec.submit {
                try { shellOut?.write(text.toByteArray(Charsets.UTF_8)); shellOut?.flush() }
                catch (e: Exception) { append("\n[ERROR] ${e.message}\n") }
            }
        }
        fun go() {
            val cmd = input.text.toString(); if (cmd.isBlank()) return
            input.setText(""); send(cmd + "\n")
        }
        run.setOnClickListener { go() }
        input.setOnEditorActionListener { _,_,_ -> go(); true }
        ctrlC.setOnClickListener { send("\u0003") }
        clear.setOnClickListener { out.text = "" }

        exec.submit {
            try {
                val s = SshClient.connect(p); session = s
                val ch = s.openChannel("shell") as ChannelShell
                ch.setPty(true); ch.setPtyType("xterm-256color", 140, 42, 0, 0)
                val inputStream = ch.inputStream
                val outputStream = ch.outputStream
                shellOut = outputStream; channel = ch
                ch.connect(10_000)
                runOnUiThread { input.isEnabled = true; run.isEnabled = true; ctrlC.isEnabled = true }
                append("[已连接，主机指纹已校验]\n")
                val buf = ByteArray(4096)
                while (!Thread.currentThread().isInterrupted && ch.isConnected) {
                    val n = inputStream.read(buf)
                    if (n < 0) break
                    if (n > 0) append(String(buf, 0, n, Charsets.UTF_8))
                }
                append("\n[连接已关闭]\n")
            } catch (e: Exception) {
                append("\n[连接失败] ${e.message}\n")
            }
        }
    }

    override fun onDestroy() {
        try { shellOut?.write("exit\n".toByteArray()); shellOut?.flush() } catch (_: Exception) {}
        try { channel?.disconnect() } catch (_: Exception) {}
        try { session?.disconnect() } catch (_: Exception) {}
        exec.shutdownNow(); super.onDestroy()
    }
}
