package com.waipad.app

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LocalImageStore(private val context: Context) {
    private val dir = File(context.filesDir, "wai_images").apply { mkdirs() }
    private val metaDir = File(context.filesDir, "wai_images_meta").apply { mkdirs() }

    private fun atomicWrite(file: File, bytes: ByteArray) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        FileOutputStream(tmp).use { out ->
            out.write(bytes)
            out.flush()
            out.fd.sync()
        }
        if (!tmp.renameTo(file)) {
            file.delete()
            if (!tmp.renameTo(file)) throw IllegalStateException("本地文件落盘失败: ${file.name}")
        }
    }

    private fun atomicWriteText(file: File, text: String) = atomicWrite(file, text.toByteArray(Charsets.UTF_8))

    private fun findByJobId(jobId: String): JSONObject? {
        if (jobId.isBlank()) return null
        metaDir.listFiles()?.filter { it.isFile && it.name.endsWith(".json") }?.forEach { mf ->
            try {
                val m = JSONObject(mf.readText(Charsets.UTF_8))
                if (m.optString("job_id") == jobId) {
                    val name = m.optString("name")
                    val f = resolve(name)
                    if (f != null) return decorate(f, m).put("deduplicated", true)
                }
            } catch (_: Exception) {}
        }
        return null
    }

    fun saveBytes(bytes: ByteArray, mime: String, suggested: String = "wai", metadata: JSONObject = JSONObject()): JSONObject {
        require(bytes.isNotEmpty()) { "图片内容为空" }
        val existing = findByJobId(metadata.optString("job_id"))
        if (existing != null) return existing
        val ext = when {
            mime.contains("jpeg", true) -> "jpg"
            mime.contains("webp", true) -> "webp"
            else -> "png"
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val safe = suggested.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(48).ifBlank { "wai" }
        val f = File(dir, "${safe}_${stamp}.$ext")
        atomicWrite(f, bytes)
        val m = JSONObject(metadata.toString())
            .put("name", f.name)
            .put("size", f.length())
            .put("time", f.lastModified())
            .put("favorite", metadata.optBoolean("favorite", false))
            .put("storage", "app_private")
            .put("cloud_sync", false)
        atomicWriteText(File(metaDir, f.name + ".json"), m.toString())
        return decorate(f, m)
    }

    fun saveDataUrl(dataUrl: String, suggested: String = "wai", metadata: JSONObject = JSONObject()): JSONObject {
        val comma = dataUrl.indexOf(',')
        require(comma > 0) { "图片数据无效" }
        val header = dataUrl.substring(0, comma)
        val mime = when {
            header.contains("image/jpeg") -> "image/jpeg"
            header.contains("image/webp") -> "image/webp"
            else -> "image/png"
        }
        val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
        return saveBytes(bytes, mime, suggested, metadata)
    }

    private fun readMeta(f: File): JSONObject {
        val mf = File(metaDir, f.name + ".json")
        return try { if (mf.exists()) JSONObject(mf.readText(Charsets.UTF_8)) else JSONObject() } catch (_: Exception) { JSONObject() }
    }

    private fun decorate(f: File, m: JSONObject = readMeta(f)): JSONObject {
        return JSONObject(m.toString())
            .put("name", f.name)
            .put("size", f.length())
            .put("time", f.lastModified())
            .put("url", "https://app.local/local-images/${f.name}")
    }

    fun list(): JSONArray {
        val a = JSONArray()
        dir.listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") }?.sortedByDescending { it.lastModified() }?.take(2000)?.forEach { f ->
            a.put(decorate(f))
        }
        return a
    }

    fun resolve(name: String): File? {
        val clean = File(name).name
        if (clean != name || clean.endsWith(".tmp")) return null
        val f = File(dir, clean)
        return if (f.exists() && f.isFile && f.parentFile == dir) f else null
    }

    fun metadata(name: String): JSONObject {
        val f = resolve(name) ?: return JSONObject().put("error", "not found")
        return decorate(f)
    }

    fun toggleFavorite(name: String): JSONObject {
        val f = resolve(name) ?: return JSONObject().put("error", "not found")
        val m = readMeta(f)
        m.put("favorite", !m.optBoolean("favorite", false))
        atomicWriteText(File(metaDir, f.name + ".json"), m.toString())
        return decorate(f, m)
    }

    fun hasJob(jobId: String): Boolean {
        if (jobId.isBlank()) return false
        return dir.listFiles()?.filter { it.isFile }?.any { f ->
            try { readMeta(f).optString("job_id", "") == jobId } catch (_: Exception) { false }
        } ?: false
    }

    fun delete(name: String): Boolean {
        val f = resolve(name) ?: return false
        File(metaDir, f.name + ".json").delete()
        return f.delete()
    }

    fun stats(): JSONObject {
        val files = dir.listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") }.orEmpty()
        val used = files.sumOf { it.length() }
        return JSONObject()
            .put("count", files.size)
            .put("used_bytes", used)
            .put("bytes", used)
            .put("free_bytes", context.filesDir.usableSpace)
            .put("path_hint", "WAI Pad 应用私有存储")
            .put("cloud_sync", false)
    }
}
