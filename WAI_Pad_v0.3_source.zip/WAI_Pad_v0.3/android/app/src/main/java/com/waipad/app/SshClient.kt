package com.waipad.app

import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Base64
import java.util.Properties

object SshClient {
    fun connect(host: String, port: Int, user: String, password: String): Session {
        require(host.isNotBlank()) { "SSH 主机为空" }
        require(port in 1..65535) { "SSH 端口无效" }
        val jsch = JSch()
        val s = jsch.getSession(user.ifBlank { "root" }, host, port)
        if (password.isNotEmpty()) s.setPassword(password)
        val cfg = Properties()
        // First connection is TOFU; afterwards WAI Pad pins the SHA-256 host fingerprint.
        cfg["StrictHostKeyChecking"] = "no"
        cfg["PreferredAuthentications"] = "password,keyboard-interactive,publickey"
        s.setConfig(cfg)
        s.serverAliveInterval = 20_000
        s.serverAliveCountMax = 3
        s.connect(18_000)
        return s
    }

    fun connect(prefs: SecurePrefs): Session {
        val s = connect(
            prefs.get("host", "connect.nmb2.seetacloud.com"),
            prefs.get("port", "28823").toIntOrNull() ?: 28823,
            prefs.get("user", "root"),
            prefs.get("password")
        )
        val fp = fingerprint(s)
        val saved = prefs.get("sshFingerprint")
        if (saved.isBlank()) {
            prefs.put("sshFingerprint", fp)
        } else if (saved != fp) {
            s.disconnect()
            throw SecurityException("SSH 主机指纹发生变化，WAI Pad 已阻止连接。请在设置中确认后重置指纹。旧=$saved 新=$fp")
        }
        return s
    }

    fun fingerprint(session: Session): String {
        val raw = try { Base64.getDecoder().decode(session.hostKey.key) } catch (_: Exception) { session.hostKey.key.toByteArray() }
        val digest = MessageDigest.getInstance("SHA-256").digest(raw)
        return "SHA256:" + Base64.getEncoder().withoutPadding().encodeToString(digest)
    }

    fun exec(session: Session, command: String, timeoutMs: Long = 90_000): Pair<Int, String> {
        val ch = session.openChannel("exec") as ChannelExec
        ch.setCommand(command); ch.setInputStream(null)
        val out = ByteArrayOutputStream(); val err = ByteArrayOutputStream()
        ch.setOutputStream(out); ch.setErrStream(err); ch.connect(10_000)
        val start = System.currentTimeMillis()
        while (!ch.isClosed && System.currentTimeMillis() - start < timeoutMs) Thread.sleep(80)
        val timedOut = !ch.isClosed
        if (timedOut) ch.disconnect()
        val code = if (timedOut) 124 else ch.exitStatus
        if (ch.isConnected) ch.disconnect()
        val text = out.toString(Charsets.UTF_8.name()) + err.toString(Charsets.UTF_8.name())
        return code to text
    }

    fun putBytes(session: Session, remotePath: String, data: ByteArray) {
        val ch = session.openChannel("sftp") as ChannelSftp
        ch.connect(10_000)
        try { ch.put(ByteArrayInputStream(data), remotePath) } finally { ch.disconnect() }
    }
}
