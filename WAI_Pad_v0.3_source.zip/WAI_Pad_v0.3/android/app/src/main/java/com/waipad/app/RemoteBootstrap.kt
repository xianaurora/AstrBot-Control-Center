package com.waipad.app

import android.content.Context
import com.jcraft.jsch.Session
import org.json.JSONObject
import java.security.MessageDigest

object RemoteBootstrap {
    private val files = listOf("engine_v34.py", "job_api.py", "maintenance.py", "guard.sh", "bootstrap.sh")

    private fun sha256(data: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(data).joinToString("") { "%02x".format(it) }

    private fun activeJob(session: Session): String? {
        val r = SshClient.exec(session, "curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health 2>/dev/null || true", 8_000)
        return try {
            val o = JSONObject(r.second.trim())
            if (o.isNull("current")) null else o.optString("current").takeIf { it.isNotBlank() && it != "null" }
        } catch (_: Exception) { null }
    }

    fun installAndStart(context: Context, session: Session): String {
        SshClient.exec(session, "mkdir -p /root/WAI_Pad/runtime && chmod 700 /root/WAI_Pad", 30_000)

        // Do not hot-replace companion code while a ComfyUI generation is active. Updating code
        // would force bootstrap.sh to restart job_api and could orphan a running generation.
        val pending = mutableListOf<String>()
        val localData = mutableMapOf<String, ByteArray>()
        for (name in files) {
            val bytes = context.assets.open("wai/server/$name").use { it.readBytes() }
            localData[name] = bytes
            val localHash = sha256(bytes)
            val remote = SshClient.exec(session, "sha256sum /root/WAI_Pad/$name 2>/dev/null | cut -d' ' -f1", 15_000).second.trim()
            if (remote != localHash) pending += name
        }
        val active = activeJob(session)
        if (pending.isNotEmpty() && active != null) {
            // Existing API is healthy enough to report an active job, so preserve it and defer update.
            return "[WAI Pad] 检测到正在生成任务 $active。为避免中断，v0.3 companion 更新已自动延后；任务结束或下次重连时会自动更新。"
        }

        val changed = mutableListOf<String>()
        for (name in pending) {
            SshClient.putBytes(session, "/root/WAI_Pad/$name", localData.getValue(name))
            changed += name
        }
        val r = SshClient.exec(
            session,
            "chmod 700 /root/WAI_Pad/*.sh; chmod 600 /root/WAI_Pad/*.py; bash /root/WAI_Pad/bootstrap.sh",
            320_000
        )
        if (r.first != 0) throw IllegalStateException("自动初始化失败(${r.first})：${r.second.takeLast(1600)}")
        return (if (changed.isEmpty()) "[WAI Pad] companion 已是最新版，无需覆盖运行中的任务。\n" else "[WAI Pad] 已更新: ${changed.joinToString()}\n") + r.second
    }
}
