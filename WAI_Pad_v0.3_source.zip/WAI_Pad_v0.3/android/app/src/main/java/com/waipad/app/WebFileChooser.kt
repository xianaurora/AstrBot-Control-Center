package com.waipad.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView

class WebFileChooser(private val activity: Activity) : WebChromeClient() {
    companion object { const val REQ = 9201 }
    var callback: ValueCallback<Array<Uri>>? = null

    override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
        callback?.onReceiveValue(null)
        callback = filePathCallback
        return try {
            val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
            }
            activity.startActivityForResult(intent, REQ)
            true
        } catch (_: Exception) {
            callback?.onReceiveValue(null); callback = null; false
        }
    }

    fun deliver(requestCode: Int, resultCode: Int, data: Intent?): Boolean {
        if (requestCode != REQ) return false
        val cb = callback ?: return true
        val result = if (resultCode == Activity.RESULT_OK) FileChooserParams.parseResult(resultCode, data) else null
        cb.onReceiveValue(result); callback = null; return true
    }
}
