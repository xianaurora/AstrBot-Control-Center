package com.waipad.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class SecurePrefs(private val context: Context) {
    private val prefs = context.getSharedPreferences("wai_pad_secure", Context.MODE_PRIVATE)
    private val alias = "wai_pad_key_v1"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return kg.generateKey()
    }

    fun put(name: String, value: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val enc = c.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        val o = JSONObject()
            .put("iv", Base64.encodeToString(c.iv, Base64.NO_WRAP))
            .put("v", Base64.encodeToString(enc, Base64.NO_WRAP))
        prefs.edit().putString(name, o.toString()).apply()
    }

    fun get(name: String, def: String = ""): String {
        val raw = prefs.getString(name, null) ?: return def
        return try {
            val o = JSONObject(raw)
            val iv = Base64.decode(o.getString("iv"), Base64.NO_WRAP)
            val data = Base64.decode(o.getString("v"), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(c.doFinal(data), StandardCharsets.UTF_8)
        } catch (_: Exception) { def }
    }

    fun remove(name: String) { prefs.edit().remove(name).apply() }

    fun hasServer(): Boolean = get("host", "connect.nmb2.seetacloud.com").isNotBlank() &&
        get("port", "28823").isNotBlank() && get("user", "root").isNotBlank() && get("password").isNotBlank()
}
