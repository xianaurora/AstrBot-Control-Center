#!/usr/bin/env bash
set -u
BASE=/root/WAI_Pad
LOG="$BASE/guard.log"
mkdir -p "$BASE/runtime"
PY="/root/venv/bin/python"; [ -x "$PY" ] || PY="$(command -v python3 || command -v python)"
log(){
  [ -f "$LOG" ] && [ "$(stat -c%s "$LOG" 2>/dev/null || echo 0)" -gt 5242880 ] && mv -f "$LOG" "$LOG.1" 2>/dev/null || true
  echo "[$(date '+%F %T')] $*" >> "$LOG"
}
health(){ curl -fsS --max-time 4 "$1" >/dev/null 2>&1; }
active_job(){ curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health 2>/dev/null | grep -Eq '"current"[[:space:]]*:[[:space:]]*"[^" ]+'; }
start_api(){
  if ! health http://127.0.0.1:6027/v1/health; then
    log 'WAI Pad API 离线，单独重启 companion'
    pkill -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1 || true
    nohup "$PY" "$BASE/job_api.py" >>"$BASE/runtime/job_api.nohup.log" 2>&1 </dev/null &
    sleep 2
  fi
}
repair_core(){
  # A panel-only outage must never kill a healthy ComfyUI generation.
  if health http://127.0.0.1:6006/system_stats && active_job; then
    log '检测到生成任务仍在运行；核心 ComfyUI 正常，延后全量 wai restart，避免中断任务。'
    start_api
    return 0
  fi
  log '核心服务连续异常，执行 wai restart'
  wai restart >>"$LOG" 2>&1 || true
  sleep 8
  if ! health http://127.0.0.1:6017/api/health || ! health http://127.0.0.1:6006/system_stats; then
    if [ -x /root/WAI_v31/WAI_ctl.sh ]; then
      log '常规重启未恢复，执行一次受控 repair'
      /root/WAI_v31/WAI_ctl.sh repair >>"$LOG" 2>&1 || true
      sleep 10
    fi
  fi
  start_api
}
case "${1:-daemon}" in
  once)
    if ! health http://127.0.0.1:6017/api/health || ! health http://127.0.0.1:6006/system_stats; then repair_core; fi
    start_api
    ;;
  daemon)
    log 'WAI Pad v0.3 守护开始'
    fail=0
    while true; do
      panel=1; comfy=1
      health http://127.0.0.1:6017/api/health || panel=0
      health http://127.0.0.1:6006/system_stats || comfy=0
      if [ "$panel" -eq 1 ] && [ "$comfy" -eq 1 ]; then
        fail=0
      else
        fail=$((fail+1)); log "核心健康检查失败 #$fail panel=$panel comfy=$comfy"
        if [ "$fail" -ge 2 ]; then repair_core; fail=0; fi
      fi
      start_api
      sleep 20
    done
    ;;
esac
