#!/usr/bin/env bash
set -Eeuo pipefail
BASE=/root/WAI_Pad
mkdir -p "$BASE/runtime"
log(){ echo "[$(date '+%F %T')] $*"; }
health(){ curl -fsS --max-time 4 "$1" >/dev/null 2>&1; }
PY="/root/venv/bin/python"
[ -x "$PY" ] || PY="$(command -v python3 || command -v python)"

log '=== WAI Pad v0.3 自动初始化 ==='
if ! command -v wai >/dev/null 2>&1; then
  log '[ERROR] 找不到 wai 命令；不会改动你的现有环境。'
  exit 2
fi

if ! health http://127.0.0.1:6017/api/health || ! health http://127.0.0.1:6006/system_stats; then
  log '[启动] WAI / ComfyUI / Qwen'
  wai start >/dev/null 2>&1 || wai restart >/dev/null 2>&1 || true
  sleep 8
fi

"$PY" -m py_compile "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py"
CODE_HASH="$(cat "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py" "$BASE/guard.sh" "$BASE/bootstrap.sh" | sha256sum | awk '{print $1}')"
OLD_HASH="$(cat "$BASE/runtime/code.sha256" 2>/dev/null || true)"

# Crucial: reconnecting the tablet must NOT kill an in-progress generation.
# Restart companion only when code changed or the API is actually dead.
if health http://127.0.0.1:6027/v1/health && [ "$CODE_HASH" = "$OLD_HASH" ]; then
  log '[任务服务] 已运行且代码未变化，保留当前任务/队列，不重启。'
else
  if pgrep -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1; then
    log '[任务服务] 代码更新或健康异常，重启 companion'
    pkill -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' || true
    sleep 1
  fi
  nohup "$PY" "$BASE/job_api.py" >>"$BASE/runtime/job_api.nohup.log" 2>&1 </dev/null &
  for _ in $(seq 1 12); do health http://127.0.0.1:6027/v1/health && break; sleep 1; done
  if ! health http://127.0.0.1:6027/v1/health; then
    log '[ERROR] WAI Pad 异步任务服务未启动，旧 WAI 仍保持原样。'
    tail -40 "$BASE/runtime/job_api.nohup.log" 2>/dev/null || true
    exit 3
  fi
  printf '%s' "$CODE_HASH" > "$BASE/runtime/code.sha256"
fi

if ! pgrep -f '^bash /root/WAI_Pad/guard.sh daemon$' >/dev/null 2>&1; then
  log '[守护] 启动自动检测与修复'
  nohup bash "$BASE/guard.sh" daemon >>"$BASE/guard.nohup.log" 2>&1 </dev/null &
fi

printf '[状态] Panel: '; health http://127.0.0.1:6017/api/health && echo OK || echo FAIL
printf '[状态] ComfyUI: '; health http://127.0.0.1:6006/system_stats && echo OK || echo FAIL
printf '[状态] Qwen: '; health http://127.0.0.1:8011/v1/models && echo OK || echo '休眠/离线（生成时可自动回退轻量模式）'
printf '[状态] WAI Pad API: '; curl -fsS --max-time 4 http://127.0.0.1:6027/v1/health || true; echo
log '[隐私] 参考图任务结束自动删除远端输入；成图保存到平板后自动删除 AutoDL 临时输出。'
log '[完成] 后续无需手工输入启动命令。'
