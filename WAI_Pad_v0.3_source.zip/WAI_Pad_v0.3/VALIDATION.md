# WAI Pad v0.3 静态验证

已通过：
- `python -m py_compile`：`job_api.py`、`engine_v34.py`、`maintenance.py`。
- `bash -n`：`bootstrap.sh`、`guard.sh`。
- `node --check`：前端 `app.js`。
- server 目录与 Android assets 内 companion 文件一致性检查。
- 新增 API 路由静态检查：diagnose / repairs / repair(level) / rollback。
- APK 版本号已升级到 0.3.0 / versionCode 3。

当前环境缺少 Android SDK，因此本轮仍不能在本机执行真正的 Gradle Android 编译。仓库保留 GitHub Actions APK 构建流程；实机安装前应先完成一次 CI 编译和安卓平板验收。
