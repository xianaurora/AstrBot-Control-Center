#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

expected="$(awk 'NR==1{print $1}' "$ASSETS/engine.sha256")"
actual="$(sha256sum "$ASSETS/engine.zip" | awk '{print $1}')"
[[ "$expected" == "$actual" ]] || { echo "engine.zip SHA mismatch" >&2; exit 20; }
unzip -t "$ASSETS/engine.zip" >/dev/null
unzip -q "$ASSETS/engine.zip" -d "$TMP/engine"
(
  cd "$TMP/engine"
  sha256sum -c manifest/module-files.sha256 >/dev/null
)

grep -qx 'version=1.6.0-dev13' "$TMP/engine/module.prop" || { echo "unexpected embedded core version" >&2; exit 21; }
grep -qx 'versionCode=16013' "$TMP/engine/module.prop" || { echo "unexpected embedded core versionCode" >&2; exit 22; }
grep -q '^VERSION=v1.6.0-dev13$' "$TMP/engine/astrctl" || { echo "astrctl release mismatch" >&2; exit 23; }

count=0
while IFS= read -r file; do
  case "$file" in
    *.sh|*/astrctl|*/service.sh|*/post-fs-data.sh|*/action.sh)
      if head -n 1 "$file" | grep -q 'bash'; then bash -n "$file"; else sh -n "$file"; fi
      count=$((count+1))
      ;;
  esac
done < <(find "$TMP/engine" -type f -print | sort)

python3 - "$ROOT" <<'PY'
import json, re, sys, xml.etree.ElementTree as ET
from pathlib import Path
root = Path(sys.argv[1])
for f in root.rglob('*.xml'):
    ET.parse(f)
for f in root.rglob('*.json'):
    json.loads(f.read_text(errors='strict'))
for f in root.rglob('*.kt'):
    lines = f.read_text(errors='replace').splitlines()
    imports = [x for x in lines if x.startswith('import ')]
    if len(imports) != len(set(imports)):
        raise SystemExit(f"duplicate Kotlin import: {f}")

control = (root/'app/src/main/java/com/xianaurora/astrbotcontrol/ui/ControlCenterApp.kt').read_text()
required = (
    'SituationText','GuidedTaskProgress','SituationAction','EnvironmentScreen',
    'EnvironmentHealthCard','AutomationSettingsCard','FeatureToggleRow',
    'DownloadSourceCard','HealthCheckCard','SettingsSaveBar','WorkbenchHome','WorkspaceLaunchCard',
    'WorkbenchFocusedBar','QqLoginWorkspace','NativeQqDesktopFrame','NativeQqLoginFrame','QrVisualCard','QqLoginInfoPanel','QqLoginComplete'
)
for name in required:
    if not re.search(r'@Composable\s+(?:private\s+)?fun\s+'+re.escape(name)+r'\s*\(', control):
        raise SystemExit(f'Compose annotation missing on {name}')
PY

CONTROL="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/ui/ControlCenterApp.kt"
WEBVIEW="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/ui/EmbeddedConsoleWebView.kt"
MODELS="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/model/ControlCenterModels.kt"
PARSER="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlStatusParser.kt"
REPO="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlCenterRepository.kt"
VM="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlCenterViewModel.kt"
ENGINE_REPO="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/EngineRepository.kt"
INSTALLER_MODELS="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/model/InstallerModels.kt"
ROOT_SHELL="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/RootShell.kt"
CATALOG="$ROOT/app/src/main/assets/resource-catalog.json"
WORKFLOW="$ROOT/.github/workflows/build-apk.yml"

# Release/version agreement.
grep -q 'versionName = "1.6.0-dev22"' "$ROOT/app/build.gradle.kts" || { echo "app version mismatch" >&2; exit 26; }
grep -q 'versionCode = 162200' "$ROOT/app/build.gradle.kts" || { echo "app versionCode mismatch" >&2; exit 27; }
grep -q 'TARGET_ENGINE_VERSION = "1.6.0-dev13"' "$ENGINE_REPO" || { echo "core target mismatch" >&2; exit 28; }
grep -q 'TARGET_ENGINE_VERSION_CODE = 16013' "$ENGINE_REPO" || { echo "core target code mismatch" >&2; exit 29; }
grep -q 'targetEngineVersion: String = "1.6.0-dev13"' "$INSTALLER_MODELS" || { echo "installer target version is stale" >&2; exit 30; }
grep -q 'targetEngineVersionCode: Int = 16013' "$INSTALLER_MODELS" || { echo "installer target code is stale" >&2; exit 31; }
grep -q '"release": "v1.6.0-dev22"' "$CATALOG" || { echo "app resource catalog release is stale" >&2; exit 32; }
grep -q 'Build dev22 APK' "$WORKFLOW" || { echo "CI build label is stale" >&2; exit 33; }

# dev19 keeps the fixed signing identity and the shortened launcher label/icon safe area.
[[ -s "$ROOT/keystore/astrbot-dev-update.jks" ]] || { echo "stable dev keystore missing" >&2; exit 331; }
[[ -s "$ROOT/keystore/dev-key-sha256.txt" ]] || { echo "stable dev certificate fingerprint missing" >&2; exit 3311; }
keytool -list -keystore "$ROOT/keystore/astrbot-dev-update.jks" -storepass 'AstrBot-Dev-Update-2026' -alias astrbot-dev-update >/dev/null 2>&1 || { echo "stable dev keystore unreadable" >&2; exit 3312; }
grep -q 'create("stableDev")' "$ROOT/app/build.gradle.kts" || { echo "stable dev signing config missing" >&2; exit 332; }
grep -q 'getByName("debug")' "$ROOT/app/build.gradle.kts" || { echo "debug signing override missing" >&2; exit 333; }
grep -q 'signingConfig = signingConfigs.getByName("stableDev")' "$ROOT/app/build.gradle.kts" || { echo "stable signing not attached" >&2; exit 334; }
grep -q 'Verify stable APK signature' "$WORKFLOW" || { echo "CI signature verification missing" >&2; exit 335; }
grep -q 'android:icon="@mipmap/ic_launcher"' "$ROOT/app/src/main/AndroidManifest.xml" || { echo "launcher icon not wired" >&2; exit 336; }
grep -q 'android:roundIcon="@mipmap/ic_launcher_round"' "$ROOT/app/src/main/AndroidManifest.xml" || { echo "round launcher icon not wired" >&2; exit 337; }
grep -q 'android:label="AstrBot CC"' "$ROOT/app/src/main/AndroidManifest.xml" || { echo "short launcher label missing" >&2; exit 338; }
[[ -s "$ROOT/app/src/main/res/drawable-nodpi/ic_launcher_foreground.png" ]] || { echo "launcher artwork missing" >&2; exit 339; }
for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  [[ -s "$ROOT/app/src/main/res/mipmap-$density/ic_launcher.png" ]] || { echo "launcher mipmap missing: $density" >&2; exit 3391; }
done
if grep -R -q 'description\.orEmpty()' "$ROOT/app/src/main/java"; then echo "CharSequence?.orEmpty compile regression remains" >&2; exit 340; fi

# dev19 interaction architecture: one workbench, one QQ login destination, staged settings.
grep -q 'CONSOLE("工作台"' "$MODELS" || { echo "workbench destination label missing" >&2; exit 341; }
grep -q 'QQ_LOGIN("QQ 登录")' "$MODELS" || { echo "unique QQ login target missing" >&2; exit 342; }
grep -q 'data class SettingsDraft' "$MODELS" || { echo "settings draft model missing" >&2; exit 343; }
grep -q 'pendingDestination: ControlDestination?' "$MODELS" || { echo "unsaved navigation guard model missing" >&2; exit 344; }
grep -q 'pendingConsoleTarget: ConsoleTarget?' "$MODELS" || { echo "pending workbench target guard missing" >&2; exit 345; }
grep -q 'fun saveSettingsDraft()' "$VM" || { echo "staged settings save missing" >&2; exit 346; }
grep -q 'fun cancelSettingsDraft' "$VM" || { echo "staged settings cancel missing" >&2; exit 347; }
grep -q 'fun updateDownloadSourceDraft' "$VM" || { echo "download source draft missing" >&2; exit 348; }
grep -q 'fun updateQqEngineDraft' "$VM" || { echo "QQ engine draft missing" >&2; exit 349; }
grep -q 'SettingsSaveBar' "$CONTROL" || { echo "settings save/cancel bar missing" >&2; exit 350; }
grep -q '还有未保存的更改' "$CONTROL" || { echo "unsaved changes dialog missing" >&2; exit 351; }
grep -q '保存更改' "$CONTROL" || { echo "save changes UI missing" >&2; exit 352; }
if grep -q 'vm\.setDownloadSource(' "$CONTROL"; then echo "download source still applies immediately" >&2; exit 353; fi
if grep -q 'vm\.runAction("engine-' "$CONTROL"; then echo "QQ engine still applies immediately" >&2; exit 354; fi
if grep -q 'QQ 扫码登录' "$CONTROL"; then echo "duplicate legacy QQ login wording remains in current UI" >&2; exit 355; fi
if grep -q '返回 QQ' "$CONTROL"; then echo "duplicate return-to-QQ login navigation remains" >&2; exit 356; fi

# Build regression: never rely on java.lang.Process.pid() in Android RootShell.
if grep -Eq '[[:alnum:]_.)]+\.pid\(' "$ROOT_SHELL"; then
  echo "RootShell reintroduced Process.pid()-style call" >&2; exit 34
fi
grep -q 'rootPidFile' "$ROOT_SHELL" || { echo "RootShell PID-file timeout tracking missing" >&2; exit 35; }
grep -q 'terminateRootTree' "$ROOT_SHELL" || { echo "RootShell descendant timeout cleanup missing" >&2; exit 36; }
grep -q 'MAX_CAPTURE_CHARS' "$ROOT_SHELL" || { echo "RootShell output is unbounded" >&2; exit 37; }

# User-facing information architecture.
grep -q 'ENVIRONMENT("环境"' "$MODELS" || { echo "environment destination missing" >&2; exit 40; }
grep -q 'OPERATIONS("工具"' "$MODELS" || { echo "tools destination label missing" >&2; exit 41; }
grep -q 'GuidedTaskProgress' "$CONTROL" || { echo "guided task progress missing" >&2; exit 42; }
if grep -q 'NextStepBeacon' "$CONTROL"; then echo "old breathing next-step beacon remains" >&2; exit 43; fi
grep -q 'CONSOLE("工作台"' "$MODELS" || { echo "workbench destination label missing" >&2; exit 44; }
grep -q 'WorkbenchHome' "$CONTROL" || { echo "workbench home missing" >&2; exit 441; }
grep -q 'WorkspaceLaunchCard' "$CONTROL" || { echo "uniform workbench launcher cards missing" >&2; exit 4411; }
grep -q 'WorkbenchStatusStrip' "$CONTROL" || { echo "workbench status strip missing" >&2; exit 44111; }
grep -q 'WorkbenchRuntimeSummary' "$CONTROL" || { echo "workbench runtime summary missing" >&2; exit 44112; }
grep -q 'WorkbenchNextAction' "$CONTROL" || { echo "workbench next-action panel missing" >&2; exit 44113; }
grep -q 'WorkbenchFocusedBar' "$CONTROL" || { echo "focused workbench bar missing" >&2; exit 4412; }
if grep -q 'private fun WorkbenchRail' "$CONTROL"; then echo "legacy mixed workbench rail remains" >&2; exit 4413; fi
grep -q '关闭全部自动功能' "$CONTROL" || { echo "disable-all automation UX missing" >&2; exit 45; }
grep -q '检查机器人' "$CONTROL" || { echo "guided health-check entry missing" >&2; exit 46; }
grep -q '帮我修复消息连接' "$CONTROL" || { echo "guided health action missing" >&2; exit 47; }
[[ "$(grep -c 'SituationCard(ui, vm' "$CONTROL" | tr -d ' ')" == 1 ]] || { echo "current-situation card is duplicated outside overview" >&2; exit 471; }

# Environment/recovery controls and mainland source profiles.
grep -q 'environment-reinstall' "$REPO" || { echo "environment reinstall app wiring missing" >&2; exit 50; }
grep -q 'environment-reinstall)' "$TMP/engine/astrctl" || { echo "environment reinstall core command missing" >&2; exit 51; }
grep -q 'cmd_environment_reinstall()' "$TMP/engine/astrctl" || { echo "environment reinstall core implementation missing" >&2; exit 52; }
grep -q 'disableAllUserAutomation' "$REPO" || { echo "disable-all automation backend missing" >&2; exit 53; }
grep -q 'download-source)' "$TMP/engine/astrctl" || { echo "download source core command missing" >&2; exit 54; }
grep -q 'DOWNLOAD_SOURCE_EFFECTIVE' "$TMP/engine/astrctl" || { echo "effective source status missing" >&2; exit 55; }
[[ -r "$TMP/engine/guest/apply-download-source.sh" ]] || { echo "download source helper missing" >&2; exit 56; }
for token in mirrors.aliyun.com/ubuntu-ports mirrors.ustc.edu.cn/ubuntu-ports mirrors.tuna.tsinghua.edu.cn/ubuntu-ports mirrors.bfsu.edu.cn/ubuntu-ports mirrors.huaweicloud.com/ubuntu-ports ports.ubuntu.com/ubuntu-ports; do
  grep -q "$token" "$TMP/engine/guest/apply-download-source.sh" || { echo "source profile missing: $token" >&2; exit 57; }
done
for token in mirrors.aliyun.com/pypi mirrors.ustc.edu.cn/pypi pypi.tuna.tsinghua.edu.cn mirrors.bfsu.edu.cn/pypi pypi.org/simple; do
  grep -q "$token" "$TMP/engine/guest/apply-download-source.sh" || { echo "PyPI source missing: $token" >&2; exit 58; }
done
grep -q 'noble-security' "$TMP/engine/guest/apply-download-source.sh" || { echo "Ubuntu security suite missing" >&2; exit 59; }
grep -q 'https://ports.ubuntu.com/ubuntu-ports' "$TMP/engine/guest/apply-download-source.sh" || { echo "official Ubuntu security source missing" >&2; exit 60; }

# Settings are concurrent-safe and defaults agree.
grep -q 'LOCK_DIR=\$WORK_DIR/settings.lock.d' "$TMP/engine/lib/common.sh" || { echo "atomic settings lock directory missing" >&2; exit 61; }
grep -q 'while ! mkdir "$LOCK_DIR"' "$TMP/engine/lib/common.sh" || { echo "mkdir settings lock missing" >&2; exit 62; }
grep -q 'OWNER_PID=' "$TMP/engine/lib/common.sh" || { echo "stale-owner recovery missing" >&2; exit 621; }
if grep -q 'flock -xn 9' "$TMP/engine/lib/common.sh"; then echo "FD flock settings lock regression remains" >&2; exit 622; fi
grep -q 'TMP=\$WORK_DIR/settings.\$\$.new' "$TMP/engine/lib/common.sh" || { echo "settings temp file is shared" >&2; exit 63; }
if grep -R -q 'config_get stack_autostart 0' "$TMP/engine"; then echo "inconsistent stack_autostart default remains" >&2; exit 64; fi

# Native QR remains the normal path, rendered crisply without technical copy.
grep -q 'capture_qq_login_frame()' "$TMP/engine/guest/run-snowluma.sh" || { echo "native QQ frame capture missing" >&2; exit 70; }
grep -q -- '-f x11grab' "$TMP/engine/guest/run-snowluma.sh" || { echo "FFmpeg x11grab capture missing" >&2; exit 71; }
grep -q 'startNativeQqFramePolling' "$VM" || { echo "native frame polling missing" >&2; exit 72; }
if grep -q 'repeat(360)' "$VM"; then echo "native QR polling still has a fixed lifetime" >&2; exit 73; fi
grep -q 'resumeQqLoginPollingIfNeeded' "$VM" || { echo "native QR foreground resume missing" >&2; exit 74; }
grep -q 'filterQuality = FilterQuality.None' "$CONTROL" || { echo "crisp QR scaling missing" >&2; exit 75; }
grep -q 'QQ 登录窗口' "$CONTROL" || { echo "interactive QQ login window copy missing" >&2; exit 76; }
grep -q 'pointerInput(width, height)' "$CONTROL" || { echo "native QQ login frame is not touch-enabled" >&2; exit 761; }
grep -q 'fun tapQqLoginFrame' "$VM" || { echo "QQ login touch action missing" >&2; exit 762; }
grep -q 'suspend fun qqLoginTap' "$REPO" || { echo "QQ login touch backend missing" >&2; exit 763; }
grep -q 'qrFrameToken' "$MODELS" || { echo "same-frame QQ touch metadata missing from UI state" >&2; exit 7631; }
grep -q 'qrFrameToken = frame.frameToken' "$VM" || { echo "QQ frame metadata is not persisted with the rendered frame" >&2; exit 7632; }
grep -q 'snowluma-login-tap main' "$REPO" || { echo "Android QQ touch is not routed through same-frame core mapping" >&2; exit 7633; }
grep -q 'cmd_snowluma_login_tap()' "$TMP/engine/astrctl" || { echo "core same-frame QQ tap command missing" >&2; exit 7634; }
grep -q 'SLF_TOUCH_META=' "$TMP/engine/astrctl" || { echo "QQ frame touch metadata protocol missing" >&2; exit 7635; }
grep -q "printf 'display=%s" "$TMP/engine/guest/run-snowluma.sh" || { echo "QQ capture does not persist DISPLAY metadata" >&2; exit 7636; }
grep -q 'vm::openQqDesktop' "$CONTROL" || { echo "native full-desktop entry missing" >&2; exit 764; }
grep -q 'NativeQqDesktopFrame' "$CONTROL" || { echo "native full-desktop renderer missing" >&2; exit 7641; }
grep -q 'fun tapQqDesktopFrame' "$VM" || { echo "native full-desktop touch action missing" >&2; exit 7642; }
grep -q 'suspend fun qqLoginDesktopFrame' "$REPO" || { echo "native full-desktop capture backend missing" >&2; exit 7643; }
grep -q 'suspend fun qqLoginDesktopTap' "$REPO" || { echo "native full-desktop touch backend missing" >&2; exit 7644; }
if grep -q 'repository.qqLoginDesktopSession()' "$VM"; then echo "full desktop still routes through noVNC session" >&2; exit 7645; fi
grep -q 'snowluma-instance-list' "$REPO" || { echo "SnowLuma display discovery missing" >&2; exit 7646; }
grep -q 'fun refreshQqLoginCode' "$VM" || { echo "manual QR refresh action missing" >&2; exit 77; }
REFRESH_BLOCK="$(sed -n '/^refresh_qq_qr_code()/,/^start_qq_for()/p' "$TMP/engine/guest/run-snowluma.sh")"
[[ "$(grep -o 'click 1' <<<"$REFRESH_BLOCK" | wc -l | tr -d ' ')" == 1 ]] || { echo "QR refresh must send exactly one click" >&2; exit 78; }
if grep -Eq '^[[:space:]]*(while|for)[[:space:]]' <<<"$REFRESH_BLOCK"; then echo "QR refresh contains an automatic click loop" >&2; exit 79; fi

# AstrBot diagnostics must not block the actual WebView load.
grep -q 'cmd_web_probe()' "$TMP/engine/astrctl" || { echo "AstrBot WebUI probe missing" >&2; exit 80; }
grep -q 'suspend fun astrbotWebProbe' "$REPO" || { echo "Android AstrBot probe wiring missing" >&2; exit 81; }
grep -q 'diagnostic only and must never delay' "$VM" || { echo "AstrBot probe still risks gating WebView" >&2; exit 82; }
if grep -q 'phase == "probing"' "$CONTROL"; then echo "AstrBot probe still hides WebView" >&2; exit 821; fi
grep -q 'ui.console.target == ConsoleTarget.ASTRBOT -> AstrBotNativeConsoleWorkspace' "$CONTROL" || { echo "AstrBot classic-Activity placeholder is not wired" >&2; exit 822; }
if grep -q 'freshLocalContent = ui.console.target == ConsoleTarget.ASTRBOT' "$CONTROL"; then echo "AstrBot is still routed through Compose AndroidView" >&2; exit 823; fi
ASTRBOT_ACTIVITY="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/AstrBotWebActivity.kt"
[[ -r "$ASTRBOT_ACTIVITY" ]] || { echo "classic AstrBot WebView Activity missing" >&2; exit 824; }
grep -q 'android:name=".AstrBotWebActivity"' "$ROOT/app/src/main/AndroidManifest.xml" || { echo "AstrBot WebView Activity not declared" >&2; exit 825; }
grep -q 'WebView(this)' "$ASTRBOT_ACTIVITY" || { echo "AstrBot WebView is not Activity-context hosted" >&2; exit 826; }
grep -q 'setContentView(root)' "$ASTRBOT_ACTIVITY" || { echo "AstrBot WebView is not in a classic Activity View tree" >&2; exit 827; }
grep -q 'PixelCopy.request' "$ASTRBOT_ACTIVITY" || { echo "actual-pixel blank probe missing" >&2; exit 828; }
grep -q 'whiteRatio >= 0.992' "$ASTRBOT_ACTIVITY" || { echo "pixel blank threshold missing" >&2; exit 829; }
grep -q 'app-webview.log' "$ASTRBOT_ACTIVITY" || { echo "WebView diagnostics are not exported to module logs" >&2; exit 830; }
grep -q 'onConsoleMessage' "$ASTRBOT_ACTIVITY" || { echo "classic WebView console diagnostics missing" >&2; exit 831; }
grep -q 'onReceivedHttpError' "$ASTRBOT_ACTIVITY" || { echo "classic WebView HTTP diagnostics missing" >&2; exit 832; }
grep -q 'onRenderProcessGone' "$ASTRBOT_ACTIVITY" || { echo "classic WebView renderer recovery missing" >&2; exit 833; }
if grep -q 'launchAstrBotNativeConsole(consoleUrl)' "$VM"; then echo "AstrBot still auto-launches and ejects the user from workbench" >&2; exit 834; fi
grep -q 'fun reopenAstrBotNativeConsole' "$VM" || { echo "AstrBot native Activity reopen action missing" >&2; exit 835; }
grep -q 'LOAD_DEFAULT' "$ASTRBOT_ACTIVITY" || { echo "classic Activity should start with normal WebView cache policy" >&2; exit 836; }
grep -q 'NO_CACHE_HEADERS' "$ASTRBOT_ACTIVITY" || { echo "manual fresh reload fallback missing" >&2; exit 837; }
grep -q 'onBackPressedDispatcher.addCallback(this)' "$ASTRBOT_ACTIVITY" || { echo "AstrBot Activity back override missing" >&2; exit 838; }
grep -A8 'onBackPressedDispatcher.addCallback(this)' "$ASTRBOT_ACTIVITY" | grep -q 'finish()' || { echo "AstrBot system back does not exit workbench" >&2; exit 839; }
if grep -A8 'onBackPressedDispatcher.addCallback(this)' "$ASTRBOT_ACTIVITY" | grep -q 'canGoBack'; then echo "AstrBot system back still consumes web history" >&2; exit 840; fi
grep -q 'private fun installSystemInsets' "$ASTRBOT_ACTIVITY" || { echo "AstrBot status-bar inset handling missing" >&2; exit 8401; }
grep -q 'WindowInsets.Type.statusBars()' "$ASTRBOT_ACTIVITY" || { echo "AstrBot toolbar can overlap status bar" >&2; exit 8402; }
grep -q 'window.decorView' "$ASTRBOT_ACTIVITY" || { echo "AstrBot insets are not attached to decor view" >&2; exit 8403; }
grep -q 'statusBarFallbackHeight()' "$ASTRBOT_ACTIVITY" || { echo "AstrBot first-frame status bar fallback missing" >&2; exit 8404; }
grep -q 'applySystemBarOffsets()' "$ASTRBOT_ACTIVITY" || { echo "AstrBot explicit system-bar offsets missing" >&2; exit 8405; }
grep -q 'private fun showPageMenu' "$ASTRBOT_ACTIVITY" || { echo "AstrBot overflow tools missing" >&2; exit 841; }
grep -q 'private fun setPageFullscreen' "$ASTRBOT_ACTIVITY" || { echo "AstrBot fullscreen mode missing" >&2; exit 8411; }
grep -q 'fullscreenButton' "$ASTRBOT_ACTIVITY" || { echo "AstrBot fullscreen button missing" >&2; exit 8412; }
grep -q 'text = "‹ 工作台"' "$ASTRBOT_ACTIVITY" || { echo "AstrBot unified workbench back affordance missing" >&2; exit 8413; }
grep -q 'menu.add("网页后退")' "$ASTRBOT_ACTIVITY" || { echo "AstrBot web-history action missing" >&2; exit 842; }
grep -q 'private var astrbotLaunchJob: Job?' "$VM" || { echo "explicit AstrBot launch waiter missing" >&2; exit 843; }
grep -A10 'private fun AstrBotNativeConsoleWorkspace' "$CONTROL" | grep -q 'ready: Boolean' || { echo "AstrBot workspace readiness parameter missing" >&2; exit 844; }
grep -A10 'private fun AstrBotNativeConsoleWorkspace' "$CONTROL" | grep -q 'canOpenBrowser: Boolean' || { echo "AstrBot browser readiness parameter missing" >&2; exit 845; }

# Earlier stability regressions stay fixed.
if grep -q 'AnimatedVisibility' "$CONTROL"; then echo "ControlCenterApp reintroduced AnimatedVisibility" >&2; exit 91; fi
if grep -Eq 'SelectionContainer[[:space:]]*[{(]' "$CONTROL"; then echo "live logs wrapped in SelectionContainer" >&2; exit 92; fi
grep -q 'importVerifiedRootfsFile(file: File, catalog: RootfsCatalog' "$ENGINE_REPO" || { echo "rootfs final validation is not catalog-driven" >&2; exit 93; }
grep -q 'partial.length() == catalog.size' "$ENGINE_REPO" || { echo "completed partial rootfs reuse missing" >&2; exit 94; }
grep -q 'operationsSection != OperationsSection.LOGS' "$VM" || { echo "log polling is not section-scoped" >&2; exit 95; }

sh "$TMP/engine/tests/test-control-center-v1604-qr-rendering.sh" "$TMP/engine" >/dev/null

echo "SOURCE_GATE_OK engine_sha=$actual shell_files=$count feature_release=1 native_qr=1 native_desktop_touch=1 environment=1 source_profiles=1 guided_health=1 workbench_v3=1 staged_settings=1 login_dedup=1 interactive_login_frame=1 tools_dedup=1 statusbar_insets=1 astrbot_classic_webview=1 astrbot_direct_exit=1 pixel_probe=1 kotlin_compile_fix=1 stable_signing=1 launcher_icon_safezone=1 launcher_icon_dev22=1 same_frame_touch=1 atomic_settings_lock=1 astrbot_fullscreen=1 compact_workbench=1"
