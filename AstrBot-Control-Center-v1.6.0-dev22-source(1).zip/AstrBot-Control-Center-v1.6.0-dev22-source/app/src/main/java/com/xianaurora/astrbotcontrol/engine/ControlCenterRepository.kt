package com.xianaurora.astrbotcontrol.engine

import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Base64
import com.xianaurora.astrbotcontrol.model.DiagnosticExportState
import com.xianaurora.astrbotcontrol.model.LogSource
import com.xianaurora.astrbotcontrol.model.QqLoginFrame
import com.xianaurora.astrbotcontrol.model.QqLoginSession
import com.xianaurora.astrbotcontrol.model.RuntimeStatus

class ControlCenterRepository(
    private val shell: RootShell = RootShell()
) {
    companion object {
        private const val ASTRCTL = EngineRepository.ASTRCTL
    }

    suspend fun available(): Boolean = shell.root("test -x ${RootShell.q(ASTRCTL)}", 8).ok

    suspend fun keepConsoleActive(): ShellResult = shell.root(
        "${RootShell.q(ASTRCTL)} console-ping",
        10
    )

    suspend fun status(forceLive: Boolean = false): Result<RuntimeStatus> {
        val cmd = if (forceLive) "web-status-live" else "web-status"
        val result = shell.root("${RootShell.q(ASTRCTL)} $cmd", if (forceLive) 20 else 12)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "无法读取控制中心状态" } }))
        }
        return Result.success(ControlStatusParser.parse(result.stdout))
    }

    suspend fun queue(action: String): ShellResult {
        val safeAction = when (action) {
            "start", "stop", "restart", "heal", "repair", "environment-reinstall", "plugin-deps", "bridge-repair",
            "engine-snowluma", "engine-napcat", "napcat-reset-login" -> action
            else -> return ShellResult(2, "", "不支持的操作：$action")
        }
        return shell.root("${RootShell.q(ASTRCTL)} queue $safeAction app", 15)
    }

    suspend fun setUserFeature(feature: String, enabled: Boolean): ShellResult {
        val command = when (feature) {
            "autostart" -> "stack-autostart ${if (enabled) "on" else "off"}"
            "watchdog" -> "watchdog ${if (enabled) "on" else "off"}"
            "rescue" -> "rescue ${if (enabled) "on" else "off"}"
            "message_guard" -> "message-guard ${if (enabled) "on" else "off"}"
            else -> return ShellResult(2, "", "不支持的自动化功能：$feature")
        }
        return shell.root("${RootShell.q(ASTRCTL)} $command", 18)
    }

    suspend fun disableAllUserAutomation(): ShellResult {
        // Keep this intentionally explicit: these are the user-facing automatic
        // behaviors. Launch supervision itself is infrastructure and is not exposed
        // as a switch because disabling it can break managed processes.
        val commands = listOf(
            "message-guard off",
            "watchdog off",
            "rescue off",
            "stack-autostart off"
        )
        for (command in commands) {
            val result = shell.root("${RootShell.q(ASTRCTL)} $command", 18)
            if (!result.ok) return result
        }
        return ShellResult(0, "已关闭自动上线与自动恢复功能", "")
    }

    suspend fun setDownloadSource(profile: String): ShellResult {
        val safe = profile.takeIf { it in setOf("auto", "aliyun", "ustc", "tuna", "bfsu", "huawei", "official") }
            ?: return ShellResult(2, "", "不支持的下载来源：$profile")
        return shell.root("${RootShell.q(ASTRCTL)} download-source ${RootShell.q(safe)}", 20)
    }

    suspend fun healthCheck(): ShellResult = shell.root("${RootShell.q(ASTRCTL)} doctor", 75)

    suspend fun rebootDevice(): ShellResult = shell.root("sync; reboot", 8)

    suspend fun logSources(): Result<List<LogSource>> {
        val result = shell.root("${RootShell.q(ASTRCTL)} logs-list", 15)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "无法读取日志列表" } }))
        }
        val items = result.stdout.lineSequence().mapNotNull { line ->
            if (!line.startsWith("LOG|")) return@mapNotNull null
            val p = line.split('|', limit = 3)
            if (p.size < 3 || p[1].isBlank()) null else LogSource(p[1], p[2].ifBlank { p[1] })
        }.toList()
        return Result.success(items)
    }

    suspend fun log(key: String, lines: Int = 360): Result<String> {
        val safeKey = key.takeIf { it.matches(Regex("[A-Za-z0-9._-]+")) } ?: "health"
        val safeLines = lines.coerceIn(20, 1200)
        val result = shell.root("${RootShell.q(ASTRCTL)} log ${RootShell.q(safeKey)} $safeLines", 18)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "日志读取失败" } }))
        }
        return Result.success(result.stdout)
    }

    suspend fun exportStart(mode: String): Result<DiagnosticExportState> {
        val safeMode = if (mode == "raw") "raw" else "redacted"
        val result = shell.root("${RootShell.q(ASTRCTL)} export-start $safeMode", 15)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "诊断导出没有启动" } }))
        }
        return exportStatus()
    }

    suspend fun exportStatus(): Result<DiagnosticExportState> {
        val result = shell.root("${RootShell.q(ASTRCTL)} export-status", 10)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "无法读取导出状态" } }))
        }
        val values = linkedMapOf<String, String>()
        result.stdout.lineSequence().forEach { line ->
            if (!line.startsWith("EXPORT|")) return@forEach
            val p = line.split('|', limit = 3)
            if (p.size == 3) values[p[1]] = p[2]
        }
        return Result.success(
            DiagnosticExportState(
                state = values["state"].orEmpty().ifBlank { "idle" },
                phase = values["phase"].orEmpty().ifBlank { "idle" },
                percent = values["percent"]?.toIntOrNull()?.coerceIn(0, 100) ?: 0,
                detail = values["detail"].orEmpty(),
                path = values["path"].orEmpty().ifBlank { values["output"].orEmpty() },
                mode = values["mode"].orEmpty().ifBlank { "redacted" },
                running = values["running"] == "1"
            )
        )
    }

    suspend fun exportCancel(): ShellResult = shell.root("${RootShell.q(ASTRCTL)} export-cancel", 12)

    suspend fun qqLoginSession(engine: String): Result<QqLoginSession> {
        if (engine != "snowluma") {
            return webUrl("napcat", "login").map { url ->
                QqLoginSession(state = "ready", url = url, detail = "NapCat 登录页面已就绪")
            }
        }
        val result = shell.root("${RootShell.q(ASTRCTL)} snowluma-login-request main", 15)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout }))
        return parseLoginReply(result.stdout)
    }

    suspend fun qqLoginFrame(): Result<QqLoginFrame> {
        val result = shell.root("${RootShell.q(ASTRCTL)} snowluma-login-frame main", 14)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "读取 QQ 登录画面失败" } }))
        val line = result.stdout.lineSequence().firstOrNull { it.startsWith("FRAME|") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回 QQ 登录画面"))
        val parts = line.split('|', limit = 7)
        val state = parts.getOrNull(1).orEmpty().ifBlank { "idle" }
        val width = parts.getOrNull(2)?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val height = parts.getOrNull(3)?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val detail = parts.getOrNull(4).orEmpty()
        val meta = parts.getOrNull(5).orEmpty().split(',', limit = 6)
        val frameToken = meta.getOrNull(0).orEmpty()
        val display = meta.getOrNull(1)?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val windowX = meta.getOrNull(2)?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val windowY = meta.getOrNull(3)?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val windowWidth = meta.getOrNull(4)?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val windowHeight = meta.getOrNull(5)?.toIntOrNull()?.coerceAtLeast(0) ?: 0
        val encoded = parts.getOrNull(6).orEmpty()
        val png = if (encoded.isBlank()) ByteArray(0) else runCatching { Base64.decode(encoded, Base64.DEFAULT) }.getOrElse { ByteArray(0) }
        if (state == "ready" && png.isEmpty()) return Result.failure(IllegalStateException("QQ 登录画面数据为空"))
        val expired = state == "ready" && png.isNotEmpty() && looksLikeExpiredQqQr(png)
        return Result.success(
            QqLoginFrame(
                state = state,
                width = width,
                height = height,
                detail = detail,
                png = png,
                expired = expired,
                frameToken = frameToken,
                display = display,
                windowX = windowX,
                windowY = windowY,
                windowWidth = windowWidth,
                windowHeight = windowHeight
            )
        )
    }

    suspend fun qqLoginTap(
        x: Int,
        y: Int,
        frameWidth: Int,
        frameHeight: Int,
        frameToken: String,
        display: Int,
        windowX: Int,
        windowY: Int,
        windowWidth: Int,
        windowHeight: Int
    ): Result<String> {
        val width = frameWidth.coerceAtLeast(1)
        val height = frameHeight.coerceAtLeast(1)
        val safeX = x.coerceIn(0, width - 1)
        val safeY = y.coerceIn(0, height - 1)
        if (display <= 0 || windowWidth <= 0 || windowHeight <= 0 || frameToken.isBlank()) {
            return Result.failure(IllegalStateException("当前登录画面缺少触摸坐标信息，请等待画面刷新"))
        }
        val command = buildString {
            append(RootShell.q(ASTRCTL)).append(" snowluma-login-tap main ")
            append(RootShell.q(frameToken)).append(' ')
            append(safeX).append(' ').append(safeY).append(' ')
            append(width).append(' ').append(height).append(' ')
            append(display).append(' ').append(windowX.coerceAtLeast(0)).append(' ').append(windowY.coerceAtLeast(0)).append(' ')
            append(windowWidth).append(' ').append(windowHeight)
        }
        val result = shell.root(command, 12)
        val tapLine = result.stdout.lineSequence().lastOrNull { it.startsWith("TAP|") }.orEmpty()
        if (!result.ok || tapLine.startsWith("TAP|failed|")) {
            val detail = tapLine.substringAfter("TAP|failed|", "").ifBlank { result.stderr.ifBlank { result.stdout } }
            return Result.failure(IllegalStateException(detail.ifBlank { "QQ 登录窗口没有响应触摸" }))
        }
        return Result.success(tapLine.substringAfter("TAP|ok|", "已发送触摸").ifBlank { "已发送触摸" })
    }

    private suspend fun snowlumaMainDisplay(): Int {
        val result = shell.root("${RootShell.q(ASTRCTL)} snowluma-instance-list", 8)
        val line = result.stdout.lineSequence().firstOrNull { it.startsWith("INSTANCE|main|") }
        return line?.split('|')?.getOrNull(7)?.toIntOrNull()?.takeIf { it in 1..999 } ?: 31
    }

    suspend fun qqLoginDesktopFrame(): Result<QqLoginFrame> {
        val display = snowlumaMainDisplay()
        val guestScript = """
            set -eu
            export DISPLAY=:__DISPLAY__
            command -v ffmpeg >/dev/null 2>&1 || { echo '缺少 ffmpeg' >&2; exit 3; }
            command -v xdotool >/dev/null 2>&1 || { echo '缺少 xdotool' >&2; exit 3; }
            GEOM="§(xdotool getdisplaygeometry 2>/dev/null || true)"
            WIDTH="§(printf '%s' "§GEOM" | awk '{print §1}')"
            HEIGHT="§(printf '%s' "§GEOM" | awk '{print §2}')"
            case "§WIDTH:§HEIGHT" in *[!0-9:]*|:*|*:) WIDTH=1024; HEIGHT=640 ;; esac
            [ "§WIDTH" -gt 0 ] || WIDTH=1024; [ "§HEIGHT" -gt 0 ] || HEIGHT=640
            OUT="/tmp/astrbot-cc-desktop-§§.jpg"
            trap 'rm -f "§OUT" 2>/dev/null || true' EXIT
            ffmpeg -nostdin -hide_banner -loglevel error -f x11grab -draw_mouse 1 \
              -video_size "§{WIDTH}x§{HEIGHT}" -i ":__DISPLAY__.0+0,0" \
              -frames:v 1 -q:v 11 -y "§OUT" >/dev/null 2>&1
            [ -s "§OUT" ] || { echo '完整桌面截图为空' >&2; exit 6; }
            DATA="§(base64 -w 0 "§OUT" 2>/dev/null || base64 "§OUT" 2>/dev/null | tr -d '\r\n')"
            [ -n "§DATA" ] || { echo '完整桌面编码失败' >&2; exit 7; }
            printf 'DESKTOPFRAME|ready|%s|%s|完整桌面已更新|%s\n' "§WIDTH" "§HEIGHT" "§DATA"
        """.trimIndent()
            .replace("__DISPLAY__", display.toString())
            .replace('§', '$')
        val command = "printf '%s\n' ${RootShell.q(guestScript)} exit | ${RootShell.q(ASTRCTL)} shell"
        val result = shell.root(command, 18)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "读取完整 QQ 桌面失败" } }))
        }
        val line = result.stdout.lineSequence().firstOrNull { it.startsWith("DESKTOPFRAME|") }
            ?: return Result.failure(IllegalStateException("没有收到完整 QQ 桌面画面"))
        val parts = line.split('|', limit = 7)
        val width = parts.getOrNull(2)?.toIntOrNull()?.coerceAtLeast(1) ?: 1024
        val height = parts.getOrNull(3)?.toIntOrNull()?.coerceAtLeast(1) ?: 640
        val detail = parts.getOrNull(4).orEmpty()
        val encoded = parts.getOrNull(5).orEmpty()
        val image = runCatching { Base64.decode(encoded, Base64.DEFAULT) }.getOrElse { ByteArray(0) }
        if (image.isEmpty()) return Result.failure(IllegalStateException("完整 QQ 桌面画面数据为空"))
        return Result.success(QqLoginFrame(state = "ready", width = width, height = height, detail = detail, png = image))
    }

    suspend fun qqLoginDesktopTap(x: Int, y: Int, frameWidth: Int, frameHeight: Int): Result<String> {
        val display = snowlumaMainDisplay()
        val width = frameWidth.coerceAtLeast(1)
        val height = frameHeight.coerceAtLeast(1)
        val safeX = x.coerceIn(0, width - 1)
        val safeY = y.coerceIn(0, height - 1)
        val guestScript = """
            set -eu
            export DISPLAY=:__DISPLAY__
            GEOM="§(xdotool getdisplaygeometry 2>/dev/null || true)"
            DW="§(printf '%s' "§GEOM" | awk '{print §1}')"; DH="§(printf '%s' "§GEOM" | awk '{print §2}')"
            case "§DW:§DH" in *[!0-9:]*|:*|*:) DW=1024; DH=640 ;; esac
            X=§((__X__ * DW / __FW__)); Y=§((__Y__ * DH / __FH__))
            [ "§X" -lt "§DW" ] || X=§((DW-1)); [ "§Y" -lt "§DH" ] || Y=§((DH-1))
            xdotool mousemove "§X" "§Y" click 1 >/dev/null 2>&1
            echo "完整 QQ 桌面已点击 §X,§Y"
        """.trimIndent()
            .replace("__DISPLAY__", display.toString())
            .replace("__X__", safeX.toString())
            .replace("__Y__", safeY.toString())
            .replace("__FW__", width.toString())
            .replace("__FH__", height.toString())
            .replace('§', '$')
        val command = "printf '%s\n' ${RootShell.q(guestScript)} exit | ${RootShell.q(ASTRCTL)} shell"
        val result = shell.root(command, 12)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "完整 QQ 桌面没有响应触摸" } }))
        return Result.success(result.stdout.lineSequence().lastOrNull().orEmpty().ifBlank { "已发送桌面触摸" })
    }

    suspend fun qqLoginRefreshCode(): Result<String> {
        val result = shell.root("${RootShell.q(ASTRCTL)} snowluma-login-refresh-code main", 16)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "刷新二维码失败" } }))
        }
        val line = result.stdout.lineSequence().firstOrNull { it.startsWith("REFRESH|") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回二维码刷新结果"))
        val parts = line.split('|', limit = 4)
        val state = parts.getOrNull(1).orEmpty()
        val detail = parts.getOrNull(3).orEmpty().ifBlank { parts.getOrNull(2).orEmpty() }
        return if (state == "ok" || state == "cooldown") Result.success(detail.ifBlank { "已请求 QQ 刷新二维码" })
        else Result.failure(IllegalStateException(detail.ifBlank { "QQ 没有接受二维码刷新操作" }))
    }

    suspend fun astrbotWebProbe(): Result<String> {
        val result = shell.root("${RootShell.q(ASTRCTL)} web-probe astrbot", 14)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "AstrBot WebUI 检查失败" } }))
        }
        val line = result.stdout.lineSequence().firstOrNull { it.startsWith("WEBPROBE|") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回 AstrBot WebUI 检查结果"))
        val parts = line.split('|', limit = 4)
        val state = parts.getOrNull(1).orEmpty()
        val detail = parts.getOrNull(3).orEmpty().ifBlank { parts.getOrNull(2).orEmpty() }
        return if (state == "ok") Result.success(detail.ifBlank { "AstrBot WebUI 首页与静态资源检查通过" })
        else Result.failure(IllegalStateException(detail.ifBlank { "AstrBot WebUI 静态资源异常" }))
    }

    suspend fun qqLoginDesktopStop(): ShellResult = shell.root(
        "${RootShell.q(ASTRCTL)} snowluma-instance-desktop-stop main",
        12
    )

    suspend fun qqLoginDesktopSession(): Result<QqLoginSession> {
        val result = shell.root("${RootShell.q(ASTRCTL)} snowluma-login-desktop main", 28)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout }))
        return parseLoginReply(result.stdout)
    }

    suspend fun qqLoginDisplayRecovery(): Result<QqLoginSession> = qqLoginDesktopSession()

    private fun parseLoginReply(output: String): Result<QqLoginSession> {
        val line = output.lineSequence().firstOrNull { it.startsWith("LOGIN|") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回扫码状态"))
        val parts = line.split('|', limit = 4)
        val state = parts.getOrNull(1).orEmpty().ifBlank { "idle" }
        val url = parts.getOrNull(2).orEmpty()
        val detail = parts.getOrNull(3).orEmpty()
        if (url.isNotBlank() && !isLocalConsoleUrl(url)) {
            return Result.failure(IllegalStateException("扫码桌面返回了非本机地址，已拒绝打开"))
        }
        return Result.success(QqLoginSession(state = state, url = url, detail = detail))
    }

    suspend fun webUrl(kind: String, mode: String = "admin"): Result<String> {
        val safeKind = when (kind) {
            "astrbot", "napcat", "snowluma" -> kind
            else -> return Result.failure(IllegalArgumentException("未知控制台：$kind"))
        }
        val safeMode = when (mode) {
            "admin", "login", "qr" -> mode
            else -> "admin"
        }
        val result = shell.root("${RootShell.q(ASTRCTL)} web-url $safeKind $safeMode", 10)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout }))
        val url = result.stdout.lineSequence().map { it.trim() }.firstOrNull { it.startsWith("http://") || it.startsWith("https://") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回可打开的地址"))
        if (!isLocalConsoleUrl(url)) return Result.failure(IllegalStateException("控制台返回了非本机地址，已拒绝打开"))
        return Result.success(url)
    }



    private fun looksLikeExpiredQqQr(png: ByteArray): Boolean {
        val bitmap = runCatching { BitmapFactory.decodeByteArray(png, 0, png.size) }.getOrNull() ?: return false
        return try {
            val w = bitmap.width
            val h = bitmap.height
            if (w < 160 || h < 240) return false
            val left = (w * 0.22f).toInt().coerceIn(0, w - 1)
            val right = (w * 0.78f).toInt().coerceIn(left + 1, w)
            val top = (h * 0.43f).toInt().coerceIn(0, h - 1)
            val bottom = (h * 0.62f).toInt().coerceIn(top + 1, h)
            var redDominant = 0
            var sampled = 0
            var y = top
            while (y < bottom) {
                var x = left
                while (x < right) {
                    val c = bitmap.getPixel(x, y)
                    val r = Color.red(c)
                    val g = Color.green(c)
                    val b = Color.blue(c)
                    if (r > 175 && r > g * 1.30f && r > b * 1.22f) redDominant++
                    sampled++
                    x += 2
                }
                y += 2
            }
            sampled > 0 && redDominant >= 12
        } finally {
            bitmap.recycle()
        }
    }
    private fun isLocalConsoleUrl(url: String): Boolean {
        return runCatching {
            val uri = java.net.URI(url)
            (uri.scheme == "http" || uri.scheme == "https") &&
                (uri.host == "127.0.0.1" || uri.host == "localhost" || uri.host == "::1")
        }.getOrDefault(false)
    }
}
