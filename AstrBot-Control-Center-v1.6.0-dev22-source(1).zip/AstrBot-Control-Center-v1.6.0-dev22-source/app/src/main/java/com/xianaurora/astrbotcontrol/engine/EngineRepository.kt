package com.xianaurora.astrbotcontrol.engine

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.StatFs
import com.xianaurora.astrbotcontrol.model.CheckItem
import com.xianaurora.astrbotcontrol.model.EngineStatus
import com.xianaurora.astrbotcontrol.model.ExistingEngineInfo
import com.xianaurora.astrbotcontrol.model.InstallEvent
import com.xianaurora.astrbotcontrol.model.InstallPlanItem
import com.xianaurora.astrbotcontrol.model.ResourceStatus
import com.xianaurora.astrbotcontrol.model.RootBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import org.json.JSONObject

class EngineRepository(
    private val context: Context,
    private val shell: RootShell = RootShell()
) {
    companion object {
        const val MODULE_ID = "astrbot_standalone"
        const val MODULE_DIR = "/data/adb/modules/$MODULE_ID"
        const val ASTRCTL = "$MODULE_DIR/astrctl"
        const val EXPECTED_PROTOCOL = 1
        const val TARGET_ENGINE_VERSION = "1.6.0-dev13"
        const val TARGET_ENGINE_VERSION_CODE = 16013
        const val ENGINE_BACKUP_DIR = "/data/adb/astrbot_standalone/engine-backups"
        const val PENDING_MODULE_DIR = "/data/adb/modules_update/$MODULE_ID"
        const val ROOTFS_NAME = "AstrBot-Standalone-Base-Ubuntu24.04-arm64-v1.0.0.tar.xz"
        const val ROOTFS_SIZE = 65831076L
        const val ROOTFS_SHA = "4590dbac3ec23adbadbeba67a9d9c0098069d55ebee4731a9889616a82981441"
    }

    data class RootInfo(val backend: RootBackend, val version: String, val rootGranted: Boolean)
    data class EngineAsset(val file: File, val sha256: String)
    data class InstallResult(val ok: Boolean, val message: String, val backend: RootBackend)
    data class RootfsCatalog(val filename: String, val size: Long, val sha256: String, val urls: List<String>)
    data class DownloadProgress(val current: Long, val total: Long, val speedBytesPerSecond: Long, val source: String)


    fun rootfsCatalog(): RootfsCatalog {
        val text = context.assets.open("resource-catalog.json").bufferedReader().use { it.readText() }
        val root = JSONObject(text)
        val arr = root.getJSONArray("resources")
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            if (item.optString("id") == "ubuntu-rootfs") {
                val urlsJson = item.optJSONArray("download_urls") ?: item.optJSONArray("downloadUrls")
                val urls = buildList {
                    if (urlsJson != null) for (j in 0 until urlsJson.length()) {
                        urlsJson.optString(j).takeIf { it.startsWith("https://") }?.let(::add)
                    }
                }
                return RootfsCatalog(
                    item.optString("filename", ROOTFS_NAME),
                    item.optLong("size", ROOTFS_SIZE),
                    item.optString("sha256", ROOTFS_SHA),
                    urls
                )
            }
        }
        return RootfsCatalog(ROOTFS_NAME, ROOTFS_SIZE, ROOTFS_SHA, emptyList())
    }

    suspend fun downloadRootfs(onProgress: (DownloadProgress) -> Unit): ShellResult = withContext(Dispatchers.IO) {
        val catalog = rootfsCatalog()
        val target = File(context.cacheDir, catalog.filename)
        val partial = File(context.cacheDir, catalog.filename + ".part")
        // A verified cache remains usable even when the current catalog has no
        // network mirror configured. The old order returned "no download URL"
        // before checking a fully downloaded target/.part file.
        if (target.isFile && target.length() == catalog.size && sha256(target).equals(catalog.sha256, true)) {
            return@withContext importVerifiedRootfsFile(target, catalog)
        }
        if (target.exists() && (target.length() != catalog.size || !sha256(target).equals(catalog.sha256, true))) target.delete()
        var lastError = ""
        if (partial.isFile && partial.length() > catalog.size) partial.delete()
        if (partial.isFile && partial.length() == catalog.size) {
            val partialSha = sha256(partial)
            if (partialSha.equals(catalog.sha256, true)) {
                if (target.exists()) target.delete()
                if (!partial.renameTo(target)) partial.copyTo(target, overwrite = true)
                return@withContext importVerifiedRootfsFile(target, catalog)
            }
            partial.delete()
        }
        if (catalog.urls.isEmpty()) return@withContext ShellResult(78, "", "当前发布清单没有配置经过验证的 Ubuntu 基础资源下载地址")
        for (source in catalog.urls) {
            try {
                var existing = if (partial.isFile) partial.length() else 0L
                val conn = (URL(source).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 30000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "AstrBot-Control-Center/1.6.0-dev17")
                    if (existing > 0) setRequestProperty("Range", "bytes=$existing-")
                }
                conn.connect()
                val code = conn.responseCode
                if (code !in 200..299) throw IllegalStateException("HTTP $code")
                val append = existing > 0 && code == HttpURLConnection.HTTP_PARTIAL
                if (!append) existing = 0L
                val total = when {
                    code == HttpURLConnection.HTTP_PARTIAL -> catalog.size
                    conn.contentLengthLong > 0 -> conn.contentLengthLong
                    else -> catalog.size
                }
                var copied = existing
                var markBytes = copied
                var markNanos = System.nanoTime()
                conn.inputStream.use { input ->
                    FileOutputStream(partial, append).use { output ->
                        val buffer = ByteArray(256 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            output.write(buffer, 0, n)
                            copied += n
                            val now = System.nanoTime()
                            if (now - markNanos >= 250_000_000L || copied >= total) {
                                val seconds = (now - markNanos) / 1_000_000_000.0
                                val speed = if (seconds > 0) ((copied - markBytes) / seconds).toLong() else 0L
                                onProgress(DownloadProgress(copied, total, speed, source))
                                markBytes = copied; markNanos = now
                            }
                        }
                    }
                }
                conn.disconnect()
                if (partial.length() != catalog.size) throw IllegalStateException("文件大小不匹配：${partial.length()} / ${catalog.size}")
                val got = sha256(partial)
                if (!got.equals(catalog.sha256, true)) {
                    partial.delete()
                    throw IllegalStateException("SHA-256 校验失败")
                }
                if (target.exists()) target.delete()
                if (!partial.renameTo(target)) partial.copyTo(target, overwrite = true)
                return@withContext importVerifiedRootfsFile(target, catalog)
            } catch (t: Throwable) {
                lastError = "${t.message ?: t::class.java.simpleName} · $source"
            }
        }
        ShellResult(79, "", lastError.ifBlank { "所有下载源均不可用；已下载的 .part 会保留用于续传" })
    }

    private suspend fun importVerifiedRootfsFile(file: File, catalog: RootfsCatalog = rootfsCatalog()): ShellResult {
        if (file.length() != catalog.size) return ShellResult(4, "", "文件大小不匹配：${file.length()} / ${catalog.size}")
        val got = sha256(file)
        if (!got.equals(catalog.sha256, true)) return ShellResult(5, "", "SHA-256 不匹配：$got")
        return shell.root("${RootShell.q(ASTRCTL)} installer-resource-import rootfs ${RootShell.q(file.absolutePath)}", 90)
    }

    suspend fun rootInfo(): RootInfo {
        val id = shell.root("id -u", 15)
        if (!id.ok || id.stdout.lineSequence().firstOrNull()?.trim() != "0") return RootInfo(RootBackend.NONE, "", false)
        val probe = shell.root(
            "if [ -x /data/adb/ksud ]; then echo KERNELSU; echo /data/adb/ksud; /data/adb/ksud --version 2>/dev/null || /data/adb/ksud -V 2>/dev/null || true; " +
                "elif command -v ksud >/dev/null 2>&1; then echo KERNELSU; command -v ksud; ksud --version 2>/dev/null || ksud -V 2>/dev/null || true; " +
                "elif command -v apd >/dev/null 2>&1; then echo APATCH; command -v apd; apd --version 2>/dev/null || true; " +
                "elif command -v magisk >/dev/null 2>&1; then echo MAGISK; command -v magisk; magisk -V 2>/dev/null || magisk --version 2>/dev/null || true; else echo UNKNOWN; fi"
        )
        val lines = probe.stdout.lines().filter { it.isNotBlank() }
        val backend = when (lines.firstOrNull()?.trim()) {
            "MAGISK" -> RootBackend.MAGISK
            "KERNELSU" -> RootBackend.KERNEL_SU
            "APATCH" -> RootBackend.APATCH
            else -> RootBackend.UNKNOWN
        }
        return RootInfo(backend, lines.drop(1).joinToString(" · ").take(160), true)
    }


    suspend fun existingEngineInfo(): ExistingEngineInfo {
        val r = shell.root(
            """
D=/data/adb/modules/$MODULE_ID
P=/data/adb/astrbot_standalone
B=$ENGINE_BACKUP_DIR
if [ -r "${'$'}D/module.prop" ]; then
  echo installed=1
  awk -F= '${'$'}1=="id"{print "module_id=" substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}D/module.prop"
  awk -F= '${'$'}1=="version"{print "version=" substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}D/module.prop"
  awk -F= '${'$'}1=="versionCode"{print "version_code=" substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}D/module.prop"
  if [ ! -e "${'$'}D/disable" ] && [ ! -e "${'$'}D/remove" ]; then echo enabled=1; else echo enabled=0; fi
else
  echo installed=0; echo module_id=$MODULE_ID; echo version=; echo version_code=0; echo enabled=0
fi
[ -d "${'$'}P" ] && echo persistent=1 || echo persistent=0
KB=${'$'}(du -sk "${'$'}P" 2>/dev/null | awk '{print ${'$'}1}'); echo data_kb=${'$'}{KB:-0}
[ -x "${'$'}P/rootfs/bin/bash" ] && [ -r "${'$'}P/state/rootfs.manifest" ] && echo rootfs=1 || echo rootfs=0
[ -r "${'$'}P/state/app.manifest" ] && [ -r "${'$'}P/app/data/cmd_config.json" ] && [ -x "${'$'}P/tools/bin/uv" ] && echo astrbot=1 || echo astrbot=0
[ -r "${'$'}P/state/napcat.manifest" ] && [ -x "${'$'}P/napcat-home/Napcat/opt/QQ/qq" ] && echo napcat=1 || echo napcat=0
[ -r "${'$'}P/state/stage4.manifest" ] && [ -s "${'$'}P/state/onebot-token.txt" ] && echo onebot=1 || echo onebot=0
if [ -r "${'$'}B/latest.conf" ]; then
  ARCH=${'$'}(awk -F= '${'$'}1=="archive"{print substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}B/latest.conf")
  RBV=${'$'}(awk -F= '${'$'}1=="version"{print substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}B/latest.conf")
  [ -r "${'$'}ARCH" ] && { echo rollback=1; echo rollback_version=${'$'}RBV; } || { echo rollback=0; echo rollback_version=; }
else echo rollback=0; echo rollback_version=; fi
            """.trimIndent(), 20
        )
        val m = ProtocolParser.keyValues(r.stdout)
        return ExistingEngineInfo(
            present = m["installed"] == "1",
            version = m["version"].orEmpty(),
            versionCode = m["version_code"]?.toIntOrNull() ?: 0,
            moduleId = m["module_id"].orEmpty().ifBlank { MODULE_ID },
            enabled = m["enabled"] == "1",
            persistentDataPresent = m["persistent"] == "1",
            persistentDataBytes = (m["data_kb"]?.toLongOrNull() ?: 0L) * 1024L,
            rootfsReady = m["rootfs"] == "1",
            astrbotReady = m["astrbot"] == "1",
            napcatReady = m["napcat"] == "1",
            onebotReady = m["onebot"] == "1",
            rollbackAvailable = m["rollback"] == "1",
            rollbackVersion = m["rollback_version"].orEmpty()
        )
    }

    suspend fun createEngineBackup(existing: ExistingEngineInfo): ShellResult {
        if (!existing.installed) return ShellResult(0, "没有现有核心组件，无需创建回退点", "")
        val r = shell.root(
            """
D=/data/adb/modules/$MODULE_ID
P=/data/adb/astrbot_standalone
B=$ENGINE_BACKUP_DIR
[ -r "${'$'}D/module.prop" ] || { echo '现有核心组件不存在' >&2; exit 40; }
if [ -x "${'$'}D/engine-maintenance.sh" ]; then exec /system/bin/sh "${'$'}D/engine-maintenance.sh" snapshot "${'$'}D"; fi
BB=${'$'}D/bin/busybox
[ -x "${'$'}BB" ] || { echo '现有核心组件缺少 BusyBox，无法创建安全回退点' >&2; exit 41; }
mkdir -p "${'$'}B" || exit 42; chmod 0700 "${'$'}B" 2>/dev/null || true
VER=${'$'}("${'$'}BB" awk -F= '${'$'}1=="version"{print substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}D/module.prop"); [ -n "${'$'}VER" ] || VER=unknown
VCODE=${'$'}("${'$'}BB" awk -F= '${'$'}1=="versionCode"{print substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}D/module.prop"); [ -n "${'$'}VCODE" ] || VCODE=0
STAMP=${'$'}(date '+%Y%m%d-%H%M%S' 2>/dev/null || echo ${'$'}${'$'})
SAFE=${'$'}(printf '%s' "${'$'}VER" | "${'$'}BB" tr -c 'A-Za-z0-9._-' '_')
TAR=${'$'}B/engine-${'$'}SAFE-${'$'}STAMP.tar
"${'$'}BB" tar -cpf "${'$'}TAR.tmp" -C /data/adb/modules $MODULE_ID || exit 43
SHA=${'$'}("${'$'}BB" sha256sum "${'$'}TAR.tmp" | "${'$'}BB" awk '{print ${'$'}1}')
[ ${'$'}{#SHA} -eq 64 ] || { rm -f "${'$'}TAR.tmp"; exit 44; }
mv -f "${'$'}TAR.tmp" "${'$'}TAR" || exit 45; chmod 0600 "${'$'}TAR" 2>/dev/null || true
{ echo version=${'$'}VER; echo version_code=${'$'}VCODE; echo created_at=${'$'}(date +%s 2>/dev/null || echo 0); echo archive=${'$'}TAR; echo sha256=${'$'}SHA; echo source=${'$'}D; } > "${'$'}B/latest.conf.tmp" || exit 46
mv -f "${'$'}B/latest.conf.tmp" "${'$'}B/latest.conf" || exit 47; chmod 0600 "${'$'}B/latest.conf" 2>/dev/null || true
echo SNAPSHOT\|ready\|version=${'$'}VER\|archive=${'$'}TAR
            """.trimIndent(), 90
        )
        return r
    }

    suspend fun restoreEngineBackup(): ShellResult = shell.root(
        """
D=/data/adb/modules/$MODULE_ID
U=$PENDING_MODULE_DIR
B=$ENGINE_BACKUP_DIR
if [ -x "${'$'}D/engine-maintenance.sh" ]; then
  /system/bin/sh "${'$'}D/engine-maintenance.sh" rollback --confirm || exit ${'$'}?
  rm -rf "${'$'}U" 2>/dev/null || true
  rm -f "${'$'}D/update" 2>/dev/null || true
  sync
  exit 0
fi
META=${'$'}B/latest.conf
[ -r "${'$'}META" ] || { echo '没有可用核心组件回退点' >&2; exit 50; }
if [ -x "${'$'}D/bin/busybox" ]; then TOOL=${'$'}D/bin/busybox; else TOOL=/system/bin/toybox; fi
ARCH=${'$'}("${'$'}TOOL" awk -F= '${'$'}1=="archive"{print substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}META")
EXPECT=${'$'}("${'$'}TOOL" awk -F= '${'$'}1=="sha256"{print substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}META")
VER=${'$'}("${'$'}TOOL" awk -F= '${'$'}1=="version"{print substr(${'$'}0,index(${'$'}0,"=")+1);exit}' "${'$'}META")
[ -r "${'$'}ARCH" ] || exit 51
GOT=${'$'}("${'$'}TOOL" sha256sum "${'$'}ARCH" 2>/dev/null | "${'$'}TOOL" awk '{print ${'$'}1}')
[ "${'$'}GOT" = "${'$'}EXPECT" ] || { echo '回退包校验失败' >&2; exit 52; }
TMP=/data/adb/.astrbot-engine-rollback-${'$'}${'$'}; FAILED=${'$'}B/failed-current-${'$'}(date '+%Y%m%d-%H%M%S' 2>/dev/null || echo ${'$'}${'$'})
rm -rf "${'$'}TMP" 2>/dev/null || true; mkdir -p "${'$'}TMP" || exit 53
"${'$'}TOOL" tar -xpf "${'$'}ARCH" -C "${'$'}TMP" || exit 54
R=${'$'}TMP/$MODULE_ID
[ -r "${'$'}R/module.prop" ] && [ -x "${'$'}R/astrctl" ] && [ -x "${'$'}R/service.sh" ] || exit 55
if [ -d "${'$'}D" ]; then mv "${'$'}D" "${'$'}FAILED" || exit 56; fi
mv "${'$'}R" "${'$'}D" || { [ -d "${'$'}FAILED" ] && mv "${'$'}FAILED" "${'$'}D" 2>/dev/null || true; exit 57; }
rm -rf "${'$'}TMP" "${'$'}U" 2>/dev/null || true
rm -f "${'$'}D/update" 2>/dev/null || true
chown -R 0:0 "${'$'}D" 2>/dev/null || true
printf '%s\n' "${'$'}(date +%s 2>/dev/null || echo 0)" > /data/adb/astrbot_standalone/state/reboot-required
printf '%s\n' "${'$'}VER" > /data/adb/astrbot_standalone/state/engine-rollback-pending.txt
sync; echo ROLLBACK\|restored=1\|version=${'$'}VER\|reboot_required=1
        """.trimIndent(), 120
    )

    suspend fun clearPendingEngineUpdate(): ShellResult = shell.root(
        "rm -rf ${RootShell.q(PENDING_MODULE_DIR)} 2>/dev/null || true; " +
            "rm -f ${RootShell.q(MODULE_DIR + "/update")} 2>/dev/null || true; sync; echo 'PENDING_UPDATE|cleared=1'",
        20
    )


    suspend fun bootId(): String {
        val normal = shell.normal("cat /proc/sys/kernel/random/boot_id 2>/dev/null || true", 8).stdout.trim()
        if (normal.isNotBlank()) return normal
        return shell.root("cat /proc/sys/kernel/random/boot_id 2>/dev/null || true", 8).stdout.trim()
    }

    suspend fun clearRollbackPendingMarkers(): ShellResult = shell.root(
        "rm -f /data/adb/astrbot_standalone/state/reboot-required /data/adb/astrbot_standalone/state/engine-rollback-pending.txt 2>/dev/null || true",
        8
    )

    suspend fun preflight(asset: EngineAsset, root: RootInfo): List<CheckItem> = withContext(Dispatchers.IO) {
        val abiOk = Build.SUPPORTED_ABIS.any { it == "arm64-v8a" }
        val page = shell.root("getconf PAGE_SIZE 2>/dev/null || getconf PAGESIZE 2>/dev/null || echo 0").stdout.trim().toLongOrNull() ?: 0L
        val pageOk = page == 4096L
        val stat = StatFs("/data")
        val free = stat.availableBytes
        val minFree = 2L * 1024 * 1024 * 1024
        val managerOk = root.backend in setOf(RootBackend.MAGISK, RootBackend.KERNEL_SU, RootBackend.APATCH)
        val existing = existingEngineInfo()
        val identityOk = !existing.present || existing.moduleId == MODULE_ID
        listOf(
            CheckItem("engine", "核心组件安装包", "内置文件 SHA-256 ${asset.sha256.take(12)}…", asset.file.isFile && asset.file.length() > 0),
            CheckItem("abi", "ARM64 架构", Build.SUPPORTED_ABIS.joinToString(), abiOk),
            CheckItem("pagesize", "4 KB 内存页", if (page > 0) "$page bytes" else "无法读取", pageOk),
            CheckItem("root", "Root 权限", if (root.rootGranted) "已授权 · ${root.backend.label} ${root.version}" else "需要 Root 授权", root.rootGranted),
            CheckItem("manager", "Root 模块管理器", if (managerOk) root.backend.label else "需要 Magisk / KernelSU / APatch", managerOk),
            CheckItem("engine-id", "核心组件身份", if (identityOk) "模块 ID：$MODULE_ID" else "检测到异常模块 ID：${existing.moduleId}", identityOk),
            CheckItem("single-engine", "单核心组件原地升级", "检测到旧版时只原地替换同一个 $MODULE_ID，不并行安装第二个核心组件", true),
            CheckItem("space", "安装空间", "可用 ${formatBytes(free)} · 建议至少 ${formatBytes(minFree)}", free >= minFree)
        )
    }

    suspend fun prepareEngineAsset(): EngineAsset = withContext(Dispatchers.IO) {
        val out = File(context.cacheDir, "astrbot-core-${TARGET_ENGINE_VERSION}.zip")
        context.assets.open("engine.zip").use { input ->
            FileOutputStream(out).use { output -> input.copyTo(output, 256 * 1024) }
        }
        val got = sha256(out)
        val expected = context.assets.open("engine.sha256").bufferedReader().use { it.readText().trim().split(Regex("\\s+"))[0] }
        require(expected.length == 64 && got.equals(expected, true)) { "内置核心组件安装包完整性校验失败" }
        EngineAsset(out, got)
    }

    suspend fun installEngine(asset: EngineAsset, root: RootInfo): InstallResult {
        if (!root.rootGranted) return InstallResult(false, "尚未获得 Root 权限", root.backend)
        val staging = "/data/local/tmp/astrbot-control-center-core.zip"
        val copy = shell.root("cp ${RootShell.q(asset.file.absolutePath)} ${RootShell.q(staging)} && chmod 0644 ${RootShell.q(staging)}", 30)
        if (!copy.ok) return InstallResult(false, "无法把核心组件交给 Root 环境：${copy.stderr.ifBlank { copy.stdout }}", root.backend)
        val command = when (root.backend) {
            RootBackend.MAGISK -> "magisk --install-module ${RootShell.q(staging)}"
            RootBackend.KERNEL_SU -> "if [ -x /data/adb/ksud ]; then /data/adb/ksud module install ${RootShell.q(staging)}; else ksud module install ${RootShell.q(staging)}; fi"
            RootBackend.APATCH -> "apd module install ${RootShell.q(staging)}"
            else -> return InstallResult(false, "当前 Root 管理器没有受支持的模块安装命令", root.backend)
        }
        val result = shell.root(command, 120)
        if (result.ok) {
            shell.root("rm -f ${RootShell.q(staging)}", 10)
            return InstallResult(true, result.stdout.ifBlank { "核心组件已写入，等待重启验证" }, root.backend)
        }
        val fallback = "/sdcard/Download/AstrBot-Core-${TARGET_ENGINE_VERSION}-arm64.zip"
        val exported = shell.root("cp ${RootShell.q(staging)} ${RootShell.q(fallback)} && chmod 0644 ${RootShell.q(fallback)}", 20).ok
        shell.root("rm -f ${RootShell.q(staging)}", 10)
        val detail = (result.stderr + "\n" + result.stdout).trim().ifBlank { "Root 管理器没有返回文本" }
        val meta = "exit=${result.code}${if (result.timedOut) ", timedOut=1" else ""}"
        return if (root.backend == RootBackend.APATCH) {
            InstallResult(false, "APatch 命令行安装没有完成（$meta）。${if (exported) "已把经过校验的核心组件安装包保留到 $fallback，可在 APatch 管理器的模块页手动导入。" else "自动导出备用 ZIP 也没有完成。"} 原始返回：$detail", root.backend)
        } else {
            InstallResult(false, "${root.backend.label} 模块安装命令没有完成（$meta）。${if (exported) "已把经过校验的核心组件安装包保留到 $fallback，可在 Root 管理器模块页手动导入。" else "自动导出备用 ZIP 也没有完成。"} 原始返回：$detail", root.backend)
        }
    }

    suspend fun reboot(): ShellResult = shell.root("sync; reboot", 8)

    suspend fun enginePresent(): Boolean = shell.root("test -x ${RootShell.q(ASTRCTL)}", 8).ok

    suspend fun protocol(): Int {
        val r = shell.root("${RootShell.q(ASTRCTL)} app-protocol", 10)
        if (!r.ok) return 0
        val m = r.stdout.split('|').drop(1).associate { token ->
            val i = token.indexOf('='); if (i > 0) token.substring(0, i) to token.substring(i + 1) else token to ""
        }
        return m["version"]?.toIntOrNull() ?: 0
    }

    suspend fun status(): EngineStatus {
        val r = shell.root("${RootShell.q(ASTRCTL)} installer-status", 15)
        return if (r.ok) ProtocolParser.status(r.stdout) else EngineStatus(detail = r.stderr.ifBlank { r.stdout })
    }

    suspend fun plan(): List<InstallPlanItem> {
        val r = shell.root("${RootShell.q(ASTRCTL)} installer-plan", 15)
        return if (r.ok) ProtocolParser.plan(r.stdout) else emptyList()
    }

    suspend fun resourceStatus(): ResourceStatus {
        val r = shell.root("${RootShell.q(ASTRCTL)} installer-resource-status", 20)
        return if (r.ok) ProtocolParser.resource(r.stdout) else ResourceStatus()
    }

    suspend fun events(limit: Int = 80): List<InstallEvent> {
        val r = shell.root("${RootShell.q(ASTRCTL)} installer-events ${limit.coerceIn(10, 200)}", 15)
        return if (r.ok) ProtocolParser.events(r.stdout) else emptyList()
    }

    suspend fun technicalLog(lines: Int = 120): String {
        val n = lines.coerceIn(20, 300)
        val r = shell.root("tail -n $n /data/adb/astrbot_standalone/logs/action.log 2>/dev/null || true", 15)
        return r.stdout
    }

    suspend fun startRuntime(): ShellResult = shell.root("${RootShell.q(ASTRCTL)} installer-start", 20)

    suspend fun importRootfs(uri: Uri, onProgress: (Float) -> Unit): ShellResult = withContext(Dispatchers.IO) {
        val catalog = rootfsCatalog()
        val tmp = File(context.cacheDir, catalog.filename)
        val digest = MessageDigest.getInstance("SHA-256")
        var copied = 0L
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tmp).use { output ->
                val buffer = ByteArray(256 * 1024)
                while (true) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    output.write(buffer, 0, n)
                    digest.update(buffer, 0, n)
                    copied += n
                    onProgress((copied.toDouble() / catalog.size.toDouble()).coerceIn(0.0, 1.0).toFloat())
                }
            }
        } ?: return@withContext ShellResult(2, "", "无法读取所选文件")
        val got = digest.digest().joinToString("") { "%02x".format(it) }
        if (copied != catalog.size) return@withContext ShellResult(4, "", "文件大小不匹配：$copied / ${catalog.size}")
        if (!got.equals(catalog.sha256, true)) return@withContext ShellResult(5, "", "SHA-256 不匹配：$got")
        importVerifiedRootfsFile(tmp, catalog)
    }

    suspend fun readExistingDataSize(): Long {
        val r = shell.root("du -sk /data/adb/astrbot_standalone 2>/dev/null | awk '{print \$1}'", 15)
        return (r.stdout.trim().toLongOrNull() ?: 0L) * 1024L
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val b = ByteArray(256 * 1024)
            while (true) {
                val n = input.read(b); if (n <= 0) break; md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun formatBytes(v: Long): String {
        val gib = v / 1024.0 / 1024.0 / 1024.0
        return if (gib >= 1) "%.1f GiB".format(gib) else "%.0f MiB".format(v / 1024.0 / 1024.0)
    }
}
