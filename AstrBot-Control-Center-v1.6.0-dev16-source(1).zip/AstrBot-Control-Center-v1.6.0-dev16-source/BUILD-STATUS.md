# Build status — v1.6.0-dev16

- Android App: `1.6.0-dev16` / `161400`
- Embedded engine: intentionally unchanged at `1.6.0-dev11` / `16011`
- AstrBot UI: dedicated classic `AstrBotWebActivity`, not Compose `AndroidView`
- White-screen diagnostics: WebView provider, JS console, HTTP errors, renderer exits, DOM probe and PixelCopy pixel statistics
- Failure log bridge: `/data/adb/astrbot_standalone/logs/app-webview.log`

Run `bash scripts/verify-source.sh` before CI. The repository's GitHub Actions workflow performs the source gate, unit tests and full debug APK assembly with Android SDK 37.
