# dev22 — compact workbench, same-frame QQ touch, atomic settings lock

## User-visible changes

- Workbench no longer vertically centers three oversized launch cards in a mostly empty tablet canvas. It now shows a compact runtime strip, three consistent workspace launchers, the current service chain, and one context-aware next action.
- AstrBot keeps the classic Activity-hosted WebView that fixed the Android 16 white-screen issue, but its chrome now matches the workbench focused bar: `‹ 工作台`, title/status, fullscreen, and overflow tools. Fullscreen hides only the app chrome; it does not swap WebView implementations.
- The launcher icon now uses the user-provided `content-7.jpg` artwork. JPEG corner black is removed to transparency and both legacy/adaptive variants use conservative safe-area scaling.

## QQ login touch fix

- Each SnowLuma login screenshot now persists the exact X11 frame metadata used to capture it: DISPLAY, root X/Y, window width/height, window id and capture time.
- `snowluma-login-frame` returns compact touch metadata alongside the PNG.
- Android stores that metadata together with the rendered frame.
- Taps call the new `snowluma-login-tap` command with the metadata from the exact frame the user is viewing. The core maps image pixels back to X11 root coordinates without rediscovering or remeasuring the QQ window at click time.

This removes the dev21 failure mode where a tap near the Login button could land around Auto Login because click-time window geometry differed from capture-time geometry.

## NapCat / SnowLuma settings lock fix

- Embedded core moves from `v1.6.0-dev12` to `v1.6.0-dev13`.
- Settings writes no longer use BusyBox `flock` or inherited file descriptor locking.
- `config_set` now acquires an atomic `mkdir` lock directory, records owner PID/time, and recovers stale locks left by crashed writers.
- Existing engine-switch rollback remains in place, so a failed target commit/start attempts to restore the previous QQ engine.
