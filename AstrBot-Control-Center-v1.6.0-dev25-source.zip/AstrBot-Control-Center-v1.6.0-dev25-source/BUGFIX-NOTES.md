# v1.6.0-dev25 修复摘要

- 新增顶部全局任务中心：后台保存、引擎切换和 action 显示进度、步骤、完成/失败状态。
- 设置状态拆分为“未提交草稿”和“后台应用中”，修复已切换成功仍要求再次保存的问题。
- 首次开机/服务恢复期间不再直接提示“状态读取失败”，改为连接、缓存、恢复、暂不可用状态。
- AstrBot 与 Compose 工作区菜单统一为图标圆角浮层；修复 AstrBot 菜单偏到屏幕中间，增加按钮/浮层动画。
- AstrBot 独立 Activity 同样显示全局任务中心，后台任务跨工作区仍可查看。
- UI 增加 Compact / Medium / Expanded / Large 四档窗口适配，改善分屏、不同尺寸平板和大屏留白。
- CI 增加 APK 16 KB zip alignment 验证和 engine ELF page-size 审计；当前 core 中仍有 3 个 4 KB ELF，已明确标记为未完成的底层兼容项。
