# dev24 validation report

## Latest-device evidence used
- Diagnostic action log: NapCat → SnowLuma switch from `18:45:59` to `18:46:27` (~28 s).
- The core was already switching successfully; most of this interval was shutdown/start sequencing rather than UI rendering.
- The Android layer also performed repeated privileged status/settings/URL calls, amplifying perceived latency.

## Performance gates
- Same-session RootShell PID cleanup; no second normal `su` cleanup transition.
- App-private cached status snapshot is painted before background refresh.
- Same verified embedded-core version has a persistent fast-entry marker.
- Ordinary staged settings use one root batch.
- Queued maintenance releases global busy state after queue acceptance.
- AstrBot/SnowLuma deterministic loopback URLs do not require a root URL lookup.
- Explicit NapCat engine switch uses the bounded collective fast-stop path (6 s graceful ceiling).

## Visual gates
- AstrBot Activity uses a custom rounded `PopupWindow`, not platform `PopupMenu`.
- Compose workspace menu is clipped to a 28dp rounded surface.
- Material dialogs use 44dp shape.
- Floating settings save surface uses 36/44dp rounded geometry.

## Checks completed
- `scripts/verify-source.sh`: PASS (`SOURCE_GATE_OK`).
- Embedded `engine.zip` SHA and `manifest/module-files.sha256`: PASS.
- `test-engine-switch-fast-stop-v16015.sh`: PASS.
- `test-control-center-v1604-qr-rendering.sh`: PASS against current dev15 core.
- Pure Kotlin `ControlCenterModels + ControlStatusParser`: compiled with local `kotlinc`.
- Pure Kotlin `InstallerModels`: compiled with local `kotlinc`.
- Kotlin/KTS lexical structure scan: PASS for 22 files.

## Build boundary
A real Android `compileDebugKotlin` / `assembleDebug` could not be executed here: this source snapshot does not contain `gradlew`, and this environment does not have the complete Android Gradle/SDK chain. GitHub Actions remains the final Android compiler gate.
