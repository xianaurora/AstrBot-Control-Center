package com.xianaurora.astrbotcontrol.model

/**
 * Process-local bridge for background task visibility across activities.
 *
 * ControlCenterViewModel remains the source of truth.  The classic AstrBot Activity cannot
 * share that activity-scoped ViewModel, so it reads this immutable snapshot to render the
 * same top task indicator while the main activity stays alive underneath it.
 */
object BackgroundTaskHub {
    @Volatile
    private var latest: List<BackgroundTask> = emptyList()

    fun publish(tasks: List<BackgroundTask>) {
        latest = tasks.toList()
    }

    fun snapshot(): List<BackgroundTask> = latest
}
