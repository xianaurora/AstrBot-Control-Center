package com.xianaurora.astrbotcontrol

import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.PixelCopy
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.xianaurora.astrbotcontrol.engine.RootShell
import com.xianaurora.astrbotcontrol.model.BackgroundTask
import com.xianaurora.astrbotcontrol.model.BackgroundTaskHub
import com.xianaurora.astrbotcontrol.model.BackgroundTaskState
import com.xianaurora.astrbotcontrol.model.TaskStepState
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * AstrBot intentionally uses a classic Activity-hosted WebView instead of Compose AndroidView.
 *
 * dev14/dev15 proved that changing cache/storage/layer heuristics inside the Compose-hosted
 * WebView did not fix the target Lenovo Android 16 tablet. This Activity is a clean rendering
 * boundary: the WebView is a direct child of the Activity View hierarchy and a native status
 * panel remains visible even if the web renderer paints a completely white surface.
 */
class AstrBotWebActivity : ComponentActivity() {
    private lateinit var root: FrameLayout
    private lateinit var webContainer: FrameLayout
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var toolbar: LinearLayout
    private lateinit var statusPanel: LinearLayout
    private lateinit var statusTitle: TextView
    private lateinit var statusDetail: TextView
    private lateinit var headerStatus: TextView
    private lateinit var taskButton: TextView
    private lateinit var fullscreenButton: TextView
    private lateinit var fullscreenExitButton: TextView
    private lateinit var moreButton: TextView

    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentUrl: String = ""
    private var lastConsoleIssue: String = ""
    private var lastHttpIssue: String = ""
    private var lastJsProbe: String = ""
    private var lastPixelProbe: String = "not-run"
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var softwareRendering = false
    private var rendererRecoveryCount = 0
    private var visualProbeGeneration = 0
    private var systemTopInset = 0
    private var systemBottomInset = 0
    private var isFullscreen = false
    private var lastTaskIndicator = ""
    private val taskPoll = object : Runnable {
        override fun run() {
            updateNativeTaskButton()
            mainHandler.postDelayed(this, 450L)
        }
    }

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = fileCallback
        fileCallback = null
        callback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentUrl = intent.getStringExtra(EXTRA_URL).orEmpty().ifBlank { DEFAULT_URL }
        if (!isAllowedLocalUrl(currentUrl)) {
            finishWithMessage("AstrBot 地址无效，已拒绝打开")
            return
        }

        buildClassicViewTree()
        installSystemInsets()
        configureWebView()
        onBackPressedDispatcher.addCallback(this) {
            // Fullscreen is one reversible layer. Outside fullscreen, app back exits
            // the AstrBot workspace; web history remains in the overflow menu so an
            // SPA route can never trap the user here.
            if (isFullscreen) setPageFullscreen(false) else finish()
        }

        logEvent("activity-create url=$currentUrl device=${android.os.Build.MANUFACTURER}/${android.os.Build.MODEL} sdk=${android.os.Build.VERSION.SDK_INT} webview=${webViewPackage()}")
        updateHeaderStatus("正在连接 · 127.0.0.1:6185")
        showStatus("正在打开 AstrBot", "正在连接本机管理页面…", persistent = true)
        webView.loadUrl(currentUrl)
    }

    override fun onStart() {
        super.onStart()
        mainHandler.removeCallbacks(taskPoll)
        mainHandler.post(taskPoll)
    }

    override fun onStop() {
        mainHandler.removeCallbacks(taskPoll)
        super.onStop()
    }

    private fun buildClassicViewTree() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(247, 250, 250)) }
        setContentView(root)

        val toolbarHeight = dp(58)
        val toolbarOuterGap = dp(10)
        systemTopInset = statusBarFallbackHeight()
        systemBottomInset = navigationBarFallbackHeight()

        // Keep the proven classic Activity-hosted WebView, but place it inside a
        // native rounded container so AstrBot visually follows the exact same
        // focus-workspace geometry as SnowLuma/NapCat.  This remains a normal
        // Android View hierarchy and does not reintroduce Compose AndroidView.
        webContainer = FrameLayout(this).apply {
            background = roundedBackground(Color.WHITE, dp(30), strokeColor = Color.rgb(224, 231, 231))
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            elevation = dp(1).toFloat()
        }
        webView = WebView(this)
        webContainer.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(webContainer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
            leftMargin = dp(12)
            rightMargin = dp(12)
            bottomMargin = systemBottomInset + dp(8)
            topMargin = systemTopInset + toolbarOuterGap + toolbarHeight + dp(8)
        })

        toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
            background = roundedBackground(Color.rgb(240, 244, 244), dp(26), strokeColor = Color.rgb(224, 231, 231))
            elevation = dp(1).toFloat()
        }
        val back = TextView(this).apply {
            text = "‹ 工作台"
            contentDescription = "返回工作台"
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Color.rgb(35, 40, 48))
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            setOnClickListener { finish() }
        }
        val titleBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, dp(8), 0)
        }
        val title = TextView(this).apply {
            text = "AstrBot"
            setTextColor(Color.rgb(24, 27, 33))
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        headerStatus = TextView(this).apply {
            text = "正在连接本机服务"
            setTextColor(Color.rgb(95, 101, 112))
            textSize = 11.5f
        }
        titleBlock.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        titleBlock.addView(headerStatus, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        taskButton = TextView(this).apply {
            text = "✓"
            contentDescription = "后台任务"
            gravity = Gravity.CENTER
            textSize = 13.5f
            setTextColor(Color.rgb(35, 40, 48))
            background = roundedBackground(Color.rgb(230, 236, 236), dp(18))
            isClickable = true
            isFocusable = true
            setOnClickListener { view ->
                view.animate().cancel()
                view.animate().scaleX(0.9f).scaleY(0.9f).setDuration(70L).withEndAction {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(130L).start()
                }.start()
                showNativeTaskCenter(view)
            }
        }
        fullscreenButton = TextView(this).apply {
            text = "⛶"
            contentDescription = "全屏显示 AstrBot"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(Color.rgb(35, 40, 48))
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            setOnClickListener { setPageFullscreen(true) }
        }
        moreButton = TextView(this).apply {
            text = "⋮"
            contentDescription = "AstrBot 页面工具"
            gravity = Gravity.CENTER
            textSize = 26f
            setTextColor(Color.rgb(35, 40, 48))
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            setOnClickListener { showPageMenu(this) }
        }
        toolbar.addView(back, LinearLayout.LayoutParams(dp(102), ViewGroup.LayoutParams.MATCH_PARENT))
        toolbar.addView(titleBlock, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        toolbar.addView(taskButton, LinearLayout.LayoutParams(dp(62), dp(38)).apply { marginEnd = dp(4) })
        toolbar.addView(fullscreenButton, LinearLayout.LayoutParams(dp(52), ViewGroup.LayoutParams.MATCH_PARENT))
        toolbar.addView(moreButton, LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(toolbar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, toolbarHeight).apply {
            gravity = Gravity.TOP
            leftMargin = dp(12)
            rightMargin = dp(12)
            topMargin = systemTopInset + toolbarOuterGap
        })

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.VISIBLE
        }
        root.addView(progress, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)).apply {
            gravity = Gravity.TOP
            leftMargin = dp(28)
            rightMargin = dp(28)
            topMargin = systemTopInset + toolbarOuterGap + toolbarHeight + dp(6)
        })

        statusPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(14))
            background = roundedBackground(Color.rgb(240, 244, 244), dp(24), strokeColor = Color.rgb(214, 224, 224))
            elevation = dp(10).toFloat()
        }
        statusTitle = TextView(this).apply {
            setTextColor(Color.rgb(28, 31, 36))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        statusDetail = TextView(this).apply {
            setTextColor(Color.rgb(82, 87, 98))
            textSize = 12.5f
            setPadding(0, dp(5), 0, dp(10))
        }
        statusPanel.addView(statusTitle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        statusPanel.addView(statusDetail, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val panelWidth = minOf(resources.displayMetrics.widthPixels - dp(28), dp(620))
        root.addView(statusPanel, FrameLayout.LayoutParams(panelWidth, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = systemBottomInset + dp(14)
        })

        fullscreenExitButton = TextView(this).apply {
            text = "⛶"
            contentDescription = "退出 AstrBot 全屏"
            gravity = Gravity.CENTER
            textSize = 22f
            setTextColor(Color.WHITE)
            background = roundedBackground(Color.argb(190, 25, 28, 34), dp(18))
            elevation = dp(8).toFloat()
            visibility = View.GONE
            isClickable = true
            isFocusable = true
            setOnClickListener { setPageFullscreen(false) }
        }
        root.addView(fullscreenExitButton, FrameLayout.LayoutParams(dp(48), dp(48)).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = dp(14)
            rightMargin = dp(14)
        })
    }

    private fun statusBarFallbackHeight(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
    }

    private fun navigationBarFallbackHeight(): Int {
        val id = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun installSystemInsets() {
        window.statusBarColor = Color.rgb(247, 250, 250)
        window.navigationBarColor = Color.rgb(247, 250, 250)
        val decor = window.decorView
        decor.setOnApplyWindowInsetsListener { _, insets ->
            val reportedTop = if (android.os.Build.VERSION.SDK_INT >= 30) {
                insets.getInsets(WindowInsets.Type.statusBars()).top
            } else {
                @Suppress("DEPRECATION")
                insets.systemWindowInsetTop
            }
            val reportedBottom = if (android.os.Build.VERSION.SDK_INT >= 30) {
                insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            } else {
                @Suppress("DEPRECATION")
                insets.systemWindowInsetBottom
            }
            systemTopInset = maxOf(reportedTop, statusBarFallbackHeight())
            systemBottomInset = maxOf(reportedBottom, navigationBarFallbackHeight())
            applySystemBarOffsets()
            insets
        }
        // Apply the resource fallback immediately so the first frame can never be
        // drawn underneath the clock/status icons while Android 16 dispatches insets.
        applySystemBarOffsets()
        decor.requestApplyInsets()
        root.requestApplyInsets()
    }

    private fun applySystemBarOffsets() {
        if (!::root.isInitialized || !::webContainer.isInitialized) return
        val toolbarHeight = dp(58)
        val toolbarOuterGap = dp(10)
        val topInset = if (isFullscreen) 0 else systemTopInset
        val bottomInset = if (isFullscreen) 0 else systemBottomInset
        (webContainer.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.leftMargin = if (isFullscreen) 0 else dp(12)
            lp.rightMargin = if (isFullscreen) 0 else dp(12)
            lp.bottomMargin = if (isFullscreen) 0 else bottomInset + dp(8)
            lp.topMargin = if (isFullscreen) 0 else topInset + toolbarOuterGap + toolbarHeight + dp(8)
            webContainer.layoutParams = lp
        }
        webContainer.background = if (isFullscreen) {
            roundedBackground(Color.WHITE, 0)
        } else {
            roundedBackground(Color.WHITE, dp(30), strokeColor = Color.rgb(224, 231, 231))
        }
        if (::toolbar.isInitialized) {
            toolbar.visibility = if (isFullscreen) View.GONE else View.VISIBLE
            (toolbar.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
                lp.topMargin = topInset + toolbarOuterGap
                toolbar.layoutParams = lp
            }
        }
        (progress.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.leftMargin = if (isFullscreen) 0 else dp(28)
            lp.rightMargin = if (isFullscreen) 0 else dp(28)
            lp.topMargin = if (isFullscreen) 0 else topInset + toolbarOuterGap + toolbarHeight + dp(6)
            progress.layoutParams = lp
        }
        (statusPanel.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.bottomMargin = bottomInset + dp(14)
            statusPanel.layoutParams = lp
        }
        if (::fullscreenExitButton.isInitialized) {
            fullscreenExitButton.visibility = if (isFullscreen) View.VISIBLE else View.GONE
        }
        root.requestLayout()
    }

    private fun setPageFullscreen(enabled: Boolean) {
        if (isFullscreen == enabled) return
        isFullscreen = enabled
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                if (enabled) {
                    controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                    controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else {
                    controller.show(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                }
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (enabled) {
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            } else {
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }
        }
        applySystemBarOffsets()
        logEvent("fullscreen enabled=$enabled")
    }

    private fun roundedBackground(fillColor: Int, radiusPx: Int, strokeColor: Int? = null): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fillColor)
        cornerRadius = radiusPx.toFloat()
        if (strokeColor != null) setStroke(dp(1), strokeColor)
    }


    private fun updateNativeTaskButton() {
        if (!::taskButton.isInitialized) return
        val tasks = BackgroundTaskHub.snapshot()
        val active = tasks.filter { it.active }
        val failed = tasks.count { it.state == BackgroundTaskState.FAILED }
        val indicator = when {
            active.isNotEmpty() -> "◌ ${active.size}"
            failed > 0 -> "! $failed"
            else -> "✓"
        }
        taskButton.text = indicator
        taskButton.contentDescription = when {
            active.isNotEmpty() -> "${active.size} 个后台任务正在执行"
            failed > 0 -> "$failed 个后台任务失败"
            else -> "后台任务已完成"
        }
        taskButton.background = roundedBackground(
            when {
                active.isNotEmpty() -> Color.rgb(224, 234, 236)
                failed > 0 -> Color.rgb(244, 230, 226)
                else -> Color.rgb(230, 236, 236)
            },
            dp(18)
        )
        if (indicator != lastTaskIndicator) {
            taskButton.animate().cancel()
            taskButton.scaleX = 0.9f
            taskButton.scaleY = 0.9f
            taskButton.alpha = 0.72f
            taskButton.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180L).start()
            lastTaskIndicator = indicator
        }
    }

    private fun showNativeTaskCenter(anchor: View) {
        val tasks = BackgroundTaskHub.snapshot()
        val panelWidth = minOf(dp(360), resources.displayMetrics.widthPixels - dp(24))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(12))
            background = roundedBackground(Color.rgb(250, 251, 251), dp(28), strokeColor = Color.rgb(224, 229, 229))
            elevation = dp(14).toFloat()
        }
        val title = TextView(this).apply {
            text = "后台任务"
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(28, 31, 36))
            setPadding(dp(8), dp(4), dp(8), dp(10))
        }
        panel.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (tasks.isEmpty()) {
            panel.addView(TextView(this).apply {
                text = "✓ 暂无后台任务"
                textSize = 14f
                setTextColor(Color.rgb(90, 96, 105))
                setPadding(dp(10), dp(18), dp(10), dp(20))
            })
        } else {
            tasks.take(6).forEach { task ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    background = roundedBackground(Color.rgb(242, 246, 246), dp(18))
                    isClickable = true
                    isFocusable = true
                }
                val stateGlyph = when (task.state) {
                    BackgroundTaskState.QUEUED -> "○"
                    BackgroundTaskState.RUNNING -> "◌"
                    BackgroundTaskState.SUCCEEDED -> "✓"
                    BackgroundTaskState.FAILED -> "!"
                }
                row.addView(TextView(this).apply {
                    text = "$stateGlyph  ${task.title}"
                    textSize = 14.5f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(Color.rgb(30, 34, 40))
                })
                row.addView(TextView(this).apply {
                    text = "${task.progress}% · ${task.detail}"
                    textSize = 11.5f
                    setTextColor(Color.rgb(91, 98, 108))
                    setPadding(0, dp(4), 0, dp(5))
                })
                row.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 100
                    progress = task.progress.coerceIn(0, 100)
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
                row.setOnClickListener {
                    showNativeTaskDetail(anchor, task)
                }
                panel.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(8)
                })
            }
        }
        val popup = PopupWindow(panel, panelWidth, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            isOutsideTouchable = true
            elevation = dp(16).toFloat()
            animationStyle = 0
        }
        panel.alpha = 0f
        panel.scaleX = 0.94f
        panel.scaleY = 0.94f
        panel.translationY = -dp(6).toFloat()
        popup.showAsDropDown(anchor, anchor.width - panelWidth, dp(6))
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(150L).start()
    }

    private fun showNativeTaskDetail(anchor: View, task: BackgroundTask) {
        val panelWidth = minOf(dp(360), resources.displayMetrics.widthPixels - dp(24))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = roundedBackground(Color.rgb(250, 251, 251), dp(28), strokeColor = Color.rgb(224, 229, 229))
            elevation = dp(14).toFloat()
        }
        panel.addView(TextView(this).apply {
            text = task.title
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(28, 31, 36))
        })
        panel.addView(TextView(this).apply {
            text = "${task.progress}% · ${task.detail}"
            textSize = 12f
            setTextColor(Color.rgb(92, 98, 108))
            setPadding(0, dp(5), 0, dp(12))
        })
        task.steps.forEach { step ->
            val glyph = when (step.state) {
                TaskStepState.WAITING -> "○"
                TaskStepState.RUNNING -> "◌"
                TaskStepState.DONE -> "✓"
                TaskStepState.FAILED -> "!"
            }
            panel.addView(TextView(this).apply {
                text = "$glyph  ${step.label}${if (step.detail.isNotBlank()) " · ${step.detail}" else ""}"
                textSize = 13.5f
                setTextColor(Color.rgb(47, 52, 60))
                setPadding(dp(4), dp(7), dp(4), dp(7))
            })
        }
        val popup = PopupWindow(panel, panelWidth, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            isOutsideTouchable = true
            elevation = dp(16).toFloat()
        }
        popup.showAsDropDown(anchor, anchor.width - panelWidth, dp(6))
    }

    private fun showPageMenu(anchor: View) {
        moreButton.animate().cancel()
        moreButton.animate().rotation(90f).scaleX(.88f).scaleY(.88f).setDuration(120).withEndAction {
            moreButton.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()

        val panelWidth = minOf(dp(238), resources.displayMetrics.widthPixels - dp(24))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = roundedBackground(Color.rgb(248, 250, 251), dp(28), Color.rgb(226, 230, 235))
            elevation = dp(16).toFloat()
            pivotX = panelWidth.toFloat()
            pivotY = 0f
            alpha = 0f
            scaleX = .92f
            scaleY = .92f
            translationY = -dp(6).toFloat()
        }
        lateinit var popup: PopupWindow
        fun separator() {
            panel.addView(View(this).apply { setBackgroundColor(Color.rgb(229, 233, 237)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                leftMargin = dp(10); rightMargin = dp(10); topMargin = dp(4); bottomMargin = dp(4)
            })
        }
        fun item(icon: String, label: String, enabled: Boolean = true, action: () -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), 0)
                isEnabled = enabled
                background = roundedBackground(Color.TRANSPARENT, dp(18))
            }
            val glyph = TextView(this).apply {
                text = icon
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(if (enabled) Color.rgb(45, 51, 58) else Color.rgb(176, 181, 187))
                background = roundedBackground(Color.rgb(236, 240, 242), dp(13))
            }
            val textView = TextView(this).apply {
                text = label
                textSize = 15f
                gravity = Gravity.CENTER_VERTICAL
                setTextColor(if (enabled) Color.rgb(34, 38, 43) else Color.rgb(171, 177, 184))
            }
            row.addView(glyph, LinearLayout.LayoutParams(dp(30), dp(30)))
            row.addView(textView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply { leftMargin = dp(12) })
            row.setOnClickListener {
                if (!enabled) return@setOnClickListener
                row.animate().scaleX(.97f).scaleY(.97f).setDuration(70).withEndAction {
                    popup.dismiss()
                    action()
                }.start()
            }
            panel.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
                topMargin = dp(2); bottomMargin = dp(2)
            })
        }
        item("←", "网页后退", ::webView.isInitialized && webView.canGoBack()) { webView.goBack() }
        item("→", "网页前进", ::webView.isInitialized && webView.canGoForward()) { webView.goForward() }
        item("↻", "重新加载") { reloadFresh() }
        separator()
        item("⛶", if (isFullscreen) "退出全屏" else "全屏显示") { setPageFullscreen(!isFullscreen) }
        item("▣", if (softwareRendering) "切回硬件渲染" else "兼容渲染") { toggleRenderingLayer() }
        separator()
        item("↗", "浏览器打开") { openExternalBrowser() }
        item("◎", "复制诊断") { copyDiagnostics() }
        popup = PopupWindow(panel, panelWidth, ViewGroup.LayoutParams.WRAP_CONTENT, true).apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            isOutsideTouchable = true
            elevation = dp(18).toFloat()
            setOnDismissListener {
                moreButton.contentDescription = "AstrBot 页面工具"
                moreButton.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(160).start()
            }
        }
        // Anchor the panel to the actual overflow button.  No screen-center or
        // hard-coded device coordinate is involved, so this survives different
        // tablet widths, display density and multi-window sizes.
        popup.showAsDropDown(anchor, anchor.width - panelWidth, dp(6))
        panel.post {
            panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(190).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
    }

    private fun updateHeaderStatus(text: String, warning: Boolean = false) {
        if (!::headerStatus.isInitialized) return
        headerStatus.text = text
        headerStatus.setTextColor(if (warning) Color.rgb(176, 87, 36) else Color.rgb(80, 91, 104))
    }

    private fun configureWebView() {
        webView.setBackgroundColor(Color.WHITE)
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = false
            javaScriptCanOpenWindowsAutomatically = true
        }
        webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress.coerceIn(0, 100)
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                val message = consoleMessage?.message().orEmpty().trim()
                if (message.isNotBlank() && consoleMessage?.messageLevel() in setOf(ConsoleMessage.MessageLevel.ERROR, ConsoleMessage.MessageLevel.WARNING)) {
                    lastConsoleIssue = "${consoleMessage?.messageLevel()}: ${message.take(420)} @ ${consoleMessage?.sourceId().orEmpty().substringAfterLast('/').take(80)}:${consoleMessage?.lineNumber() ?: 0}"
                    logEvent("console $lastConsoleIssue")
                }
                return true
            }

            override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                val chooser = runCatching { fileChooserParams?.createIntent() }.getOrNull()
                    ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                return runCatching { fileLauncher.launch(chooser); true }.getOrElse {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = null
                    showFailure("无法打开文件选择器", it.message.orEmpty())
                    false
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (isAllowedLocalUri(uri)) false else {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    true
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                visualProbeGeneration += 1
                progress.visibility = View.VISIBLE
                lastConsoleIssue = ""
                lastHttpIssue = ""
                lastJsProbe = ""
                lastPixelProbe = "not-run"
                updateHeaderStatus("正在载入 · 127.0.0.1:6185")
                showStatus("AstrBot 页面正在载入", url.orEmpty().take(160), persistent = true)
                logEvent("page-start url=${url.orEmpty()}")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
                logEvent("page-finished url=${url.orEmpty()} title=${view?.title.orEmpty()}")
                runVisualDiagnostics(visualProbeGeneration)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    val detail = "${error?.errorCode ?: 0} ${error?.description ?: "无法访问本机页面"}"
                    logEvent("main-frame-error $detail url=${request.url}")
                    updateHeaderStatus("连接失败", warning = true)
                    showFailure("AstrBot 页面连接失败", detail)
                    syncLogToModule()
                } else if (request != null && isAllowedLocalUri(request.url)) {
                    logEvent("subresource-error ${error?.errorCode ?: 0} ${error?.description?.toString() ?: ""} ${request.url}")
                }
            }

            override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                val status = errorResponse?.statusCode ?: 0
                if (request?.isForMainFrame == true && status >= 400) {
                    lastHttpIssue = "HTTP $status ${errorResponse?.reasonPhrase.orEmpty()} ${request.url}"
                    logEvent("main-frame-http $lastHttpIssue")
                    updateHeaderStatus("HTTP $status", warning = true)
                    showFailure("AstrBot 页面返回 HTTP $status", errorResponse?.reasonPhrase.orEmpty())
                    syncLogToModule()
                } else if (status >= 400 && request != null && isAllowedLocalUri(request.url)) {
                    lastHttpIssue = "HTTP $status ${request.url.encodedPath.orEmpty().takeLast(160)}"
                    logEvent("subresource-http $lastHttpIssue")
                }
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                rendererRecoveryCount += 1
                logEvent("renderer-gone crashed=${detail?.didCrash()} priority=${detail?.rendererPriorityAtExit()} count=$rendererRecoveryCount")
                syncLogToModule()
                if (rendererRecoveryCount <= 1) {
                    showStatus("WebView 渲染器已重建", "系统回收或终止了渲染进程，正在重新打开页面。", persistent = true)
                    recreateWebViewAfterRendererLoss()
                } else {
                    showFailure("WebView 渲染进程连续退出", "请从右上角 ⋮ 尝试重新加载或浏览器打开，并保留诊断信息。")
                }
                return true
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            if (url.isNullOrBlank()) return@setDownloadListener
            runCatching {
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", userAgent.orEmpty())
                    setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                }
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            }.onFailure { showFailure("下载启动失败", it.message.orEmpty()) }
        }
    }

    private fun runVisualDiagnostics(generation: Int) {
        if (generation != visualProbeGeneration || !::webView.isInitialized) return
        webView.evaluateJavascript(JS_DIAGNOSTIC) { raw ->
            if (generation != visualProbeGeneration) return@evaluateJavascript
            lastJsProbe = decodeJsString(raw)
            logEvent("js-probe $lastJsProbe")
            mainHandler.postDelayed({ runPixelProbe(generation) }, 1400L)
        }
    }

    private fun runPixelProbe(generation: Int) {
        if (generation != visualProbeGeneration || webView.width <= 0 || webView.height <= 0) return
        val location = IntArray(2)
        webView.getLocationInWindow(location)
        val rect = Rect(location[0], location[1], location[0] + webView.width, location[1] + webView.height)
        val bitmap = runCatching { Bitmap.createBitmap(webView.width, webView.height, Bitmap.Config.ARGB_8888) }.getOrNull()
        if (bitmap == null) {
            lastPixelProbe = "bitmap-allocation-failed ${webView.width}x${webView.height}"
            logEvent("pixel-probe $lastPixelProbe")
            showStatus("AstrBot 页面已载入", "无法分配像素检查缓冲区；如果仍是白屏，可切换渲染或浏览器打开。", persistent = true)
            return
        }
        // PixelCopy samples the final Activity window. Hide our native status panel
        // for one frame so the probe measures the WebView pixels instead of counting
        // the diagnostic overlay itself as successful page content.
        statusPanel.visibility = View.GONE
        root.postOnAnimation {
            PixelCopy.request(window, rect, bitmap, { result ->
                if (generation != visualProbeGeneration) { bitmap.recycle(); return@request }
                if (result != PixelCopy.SUCCESS) {
                    lastPixelProbe = "pixelcopy-result=$result"
                    bitmap.recycle()
                    logEvent("pixel-probe $lastPixelProbe")
                    showStatus("AstrBot 页面已载入", "像素检查失败（$result）；如果仍是白屏，可切换渲染或浏览器打开。", persistent = true)
                    syncLogToModule()
                    return@request
                }
                val stats = analyzePixels(bitmap)
                bitmap.recycle()
                lastPixelProbe = stats
                logEvent("pixel-probe $stats")
                val whiteRatio = parseWhiteRatio(stats)
                if (whiteRatio >= 0.992) {
                val extra = buildString {
                    append("实际 WebView 区域接近纯白（${"%.2f".format(Locale.US, whiteRatio * 100)}% 白像素）。")
                    if (lastJsProbe.isNotBlank()) append(" DOM：").append(lastJsProbe.take(220))
                    if (lastConsoleIssue.isNotBlank()) append(" JS：").append(lastConsoleIssue.take(180))
                    if (lastHttpIssue.isNotBlank()) append(" 资源：").append(lastHttpIssue.take(160))
                }
                updateHeaderStatus("页面异常 · 可从 ⋮ 打开工具", warning = true)
                showFailure("检测到真实白屏", extra)
                syncLogToModule()
                } else {
                    statusPanel.visibility = View.GONE
                    updateHeaderStatus("已连接 · 127.0.0.1:6185")
                    logEvent("visual-ok whiteRatio=$whiteRatio")
                }
            }, mainHandler)
        }
    }

    private fun analyzePixels(bitmap: Bitmap): String {
        val stepX = maxOf(1, bitmap.width / 96)
        val stepY = maxOf(1, bitmap.height / 96)
        var total = 0
        var white = 0
        var dark = 0
        var colored = 0
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val c = bitmap.getPixel(x, y)
                val a = Color.alpha(c)
                val r = Color.red(c)
                val g = Color.green(c)
                val b = Color.blue(c)
                if (a > 16) {
                    total += 1
                    if (r >= 245 && g >= 245 && b >= 245) white += 1
                    if (r <= 45 && g <= 45 && b <= 45) dark += 1
                    if (maxOf(r, g, b) - minOf(r, g, b) >= 28) colored += 1
                }
                x += stepX
            }
            y += stepY
        }
        val safeTotal = total.coerceAtLeast(1)
        return "size=${bitmap.width}x${bitmap.height}|samples=$total|white=${white.toDouble()/safeTotal}|dark=${dark.toDouble()/safeTotal}|colored=${colored.toDouble()/safeTotal}"
    }

    private fun parseWhiteRatio(stats: String): Double = stats.substringAfter("|white=", "0").substringBefore('|').toDoubleOrNull() ?: 0.0

    private fun reloadFresh() {
        visualProbeGeneration += 1
        lastConsoleIssue = ""
        lastHttpIssue = ""
        webView.stopLoading()
        webView.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        val separator = if ('?' in currentUrl) '&' else '?'
        val url = "$currentUrl${separator}acc_reload=${System.currentTimeMillis()}"
        showStatus("正在重新加载 AstrBot", "本次跳过 HTTP 缓存，不清除登录与站点数据。", persistent = true)
        logEvent("manual-reload $url")
        webView.loadUrl(url, NO_CACHE_HEADERS)
    }

    private fun toggleRenderingLayer() {
        softwareRendering = !softwareRendering
        webView.setLayerType(if (softwareRendering) View.LAYER_TYPE_SOFTWARE else View.LAYER_TYPE_HARDWARE, null)
        logEvent("render-layer ${if (softwareRendering) "software" else "hardware"}")
        showStatus("已切换渲染层", "现在使用${if (softwareRendering) "兼容/软件" else "硬件"}渲染，正在重新载入页面。", persistent = true)
        webView.reload()
    }

    private fun recreateWebViewAfterRendererLoss() {
        if (!::webView.isInitialized) return
        val old = webView
        old.stopLoading()
        old.webChromeClient = null
        old.webViewClient = WebViewClient()
        root.removeView(old)
        old.destroy()
        webView = WebView(this)
        root.addView(webView, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
            topMargin = systemTopInset + dp(62)
        })
        configureWebView()
        if (softwareRendering) webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        webView.loadUrl(currentUrl)
    }

    private fun openExternalBrowser() {
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))) }
            .onFailure { Toast.makeText(this, "系统浏览器无法打开：${it.message.orEmpty()}", Toast.LENGTH_LONG).show() }
    }

    private fun copyDiagnostics() {
        val text = diagnosticsText()
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("AstrBot WebView diagnostics", text))
        Toast.makeText(this, "WebView 诊断已复制", Toast.LENGTH_SHORT).show()
        syncLogToModule()
    }

    private fun diagnosticsText(): String = buildString {
        appendLine("AstrBot Control Center ${BuildConfig.VERSION_NAME}")
        appendLine("device=${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} sdk=${android.os.Build.VERSION.SDK_INT}")
        appendLine("webview=${webViewPackage()}")
        appendLine("url=${webView.url ?: currentUrl}")
        appendLine("title=${webView.title.orEmpty()}")
        appendLine("progress=${webView.progress}")
        appendLine("layer=${if (webView.layerType == View.LAYER_TYPE_SOFTWARE) "software" else "hardware/default"}")
        appendLine("jsProbe=$lastJsProbe")
        appendLine("pixelProbe=$lastPixelProbe")
        appendLine("console=$lastConsoleIssue")
        appendLine("http=$lastHttpIssue")
    }

    private fun showStatus(title: String, detail: String, persistent: Boolean) {
        statusTitle.text = title
        statusDetail.text = detail
        statusPanel.visibility = View.VISIBLE
        if (!persistent) mainHandler.postDelayed({ statusPanel.visibility = View.GONE }, 3500L)
    }

    private fun showFailure(title: String, detail: String) {
        updateHeaderStatus("页面异常 · 右上角 ⋮ 可打开工具", warning = true)
        showStatus(title, detail.ifBlank { "请从右上角 ⋮ 重新加载；若仍失败可用浏览器打开。" }, persistent = true)
        logEvent("failure title=$title detail=${detail.take(600)}")
    }

    private fun logEvent(message: String) {
        runCatching {
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
            logFile().appendText("WEBVIEW|time=$stamp|app=${BuildConfig.VERSION_NAME}|$message\n")
        }
    }

    private fun logFile(): File = File(filesDir, "astrbot-webview.log")

    private fun syncLogToModule() {
        val source = logFile()
        if (!source.isFile) return
        lifecycleScope.launch {
            val command = "mkdir -p /data/adb/astrbot_standalone/logs && cp ${RootShell.q(source.absolutePath)} /data/adb/astrbot_standalone/logs/app-webview.log && chmod 0644 /data/adb/astrbot_standalone/logs/app-webview.log"
            RootShell().root(command, 4)
        }
    }

    private fun webViewPackage(): String = WebView.getCurrentWebViewPackage()?.let { "${it.packageName} ${it.versionName}" } ?: "unknown"

    private fun isAllowedLocalUrl(url: String): Boolean = runCatching { isAllowedLocalUri(Uri.parse(url)) }.getOrDefault(false)

    private fun isAllowedLocalUri(uri: Uri): Boolean {
        val host = uri.host?.lowercase(Locale.ROOT).orEmpty()
        return uri.scheme?.lowercase(Locale.ROOT) in setOf("http", "https") && host in setOf("127.0.0.1", "localhost", "::1")
    }

    private fun finishWithMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        finish()
    }

    private fun decodeJsString(value: String?): String {
        val raw = value.orEmpty()
        return if (raw.length >= 2 && raw.first() == '"' && raw.last() == '"') raw.substring(1, raw.length - 1)
            .replace("\\n", " ").replace("\\r", " ").replace("\\\"", "\"").replace("\\\\", "\\") else raw
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    override fun onPause() {
        if (::webView.isInitialized) webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::webView.isInitialized) webView.onResume()
    }

    override fun onDestroy() {
        visualProbeGeneration += 1
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        if (::webView.isInitialized) {
            logEvent("activity-destroy ${diagnosticsText().replace('\n', ' ').take(1600)}")
            syncLogToModule()
            webView.stopLoading()
            webView.webChromeClient = null
            webView.webViewClient = WebViewClient()
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "astrbot_web_url"
        private const val DEFAULT_URL = "http://127.0.0.1:6185/"
        private val NO_CACHE_HEADERS = mapOf("Cache-Control" to "no-cache, no-store, max-age=0", "Pragma" to "no-cache")
        private val JS_DIAGNOSTIC = """
            (function(){
              try {
                var root=document.querySelector('#app,#root,[data-v-app]')||document.body;
                var text=((root&&root.innerText)||'').replace(/\\s+/g,' ').trim();
                var rect=root&&root.getBoundingClientRect?root.getBoundingClientRect():{width:0,height:0};
                return ['ready='+document.readyState,'title='+(document.title||''),'text='+text.length,'children='+(root?root.children.length:0),'size='+Math.round(rect.width)+'x'+Math.round(rect.height),'url='+location.href].join('|');
              } catch(e) { return 'probe-error='+(e&&e.message?e.message:'unknown'); }
            })();
        """.trimIndent()
    }
}
