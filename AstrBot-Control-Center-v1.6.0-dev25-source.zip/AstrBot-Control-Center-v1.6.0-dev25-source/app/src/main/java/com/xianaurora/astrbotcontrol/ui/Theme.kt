package com.xianaurora.astrbotcontrol.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val Light = lightColorScheme(
    primary = Color(0xFF006B70),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF9CF0F4),
    onPrimaryContainer = Color(0xFF002022),
    secondary = Color(0xFF4A6365),
    background = Color(0xFFF7FAFA),
    surface = Color(0xFFF7FAFA),
    surfaceContainer = Color(0xFFF0F4F4),
    surfaceContainerHigh = Color(0xFFEAF0F0),
    surfaceContainerHighest = Color(0xFFE3EAEA),
    outline = Color(0xFF6F797A),
    outlineVariant = Color(0xFFBEC8C8),
    error = Color(0xFFBA1A1A)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF80D4D8),
    onPrimary = Color(0xFF003739),
    primaryContainer = Color(0xFF004F53),
    onPrimaryContainer = Color(0xFF9CF0F4),
    secondary = Color(0xFFB1CCCE),
    background = Color(0xFF0E1415),
    surface = Color(0xFF0E1415),
    surfaceContainer = Color(0xFF171E1F),
    surfaceContainerHigh = Color(0xFF202829),
    surfaceContainerHighest = Color(0xFF293233),
    outline = Color(0xFF899394),
    outlineVariant = Color(0xFF3F494A),
    error = Color(0xFFFFB4AB)
)

@Composable
fun AstrBotTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val context = LocalContext.current
    val scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (dark) Dark else Light
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(12.dp),
            small = RoundedCornerShape(18.dp),
            medium = RoundedCornerShape(24.dp),
            large = RoundedCornerShape(32.dp),
            extraLarge = RoundedCornerShape(40.dp)
        ),
        content = content
    )
}
