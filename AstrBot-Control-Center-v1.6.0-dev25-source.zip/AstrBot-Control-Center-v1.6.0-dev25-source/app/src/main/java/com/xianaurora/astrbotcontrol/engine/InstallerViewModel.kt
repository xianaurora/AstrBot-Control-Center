package com.xianaurora.astrbotcontrol.engine

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xianaurora.astrbotcontrol.model.EngineStatus
import com.xianaurora.astrbotcontrol.model.InstallScreen
import com.xianaurora.astrbotcontrol.model.InstallerError
import com.xianaurora.astrbotcontrol.model.InstallerUiState
import com.xianaurora.astrbotcontrol.model.RootBackend
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class InstallerViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = EngineRepository(app)
    private val prefs = app.getSharedPreferences("installer", 0)
    private val _ui = MutableStateFlow(InstallerUiState())
    val ui: StateFlow<InstallerUiState> = _ui.asStateFlow()

    private var rootInfo = EngineRepository.RootInfo(RootBackend.NONE, "", false)
    private var engineAsset: EngineRepository.EngineAsset? = null
    private var pollJob: Job? = null
    private var engineInstallJob: Job? = null

    init { restoreOrDetect() }

    fun begin() = viewModelScope.launch { runPreflight() }

    fun runPreflight() = viewModelScope.launch {
        _ui.update { it.copy(screen = InstallScreen.PREFLIGHT, busy = true, error = null, message = "正在进行离线设备检查") }
        try {
            val asset = engineAsset ?: repository.prepareEngineAsset().also { engineAsset = it }
            rootInfo = repository.rootInfo()
            val existing = repository.existingEngineInfo()
            val checks = repository.preflight(asset, rootInfo)
            _ui.update {
                it.copy(
                    screen = InstallScreen.PREFLIGHT,
                    busy = false,
                    rootBackend = rootInfo.backend,
                    rootBackendVersion = rootInfo.version,
                    existingEngine = existing,
                    engineUpgradeConfirmed = false,
                    checks = checks,
                    engineAssetSha256 = asset.sha256,
                    engineAssetReady = true,
                    message = if (checks.all { c -> c.ok }) {
                        if (existing.installed) {
                            "检测到现有核心组件：${existing.version.ifBlank { "未知版本" }}。下一步会明确显示版本变化，只有你确认后才升级。"
                        } else "设备检查通过，下一步仍然不会联网"
                    } else "有项目需要处理后才能继续"
                )
            }
        } catch (t: Throwable) {
            fail("PREFLIGHT_FAILED", "设备检查没有完成", t.message ?: "无法准备内置核心组件", "preflight")
        }
    }

    fun goToEngineInstall() {
        if (_ui.value.checks.any { it.blocking && !it.ok }) return
        _ui.update { it.copy(screen = InstallScreen.ENGINE_INSTALL, error = null, engineUpgradeConfirmed = false) }
    }

    fun setEngineUpgradeConfirmed(confirmed: Boolean) {
        _ui.update { it.copy(engineUpgradeConfirmed = confirmed) }
    }

    fun installEngine() {
        // UI taps can arrive again while the first Root query is still running. Mark the
        // operation busy before the first suspend point and keep one install job at a time.
        if (engineInstallJob?.isActive == true || _ui.value.busy) return

        val visibleState = _ui.value
        if (visibleState.existingEngine.installed && !visibleState.engineUpgradeConfirmed) {
            _ui.update { it.copy(message = "请先确认版本变化、数据保留和回退说明，再执行核心组件升级。") }
            return
        }

        _ui.update {
            it.copy(
                busy = true,
                error = null,
                message = if (visibleState.existingEngine.installed) {
                    "正在确认当前核心组件并准备升级保护，请勿重复点击"
                } else {
                    "正在确认设备状态并准备本地核心组件，请勿重复点击"
                }
            )
        }

        engineInstallJob = viewModelScope.launch {
            try {
                val asset = engineAsset ?: repository.prepareEngineAsset().also { engineAsset = it }
                val existing = repository.existingEngineInfo()
                _ui.update { it.copy(existingEngine = existing) }

                if (existing.installed && !_ui.value.engineUpgradeConfirmed) {
                    _ui.update { it.copy(busy = false, message = "请先确认版本变化、数据保留和回退说明，再执行核心组件升级。") }
                    return@launch
                }
                if (existing.versionCode > EngineRepository.TARGET_ENGINE_VERSION_CODE) {
                    fail(
                        "ENGINE_DOWNGRADE_BLOCKED",
                        "检测到更高版本核心组件",
                        "当前 ${existing.version}（${existing.versionCode}）高于本安装包 ${EngineRepository.TARGET_ENGINE_VERSION}（${EngineRepository.TARGET_ENGINE_VERSION_CODE}）。为避免意外降级，已停止。",
                        "engine_install"
                    )
                    return@launch
                }

                _ui.update {
                    it.copy(
                        message = if (existing.installed) {
                            "正在为 ${existing.version.ifBlank { "现有" }} 核心组件创建升级前回退点；不会复制 Ubuntu、AstrBot、QQ、插件或配置"
                        } else "正在准备本地核心组件；此步骤不访问网络"
                    )
                }

                if (existing.installed) {
                    val backup = repository.createEngineBackup(existing)
                    if (!backup.ok) {
                        fail("ENGINE_BACKUP_FAILED", "无法创建升级前回退点", backup.stderr.ifBlank { backup.stdout }, "engine_backup")
                        return@launch
                    }
                    prefs.edit().putBoolean("engineBackupAvailable", true).putString("previousEngineVersion", existing.version).apply()
                    _ui.update {
                        it.copy(
                            existingEngine = existing.copy(rollbackAvailable = true, rollbackVersion = existing.version),
                            message = "回退点已完成。正在把内置核心组件交给 ${rootInfo.backend.label}；仍不会联网"
                        )
                    }
                }

                val installBootId = repository.bootId()
                val result = repository.installEngine(asset, rootInfo)
                if (result.ok) {
                    prefs.edit()
                        .putBoolean("engineInstallSubmitted", true)
                        .putBoolean("awaitingReboot", true)
                        .putString("engineInstallBootId", installBootId)
                        .apply()
                    _ui.update { it.copy(screen = InstallScreen.REBOOT_REQUIRED, busy = false, message = "核心组件已交给 Root 管理器。必须先完成一次真实重启，重启前不会拿旧核心组件做协议验证。") }
                } else {
                    val code = if (result.backend == RootBackend.APATCH) "APATCH_ENGINE_INSTALL_FAILED" else "ENGINE_INSTALL_FAILED"
                    fail(code, "核心组件安装没有完成", result.message, "engine_install")
                }
            } catch (t: Throwable) {
                fail("ENGINE_INSTALL_FAILED", "核心组件安装没有完成", t.message ?: t::class.java.simpleName, "engine_install")
            } finally {
                engineInstallJob = null
            }
        }
    }

    fun rollbackEngine() = viewModelScope.launch {
        _ui.update { it.copy(busy = true, message = "正在恢复升级前核心组件；AstrBot、QQ、插件和配置不会被回滚") }
        val r = repository.restoreEngineBackup()
        if (!r.ok) {
            fail("ENGINE_ROLLBACK_FAILED", "核心组件回退没有完成", r.stderr.ifBlank { r.stdout }, "engine_backup")
            return@launch
        }
        // Root managers such as KernelSU/Magisk can keep a staged copy in modules_update.
        // A rollback must discard that staged update or it could be re-applied on the next boot.
        repository.clearPendingEngineUpdate()
        val beforeRebootBootId = repository.bootId()
        prefs.edit()
            .putBoolean("engineInstallSubmitted", false)
            .putBoolean("engineVerified", false)
            .putBoolean("awaitingReboot", true)
            .putBoolean("rollbackPrepared", true)
            .putString("rollbackBootId", beforeRebootBootId)
            .putString("rollbackExpectedVersion", prefs.getString("previousEngineVersion", "").orEmpty())
            .remove("engineInstallBootId")
            .apply()
        _ui.update {
            it.copy(
                screen = InstallScreen.ROLLBACK_REBOOT_REQUIRED,
                busy = false,
                rollbackPrepared = true,
                message = "升级前核心组件已恢复。重启后会重新使用原版本；业务数据没有被回退。"
            )
        }
    }

    fun finishRollback() {
        prefs.edit()
            .remove("rollbackPrepared")
            .remove("rollbackBootId")
            .remove("rollbackExpectedVersion")
            .remove("awaitingReboot")
            .remove("engineInstallBootId")
            .apply()
        _ui.value = InstallerUiState(screen = InstallScreen.WELCOME, message = "已回到升级前核心组件。可以继续使用原 Web 控制台，或稍后重新尝试升级。")
    }

    fun requestReboot() = viewModelScope.launch {
        prefs.edit().putBoolean("awaitingReboot", true).apply()
        _ui.update { it.copy(busy = true, message = "正在安全同步数据并重启") }
        val r = repository.reboot()
        if (!r.ok) _ui.update { it.copy(busy = false, message = "自动重启未执行，请手动重启设备后重新打开控制中心。") }
    }

    fun verifyEngine() = viewModelScope.launch {
        val installBootId = prefs.getString("engineInstallBootId", "").orEmpty()
        val currentBootId = repository.bootId()
        if (prefs.getBoolean("engineInstallSubmitted", false) && installBootId.isNotBlank() && currentBootId == installBootId) {
            _ui.update { it.copy(screen = InstallScreen.REBOOT_REQUIRED, busy = false, error = null, message = "还没有检测到真实重启。当前仍是升级前核心组件，不能在此时做协议/版本验证。请先重启设备。") }
            return@launch
        }
        _ui.update { it.copy(screen = InstallScreen.ENGINE_VERIFY, busy = true, error = null, message = "正在验证重启后的核心组件") }
        if (!repository.enginePresent()) {
            fail("ENGINE_NOT_FOUND_AFTER_REBOOT", "重启后没有找到核心组件", "Root 管理器没有启用模块，或模块安装没有真正完成。", "engine_verify")
            return@launch
        }
        val protocol = repository.protocol()
        if (protocol != EngineRepository.EXPECTED_PROTOCOL) {
            fail("PROTOCOL_MISMATCH", "控制中心与核心组件版本不兼容", "需要协议 ${EngineRepository.EXPECTED_PROTOCOL}，当前核心组件返回 $protocol。", "protocol")
            return@launch
        }
        var status = repository.status()
        status = awaitTargetEngineTakeover(status)
        val installed = repository.existingEngineInfo()
        val normalized = status.engineVersion.removePrefix("v")
        val installedMatchesTarget = installed.installed && installed.version.removePrefix("v") == EngineRepository.TARGET_ENGINE_VERSION && installed.versionCode == EngineRepository.TARGET_ENGINE_VERSION_CODE
        if (!installedMatchesTarget && normalized.isNotBlank() && normalized != EngineRepository.TARGET_ENGINE_VERSION) {
            fail("ENGINE_VERSION_MISMATCH", "重启后核心组件版本不符合预期", "模块文件为 ${installed.version.ifBlank { "未知" }}，运行状态为 ${status.engineVersion.ifBlank { "未知" }}；期望 ${EngineRepository.TARGET_ENGINE_VERSION}。", "engine_verify")
            return@launch
        }
        if (installedMatchesTarget && normalized != EngineRepository.TARGET_ENGINE_VERSION) {
            // The payload on disk is already the requested release. Do not block the user
            // because an old status cache still advertises the previous string.
            status = status.copy(engineVersion = "v${EngineRepository.TARGET_ENGINE_VERSION}")
        }
        if (status.rebootRequired || status.engineVerifiedEpoch <= 0) {
            _ui.update { it.copy(screen = InstallScreen.REBOOT_REQUIRED, busy = false, engineStatus = status, message = "核心组件仍在等待一次完整重启。") }
            return@launch
        }
        prefs.edit()
            .putBoolean("awaitingReboot", false)
            .putBoolean("engineVerified", true)
            .putInt("engineVerifiedVersionCode", EngineRepository.TARGET_ENGINE_VERSION_CODE)
            .putBoolean("engineInstallSubmitted", false)
            .remove("engineInstallBootId")
            .apply()
        loadRuntimePlan(status)
    }

    fun refreshPlan() = viewModelScope.launch { loadRuntimePlan(repository.status()) }

    private suspend fun loadRuntimePlan(status: EngineStatus) {
        val targetScreen = if (status.allRuntimeReady) InstallScreen.READY else InstallScreen.RUNTIME_PLAN
        // Do not leave the welcome page visible while several Root status calls are running.
        // Publish the resolved destination immediately, then refresh secondary details.
        _ui.update {
            it.copy(
                screen = targetScreen,
                busy = !status.allRuntimeReady,
                engineStatus = status,
                error = null,
                message = if (status.allRuntimeReady) "运行环境已经准备完成" else "正在刷新运行资源状态…"
            )
        }
        val plan = repository.plan()
        val resource = repository.resourceStatus()
        val events = repository.events(80)
        val autoDownloadAvailable = repository.rootfsCatalog().urls.isNotEmpty()
        val technicalLog = repository.technicalLog(100)
        _ui.update {
            it.copy(
                screen = targetScreen,
                busy = false,
                engineStatus = status,
                plan = plan,
                resourceStatus = resource,
                resourceAutoDownloadAvailable = autoDownloadAvailable,
                events = events,
                technicalLog = technicalLog,
                error = null,
                message = when {
                    status.allRuntimeReady -> "运行环境已经准备完成"
                    !status.rootfsReady && !resource.ready -> "核心组件已就绪。接下来才进入联网/资源准备阶段；Ubuntu 兼容基础包需要先准备。"
                    else -> "准备就绪。点击开始后才允许核心组件联网获取运行资源。"
                }
            )
        }
    }

    fun startRuntimeInstall() = viewModelScope.launch {
        val status = repository.status()
        val resource = repository.resourceStatus()
        if (!status.rootfsReady && !resource.ready) {
            _ui.update { it.copy(screen = InstallScreen.RUNTIME_PLAN, resourceStatus = resource, message = "缺少已验证的 Ubuntu 基础资源。请先从本地导入；正式发布下载源接入后，这里会提供自动获取。") }
            return@launch
        }
        val r = repository.startRuntime()
        if (!r.ok) {
            fail("INSTALLER_START_FAILED", "无法开始运行环境安装", r.stderr.ifBlank { r.stdout }, "installer_start")
            return@launch
        }
        prefs.edit().putBoolean("runtimeStarted", true).apply()
        _ui.update { it.copy(screen = InstallScreen.RUNTIME_INSTALL, busy = false, installStartedByApp = true, message = "安装任务已提交。每个阶段和失败原因都会持续显示。") }
        startPolling()
    }

    fun downloadRootfs() = viewModelScope.launch {
        _ui.update { it.copy(busy = true, resourceDownloadProgress = 0f, resourceDownloadDetail = "正在连接已验证资源源；断线后会保留 .part 并尝试续传", error = null) }
        val r = repository.downloadRootfs { p ->
            val progress = if (p.total > 0) (p.current.toDouble() / p.total.toDouble()).coerceIn(0.0, 1.0).toFloat() else 0f
            val mib = p.speedBytesPerSecond / 1024.0 / 1024.0
            _ui.update { state -> state.copy(resourceDownloadProgress = progress, resourceDownloadDetail = "${p.current / 1024 / 1024} / ${p.total / 1024 / 1024} MiB · %.1f MiB/s".format(mib)) }
        }
        if (r.ok) {
            _ui.update { it.copy(busy = false, resourceDownloadProgress = null, resourceDownloadDetail = "Ubuntu 基础资源已下载、双重校验并导入核心组件。", message = "运行资源已准备，可以开始环境安装。") }
            refreshPlan()
        } else {
            _ui.update { it.copy(busy = false, resourceDownloadProgress = null) }
            val code = if (r.code == 78) "ROOTFS_SOURCE_NOT_CONFIGURED" else "NETWORK_DOWNLOAD_FAILED"
            fail(code, if (r.code == 78) "自动下载源尚未配置" else "Ubuntu 基础资源下载没有完成", r.stderr.ifBlank { r.stdout }, if (r.code == 78) "rootfs_resource" else "network_download")
        }
    }

    fun importRootfs(uri: Uri) = viewModelScope.launch {
        _ui.update { it.copy(busy = true, importProgress = 0f, error = null, message = "正在本地校验 Ubuntu 兼容基础包；不会联网") }
        val r = repository.importRootfs(uri) { progress -> _ui.update { it.copy(importProgress = progress) } }
        if (r.ok) {
            _ui.update { it.copy(busy = false, importProgress = null, message = "Ubuntu 基础资源已通过 SHA-256 校验并交给核心组件。") }
            refreshPlan()
        } else {
            _ui.update { it.copy(busy = false, importProgress = null) }
            fail("RESOURCE_IMPORT_FAILED", "Ubuntu 基础资源无法使用", r.stderr.ifBlank { r.stdout }, "resource_integrity")
        }
    }

    fun retryCurrent() {
        when (_ui.value.error?.code.orEmpty()) {
            "ENGINE_BACKUP_FAILED", "ENGINE_INSTALL_FAILED", "APATCH_ENGINE_INSTALL_FAILED", "ENGINE_DOWNGRADE_BLOCKED" -> _ui.update { it.copy(screen = InstallScreen.ENGINE_INSTALL, error = null) }
            "ENGINE_NOT_FOUND_AFTER_REBOOT", "PROTOCOL_MISMATCH", "ENGINE_VERSION_MISMATCH" -> verifyEngine()
            "ROOTFS_RESOURCE_MISSING", "RESOURCE_IMPORT_FAILED" -> refreshPlan()
            "FIRST_START_FAILED" -> refreshPlan()
            else -> startRuntimeInstall()
        }
    }

    fun openHelp(topic: String? = null) {
        _ui.update { state ->
            state.copy(
                screen = InstallScreen.HELP,
                helpTopic = topic ?: state.engineStatus.solutionId.ifBlank { null },
                helpReturnScreen = state.screen
            )
        }
    }

    fun closeHelp() {
        val target = _ui.value.helpReturnScreen ?: when {
            _ui.value.rollbackPrepared -> InstallScreen.ROLLBACK_REBOOT_REQUIRED
            _ui.value.engineStatus.allRuntimeReady -> InstallScreen.READY
            prefs.getBoolean("engineVerified", false) -> if (_ui.value.engineStatus.workerRunning) InstallScreen.RUNTIME_INSTALL else InstallScreen.RUNTIME_PLAN
            prefs.getBoolean("engineInstallSubmitted", false) -> InstallScreen.REBOOT_REQUIRED
            _ui.value.checks.isNotEmpty() -> InstallScreen.PREFLIGHT
            else -> InstallScreen.WELCOME
        }
        _ui.update { it.copy(screen = target, helpReturnScreen = null, error = null) }
    }

    fun showTechnicalLog() = viewModelScope.launch {
        _ui.update { it.copy(technicalLog = repository.technicalLog(180), events = repository.events(120)) }
    }

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = viewModelScope.launch {
            while (true) {
                val status = repository.status()
                val events = repository.events(100)
                val log = repository.technicalLog(120)
                _ui.update { it.copy(engineStatus = status, events = events, technicalLog = log) }
                when {
                    status.state == "failed" || status.errorCode.isNotBlank() -> {
                        failFromStatus(status); return@launch
                    }
                    status.allRuntimeReady && !status.workerRunning -> {
                        prefs.edit().putBoolean("runtimeComplete", true).apply()
                        _ui.update { it.copy(screen = InstallScreen.READY, busy = false, message = "安装完成。QQ 登录是下一步使用流程，不会触发重新安装。") }
                        return@launch
                    }
                    !status.workerRunning && prefs.getBoolean("runtimeStarted", false) && status.stage !in listOf("idle", "overall") -> {
                        if (!status.allRuntimeReady && status.state != "success") {
                            fail("INSTALLER_STOPPED", "安装任务已经停止", "没有检测到正在运行的安装任务。已完成组件和下载缓存会保留。", "generic")
                            return@launch
                        }
                    }
                }
                delay(if (status.workerRunning) 850 else 1800)
            }
        }
    }

    private fun restoreOrDetect() = viewModelScope.launch {
        _ui.update { it.copy(screen = InstallScreen.RESTORING, busy = true, error = null, message = "正在恢复上次安装状态并读取核心组件，请稍候") }
        if (prefs.getBoolean("rollbackPrepared", false)) {
            // Make rollback durable across KernelSU/Magisk style staged module updates.
            repository.clearPendingEngineUpdate()
            val previousBootId = prefs.getString("rollbackBootId", "").orEmpty()
            val currentBootId = repository.bootId()
            val expected = prefs.getString("rollbackExpectedVersion", "").orEmpty()
            if (previousBootId.isNotBlank() && currentBootId.isNotBlank() && currentBootId != previousBootId) {
                repository.clearRollbackPendingMarkers()
                val existing = repository.existingEngineInfo()
                _ui.value = InstallerUiState(
                    screen = InstallScreen.ROLLBACK_COMPLETE,
                    existingEngine = existing,
                    rollbackPrepared = true,
                    message = "已完成重启。当前核心组件：${existing.version.ifBlank { expected.ifBlank { "升级前版本" } }}；AstrBot、插件、QQ 与运行环境数据没有被回退。"
                )
            } else {
                _ui.value = InstallerUiState(
                    screen = InstallScreen.ROLLBACK_REBOOT_REQUIRED,
                    rollbackPrepared = true,
                    message = "升级前核心组件已恢复到模块目录，还需要重启一次让 Root 管理器加载旧版本。"
                )
            }
            return@launch
        }
        val installSubmitted = prefs.getBoolean("engineInstallSubmitted", false)
        val engineVerified = prefs.getBoolean("engineVerified", false)
        val verifiedVersionCode = prefs.getInt("engineVerifiedVersionCode", 0)
        if (engineVerified && !installSubmitted && verifiedVersionCode == EngineRepository.TARGET_ENGINE_VERSION_CODE) {
            // A previously verified *same release* is safe to show immediately.  Do not
            // make every normal app launch wait for another privileged process.  Runtime
            // truth is refreshed after the first frame by the control center itself.
            _ui.value = InstallerUiState(screen = InstallScreen.READY, busy = false)
            return@launch
        }
        if (engineVerified && !installSubmitted && repository.quickVerifiedEngineReady()) {
            // Migration path for installs verified by older app builds that did not persist
            // the target version marker. This one-time privileged probe seeds the fast path.
            prefs.edit().putInt("engineVerifiedVersionCode", EngineRepository.TARGET_ENGINE_VERSION_CODE).apply()
            _ui.value = InstallerUiState(screen = InstallScreen.READY, busy = false)
            return@launch
        }
        if (!installSubmitted && !engineVerified) {
            _ui.value = InstallerUiState(screen = InstallScreen.WELCOME, busy = false)
            return@launch
        }
        if (installSubmitted && !engineVerified) {
            val installBootId = prefs.getString("engineInstallBootId", "").orEmpty()
            val currentBootId = repository.bootId()
            if (installBootId.isNotBlank() && currentBootId.isNotBlank() && currentBootId == installBootId) {
                _ui.value = InstallerUiState(
                    screen = InstallScreen.REBOOT_REQUIRED,
                    message = "核心组件已交给 Root 管理器，但还没有检测到真实重启。当前活动的仍可能是升级前核心组件，因此不会提前做协议验证。"
                )
                return@launch
            }
        }
        val enginePresent = repository.enginePresent()
        if (!enginePresent) {
            _ui.value = InstallerUiState(screen = if (prefs.getBoolean("engineInstallSubmitted", false)) InstallScreen.REBOOT_REQUIRED else InstallScreen.WELCOME, busy = false)
            return@launch
        }
        val protocol = repository.protocol()
        if (protocol != EngineRepository.EXPECTED_PROTOCOL) {
            fail("PROTOCOL_MISMATCH", "检测到不兼容的核心组件", "当前协议为 $protocol，需要 ${EngineRepository.EXPECTED_PROTOCOL}。", "protocol")
            return@launch
        }

        // App upgrades can ship a newer embedded core while SharedPreferences still say the
        // previous core was already verified. Do not silently enter the native control center
        // with an older core: dev5 depends on the dev3 active-engine status and QR readiness
        // contract. Prepare the normal guarded upgrade flow instead, preserving the rollback
        // point and requiring the user's explicit confirmation before touching the module.
        val existing = repository.existingEngineInfo()
        if (!installSubmitted && existing.installed && existing.versionCode in 1 until EngineRepository.TARGET_ENGINE_VERSION_CODE) {
            val asset = engineAsset ?: repository.prepareEngineAsset().also { engineAsset = it }
            rootInfo = repository.rootInfo()
            val checks = repository.preflight(asset, rootInfo)
            prefs.edit().putBoolean("engineVerified", false).apply()
            _ui.value = InstallerUiState(
                screen = if (checks.any { it.blocking && !it.ok }) InstallScreen.PREFLIGHT else InstallScreen.ENGINE_INSTALL,
                busy = false,
                rootBackend = rootInfo.backend,
                rootBackendVersion = rootInfo.version,
                checks = checks,
                engineAssetSha256 = asset.sha256,
                engineAssetReady = true,
                existingEngine = existing,
                engineUpgradeConfirmed = false,
                message = "控制中心已更新，需要把核心组件从 ${existing.version.ifBlank { "旧版本" }} 升级到 ${EngineRepository.TARGET_ENGINE_VERSION}。业务数据不会重装，升级前会先创建回退点。"
            )
            return@launch
        }

        var status = repository.status()
        if (installSubmitted) status = awaitTargetEngineTakeover(status)
        val normalized = status.engineVersion.removePrefix("v")
        if (installSubmitted && normalized.isNotBlank() && normalized != EngineRepository.TARGET_ENGINE_VERSION) {
            val installedNow = repository.existingEngineInfo()
            val installedMatchesTarget = installedNow.installed && installedNow.version.removePrefix("v") == EngineRepository.TARGET_ENGINE_VERSION && installedNow.versionCode == EngineRepository.TARGET_ENGINE_VERSION_CODE
            if (installedMatchesTarget) {
                status = status.copy(engineVersion = "v${EngineRepository.TARGET_ENGINE_VERSION}")
            } else {
                fail("ENGINE_VERSION_MISMATCH", "重启后核心组件版本不符合预期", "模块文件为 ${installedNow.version.ifBlank { "未知" }}，运行状态为 ${status.engineVersion}；期望 ${EngineRepository.TARGET_ENGINE_VERSION}。", "engine_verify")
                return@launch
            }
        }
        if (status.rebootRequired || status.engineVerifiedEpoch <= 0) {
            _ui.update { it.copy(screen = InstallScreen.REBOOT_REQUIRED, busy = false, engineStatus = status, message = "核心组件已安装，等待重启验证。") }
            return@launch
        }
        prefs.edit()
            .putBoolean("engineVerified", true)
            .putInt("engineVerifiedVersionCode", EngineRepository.TARGET_ENGINE_VERSION_CODE)
            .putBoolean("engineInstallSubmitted", false)
            .putBoolean("awaitingReboot", false)
            .remove("engineInstallBootId")
            .apply()
        if (status.workerRunning) {
            _ui.update { it.copy(screen = InstallScreen.RUNTIME_INSTALL, busy = false, engineStatus = status, installStartedByApp = true) }
            startPolling()
        } else loadRuntimePlan(status)
    }

    private suspend fun awaitTargetEngineTakeover(initial: EngineStatus): EngineStatus {
        var status = initial
        fun mismatch(value: EngineStatus): Boolean {
            val version = value.engineVersion.removePrefix("v")
            return version.isNotBlank() && version != EngineRepository.TARGET_ENGINE_VERSION
        }
        if (!mismatch(status)) return status

        // Root module metadata can switch before the previous boot daemon has fully
        // exited. During that short handover window the old status socket may still
        // report the previous version. Wait for a stable takeover before declaring
        // the upgrade broken.
        repeat(8) { attempt ->
            _ui.update { current ->
                current.copy(
                    screen = InstallScreen.ENGINE_VERIFY,
                    busy = true,
                    error = null,
                    engineStatus = status,
                    message = "新核心组件正在接管，暂时仍检测到 ${status.engineVersion}（${attempt + 1}/8）"
                )
            }
            delay(if (attempt < 2) 450L else 900L)
            status = repository.status()
            if (!mismatch(status)) return status
        }
        return status
    }

    private fun failFromStatus(status: EngineStatus) {
        val mapped = mapError(status.errorCode.ifBlank { "INSTALL_FAILED" }, status.title.ifBlank { "安装没有完成" }, status.detail, status.solutionId)
        _ui.update { it.copy(screen = InstallScreen.ERROR, busy = false, error = mapped, engineStatus = status) }
        pollJob?.cancel()
    }

    private fun fail(code: String, title: String, message: String, solution: String) {
        _ui.update { it.copy(screen = InstallScreen.ERROR, busy = false, error = mapError(code, title, message, solution)) }
    }

    private fun mapError(code: String, title: String, message: String, solution: String): InstallerError {
        val safe = when (code) {
            "ENGINE_BACKUP_FAILED", "ENGINE_INSTALL_FAILED", "APATCH_ENGINE_INSTALL_FAILED", "ENGINE_NOT_FOUND_AFTER_REBOOT", "PROTOCOL_MISMATCH", "ENGINE_VERSION_MISMATCH", "ENGINE_DOWNGRADE_BLOCKED", "ENGINE_ROLLBACK_FAILED" ->
                "运行环境不会因为核心组件安装/验证失败而被删除；Ubuntu、AstrBot、QQ、插件和配置保存在独立持久目录。"
            "FIRST_START_FAILED" -> "运行环境已经安装完成，不需要重新下载安装包。"
            else -> "已完成的组件与通过校验的缓存会尽量保留，不会因为重试而从零开始。"
        }
        val rollbackRecommended = code in setOf("ENGINE_NOT_FOUND_AFTER_REBOOT", "PROTOCOL_MISMATCH", "ENGINE_VERSION_MISMATCH") &&
            (prefs.getBoolean("engineBackupAvailable", false) || _ui.value.existingEngine.rollbackAvailable)
        return InstallerError(
            code = code,
            title = title,
            message = message.ifBlank { "请展开技术详情查看返回信息。" },
            dataSafeMessage = safe,
            solutionId = solution.ifBlank { "generic" },
            rollbackRecommended = rollbackRecommended
        )
    }
}
