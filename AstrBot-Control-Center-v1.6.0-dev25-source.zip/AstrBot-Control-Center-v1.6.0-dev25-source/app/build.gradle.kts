import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.xianaurora.astrbotcontrol"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.xianaurora.astrbotcontrol"
        minSdk = 28
        targetSdk = 36
        versionCode = 162500
        versionName = "1.6.0-dev25"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    // Stable development signing: GitHub-hosted runners are ephemeral, so relying
    // on their default debug.keystore makes update signatures unstable across runs.
    // Environment variables can override this checked-in DEVELOPMENT key later.
    signingConfigs {
        create("stableDev") {
            val configuredPath = System.getenv("ASTRBOT_KEYSTORE_PATH")?.takeIf { it.isNotBlank() }
            storeFile = if (configuredPath != null) {
                rootProject.file(configuredPath)
            } else {
                rootProject.file("keystore/astrbot-dev-update.jks")
            }
            storePassword = System.getenv("ASTRBOT_KEYSTORE_PASSWORD")?.takeIf { it.isNotBlank() } ?: "AstrBot-Dev-Update-2026"
            keyAlias = System.getenv("ASTRBOT_KEY_ALIAS")?.takeIf { it.isNotBlank() } ?: "astrbot-dev-update"
            keyPassword = System.getenv("ASTRBOT_KEY_PASSWORD")?.takeIf { it.isNotBlank() } ?: "AstrBot-Dev-Update-2026"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("stableDev")
        }
        release {
            signingConfig = signingConfigs.getByName("stableDev")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.add("-Xannotation-default-target=param-property")
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.06.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.11.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    testImplementation("junit:junit:4.13.2")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
