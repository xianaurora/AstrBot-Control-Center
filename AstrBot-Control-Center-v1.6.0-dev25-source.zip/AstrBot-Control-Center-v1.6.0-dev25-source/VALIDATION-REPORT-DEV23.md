# Validation report — dev23

## Release targets

- Android app: `1.6.0-dev23` / `162300`
- Embedded core: `1.6.0-dev14` / `16014`
- Stable development signing: unchanged from dev17+

## Validation completed in this environment

- Source release gate: PASS (`SOURCE_GATE_OK`)
- Embedded `engine.zip` SHA match: PASS
- Embedded core manifest SHA verification: PASS
- Shell syntax (`bash -n`) across embedded engine scripts: PASS
- Planned SnowLuma stop / engine-switch regression test: PASS
- Control-center QR/rendering regression test: PASS
- Pure Kotlin model/parser compilation with local `kotlinc`: PASS
- Kotlin delimiter / parser sanity scan across project Kotlin sources: PASS
- Final archive re-extraction verification: required before handoff and recorded in package checksum file.

## Important limitation

A full Android `assembleDebug` / Compose compiler build cannot be performed in the current container because the complete Android SDK/Gradle build toolchain is not installed. GitHub Actions remains the authoritative final Android compilation step. The source gate is intentionally not presented as a substitute for that build.
