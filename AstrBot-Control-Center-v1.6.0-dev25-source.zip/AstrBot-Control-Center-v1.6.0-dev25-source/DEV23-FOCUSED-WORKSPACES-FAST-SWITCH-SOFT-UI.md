# dev23 — Focused workspaces, faster engine switching, softer UI

## Why this release exists

Real-device testing on a Lenovo Android 16 tablet showed two remaining structural issues after dev22:

1. AstrBot opened in a focused, almost-fullscreen shell while SnowLuma/NapCat/QQ login still retained the global navigation rail. The workspaces therefore looked like different applications even though the launcher page was unified.
2. SnowLuma → NapCat switching worked, but an intentional SnowLuma shutdown was mistaken for a crash by its own runtime supervisor. SnowLuma restarted itself, the outer switch waited for the stop timeout, and a successful NapCat switch could still leak `rc=1` from a trailing shell condition.

This release fixes those root causes and performs a broad visual cleanup of the Control Center and installer surfaces.

## Unified focused workspaces

- Entering SnowLuma, NapCat or QQ Login now hides the global left rail / bottom navigation, matching AstrBot's focused-workspace behavior.
- Focused workspaces use one compact shell: `‹ 工作台`, workspace title/state, fullscreen, and an overflow menu.
- The overflow menu owns secondary navigation actions (web back/forward, reload, browser open, login-window/desktop mode) instead of crowding the top bar.
- Fullscreen is available to Compose-hosted workspaces as well as AstrBot. Back exits fullscreen first, then returns to the workbench.
- Android system bars are hidden only while a Compose workspace is actually fullscreen and are restored when leaving it.

## AstrBot remains on the stable WebView path

The classic `AstrBotWebActivity` architecture that fixed the historical white screen remains intact. dev23 only changes its shell and presentation:

- rounded native WebView container in normal mode;
- matching workbench-style toolbar and spacing;
- fullscreen keeps the same WebView instance and only removes the shell;
- the existing PixelCopy / WebView diagnostics remain available for failures.

This avoids re-introducing the old Compose-embedded WebView regression.

## Faster SnowLuma ↔ NapCat switching

Embedded core is `v1.6.0-dev14` (`16014`).

- Engine switching writes a shared `snowluma-stop-requested` marker before intentionally stopping SnowLuma.
- The SnowLuma runtime loop sees that marker and exits without `SNOWLUMA_PROCESS_RESTART`.
- Graceful-stop waiting is bounded to roughly 10 seconds before the existing force-stop fallback.
- Successful `qq-engine-switch-*` actions explicitly `return 0`, so a successful NapCat switch can no longer be reported as a failure because a trailing conditional returned false.
- Existing failed-switch rollback is retained.

## Softer interface pass

- Main cards, workbench cards, focused workspace containers, setup panels and installer surfaces use a larger shared corner-radius scale.
- The global tablet rail now has a rounded outer edge rather than a hard rectangular slab.
- The phone bottom navigation receives rounded top corners and elevation.
- The settings save bar has stronger floating separation and shows active save/apply progress and action text.
- Workbench launch cards were made slightly shorter to improve information density on wide tablets.

## Preserved behavior

- Fixed dev signing identity from dev17+ is unchanged.
- Launcher label remains `AstrBot CC`.
- The dev22 launcher artwork/safe-zone treatment is unchanged.
- Same-frame QQ login touch mapping and atomic settings-directory locking from dev22 remain in place.
