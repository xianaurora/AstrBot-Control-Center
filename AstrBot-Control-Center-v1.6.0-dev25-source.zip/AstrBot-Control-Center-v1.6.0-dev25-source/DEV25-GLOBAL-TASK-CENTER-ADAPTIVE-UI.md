# dev25 · 全局任务中心 / 自适应 UI

## 目标

- 设置提交后立刻离开当前页面，后台任务在顶部统一跟踪。
- 消灭“已经应用成功却仍要求再保存”的草稿/执行状态混淆。
- 首次开机恢复期间不再把暂时拿不到状态误报为硬错误。
- AstrBot、SnowLuma、NapCat 的工作区动作菜单使用同一尺寸、图标和动效语言。
- UI 从手机/平板两档升级为 Compact / Medium / Expanded / Large 四档窗口适配。

## 全局任务中心

后台任务具有排队、运行、完成、失败四种状态，并记录进度、当前说明和步骤。设置保存、QQ 引擎切换以及后台 action 都进入任务中心。提交完成后环境页的“未保存”栏立即收起，执行中的字段进入“应用中”状态；失败时才把对应字段恢复为待保存。

任务中心位于页面顶部。点击任务可以展开步骤。经典 AstrBot Activity 通过进程级 BackgroundTaskHub 读取同一任务快照，因此进入 AstrBot 后也不会丢失后台任务可见性。

## 启动恢复状态

状态读取改为 CONNECTING / CACHED / READY / STALE / UNAVAILABLE。设备刚重启时优先显示上次状态，并提示正在恢复服务；只有连续多次读取失败才显示“状态暂时不可用”，不再首次读取失败就报错。

## 菜单与动画

- 菜单统一约 238dp 宽、28dp 圆角、图标 + 文本行。
- 菜单锚点使用实际 overflow 按钮位置，不再使用会把浮层推向屏幕中央的固定坐标。
- overflow 按钮按压缩放并旋转；浮层从按钮方向轻微缩放/位移/淡入。
- AstrBot 的原生 View 菜单与 Compose 工作区菜单使用相同视觉参数。

## 自适应布局

窗口按可用宽度分为：

- Compact: < 600dp
- Medium: 600–839dp
- Expanded: 840–1199dp
- Large: >= 1200dp

Compact 使用底部导航；其余档位使用不同宽度侧栏。Medium 不强行套用宽平板的多栏内容布局；窄标题区域会把任务/刷新操作下移到第二行。

## 4 KB / 16 KB page-size

CI 新增 APK 16 KB zip alignment 检查，并审计 engine.zip 中的 ELF LOAD 对齐。当前内嵌 core 仍有 `proot`、`loader`、`libtalloc.so.2` 为 4 KB ELF 对齐，因此 dev25 **不宣称运行核心已经完整支持 16 KB page-size**。安装前检查会明确区分 4 KB 已验证与 16 KB 核心仍需重建，避免把 16 KB 设备误标成普通未知错误。
