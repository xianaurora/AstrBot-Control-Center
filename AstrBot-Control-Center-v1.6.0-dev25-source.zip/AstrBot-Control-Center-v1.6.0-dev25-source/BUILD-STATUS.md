# Build status · v1.6.0-dev25

- App: `1.6.0-dev25` (`162500`)
- Embedded core: `1.6.0-dev15` (`16015`)
- Source gate: PASS
- Pure Kotlin model/parser compile: PASS
- Embedded core archive/hash + shell syntax: PASS
- Stable development signing: retained
- GitHub Actions: full unit tests + Compose APK build + stable certificate verification
- 16 KB APK zip-alignment check: added to CI
- Embedded core ELF audit: 4 ELF checked; 3 still use 4 KB LOAD alignment, so full 16 KB runtime-core support is **not yet claimed**

Local environment does not include the complete Android SDK/Gradle build chain. GitHub Actions remains the final Android/Compose compilation gate.
