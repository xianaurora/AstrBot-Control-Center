# dev22 validation

Validated in the source package environment:

- Embedded core archive integrity and manifest checks.
- Shell syntax for all engine shell entry points.
- Core release agreement: `1.6.0-dev13 / 16013`.
- App release agreement: `1.6.0-dev22 / 162200`.
- Atomic settings lock present; FD `flock -xn 9` removed from settings writes.
- Same-frame QQ capture/tap metadata is wired from guest capture -> core protocol -> Android state -> core tap command.
- AstrBot classic Activity WebView remains in use and now exposes fullscreen workbench chrome.
- Stable development signing identity remains configured.
- Launcher label remains `AstrBot CC`; launcher artwork replaced with the user-provided dev22 image using transparent corners and safe-area scaling.
- Pure Kotlin model/parser compilation passes with local `kotlinc`.
- Android-dependent Kotlin files were syntax-scanned; unresolved Android/Compose symbols are expected without the Android SDK classpath, and no parser-level syntax diagnostics were found.

Full Android Compose compilation must still be performed by the included GitHub Actions workflow.
