#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENGINE="$ROOT/app/src/main/assets/engine.zip"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$ENGINE" -d "$TMP/engine"
count=0
legacy=0
while IFS= read -r -d '' file; do
  if [[ "$(head -c 4 "$file" | od -An -tx1 | tr -d ' \n')" != "7f454c46" ]]; then
    continue
  fi
  count=$((count+1))
  min=""
  while read -r align; do
    [[ -n "$align" ]] || continue
    value=$((align))
    if [[ -z "$min" || $value -lt $min ]]; then min=$value; fi
  done < <(readelf -lW "$file" 2>/dev/null | awk '$1=="LOAD"{print $NF}')
  if [[ -n "$min" && $min -lt 16384 ]]; then
    legacy=$((legacy+1))
    printf 'PAGE_SIZE_ENGINE_LEGACY path=%s min_align=0x%x\n' "${file#$TMP/engine/}" "$min"
  fi
done < <(find "$TMP/engine" -type f -print0)
printf 'PAGE_SIZE_ENGINE_AUDIT elf=%d below_16k=%d\n' "$count" "$legacy"
