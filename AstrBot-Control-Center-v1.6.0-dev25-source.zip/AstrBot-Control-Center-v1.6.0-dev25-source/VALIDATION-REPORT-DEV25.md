# Validation report · dev25

## Passed locally

- `scripts/verify-source.sh`
- `engine.zip` SHA / archive integrity / embedded manifest verification
- Embedded core shell syntax gate
- `ControlCenterModels.kt + ControlStatusParser.kt` real `kotlinc` compile
- Kotlin syntax-level scan for Android/Compose files (Android symbols unresolved locally as expected; no parser-level syntax errors found)
- Task center model + cross-Activity task bridge source gates
- Adaptive width class source gates
- AstrBot menu anchor / task center source gates

## Page-size audit

`engine.zip` ELF results:

- `bin/busybox`: >= 16 KB alignment
- `bin/libtalloc.so.2`: legacy 4 KB alignment
- `bin/loader`: legacy 4 KB alignment
- `bin/proot`: legacy 4 KB alignment

The workflow checks final APK ZIP alignment with `zipalign -c -P 16 -v 4`. The embedded runtime ELF warning remains non-blocking in CI only so the artifact exposes the report; installer preflight on a 16 KB device remains conservative until the native runtime payloads are rebuilt.

## Not locally available

A complete Android SDK/Gradle/Compose build environment is not present here. GitHub Actions runs `:app:testDebugUnitTest :app:assembleDebug` and is the authoritative final compile check.
