# dev24 — response-first control center and softer native surfaces

## Why
The dev23 diagnostics quantified two different delays. A NapCat→SnowLuma switch took about 28 seconds, while the Android app also paid for repeated privileged shell transitions, status checks and URL discovery around otherwise simple navigation and save actions. The UI therefore felt like it was waiting even when the real work had already been submitted.

## Android changes
- Normal launches restore the last private app-side status snapshot immediately, then refresh real runtime state in the background.
- Once the same embedded core release has already been verified, later daily launches enter the control center without launching another root process just to re-verify the version. Older installs use one migration probe to seed this marker.
- `RootShell` removes its temporary PID file inside the same privileged session instead of starting a second `su` cleaner after every command.
- Startup log discovery, diagnostic-export status and console keepalive run after the first status paint instead of serially blocking it.
- AstrBot and SnowLuma workspaces use their deterministic loopback URL directly; opening them no longer waits for a privileged `web-url` lookup. NapCat still asks the core because its WebUI token can change.
- AstrBot launch itself is immediate: the proven classic Activity/WebView opens first and diagnoses HTTP/rendering failures from inside the workspace.
- Ordinary staged settings are applied in one root session instead of one `su` per toggle.
- Queued maintenance actions release the global busy UI as soon as the background worker accepts the job. Completion follows asynchronously.
- Engine-switch settings stay visually committed while the backend catches up, instead of snapping back to the old engine during polling.
- Material dialogs use a 44dp soft shape. The floating save surface uses 36/44dp geometry.
- The AstrBot platform `PopupMenu` was replaced by a transparent `PopupWindow` with a rounded custom panel; Compose workspace menus are clipped to the same softer geometry.

## Core dev15
- Explicit NapCat engine switching sends TERM to all managed NapCat instances together, waits at most six seconds collectively, then kills only leftovers.
- Normal user-initiated stop commands keep their longer graceful path.
- dev14 SnowLuma planned-stop behavior remains, so an intentional engine switch is not mistaken for a crash and restarted by its own supervisor.
- Settings keep the atomic directory lock introduced previously; no BusyBox FD `flock` dependency was reintroduced.

## Validation boundary
The source gate, embedded-core hashes, targeted shell regressions, pure Kotlin parser/models and a full Kotlin/KTS lexical structure scan are checked locally. This environment does not contain the Android Gradle wrapper/SDK needed for a real `assembleDebug`, so GitHub Actions remains the final Android/Compose compiler check.
