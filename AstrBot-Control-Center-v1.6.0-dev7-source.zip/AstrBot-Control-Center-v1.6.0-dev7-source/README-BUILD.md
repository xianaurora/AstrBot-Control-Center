# AstrBot Control Center v1.6.0-dev2

这是“原生 Android 控制中心 + 单一 核心组件”的开发测试版源码。`astrbot_standalone` 模块 ID 保持不变，因此从 v1.5.6.5 测试时走**原地升级**，不会并行安装第二个 核心组件。

## dev2 新增的升级保护

- 检测到现有 `astrbot_standalone` 后，必须在 App 中明确确认版本变化，App 不会因为自身更新而自动刷 核心组件。
- 写入新 核心组件 前先创建**仅包含 Root 模块本体**的回退快照，并对归档计算 SHA-256。
- `customize.sh` 也有第二道升级保护：即使绕过 App 在 Root 管理器 中手动刷 dev2，也会先为当前 核心组件 建立回退点；创建失败则停止升级。
- 核心组件 回退只恢复 `/data/adb/modules/astrbot_standalone`，不会回滚 `/data/adb/astrbot_standalone` 里的 Ubuntu、AstrBot、插件、NapCat、QQ 登录态或配置。
- 重启后 App 验证协议和目标 核心组件 版本；验证失败且存在回退点时，可恢复旧 核心组件 后再重启。
- 检测到比 dev2 更高的 核心组件 `versionCode` 时默认拒绝降级，避免误刷。

## 安装网络策略

- 第一次打开 App 不联网。
- 设备检查、内置 核心组件 SHA-256 校验、核心组件 写入、第一次重启验证全部不需要网络。
- 新装或运行环境未完整时，核心组件 不会在重启后自动执行 setup。
- 只有 核心组件 验证成功且用户进入“准备运行环境”后，才允许明确开始联网资源阶段。
- 已完整的 v1.5.6.5 运行环境会直接复用，不重新下载 Ubuntu / AstrBot / Linux QQ / NapCat。

## Android 工程

- package：`com.xianaurora.astrbotcontrol`
- minSdk：28
- compileSdk：37
- targetSdk：36
- Android Gradle Plugin：9.3.1
- Gradle：9.5.0
- JDK/JVM：17
- Jetpack Compose / Material 3

工程包含 `gradle/wrapper/gradle-wrapper.properties`，但本生成环境无法取得 `gradle-wrapper.jar`，所以源码包里没有 wrapper JAR。最省事的方式是使用 Android Studio 打开工程，让本机配置 Gradle 9.5.0，或先在电脑上安装 Gradle 9.5.0 后执行：

```bash
gradle wrapper --gradle-version 9.5.0
```

然后：

```bash
./gradlew :app:assembleDebug
```

Debug APK 默认输出：

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Ubuntu 定制基础包

核心组件 当前要求精确资源：

- 文件：`AstrBot-Standalone-Base-Ubuntu24.04-arm64-v1.0.0.tar.xz`
- 大小：`65831076` bytes
- SHA-256：`4590dbac3ec23adbadbeba67a9d9c0098069d55ebee4731a9889616a82981441`

当前发布清单没有该定制包的可信公开 HTTPS 地址，因此 dev2 不会用普通 Ubuntu Base 冒充。对于已经完整安装好的 v1.5.6.5 环境，升级 核心组件 时不会需要重新导入它。

## 测试顺序

见源码包根目录 `TESTING-CHECKLIST.md`。
