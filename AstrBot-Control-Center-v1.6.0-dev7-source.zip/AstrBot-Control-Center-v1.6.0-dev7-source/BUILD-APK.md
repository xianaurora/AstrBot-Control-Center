# 从源码生成测试 APK（v1.6.0-dev2）

## 推荐方式：Android Studio + Gradle 9.5

工程参数：

- AGP 9.3.1
- Gradle 9.5.0
- JDK 17
- compileSdk 37
- targetSdk 36
- minSdk 28

### 1. 安装 Android Studio

安装当前稳定版 Android Studio，并在 Setup Wizard / SDK Manager 中安装：

- Android SDK Platform 37
- Android SDK Build-Tools 36.0.0
- Android SDK Platform-Tools（用于 adb）

在 Gradle 设置中使用 JDK 17。

### 2. 解压源码

把本源码 ZIP 解压到一个不含中文特殊符号也尽量不含空格的目录，例如：

```text
D:\AstrBotControlCenter\
```

### 3. 生成 Gradle Wrapper（本源码包当前没有 wrapper JAR）

先在电脑安装 Gradle 9.5.0，然后在项目根目录执行一次：

Windows PowerShell：

```powershell
gradle wrapper --gradle-version 9.5.0
```

Linux/macOS：

```bash
gradle wrapper --gradle-version 9.5.0
```

成功后项目根目录会出现 `gradlew` / `gradlew.bat`，并生成 `gradle/wrapper/gradle-wrapper.jar`。

> `gradle/wrapper/gradle-wrapper.properties` 已经固定到 Gradle 9.5.0。

### 4. 打开并同步

在 Android Studio 选择 **Open**，打开源码根目录，等待 Gradle Sync 和依赖下载完成。

这一步是“电脑构建 APK”的联网下载，只下载 Android/Gradle/Compose 构建依赖；它与手机上的 AstrBot 安装流程不是一回事。

### 5. 构建 Debug APK

最稳定的命令：

Windows：

```powershell
.\gradlew.bat :app:assembleDebug
```

Linux/macOS：

```bash
./gradlew :app:assembleDebug
```

APK 输出：

```text
app/build/outputs/apk/debug/app-debug.apk
```

Debug APK 已由 Android 构建工具使用 debug key 签名，可直接用于真机开发测试。

## 安装到手机

### 方法 A：ADB（最推荐测试）

手机打开：

```text
开发者选项 → USB 调试
```

电脑：

```bash
adb devices
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

首次连接时，在手机上确认这台电脑的 ADB RSA 授权。

### 方法 B：把 APK 传到手机手动安装

把 `app-debug.apk` 复制到手机并点击安装。Android 可能要求给文件管理器允许“安装未知应用”。

## 第一次真机测试顺序

不要一上来同时测试 APK、核心组件、联网安装和修复。按 `TESTING-CHECKLIST.md` 分阶段：

1. 先安装 APK，断网打开，确认不会自动申请 Root / 自动刷 核心组件 / 自动下载资源。
2. 点击“开始安装”，检查能否识别现有 `astrbot_standalone` 和版本。
3. 确认界面显示 `v1.5.6.5 → v1.6.0-dev2`，并要求显式确认升级。
4. 升级前确认 仅核心组件 回退点创建成功。
5. 升级 核心组件，仍保持手机断网。
6. 重启后验证 核心组件 与协议；旧运行环境完整时不应重新下载任何 Ubuntu/AstrBot/QQ/NapCat 资源。
7. 验证插件、AstrBot 数据、NapCat/QQ 登录态、OneBot 和原 WebUI。
8. 全部正常后再恢复网络。

## 如果构建失败

优先记录完整 Gradle 错误，不要只截最后一行。常见排查：

- `SDK location not found`：在 Android Studio SDK Manager 配好 Android SDK，或创建本机 `local.properties`。
- `Android SDK Platform 37 not found`：安装 API 37。
- `Build Tools ... not found`：安装 Build-Tools 36.0.0。
- `Unsupported class file / Java`：Gradle JDK 切回 17。
- Gradle 版本错误：确认 wrapper 为 9.5.0。
- 首次 Sync 下载依赖失败：检查电脑网络/代理后重试；这不会影响手机现有 AstrBot 数据。

构建错误如果需要协助，保留：

```text
Android Studio 版本
JDK 版本
./gradlew --version
完整 Build Output
```
