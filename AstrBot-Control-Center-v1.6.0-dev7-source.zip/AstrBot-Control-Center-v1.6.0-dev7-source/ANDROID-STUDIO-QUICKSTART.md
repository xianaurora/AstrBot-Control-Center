# 用 Android Studio 编译并真机测试 dev2

这是当前开发版的推荐测试方式。先测试 APK 对现有 v1.5.6.5 的**检测**，确认界面显示正确后，再主动升级 核心组件。

## 1. 电脑准备

1. 安装当前 Android Studio。
2. 在 `Tools > SDK Manager` 安装 Android SDK Platform 37、Android SDK Build-Tools 36.0.0以及 Android SDK Platform-Tools。
3. 工程使用 JDK 17、Android Gradle Plugin 9.3.1、Gradle 9.5.0。Android Studio 的 Gradle JDK 请选择 17。

源码包当前只有 `gradle/wrapper/gradle-wrapper.properties`，没有 wrapper JAR。若 Android Studio 能直接同步，就让 IDE 下载/使用 Gradle 9.5.0；如果提示缺少 wrapper，先在电脑安装 Gradle 9.5.0，在项目根目录执行：

```text
gradle wrapper --gradle-version 9.5.0
```

之后会生成 `gradlew`、`gradlew.bat` 与 wrapper JAR。

## 2. 打开工程

解压源码 ZIP，Android Studio 选择 **Open**，打开包含 `settings.gradle.kts` 的 `AstrBot-Control-Center-v1.6.0-dev2-source` 根目录。等待 Gradle Sync 完成。

## 3. 编译 Debug APK

Android Studio 可以直接选择 `Build > Build APK(s)`。也可以在项目根目录执行：

Windows：

```text
gradlew.bat :app:assembleDebug
```

macOS / Linux：

```text
./gradlew :app:assembleDebug
```

生成文件：

```text
app/build/outputs/apk/debug/app-debug.apk
```

Debug APK 只用于测试，不用于正式发布。

## 4. 安装到你的真机

手机开启“开发者选项 > USB 调试”，连接电脑并在手机上允许调试授权。

```text
adb devices
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

也可以直接在 Android Studio 顶部选择你的手机并点击 Run/Debug，IDE 会编译并安装。

如果出现 `INSTALL_FAILED_UPDATE_INCOMPATIBLE`，通常是设备上存在同包名但签名不同的旧测试 APK。确认里面没有需要保留的 App 本地数据后，只卸载 Control Center APK 再装：

```text
adb uninstall com.xianaurora.astrbotcontrol
adb install app/build/outputs/apk/debug/app-debug.apk
```

这不会主动卸载独立的 核心组件，但仍应先确认你卸载的是 Control Center APK，而不是 Root 管理器 里的模块。

## 5. 第一次测试不要直接升级

先关闭 Wi-Fi 和移动数据，打开 APK，按 `TESTING-CHECKLIST.md` 的 A → B → C 顺序测试。

最重要的首轮观察：

- 第一次打开不应该联网、自动申请 Root 或自动刷模块。
- 点击开始后才申请 Root。
- 应识别当前 `v1.5.6.5`，显示 `v1.5.6.5 → v1.6.0-dev2`。
- 升级按钮在勾选“确认原地升级”前不可点击。
- 升级前必须成功创建 仅核心组件 回退点。
- Root 管理器 写入后必须提示重启；断网状态下重启不应下载任何 Ubuntu/AstrBot/QQ/NapCat 资源。
- 如果你原来的运行环境完整，dev2 验证后应直接复用，而不是重装环境。

## 6. 快速检查 核心组件

升级并重启以后可以在电脑执行：

```text
adb shell su -c 'cat /data/adb/modules/astrbot_standalone/module.prop'
adb shell su -c '/data/adb/modules/astrbot_standalone/astrctl app-protocol'
adb shell su -c '/data/adb/modules/astrbot_standalone/astrctl installer-status'
adb shell su -c '/data/adb/modules/astrbot_standalone/astrctl engine-rollback-status'
```

预期 核心组件 版本为 `1.6.0-dev2`、协议为 `1`，并能看到升级前回退点。

## 7. 出错时

不要先清空 `/data/adb/astrbot_standalone`。先截图 App 错误页并保留：

```text
/data/adb/astrbot_standalone/logs/action.log
/data/adb/astrbot_standalone/engine-backups/latest.conf
```

如果新 核心组件 重启验证失败且 App 显示“恢复原 核心组件”，优先从 App 回退。只有 App 无法使用时再执行 `TESTING-CHECKLIST.md` 里的高级回退命令。
