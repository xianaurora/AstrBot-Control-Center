package com.xianaurora.astrbotcontrol.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

data class ShellResult(
    val code: Int,
    val stdout: String,
    val stderr: String,
    val timedOut: Boolean = false
) {
    val ok: Boolean get() = code == 0 && !timedOut
}

class RootShell {
    suspend fun root(command: String, timeoutSeconds: Long = 30): ShellResult = withContext(Dispatchers.IO) {
        runProcess(listOf("su", "-c", command), timeoutSeconds)
    }

    suspend fun normal(command: String, timeoutSeconds: Long = 15): ShellResult = withContext(Dispatchers.IO) {
        runProcess(listOf("sh", "-c", command), timeoutSeconds)
    }

    private fun runProcess(args: List<String>, timeoutSeconds: Long): ShellResult {
        return try {
            val p = ProcessBuilder(args).redirectErrorStream(false).start()
            val outReader = BufferedReader(InputStreamReader(p.inputStream))
            val errReader = BufferedReader(InputStreamReader(p.errorStream))
            val out = StringBuilder()
            val err = StringBuilder()
            val outThread = Thread { outReader.useLines { lines -> lines.forEach { out.appendLine(it) } } }
            val errThread = Thread { errReader.useLines { lines -> lines.forEach { err.appendLine(it) } } }
            outThread.start(); errThread.start()
            val done = p.waitFor(timeoutSeconds, TimeUnit.SECONDS)
            if (!done) p.destroyForcibly()
            outThread.join(1500); errThread.join(1500)
            ShellResult(if (done) p.exitValue() else -1, out.toString().trimEnd(), err.toString().trimEnd(), !done)
        } catch (t: Throwable) {
            ShellResult(-1, "", t.message ?: t::class.java.simpleName)
        }
    }

    companion object {
        fun q(value: String): String = "'" + value.replace("'", "'\\''") + "'"
    }
}
