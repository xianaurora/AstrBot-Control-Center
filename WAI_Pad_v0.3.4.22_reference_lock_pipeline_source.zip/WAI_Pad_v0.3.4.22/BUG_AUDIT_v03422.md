# v0.3.4.22 Bug Audit

目标缺陷：
- A 图整体送入 IPAdapter 导致背景/饰品/附加元素污染。
- `crop_position=top` 裁脸不稳定，容易把头发/肩膀/背景一起带入脸参考。
- 人物+动作模式里 B 图的 Depth 仍可能改变人物身材比例。
- 成图出现明显大头/矮胖漂移时，没有自动拦截与重试。

修复措施：
- 新增 `reference_lock.py` 做主体裁切、背景去污染、单独脸裁切。
- `ref_wf` / `person_pose_wf` 改为显式全图+脸图双参考输入。
- `baseline_lock` 下将 Depth 降为 0，仅保留 OpenPose 主导动作。
- 成图后做轻量比例验收，失败自动换 seed 再试 1 次。
