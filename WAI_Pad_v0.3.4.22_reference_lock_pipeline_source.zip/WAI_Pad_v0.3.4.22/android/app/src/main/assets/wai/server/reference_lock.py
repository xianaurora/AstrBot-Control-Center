#!/usr/bin/env python3
"""Reference preprocessing / lightweight proportion audit for WAI Pad.

Goals:
- decontaminate flat-background anime reference images before IP-Adapter sees them
- provide a deterministic face crop instead of `crop_position=top`
- derive a lightweight baseline profile (head/body ratios)
- optionally audit generated outputs and request a retry when they drift badly

This intentionally uses only cv2/numpy, which are already available in the server
runtime, and falls back gracefully when analysis is uncertain.
"""
from __future__ import annotations

import base64
import json
import uuid
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Dict, Optional, Tuple

import cv2
import numpy as np
from PIL import Image


@dataclass
class PrepResult:
    full_dataurl: str
    face_dataurl: str
    profile: Dict


def _decode_dataurl(dataurl: str) -> Tuple[np.ndarray, str]:
    head, b64 = dataurl.split(',', 1)
    mime = head.split(';')[0].split(':', 1)[-1] if ':' in head else 'image/png'
    raw = base64.b64decode(b64)
    arr = np.frombuffer(raw, np.uint8)
    bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if bgr is None:
        raise ValueError('invalid image data')
    return bgr, mime


def _encode_png_dataurl(bgr: np.ndarray) -> str:
    ok, buf = cv2.imencode('.png', bgr)
    if not ok:
        raise RuntimeError('png encode failed')
    return 'data:image/png;base64,' + base64.b64encode(buf.tobytes()).decode('ascii')


def _border_color(bgr: np.ndarray) -> np.ndarray:
    h, w = bgr.shape[:2]
    margin = max(2, min(h, w) // 32)
    strips = [
        bgr[:margin, :, :],
        bgr[-margin:, :, :],
        bgr[:, :margin, :],
        bgr[:, -margin:, :],
    ]
    px = np.concatenate([s.reshape(-1, 3) for s in strips], axis=0)
    return np.median(px, axis=0).astype(np.uint8)


def _largest_component(mask: np.ndarray) -> np.ndarray:
    num, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    if num <= 1:
        return mask
    areas = stats[1:, cv2.CC_STAT_AREA]
    idx = 1 + int(np.argmax(areas))
    out = np.zeros_like(mask)
    out[labels == idx] = 255
    return out


def _foreground_mask(bgr: np.ndarray) -> np.ndarray:
    h, w = bgr.shape[:2]
    bg = _border_color(bgr).astype(np.int16)
    diff = np.mean(np.abs(bgr.astype(np.int16) - bg[None, None, :]), axis=2).astype(np.uint8)
    # Plain backgrounds are common; keep threshold low to preserve soft outlines.
    thr = int(max(12, min(42, np.percentile(diff, 84))))
    _, mask = cv2.threshold(diff, thr, 255, cv2.THRESH_BINARY)
    # If the whole image is nearly flat, fall back to edge-assisted Otsu.
    fill = float(mask.mean() / 255.0)
    if fill < 0.04 or fill > 0.90:
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        _, mask = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        # choose the polarity with the smaller border activation
        border = np.zeros_like(mask)
        margin = max(2, min(h, w) // 32)
        border[:margin, :] = 255; border[-margin:, :] = 255
        border[:, :margin] = 255; border[:, -margin:] = 255
        inv = cv2.bitwise_not(mask)
        if cv2.bitwise_and(mask, border).mean() > cv2.bitwise_and(inv, border).mean():
            mask = inv
    k = max(3, (min(h, w) // 180) | 1)
    kernel = np.ones((k, k), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = _largest_component(mask)
    # fill holes
    flood = mask.copy()
    ffmask = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(flood, ffmask, (0, 0), 255)
    holes = cv2.bitwise_not(flood)
    mask = cv2.bitwise_or(mask, holes)
    return _largest_component(mask)


def _bbox_from_mask(mask: np.ndarray) -> Tuple[int, int, int, int]:
    pts = cv2.findNonZero(mask)
    if pts is None:
        h, w = mask.shape[:2]
        return 0, 0, w, h
    x, y, w, h = cv2.boundingRect(pts)
    return int(x), int(y), int(w), int(h)


def _expand_box(box, img_w, img_h, sx=0.08, sy=None):
    if sy is None:
        sy = sx
    x, y, w, h = box
    px = int(round(w * sx))
    py = int(round(h * sy))
    x0 = max(0, x - px)
    y0 = max(0, y - py)
    x1 = min(img_w, x + w + px)
    y1 = min(img_h, y + h + py)
    return x0, y0, x1 - x0, y1 - y0


def _estimate_head_box(mask: np.ndarray, body_box: Tuple[int, int, int, int]) -> Tuple[int, int, int, int]:
    x, y, w, h = body_box
    h_img, w_img = mask.shape[:2]
    upper_h = max(1, int(h * 0.45))
    upper = (mask[y:y + upper_h, x:x + w] > 0).astype(np.uint8)
    widths = upper.sum(axis=1).astype(np.float32)
    nz = np.where(widths > 0)[0]
    if len(nz) < 8:
        side = int(max(32, min(w, h) * 0.28))
        cx = x + w // 2
        cy = y + int(h * 0.16)
        return _clamp_square(cx, cy, side, w_img, h_img)
    # smooth row widths and detect first strong shoulder widening
    sm = cv2.GaussianBlur(widths.reshape(-1, 1), (1, 9), 0).reshape(-1)
    anchor_end = max(nz[0] + 4, min(len(sm) - 1, int(h * 0.10)))
    baseline = float(np.median(sm[nz[0]:anchor_end + 1])) if anchor_end > nz[0] else float(np.median(sm[nz[:5]]))
    shoulder_idx = None
    for i in range(max(nz[0] + 6, int(h * 0.08)), min(len(sm), int(h * 0.36))):
        if sm[i] > max(baseline * 1.32, baseline + 18):
            shoulder_idx = i
            break
    if shoulder_idx is None:
        head_h = int(np.clip(h * 0.27, h * 0.22, h * 0.34))
    else:
        head_h = int(np.clip(shoulder_idx + 6, h * 0.20, h * 0.34))
    top = upper[:head_h, :]
    col = top.sum(axis=0).astype(np.float32)
    col_sm = cv2.GaussianBlur(col.reshape(1, -1), (9, 1), 0).reshape(-1)
    thr = col_sm.max() * 0.18 if col_sm.max() > 0 else 0
    xs = np.where(col_sm > thr)[0]
    if len(xs):
        x0 = x + int(xs[0]); x1 = x + int(xs[-1])
        head_w = x1 - x0 + 1
        cx = (x0 + x1) / 2.0
    else:
        head_w = int(w * 0.50)
        cx = x + w / 2.0
    cy = y + head_h * 0.55
    side = int(max(head_h * 1.45, head_w * 1.12))
    side = int(np.clip(side, h * 0.18, h * 0.36))
    return _clamp_square(cx, cy, side, w_img, h_img)


def _clamp_square(cx, cy, side, img_w, img_h):
    side = int(max(24, side))
    x0 = int(round(cx - side / 2))
    y0 = int(round(cy - side / 2))
    x0 = max(0, min(x0, img_w - side))
    y0 = max(0, min(y0, img_h - side))
    side = min(side, img_w, img_h)
    return int(x0), int(y0), int(side), int(side)


def _crop(img: np.ndarray, box: Tuple[int, int, int, int]) -> np.ndarray:
    x, y, w, h = box
    return img[y:y + h, x:x + w].copy()


def _cleaned_crop(bgr: np.ndarray, mask: np.ndarray, box: Tuple[int, int, int, int]) -> np.ndarray:
    x, y, w, h = box
    crop = _crop(bgr, box)
    crop_mask = mask[y:y + h, x:x + w]
    bg = _border_color(bgr)
    out = np.full_like(crop, bg)
    out[crop_mask > 0] = crop[crop_mask > 0]
    return out


def _profile_from(mask: np.ndarray, body_box, head_box, image_shape) -> Dict:
    x, y, w, h = body_box
    hx, hy, hw, hh = head_box
    ih, iw = image_shape[:2]
    return {
        'body_box': [int(x), int(y), int(w), int(h)],
        'head_box': [int(hx), int(hy), int(hw), int(hh)],
        'image_size': [int(iw), int(ih)],
        'body_aspect': round(float(h / max(w, 1)), 4),
        'head_h_ratio': round(float(hh / max(h, 1)), 4),
        'head_w_ratio': round(float(hw / max(w, 1)), 4),
        'head_center_x': round(float((hx + hw / 2 - x) / max(w, 1)), 4),
        'subject_fill': round(float((mask > 0).mean()), 4),
    }


def prepare_reference(dataurl: str) -> Dict:
    bgr, _ = _decode_dataurl(dataurl)
    mask = _foreground_mask(bgr)
    body_box = _expand_box(_bbox_from_mask(mask), bgr.shape[1], bgr.shape[0], 0.08, 0.06)
    body_mask = _crop(mask, body_box)
    head_box = _estimate_head_box(mask, body_box)
    face_box = _expand_box(head_box, bgr.shape[1], bgr.shape[0], 0.06, 0.06)
    cleaned_full = _crop(bgr, body_box)
    cleaned_face = _crop(bgr, face_box)
    profile = _profile_from(mask, body_box, head_box, bgr.shape)
    return {
        'full_dataurl': _encode_png_dataurl(cleaned_full),
        'face_dataurl': _encode_png_dataurl(cleaned_face),
        'profile': profile,
    }


def audit_output_against_profile(image_dataurl: str, profile: Optional[Dict]) -> Dict:
    if not profile:
        return {'pass': True, 'reasons': [], 'metrics': {}}
    try:
        bgr, _ = _decode_dataurl(image_dataurl)
        mask = _foreground_mask(bgr)
        body_box = _bbox_from_mask(mask)
        head_box = _estimate_head_box(mask, body_box)
        current = _profile_from(mask, body_box, head_box, bgr.shape)
        reasons = []
        metrics = {
            'head_h_ratio': current['head_h_ratio'],
            'head_w_ratio': current['head_w_ratio'],
            'body_aspect': current['body_aspect'],
        }
        ref_h = float(profile.get('head_h_ratio', 0.0) or 0.0)
        ref_w = float(profile.get('head_w_ratio', 0.0) or 0.0)
        ref_aspect = float(profile.get('body_aspect', 0.0) or 0.0)
        # Big head / chibi guard. Allow pose variation but catch the severe cases.
        if ref_h and current['head_h_ratio'] > max(ref_h * 1.28, ref_h + 0.05):
            reasons.append('head too large vs baseline')
        if ref_w and current['head_w_ratio'] > max(ref_w * 1.30, ref_w + 0.08):
            reasons.append('head too wide vs baseline')
        if ref_aspect and current['body_aspect'] < ref_aspect * 0.83:
            reasons.append('body too squat vs baseline')
        return {'pass': not reasons, 'reasons': reasons, 'metrics': metrics, 'profile_current': current}
    except Exception as e:
        return {'pass': True, 'reasons': [f'audit skipped: {e}'], 'metrics': {}}
