#!/usr/bin/env python3
import base64, hashlib, json, os, re, shutil, subprocess, time, uuid, threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib import request, parse, error

import reference_lock

APP_CANDIDATES = [Path('/root/WAI_v31'), Path('/root/WAI_v3'), Path('/root/WAI_v34_fullfix')]
APP = next((p for p in APP_CANDIDATES if (p / 'config.json').exists()), Path('/root/WAI_v31'))
CTL = next((p / 'WAI_ctl.sh' for p in APP_CANDIDATES if (p / 'WAI_ctl.sh').exists()), APP / 'WAI_ctl.sh')
BACKUP = next((x for p in APP_CANDIDATES for x in p.glob('加密增量备份*.sh') if x.exists()), None)
LEGACY_PIDS = set()
LEGACY_PIDS_LOCK = threading.Lock()
CFG = json.loads((APP / 'config.json').read_text('utf-8'))
RUNTIME = Path('/root/autodl-tmp/WAI_App_v33')
RUNTIME.mkdir(parents=True, exist_ok=True)
LOG = RUNTIME / 'panel.log'
HISTORY = RUNTIME / 'history.jsonl'
PANEL_PORT = int(os.environ.get('WAI_PANEL_PORT', CFG.get('panel_port', 6017)))
COMFY = f"http://127.0.0.1:{CFG.get('comfy_port', 6006)}"
QWEN_MODELS = f"http://127.0.0.1:{CFG.get('qwen_port', 8011)}/v1/models"
QWEN_CHAT = f"http://127.0.0.1:{CFG.get('qwen_port', 8011)}/v1/chat/completions"
MODEL = CFG.get('default_model', 'waiIllustriousSDXL_v170.safetensors')
OPENPOSE_NAME = CFG.get('openpose_controlnet', 'xinsir_openpose_sdxl_1.0.safetensors')
QUALITY = CFG.get('prompt', {}).get('quality_prefix', 'masterpiece, best quality, amazing quality')
BASE_NEG = 'worst quality, low quality, lowres, blurry, jpeg artifacts, bad anatomy, malformed hands, extra fingers, missing fingers, extra limbs, missing limbs, deformed, disfigured, text, watermark, logo'
GEN_LOCK = threading.Lock()
STYLE_LORA = 'lin53soft_style.safetensors'
STYLE_LORA_V2 = 'lin53soft_style_v2.safetensors'
STYLE_LORA_V3 = 'lin53soft_style_v3.safetensors'
STYLE_TRIGGER = 'lin53soft'
STYLE_WEIGHTS_CLEAN = {'txt':0.90,'img':0.90,'ref':0.90,'person_pose':0.90}
STYLE_WEIGHTS_LEGACY = {'txt':0.72,'img':0.72,'ref':0.72,'person_pose':0.72}
# Explicit body-exposure requests are a calibration path for the fixed style LoRA.
# Keep UNet styling slightly stronger than CLIP semantics so rendering stays stable
# without forcing a separate body archetype.
BODY_EXPOSURE_MODEL_SCALE = 1.06
BODY_EXPOSURE_CLIP_SCALE = 0.92
COMPOSITION_IP = 'ip_plus_composition_sdxl.safetensors'
CLIP_VISION_H = 'CLIP-ViT-H-14-laion2B-s32B-b79K.safetensors'
DEPTH_CONTROLNET = 'xinsir_depth_sdxl_1.0.safetensors'
DEPTH_CKPT = 'depth_anything_v2_vitb.pth'
ANTI_LEAK = 'halo, angel halo, aureole, glowing halo, double hair bun, twin buns, symmetrical hair buns, space buns'

ZH = {
    '保持同一个人物': 'same character, consistent facial features',
    '女孩': '1girl', '女生': '1girl', '男孩': '1boy', '男生': '1boy',
    '单人': 'solo', '全身': 'full body', '半身': 'upper body',
    '猫耳帽': 'cat-ear hat', '猫耳': 'cat ears', '眼镜': 'glasses',
    '白底': 'off-white background', '简洁背景': 'simple background',
    '站着': 'standing', '坐着': 'sitting', '长发': 'long hair',
    '银发': 'silver hair', '黑发': 'black hair', '白发': 'white hair', '蓝色头发': 'blue hair',
    '可爱': 'cute', '呆萌': 'adorable expression', '温柔': 'gentle expression',
    '窗边': 'by the window', '咖啡店': 'cafe', '花田': 'flower field', '夜晚': 'night',
    '电影感': 'cinematic composition', '柔和灯光': 'soft lighting', '暖色灯光': 'warm lighting'
}


def log(msg):
    try:
        with open(LOG, 'a', encoding='utf-8') as f:
            f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}\n")
    except Exception:
        pass


def jreq(url, method='GET', data=None, timeout=15, headers=None):
    body = None
    hdr = {'Content-Type': 'application/json'}
    hdr.update(headers or {})
    if data is not None:
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
    req = request.Request(url, data=body, method=method, headers=hdr)
    try:
        with request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode('utf-8'))
    except error.HTTPError as e:
        try:
            detail = e.read().decode('utf-8', 'replace')
        except Exception:
            detail = str(e)
        raise RuntimeError(f'HTTP {e.code}: {detail[-1800:]}')


def raw(url, method='GET', data=None, timeout=30, headers=None):
    req = request.Request(url, data=data, method=method, headers=headers or {})
    with request.urlopen(req, timeout=timeout) as r:
        return r.read(), r.headers.get('Content-Type', 'application/octet-stream'), r.status


def ok(url, timeout=2):
    try:
        raw(url, timeout=timeout)
        return True
    except Exception:
        return False


def objinfo():
    try:
        return jreq(COMFY + '/object_info', timeout=5)
    except Exception:
        return {}


def qwen_model():
    try:
        d = jreq(QWEN_MODELS, timeout=3)
        if d.get('data'):
            return d['data'][0].get('id') or 'local'
    except Exception:
        pass
    return None


def gpu():
    try:
        p = subprocess.run(['nvidia-smi', '-L'], capture_output=True, text=True, timeout=3)
        if p.returncode == 0 and p.stdout.strip():
            return True, p.stdout.strip().splitlines()[0]
    except Exception:
        pass
    return False, '无 GPU'


def mem():
    total = avail = 0
    try:
        for line in Path('/proc/meminfo').read_text().splitlines():
            if line.startswith('MemTotal:'):
                total = int(line.split()[1]) // 1024
            elif line.startswith('MemAvailable:'):
                avail = int(line.split()[1]) // 1024
    except Exception:
        pass
    return total, avail


def disk():
    u = shutil.disk_usage('/root/autodl-tmp')
    return round(u.free / 1024**3, 1), round(u.total / 1024**3, 1)


def nodes_ready(*names):
    o = objinfo()
    return all(n in o for n in names)


def model_file(name, folder):
    for p in [Path('/root/ComfyUI/models') / folder / name, Path('/root/autodl-tmp/AI_Models') / folder / name]:
        if p.exists() and p.stat().st_size > 1024 * 1024:
            return True
    return False


def ip_models_ready():
    names = ['ip-adapter_sdxl_vit-h.safetensors', 'ip-adapter-plus-face_sdxl_vit-h.safetensors']
    return all(model_file(n, 'ipadapter') for n in names)


def active_style_lora():
    for name in (STYLE_LORA_V3, STYLE_LORA_V2, STYLE_LORA):
        if model_file(name, 'loras'):
            return name
    return STYLE_LORA


def style_lora_ready():
    return model_file(active_style_lora(), 'loras')


def style_v2_ready():
    return model_file(STYLE_LORA_V2, 'loras') or model_file(STYLE_LORA_V3, 'loras')


def style_v3_ready():
    return model_file(STYLE_LORA_V3, 'loras')


def composition_ready():
    return model_file(COMPOSITION_IP, 'ipadapter')


def depth_ready():
    return model_file(DEPTH_CONTROLNET, 'controlnet')


def split_tags(text):
    if not text:
        return []
    parts=[]
    for x in re.split(r'[,，;；\n]+', str(text)):
        x=re.sub(r'\s+', ' ', x.strip())
        if x:
            parts.append(x)
    return parts


def dedup_tags(tags):
    out=[]; seen=set()
    for t in tags:
        key=t.strip().lower()
        if key and key not in seen:
            seen.add(key); out.append(t.strip())
    return out


def explicit_positive(pos, *terms):
    low=(pos or '').lower()
    return any(t.lower() in low for t in terms)


def _low_text(text):
    return str(text or '').lower()


def _contains_any(text, terms):
    low = _low_text(text)
    return any(term in low for term in terms)


def _requested(text, include, exclude=()):
    low = _low_text(text)
    if any(term in low for term in exclude):
        return False
    return any(term in low for term in include)


def prompt_requests_body_exposure(text):
    """Detect explicit body-exposure intent without adding age or clothing semantics."""
    return _requested(text,
        ['fully nude','full nude','nude','naked','unclothed','bare body','bare torso','topless','bottomless',
         'semi-nude','semi nude','half-nude','half nude','裸体','裸身','全裸','半裸','赤裸','无衣服','没穿衣服'],
        ['not nude','no nude','no nudity','without nudity','fully clothed','不要裸体','不要裸','不裸','禁止裸露'])


def body_exposure_positive_anchors(raw_text):
    """Neutral skin/body-rendering anchors used only for explicit exposure requests.

    Deliberately avoids age-coded words, chibi/short-leg archetypes, and clothing.
    """
    if not prompt_requests_body_exposure(raw_text):
        return []
    return [
        '(warm natural skin tone:1.10)',
        '(soft peach skin undertone:1.08)',
        '(soft low-contrast skin shading:1.10)',
        '(smooth soft body contours:1.08)',
        '(gentle natural fleshiness:1.06)',
        '(moderate soft-tissue volume:1.06)',
        '(balanced torso-to-limb proportions:1.06)',
        '(subtle waist and hip contour:1.05)',
        '(smooth softly contoured thighs:1.06)',
        '(smooth softly contoured calves:1.05)',
        '(subtle knees:1.05)'
    ]


def body_exposure_negative_tags(raw_text):
    if not prompt_requests_body_exposure(raw_text):
        return []
    return [
        'washed-out skin','chalk-white skin','grayish skin','overexposed skin','harsh skin highlights',
        'emaciated','bony body','stick limbs','overly thin limbs','sharp joints',
        'puffy body','swollen limbs','stocky body','wide hips','thick thighs','thick calves','heavy lower body',
        'chibi','super deformed','huge head','tiny body','extremely short limbs',
        'white liquid','body fluids','dripping fluid','goo','slime'
    ]


def apply_body_exposure_stabilizer(pos, neg, raw_text):
    anchors = body_exposure_positive_anchors(raw_text)
    if not anchors:
        return pos, neg
    low = _low_text(pos)
    add = [x for x in anchors if x.lower() not in low]
    if add:
        pos = ', '.join(add + [pos])
    neg = ', '.join(dedup_tags(split_tags(neg) + body_exposure_negative_tags(raw_text)))
    return pos, neg


def prompt_requests_outfit_override(text):
    """True when the user explicitly changes/adds/removes clothing or visible accessories."""
    return _contains_any(text, [
        'change outfit','change clothes','different outfit','new outfit','replace outfit','replace clothes',
        'remove jacket','remove coat','remove hoodie','remove shirt','remove top','remove skirt','remove pants','remove shorts','remove sleeves',
        'without jacket','without coat','without shirt','without top','without skirt','without pants','without shorts',
        'off shoulder','off-shoulder','bare shoulders','bare shoulder','strapless','sleeveless','crop top','midriff','bare midriff',
        'exposed waist','exposed belly','open jacket','open shirt','open chest','bare chest','exposed skin','bare skin',
        'semi-nude','semi nude','half-nude','half nude','topless','bottomless','nude','naked','underwear only',
        'white thighhighs','white thigh highs','white stockings','white pantyhose','white tights','thighhighs','stockings','pantyhose',
        'cat paw gloves','paw gloves','cat paw mittens','paw mittens','cat paws',
        '换装','换衣服','脱掉','去掉外套','去掉上衣','露肩','露腰','露腿','半裸','裸','裸体','白丝','丝袜','连裤袜','猫爪','手套'
    ])


def requested_detail_anchors(raw_text):
    anchors = []
    if _requested(raw_text,
        ['white thighhighs','white thigh highs','white stockings','white overknees','white over-knees','白丝','白色丝袜','白色过膝袜','白色长筒袜'],
        ['remove white thighhighs','remove white thigh highs','remove white stockings','without white thighhighs','without white stockings','no white thighhighs','no white stockings','不要白丝','去掉白丝','移除白丝']):
        anchors += ['(white thighhighs:1.35)', 'white stockings']
    if _requested(raw_text,
        ['white pantyhose','white tights','white panty hose','白色连裤袜','白连裤袜','白裤袜'],
        ['remove white pantyhose','remove white tights','without white pantyhose','without white tights','no white pantyhose','no white tights','不要连裤袜','去掉连裤袜']):
        anchors += ['(white pantyhose:1.35)', 'white tights']
    if _requested(raw_text,
        ['cat paw gloves','paw gloves','cat paw mittens','paw mittens','cat paws','猫爪手套','猫爪'],
        ['remove cat paw gloves','remove paw gloves','without cat paw gloves','without paw gloves','no cat paw gloves','no paw gloves','不要猫爪','去掉猫爪','不要手套','去掉手套']):
        anchors += ['(cat paw gloves:1.35)', 'paw-shaped gloves']
    return anchors


def apply_requested_detail_anchors(pos, raw_text):
    anchors = requested_detail_anchors(raw_text)
    if not anchors:
        return pos
    low = _low_text(pos)
    out = []
    for a in anchors:
        # Weighted anchors are intentionally retained even when the unweighted term already exists.
        if a.lower() not in low:
            out.append(a)
    if not out:
        return pos
    return ', '.join(out + [pos])


def append_reference_requirements(pos, raw_text, mode):
    if mode not in ('ref', 'person_pose'):
        return pos
    # SDXL reads comma-separated text as visual concepts, not as instructions.  Phrases like
    # "preserve key hairstyle details" can literally summon keys/keyrings.  Keep these as
    # short visual identity tags and never use ambiguous instruction words such as "key".
    req = [
        'same character identity',
        'same facial identity',
        'same eye color',
        'same hair color',
        'same hairstyle',
        'same bangs',
        'same visible hair accessories',
    ]
    if not prompt_requests_outfit_override(raw_text):
        req.append('same outfit')
    if mode == 'person_pose':
        req += ['pose from reference', 'matching limb placement', 'matching camera angle', 'matching framing']
    low = _low_text(pos)
    for item in req:
        if item.lower() not in low:
            pos += ', ' + item
            low += ', ' + item.lower()
    return pos


def stabilize_explicit_requests(pos, raw_text, mode):
    pos = append_reference_requirements(pos, raw_text, mode)
    pos = apply_requested_detail_anchors(pos, raw_text)
    return pos


def style_strength(mode):
    table = STYLE_WEIGHTS_CLEAN if style_v2_ready() else STYLE_WEIGHTS_LEGACY
    return float(table.get(mode, table['txt']))


def style_strength_pair(mode, body_exposure=False):
    base = style_strength(mode)
    if not body_exposure or not style_v2_ready():
        return base, base
    return min(1.20, base * BODY_EXPOSURE_MODEL_SCALE), max(0.55, base * BODY_EXPOSURE_CLIP_SCALE)


def reference_artifact_negative_tags(raw_text, pos):
    """Suppress recurrent reference-mode inventions without blocking explicit user requests."""
    requested = _low_text(raw_text) + ', ' + _low_text(pos)
    groups = [
        (['key','keys','keyring','key ring','keychain','key chain','lock','padlock'],
         ['key','keys','keyring','key chain','padlock','lock prop']),
        (['speech bubble','thought bubble','comic bubble','dialog bubble'],
         ['speech bubble','thought bubble','comic bubble','dialog bubble']),
        (['silhouette','shadow figure','shadow person','background person','extra person','second character'],
         ['character silhouette','shadow figure','shadow person','background person','extra person','second character','duplicate character']),
        (['character sheet','reference sheet','turnaround','lineup','comparison chart'],
         ['character sheet','reference sheet','turnaround','lineup','comparison chart','inset figure']),
        (['flower hair ornament','flower hairclip','hair flower','hair bun','side bun','double bun','twin bun','space bun'],
         ['flower hair ornament','hair flower','hair bun','side bun','double hair bun','twin buns','space buns']),
        (['earring','earrings','necklace','bracelet','key necklace','pendant'],
         ['earrings','necklace','bracelet','pendant']),
    ]
    out=[]
    for triggers, negatives in groups:
        if not any(t in requested for t in triggers):
            out += negatives
    return out


def build_negative(user_neg, pos, mode, raw_text=''):
    tags=[]
    tags += split_tags(user_neg)
    tags += split_tags(BASE_NEG)
    if mode == 'ref':
        tags += ['inconsistent character', 'wrong facial features', 'wrong hairstyle', 'wrong hair color']
        tags += reference_artifact_negative_tags(raw_text, pos)
    elif mode == 'person_pose':
        tags += ['wrong pose', 'incorrect limb placement', 'bad perspective', 'broken foreshortening', 'wrong facial features', 'wrong hairstyle']
        tags += reference_artifact_negative_tags(raw_text, pos)
    # These are known style-LoRA leak modes and should be blocked on every LoRA revision
    # unless the user explicitly asks for them.
    if not explicit_positive(pos, 'halo', 'aureole'):
        tags += ['halo','angel halo','aureole','glowing halo']
    if not explicit_positive(pos, 'double hair bun','twin buns','space buns','two buns','hair bun'):
        tags += ['double hair bun','twin buns','symmetrical hair buns','space buns']
    return ', '.join(dedup_tags(tags))


def append_global_style(pos, user_neg, mode='txt', raw_text=''):
    pos = f"{STYLE_TRIGGER}, {pos}".strip(' ,')
    return pos, build_negative(user_neg, pos, mode, raw_text)


def light_prompt(text, neg, mode):
    x = (text or '').strip()
    for k in sorted(ZH, key=len, reverse=True):
        x = x.replace(k, ', ' + ZH[k] + ', ')
    x = re.sub(r'[，。；、\n]+', ', ', x)
    x = re.sub(r'\s*,\s*', ', ', x)
    x = re.sub(r',\s*,+', ', ', x).strip(' ,')
    x = stabilize_explicit_requests(x, text, mode)
    pos = f"{QUALITY}, {x}".strip(' ,')
    pos, ng = append_global_style(pos, neg, mode, text)
    pos, ng = apply_body_exposure_stabilizer(pos, ng, text)
    return pos, ng, '中文轻量模式（不过 Qwen）'


def prompt_prepare(text, neg, mode, prompt_mode):
    if prompt_mode == 'english':
        pos = (text or '').strip()
        pos = stabilize_explicit_requests(pos, text, mode)
        pos, ng = append_global_style(pos, neg, mode, text)
        pos, ng = apply_body_exposure_stabilizer(pos, ng, text)
        return pos, ng, '英文直输：未经过 Qwen；负面提示词由稳定规则管理'
    if prompt_mode == 'light':
        return light_prompt(text, neg, mode)
    mid = qwen_model()
    if not mid:
        p, n, _ = light_prompt(text, neg, mode)
        return p, n, 'Qwen 暂不可用，已回退到中文轻量模式'
    sys = (
        'You format POSITIVE prompts for WAI-Illustrious-SDXL. Convert the user request to concise comma-separated English image tags. '
        'Output exactly one line beginning with POSITIVE:. Never output a negative prompt. '
        'Do not invent or change the art style; a fixed style LoRA is applied separately. Do not add style adjectives unless explicitly requested. '
        'Preserve explicit character appearance, clothing, action, scene, camera and lighting. '
        'Never invent props, keys, locks, jewelry, hair ornaments, flowers, speech bubbles, symbols, extra people, silhouettes, character sheets, or background figures unless explicitly requested. '
        'For reference mode preserve character identity, hair color and hairstyle. If the user changes, adds, or removes clothing/accessories, do not restore the reference outfit. '
        'For person+pose mode follow the pose reference exactly, including limb placement, camera angle, framing and foreshortening. Do not explain.'
    )
    payload = {
        'model': mid,
        'messages': [
            {'role': 'system', 'content': sys},
            {'role': 'user', 'content': f"mode={mode}\nrequest={text}"}
        ],
        'temperature': 0.08,
        'max_tokens': 160
    }
    for i in range(2):
        try:
            d = jreq(QWEN_CHAT, 'POST', payload, 90)
            out = d['choices'][0]['message']['content']
            pos = ''
            for line in out.splitlines():
                if line.upper().startswith('POSITIVE:'):
                    pos = line.split(':', 1)[1].strip(); break
            if not pos:
                pos = out.strip().replace('POSITIVE:', '').strip()
            if pos:
                pos = stabilize_explicit_requests(pos, text, mode)
                pos, ng = append_global_style(pos, neg, mode, text)
                pos, ng = apply_body_exposure_stabilizer(pos, ng, text)
                return pos, ng, '中文智能：已经过本地 Qwen；Qwen 不再改写负面提示词'
        except Exception as e:
            log(f'qwen fail attempt {i+1}: {e}')
            time.sleep(1)
    p, n, _ = light_prompt(text, neg, mode)
    return p, n, 'Qwen 调用失败，已回退到中文轻量模式'


def upload_dataurl(dataurl):
    head, b64 = dataurl.split(',', 1)
    data = base64.b64decode(b64)
    ext = 'webp' if 'webp' in head else ('jpg' if ('jpeg' in head or 'jpg' in head) else 'png')
    name = f"wai32_{uuid.uuid4().hex[:12]}.{ext}"
    boundary = '----wai32' + uuid.uuid4().hex
    body = (
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"image\"; filename=\"{name}\"\r\n"
        f"Content-Type: application/octet-stream\r\n\r\n"
    ).encode() + data + f"\r\n--{boundary}--\r\n".encode()
    r, _, _ = raw(COMFY + '/upload/image', 'POST', body, 120, {'Content-Type': f'multipart/form-data; boundary={boundary}'})
    return json.loads(r.decode('utf-8'))['name']


def queue(wf):
    pid=jreq(COMFY + '/prompt', 'POST', {'prompt': wf, 'client_id': str(uuid.uuid4())}, 30)['prompt_id']
    with LEGACY_PIDS_LOCK: LEGACY_PIDS.add(str(pid))
    return pid


def _prompt_id(rec):
    if isinstance(rec,(list,tuple)) and len(rec)>1: return str(rec[1])
    if isinstance(rec,dict) and rec.get('prompt_id'): return str(rec['prompt_id'])
    return None


def cancel_legacy_prompt(pid):
    """Cancel only a prompt created by this companion; prefer Comfy's atomic job cancel API."""
    if not pid: return 'missing'
    pid=str(pid)
    with LEGACY_PIDS_LOCK:
        if pid not in LEGACY_PIDS: return 'not_owned'
    try:
        try:
            out=jreq(COMFY + f'/api/jobs/{parse.quote(pid, safe="")}/cancel','POST',{},8)
            with LEGACY_PIDS_LOCK: LEGACY_PIDS.discard(pid)
            return 'cancelled' if out.get('cancelled') else 'finished_or_missing'
        except Exception as e:
            log(f'legacy atomic cancel unavailable {pid}: {e}')
        q=jreq(COMFY + '/queue',timeout=10)
        pending={_prompt_id(x) for x in (q.get('queue_pending') or [])}
        running={_prompt_id(x) for x in (q.get('queue_running') or [])}
        if pid in pending:
            jreq(COMFY + '/queue','POST',{'delete':[pid]},10)
            q=jreq(COMFY + '/queue',timeout=6)
            running={_prompt_id(x) for x in (q.get('queue_running') or [])}
            if pid not in running:
                with LEGACY_PIDS_LOCK: LEGACY_PIDS.discard(pid)
                return 'dequeued'
        if pid in running:
            q=jreq(COMFY + '/queue',timeout=6)
            if pid not in {_prompt_id(x) for x in (q.get('queue_running') or [])}: return 'finished_or_moved'
            raw(COMFY + '/interrupt','POST',b'',5)
            with LEGACY_PIDS_LOCK: LEGACY_PIDS.discard(pid)
            return 'interrupted_legacy'
        with LEGACY_PIDS_LOCK: LEGACY_PIDS.discard(pid)
        return 'not_found'
    except Exception as e:
        log(f'legacy targeted cancel {pid}: {e}'); return 'unknown'


def extract_error(h):
    status = h.get('status', {}) if isinstance(h, dict) else {}
    for msg in status.get('messages', []) or []:
        try:
            typ, data = msg[0], msg[1]
            if typ == 'execution_error':
                em = data.get('exception_message') or data.get('exception_type') or 'ComfyUI execution error'
                node = data.get('node_type') or data.get('node_id') or ''
                return f'{node}: {em}'.strip(': ')
            if typ == 'execution_interrupted':
                return '任务已取消'
        except Exception:
            pass
    if status.get('status_str') == 'error':
        return 'ComfyUI 执行失败，请看日志'
    return None


def wait_image(pid, timeout=600):
    t = time.time()
    while time.time() - t < timeout:
        h = jreq(COMFY + f'/history/{pid}', timeout=15).get(pid)
        if h:
            err = extract_error(h)
            if err:
                raise RuntimeError(err)
            for out in h.get('outputs', {}).values():
                if out.get('images'):
                    m = out['images'][0]
                    qs = parse.urlencode({'filename': m['filename'], 'subfolder': m.get('subfolder', ''), 'type': m.get('type', 'output')})
                    b, ctype, _ = raw(COMFY + '/view?' + qs, timeout=120)
                    with LEGACY_PIDS_LOCK: LEGACY_PIDS.discard(str(pid))
                    return 'data:' + ctype + ';base64,' + base64.b64encode(b).decode(), m['filename']
            if h.get('status', {}).get('completed'):
                raise RuntimeError('任务已结束，但没有返回图片')
        time.sleep(1.5)
    cancel_legacy_prompt(pid)
    with LEGACY_PIDS_LOCK: LEGACY_PIDS.discard(str(pid))
    raise TimeoutError('生成超过 10 分钟，已定向停止当前兼容任务')


def wait_all_images(pid, timeout=180):
    t=time.time()
    while time.time()-t < timeout:
        h=jreq(COMFY + f'/history/{pid}', timeout=15).get(pid)
        if h:
            err=extract_error(h)
            if err: raise RuntimeError(err)
            imgs=[]
            for node_id,out in h.get('outputs',{}).items():
                for m in out.get('images',[]) or []:
                    qs=parse.urlencode({'filename':m['filename'],'subfolder':m.get('subfolder',''),'type':m.get('type','output')})
                    b,ctype,_=raw(COMFY + '/view?' + qs, timeout=120)
                    imgs.append({'node':str(node_id),'image':'data:'+ctype+';base64,'+base64.b64encode(b).decode(),'filename':m['filename']})
            if imgs:
                with LEGACY_PIDS_LOCK: LEGACY_PIDS.discard(str(pid))
                return imgs
            if h.get('status',{}).get('completed'): raise RuntimeError('预览任务完成但没有图片')
        time.sleep(1.0)
    cancel_legacy_prompt(pid)
    with LEGACY_PIDS_LOCK: LEGACY_PIDS.discard(str(pid))
    raise TimeoutError('动作识别预览超时，已定向停止当前预览任务')


def ensure_comfy():
    if ok(COMFY + '/system_stats'):
        return True, 'ComfyUI 在线'
    try:
        p = subprocess.run([str(CTL), 'repair'], capture_output=True, text=True, timeout=150)
        log('auto repair: ' + (p.stdout + p.stderr)[-1200:])
    except Exception as e:
        log(f'auto repair failed: {e}')
    for _ in range(30):
        if ok(COMFY + '/system_stats'):
            return True, 'ComfyUI 已自动恢复'
        time.sleep(2)
    return False, 'ComfyUI 不在线，自动修复也没有成功'


def round64(v):
    return max(64, int(round(float(v) / 64.0)) * 64)


def fit_pose_dims(w, h):
    try:
        w, h = int(w), int(h)
        if w <= 0 or h <= 0:
            raise ValueError
        if abs(w / h - 1) < 0.08:
            return 1024, 1024
        if h > w:
            oh = 1344
            ow = round64(oh * w / h)
            ow = min(1152, max(448, ow))
        else:
            ow = 1344
            oh = round64(ow * h / w)
            oh = min(1152, max(448, oh))
        return ow, oh
    except Exception:
        return 1024, 1344


def set_sampler_seed(wf, seed=None):
    if seed is None:
        seed = int(time.time_ns() % 10**15)
    try:
        wf['3']['inputs']['seed'] = int(seed)
    except Exception:
        pass
    return int(seed)


def generate_with_audit(wf, profile=None, auto_retry=0):
    attempts = max(1, int(auto_retry) + 1)
    last_audit = {'pass': True, 'reasons': [], 'metrics': {}}
    last_fn = ''
    last_image = ''
    for idx in range(attempts):
        set_sampler_seed(wf)
        pid = queue(wf)
        image, fn = wait_image(pid)
        last_image, last_fn = image, fn
        if not profile:
            return image, fn, {'pass': True, 'reasons': [], 'metrics': {}, 'attempts': idx + 1}
        audit = reference_lock.audit_output_against_profile(image, profile)
        audit['attempts'] = idx + 1
        last_audit = audit
        if audit.get('pass'):
            return image, fn, audit
        log(f'reference audit retry {idx+1}/{attempts}: {audit.get("reasons")}')
    return last_image, last_fn, last_audit


def common(pos, neg, mode='txt', body_exposure=False):
    strength_model, strength_clip = style_strength_pair(mode, body_exposure)
    return {
        '4': {'class_type': 'CheckpointLoaderSimple', 'inputs': {'ckpt_name': MODEL}},
        '40': {'class_type': 'LoraLoader', 'inputs': {'model': ['4', 0], 'clip': ['4', 1], 'lora_name': active_style_lora(), 'strength_model': strength_model, 'strength_clip': strength_clip}},
        '6': {'class_type': 'CLIPTextEncode', 'inputs': {'text': pos, 'clip': ['40', 1]}},
        '7': {'class_type': 'CLIPTextEncode', 'inputs': {'text': neg, 'clip': ['40', 1]}}
    }

def txt_wf(pos, neg, w=1024, h=1344, body_exposure=False):
    d = common(pos, neg, 'txt', body_exposure)
    d.update({
        '5': {'class_type': 'EmptyLatentImage', 'inputs': {'width': int(w), 'height': int(h), 'batch_size': 1}},
        '3': {'class_type': 'KSampler', 'inputs': {'seed': int(time.time_ns() % 10**15), 'steps': 28, 'cfg': 4.8, 'sampler_name': 'euler_ancestral', 'scheduler': 'normal', 'denoise': 1.0, 'model': ['40', 0], 'positive': ['6', 0], 'negative': ['7', 0], 'latent_image': ['5', 0]}},
        '8': {'class_type': 'VAEDecode', 'inputs': {'samples': ['3', 0], 'vae': ['4', 2]}},
        '9': {'class_type': 'SaveImage', 'inputs': {'filename_prefix': 'WAI32_txt', 'images': ['8', 0]}}
    })
    return d


def img_wf(pos, neg, img, denoise=0.55, body_exposure=False):
    d = common(pos, neg, 'img', body_exposure)
    d.update({
        '10': {'class_type': 'LoadImage', 'inputs': {'image': img, 'upload': 'image'}},
        '11': {'class_type': 'VAEEncode', 'inputs': {'pixels': ['10', 0], 'vae': ['4', 2]}},
        '3': {'class_type': 'KSampler', 'inputs': {'seed': int(time.time_ns() % 10**15), 'steps': 28, 'cfg': 4.8, 'sampler_name': 'euler_ancestral', 'scheduler': 'normal', 'denoise': float(denoise), 'model': ['40', 0], 'positive': ['6', 0], 'negative': ['7', 0], 'latent_image': ['11', 0]}},
        '8': {'class_type': 'VAEDecode', 'inputs': {'samples': ['3', 0], 'vae': ['4', 2]}},
        '9': {'class_type': 'SaveImage', 'inputs': {'filename_prefix': 'WAI32_img', 'images': ['8', 0]}}
    })
    return d


def ref_wf(pos, neg, img_full, img_face, w=1024, h=1344, style_lock=True, outfit_override=False, body_exposure=False, baseline_lock=True):
    d = common(pos, neg, 'ref', body_exposure)
    if style_lock and baseline_lock:
        overall_weight = 0.18 if outfit_override else 0.24
        overall_end = 0.26 if outfit_override else 0.34
        face_weight = 0.78 if outfit_override else 0.86
        face_end = 0.64 if outfit_override else 0.72
    elif style_lock:
        overall_weight = 0.06 if outfit_override else 0.10
        overall_end = 0.16 if outfit_override else 0.22
        face_weight = 0.52 if outfit_override else 0.60
        face_end = 0.48 if outfit_override else 0.56
    else:
        overall_weight, overall_end, face_weight, face_end = 0.22, 0.32, 0.76, 0.70
    d.update({
        '10': {'class_type': 'LoadImage', 'inputs': {'image': img_full, 'upload': 'image'}},
        '11': {'class_type': 'LoadImage', 'inputs': {'image': img_face, 'upload': 'image'}},
        '12': {'class_type': 'PrepImageForClipVision', 'inputs': {'image': ['10', 0], 'interpolation': 'LANCZOS', 'crop_position': 'pad', 'sharpening': 0.03}},
        '13': {'class_type': 'PrepImageForClipVision', 'inputs': {'image': ['11', 0], 'interpolation': 'LANCZOS', 'crop_position': 'pad', 'sharpening': 0.08}},
        '20': {'class_type': 'IPAdapterUnifiedLoader', 'inputs': {'model': ['40', 0], 'preset': 'STANDARD (medium strength)'}},
        '21': {'class_type': 'IPAdapterAdvanced', 'inputs': {'model': ['20', 0], 'ipadapter': ['20', 1], 'image': ['12', 0], 'weight': overall_weight, 'weight_type': 'linear', 'combine_embeds': 'concat', 'start_at': 0.0, 'end_at': overall_end, 'embeds_scaling': 'V only'}},
        '22': {'class_type': 'IPAdapterUnifiedLoader', 'inputs': {'model': ['21', 0], 'preset': 'PLUS FACE (portraits)'}},
        '23': {'class_type': 'IPAdapterAdvanced', 'inputs': {'model': ['22', 0], 'ipadapter': ['22', 1], 'image': ['13', 0], 'weight': face_weight, 'weight_type': 'linear', 'combine_embeds': 'concat', 'start_at': 0.0, 'end_at': face_end, 'embeds_scaling': 'V only'}},
        '5': {'class_type': 'EmptyLatentImage', 'inputs': {'width': int(w), 'height': int(h), 'batch_size': 1}},
        '3': {'class_type': 'KSampler', 'inputs': {'seed': int(time.time_ns() % 10**15), 'steps': 28, 'cfg': 4.8, 'sampler_name': 'euler_ancestral', 'scheduler': 'normal', 'denoise': 1.0, 'model': ['23', 0], 'positive': ['6', 0], 'negative': ['7', 0], 'latent_image': ['5', 0]}},
        '8': {'class_type': 'VAEDecode', 'inputs': {'samples': ['3', 0], 'vae': ['4', 2]}},
        '9': {'class_type': 'SaveImage', 'inputs': {'filename_prefix': 'WAI3422_ref', 'images': ['8', 0]}}
    })
    return d

def person_pose_wf(pos, neg, person_full, person_face, pose, w, h, strict=True, style_lock=True, outfit_override=False, body_exposure=False, baseline_lock=True):
    d = common(pos, neg, 'person_pose', body_exposure)
    pose_strength = 1.28 if strict else 1.10
    if baseline_lock:
        depth_strength = 0.0
        depth_end = 0.0
    else:
        depth_strength = 0.22 if strict else 0.14
        depth_end = 0.42 if strict else 0.34
    composition_weight = 0.0 if style_lock else (0.14 if strict else 0.10)
    composition_end = 0.0 if style_lock else (0.34 if strict else 0.28)
    if style_lock and baseline_lock:
        face_weight = 0.76 if outfit_override else 0.84
        overall_weight = 0.16 if outfit_override else 0.22
        face_end = 0.62 if outfit_override else 0.70
        overall_end = 0.28 if outfit_override else 0.34
    elif style_lock:
        face_weight = 0.48 if outfit_override else 0.54
        overall_weight = 0.05 if outfit_override else 0.09
        face_end = 0.42 if outfit_override else 0.48
        overall_end = 0.14 if outfit_override else 0.20
    else:
        face_weight = 0.62 if strict else 0.68
        overall_weight = 0.20 if strict else 0.24
        face_end = 0.56 if strict else 0.66
        overall_end = 0.30 if strict else 0.38
    d.update({
        '10': {'class_type': 'LoadImage', 'inputs': {'image': person_full, 'upload': 'image'}},
        '11': {'class_type': 'LoadImage', 'inputs': {'image': person_face, 'upload': 'image'}},
        '12': {'class_type': 'PrepImageForClipVision', 'inputs': {'image': ['10', 0], 'interpolation': 'LANCZOS', 'crop_position': 'pad', 'sharpening': 0.03}},
        '13': {'class_type': 'PrepImageForClipVision', 'inputs': {'image': ['11', 0], 'interpolation': 'LANCZOS', 'crop_position': 'pad', 'sharpening': 0.08}},
        '20': {'class_type': 'IPAdapterUnifiedLoader', 'inputs': {'model': ['40', 0], 'preset': 'STANDARD (medium strength)'}},
        '21': {'class_type': 'IPAdapterAdvanced', 'inputs': {'model': ['20', 0], 'ipadapter': ['20', 1], 'image': ['12', 0], 'weight': overall_weight, 'weight_type': 'linear', 'combine_embeds': 'concat', 'start_at': 0.0, 'end_at': overall_end, 'embeds_scaling': 'V only'}},
        '22': {'class_type': 'IPAdapterUnifiedLoader', 'inputs': {'model': ['21', 0], 'preset': 'PLUS FACE (portraits)'}},
        '23': {'class_type': 'IPAdapterAdvanced', 'inputs': {'model': ['22', 0], 'ipadapter': ['22', 1], 'image': ['13', 0], 'weight': face_weight, 'weight_type': 'linear', 'combine_embeds': 'concat', 'start_at': 0.0, 'end_at': face_end, 'embeds_scaling': 'V only'}},
        '30': {'class_type': 'LoadImage', 'inputs': {'image': pose, 'upload': 'image'}},
        '31': {'class_type': 'DWPreprocessor', 'inputs': {'image': ['30', 0], 'detect_hand': 'enable', 'detect_body': 'enable', 'detect_face': 'enable', 'resolution': 1024, 'bbox_detector': 'yolox_l.onnx', 'pose_estimator': 'dw-ll_ucoco_384.onnx', 'scale_stick_for_xinsr_cn': 'enable'}},
        '32': {'class_type': 'ControlNetLoader', 'inputs': {'control_net_name': OPENPOSE_NAME}},
        '33': {'class_type': 'ControlNetApplyAdvanced', 'inputs': {'positive': ['6', 0], 'negative': ['7', 0], 'control_net': ['32', 0], 'image': ['31', 0], 'strength': pose_strength, 'start_percent': 0.0, 'end_percent': 1.0}},
        '34': {'class_type': 'DepthAnythingV2Preprocessor', 'inputs': {'image': ['30', 0], 'ckpt_name': DEPTH_CKPT, 'resolution': 768}},
        '35': {'class_type': 'ControlNetLoader', 'inputs': {'control_net_name': DEPTH_CONTROLNET}},
        '36': {'class_type': 'ControlNetApplyAdvanced', 'inputs': {'positive': ['33', 0], 'negative': ['33', 1], 'control_net': ['35', 0], 'image': ['34', 0], 'strength': depth_strength, 'start_percent': 0.0, 'end_percent': depth_end}},
        '50': {'class_type': 'PrepImageForClipVision', 'inputs': {'image': ['30', 0], 'interpolation': 'LANCZOS', 'crop_position': 'pad', 'sharpening': 0.0}},
        '51': {'class_type': 'IPAdapterModelLoader', 'inputs': {'ipadapter_file': COMPOSITION_IP}},
        '52': {'class_type': 'CLIPVisionLoader', 'inputs': {'clip_name': CLIP_VISION_H}},
        '53': {'class_type': 'IPAdapterAdvanced', 'inputs': {'model': ['23', 0], 'ipadapter': ['51', 0], 'image': ['50', 0], 'clip_vision': ['52', 0], 'weight': composition_weight, 'weight_type': 'composition precise', 'combine_embeds': 'concat', 'start_at': 0.0, 'end_at': composition_end, 'embeds_scaling': 'K+mean(V) w/ C penalty'}},
        '5': {'class_type': 'EmptyLatentImage', 'inputs': {'width': int(w), 'height': int(h), 'batch_size': 1}},
        '3': {'class_type': 'KSampler', 'inputs': {'seed': int(time.time_ns() % 10**15), 'steps': 28, 'cfg': 4.8, 'sampler_name': 'euler_ancestral', 'scheduler': 'normal', 'denoise': 1.0, 'model': (['23', 0] if style_lock else ['53', 0]), 'positive': ['36', 0], 'negative': ['36', 1], 'latent_image': ['5', 0]}},
        '8': {'class_type': 'VAEDecode', 'inputs': {'samples': ['3', 0], 'vae': ['4', 2]}},
        '9': {'class_type': 'SaveImage', 'inputs': {'filename_prefix': 'WAI3422_person_pose', 'images': ['8', 0]}}
    })
    return d


def pose_preview_wf(pose):
    return {
        '30': {'class_type': 'LoadImage', 'inputs': {'image': pose, 'upload': 'image'}},
        '31': {'class_type': 'DWPreprocessor', 'inputs': {'image': ['30', 0], 'detect_hand': 'enable', 'detect_body': 'enable', 'detect_face': 'enable', 'resolution': 1024, 'bbox_detector': 'yolox_l.onnx', 'pose_estimator': 'dw-ll_ucoco_384.onnx', 'scale_stick_for_xinsr_cn': 'enable'}},
        '34': {'class_type': 'DepthAnythingV2Preprocessor', 'inputs': {'image': ['30', 0], 'ckpt_name': DEPTH_CKPT, 'resolution': 768}},
        '91': {'class_type': 'SaveImage', 'inputs': {'filename_prefix': 'WAI34_pose_preview', 'images': ['31', 0]}},
        '92': {'class_type': 'SaveImage', 'inputs': {'filename_prefix': 'WAI34_depth_preview', 'images': ['34', 0]}}
    }


def hist(x):
    try:
        with open(HISTORY, 'a', encoding='utf-8') as f:
            f.write(json.dumps(x, ensure_ascii=False) + '\n')
    except Exception:
        pass


HTML = r'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WAI v3.4 Full Stable Fix</title><style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#101114;color:#f3f4f6;font-family:system-ui,-apple-system,"PingFang SC",sans-serif}.w{max-width:1080px;margin:auto;padding:10px}.head{text-align:center;font-size:23px;font-weight:800;margin:7px}.sub{text-align:center;color:#aab0bb}.card{background:#191b20;border:1px solid #30343b;border-radius:14px;padding:13px;margin-top:10px}.status{font-size:13px;line-height:1.9}.badge{display:inline-block;background:#242933;padding:2px 8px;border-radius:99px;margin:2px}.style{background:#12211b;border:1px solid #315b45;border-radius:12px;padding:10px;margin-top:10px;color:#b9efce}.tabs{display:flex;gap:6px;overflow:auto;position:sticky;top:0;background:#101114;padding:8px 0;z-index:3}.tab{min-width:120px;flex:1;padding:11px;border:1px solid #30343b;background:#17191d;color:#fff;border-radius:10px}.tab.on{background:#2997ff}label{display:block;font-size:14px;margin:9px 0 5px}textarea,input,select{width:100%;padding:11px;border:1px solid #3a3e46;border-radius:9px;background:#101216;color:#fff;font-size:16px}textarea{min-height:110px}.short{min-height:64px}.row{display:grid;grid-template-columns:1fr 1fr;gap:9px}button{width:100%;padding:13px;border-radius:10px;color:#fff;margin-top:9px;font-size:16px}button.primary{border:0;background:#2997ff;font-weight:700}button.secondary{border:1px solid #3a3e46;background:#23262d}button.danger{border:1px solid #704444;background:#382326}.hide{display:none}.msg{color:#aab0bb;font-size:13px;white-space:pre-wrap;margin-top:8px}.preview{max-width:100%;border-radius:12px;margin-top:10px}.note{font-size:12px;color:#aab0bb;line-height:1.6}details{margin-top:9px;border-top:1px solid #30343b;padding-top:8px}@media(max-width:650px){.row{grid-template-columns:1fr}.w{padding:7px}}</style></head><body><div class="w">
<div class="head">WAI 稳定版 v3.4.22</div><div class="sub">纯画风 LoRA · 参考图解析/去污染 · 精确脸裁切 · 轻量体型验收</div>
<div class="card status" id="status">读取状态中...</div>
<div class="style"><b>全局画风：lin53soft Style LoRA（优先 v3 纯画风版）</b><br><span class="note">所有模式统一加载同一个本地画风 LoRA；A 参考图先经过本地解析程序，自动去掉大部分背景污染，并生成单独脸部裁切；B 参考图只负责动作。系统会在参考模式下自动做一次轻量体型验收，遇到明显大头/矮胖漂移时自动换种子重试一次。</span></div>
<div class="card"><div class="row"><div><label>提示词模式</label><select id="pmode"><option value="qwen">中文智能（本地 Qwen）</option><option value="english">英文直输（不过 Qwen）</option><option value="light">中文轻量（不过 Qwen）</option></select></div><div><label>当前模型</label><input id="model" readonly value="加载中..."></div></div><div class="row"><button class="secondary" onclick="repair()">一键修复后台</button><button class="secondary" onclick="backup()">创建加密增量备份</button></div><div class="msg" id="sysmsg"></div></div>
<div class="tabs"><button class="tab on" data-t="txt">文生图</button><button class="tab" data-t="img">图生图</button><button class="tab" data-t="ref">人物参考</button><button class="tab" data-t="pp">人物+动作</button></div>
<section id="txt"><div class="card"><label>描述</label><textarea id="txtPrompt" placeholder="例如：一个浅蓝长发的猫耳少女，站在白色背景前，全身"></textarea><label>负面提示词（可空；只写你额外不想要的内容）</label><textarea class="short" id="txtNeg"></textarea><div class="row"><button class="secondary" onclick="opt('txt')">查看最终提示词</button><button class="danger" onclick="cancel()">停止当前生成</button></div><details><summary>高级：最终提示词 / 尺寸</summary><textarea id="txtPos"></textarea><textarea class="short" id="txtNegOut"></textarea><div class="row"><input id="txtW" value="1024"><input id="txtH" value="1344"></div></details><button class="primary" onclick="gen('txt')">生成图片</button><div class="msg" id="txtMsg"></div><img class="preview hide" id="txtOut"></div></section>
<section id="img" class="hide"><div class="card"><label>原图</label><input type="file" accept="image/*" id="imgFile"><label>怎么改</label><textarea id="imgPrompt" placeholder="例如：保持人物和构图，换成夜晚街道"></textarea><label>负面提示词（可空；只写你额外不想要的内容）</label><textarea class="short" id="imgNeg"></textarea><details><summary>高级：重绘幅度</summary><label>重绘幅度（推荐 0.50~0.62）</label><input id="imgDenoise" value="0.58"><textarea id="imgPos"></textarea><textarea class="short" id="imgNegOut"></textarea></details><div class="row"><button class="secondary" onclick="opt('img')">查看最终提示词</button><button class="danger" onclick="cancel()">停止当前生成</button></div><button class="primary" onclick="gen('img')">开始图生图</button><div class="msg" id="imgMsg"></div><img class="preview hide" id="imgOut"></div></section>
<section id="ref" class="hide"><div class="card"><div class="note">A 图作为人物基准：优先保留脸、发型和身体比例；上传后会先本地去背景污染并单独裁脸，再送给 IPAdapter。若成图出现明显大头/矮胖漂移，系统会自动重试一次。</div><label>A：人物参考图</label><input type="file" accept="image/*" id="refFile"><label><input type="checkbox" id="refBaseline" style="width:auto" checked> 基准人物锁定（脸 + 体型比例，服装按文字）</label><label>新图描述</label><textarea id="refPrompt" placeholder="例如：保持同一个人物，换成米色开衫，白底全身站立"></textarea><label>负面提示词（可空；只写你额外不想要的内容）</label><textarea class="short" id="refNeg"></textarea><details><summary>高级：最终提示词 / 尺寸</summary><textarea id="refPos"></textarea><textarea class="short" id="refNegOut"></textarea><div class="row"><input id="refW" value="1024"><input id="refH" value="1344"></div></details><div class="row"><button class="secondary" onclick="opt('ref')">查看最终提示词</button><button class="danger" onclick="cancel()">停止当前生成</button></div><button class="primary" onclick="gen('ref')">生成人物新图</button><div class="msg" id="refMsg"></div><img class="preview hide" id="refOut"></div></section>
<section id="pp" class="hide"><div class="card"><div class="note">最多两张图：A 只负责人，且会先本地去污染并单独裁脸；B 只负责动作。新版默认把 Depth 降到极低，仅在非基准人物锁定时作为轻透视辅助。</div><label>A：人物参考图</label><input type="file" accept="image/*" id="ppPerson"><label>B：动作参考图</label><input type="file" accept="image/*" id="ppPose"><label>新图描述</label><textarea id="ppPrompt" placeholder="例如：保持同一个人物和服装，使用动作图的姿势"></textarea><label>负面提示词（可空；只写你额外不想要的内容）</label><textarea class="short" id="ppNeg"></textarea><label><input type="checkbox" id="ppStrict" style="width:auto" checked> 动作严格模式（默认开启）</label><label><input type="checkbox" id="ppBaseline" style="width:auto" checked> 基准人物锁定（A 定脸/体型，B 主要定骨架）</label><details><summary>高级：最终提示词</summary><textarea id="ppPos"></textarea><textarea class="short" id="ppNegOut"></textarea></details><div class="row"><button class="secondary" onclick="previewPose()">先检查 B 图动作识别</button><button class="secondary" onclick="opt('pp')">查看最终提示词</button></div><div class="row"><button class="danger" onclick="cancel()">停止当前生成</button><button class="primary" onclick="gen('pp')">按人物+动作生成</button></div><div class="msg" id="ppMsg"></div><div class="row" id="posePreviewBox"></div><img class="preview hide" id="ppOut"></div></section>
</div><script>
const $=x=>document.getElementById(x);document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'));b.classList.add('on');['txt','img','ref','pp'].forEach(x=>$(x).classList.add('hide'));$(b.dataset.t).classList.remove('hide')});
async function api(p,d){let o={};if(d!==undefined)o={method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)};let r=await fetch(p,o);let txt=await r.text(),j;try{j=JSON.parse(txt)}catch{throw new Error(txt||'请求失败')}if(!r.ok)throw new Error(j.error||'请求失败');return j}
async function status(){try{let s=await api('/api/status');$('status').innerHTML=s.html;$('model').value=s.model}catch(e){$('status').textContent=e.message}}status();setInterval(status,15000);
function imageData(id){return new Promise((res,rej)=>{let f=$(id).files[0];if(!f)return res(null);let r=new FileReader();r.onload=()=>{let im=new Image();im.onload=()=>res({data:r.result,w:im.naturalWidth,h:im.naturalHeight});im.onerror=rej;im.src=r.result};r.onerror=rej;r.readAsDataURL(f)})}
async function opt(mode){let msg=$(mode+'Msg');msg.textContent='整理中...';try{let j=await api('/api/optimize',{mode:mode==='pp'?'person_pose':mode,prompt:$(mode+'Prompt').value,negative:$(mode+'Neg').value,prompt_mode:$('pmode').value});$(mode+'Pos').value=j.positive;$(mode+'NegOut').value=j.negative;msg.textContent=j.note}catch(e){msg.textContent='错误：'+e.message}}
async function gen(mode){let msg=$(mode+'Msg'),out=$(mode+'Out');msg.textContent='准备中...';out.classList.add('hide');try{let d={mode,prompt_mode:$('pmode').value,prompt:$(mode+'Prompt').value,negative:$(mode+'Neg').value};if(mode==='txt'){d.width=+$('txtW').value;d.height=+$('txtH').value}if(mode==='img'){let x=await imageData('imgFile');if(!x)throw new Error('请上传原图');d.image=x.data;d.denoise=+$('imgDenoise').value}if(mode==='ref'){let x=await imageData('refFile');if(!x)throw new Error('请上传人物参考图');d.image=x.data;d.width=+$('refW').value;d.height=+$('refH').value;d.baseline_lock=$('refBaseline').checked}if(mode==='pp'){let a=await imageData('ppPerson'),b=await imageData('ppPose');if(!a||!b)throw new Error('人物图和动作图都要上传');d.person=a.data;d.pose=b.data;d.pose_width=b.w;d.pose_height=b.h;d.strict=$('ppStrict').checked;d.baseline_lock=$('ppBaseline').checked}msg.textContent='生成中...';let j=await api('/api/generate',d);$(mode+'Pos').value=j.positive;$(mode+'NegOut').value=j.negative;out.src=j.image;out.classList.remove('hide');msg.textContent=j.note}catch(e){msg.textContent='错误：'+e.message}}
async function previewPose(){let msg=$('ppMsg');msg.textContent='正在识别 B 图骨架和深度...';try{let b=await imageData('ppPose');if(!b)throw new Error('请先上传 B 动作参考图');let j=await api('/api/preview_pose',{pose:b.data});let box=$('posePreviewBox');box.innerHTML='';j.items.forEach(it=>{let d=document.createElement('div');d.innerHTML='<div class=\"note\">'+it.label+'</div><img class=\"preview\" src=\"'+it.image+'\">';box.appendChild(d)});msg.textContent=j.note}catch(e){msg.textContent='错误：'+e.message}}
async function cancel(){try{let j=await api('/api/cancel',{});$('sysmsg').textContent=j.message}catch(e){$('sysmsg').textContent=e.message}}
async function repair(){try{$('sysmsg').textContent='修复中...';let j=await api('/api/repair',{});$('sysmsg').textContent=j.message;setTimeout(status,2500)}catch(e){$('sysmsg').textContent=e.message}}
async function backup(){try{$('sysmsg').textContent='准备备份...';let j=await api('/api/backup',{});$('sysmsg').textContent=j.message}catch(e){$('sysmsg').textContent=e.message}}
</script></body></html>'''


class H(BaseHTTPRequestHandler):
    def log_message(self, fmt, *a):
        log(fmt % a)

    def auth(self):
        a = CFG.get('auth', {})
        if not a.get('enabled'):
            return True
        h = self.headers.get('Authorization', '')
        try:
            u, p = base64.b64decode(h[6:]).decode().split(':', 1)
            return h.startswith('Basic ') and u == a['username'] and hashlib.sha256(p.encode()).hexdigest() == a['password_sha256']
        except Exception:
            return False

    def jo(self, o, code=200):
        b = json.dumps(o, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path == '/api/health':
            return self.jo({'ok': True, 'version': '3.4.22-reference-lock', 'port': PANEL_PORT})
        if not self.auth():
            self.send_response(401); self.end_headers(); return
        if self.path == '/':
            b = HTML.encode('utf-8')
            self.send_response(200); self.send_header('Content-Type', 'text/html; charset=utf-8'); self.send_header('Content-Length', str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path == '/api/status':
            g, gn = gpu(); mt, ma = mem(); df, dt = disk(); o = objinfo(); com = ok(COMFY + '/system_stats')
            ipa_nodes = all(x in o for x in ('IPAdapterUnifiedLoader', 'IPAdapterAdvanced'))
            pose_nodes = all(x in o for x in ('DWPreprocessor', 'ControlNetLoader', 'ControlNetApplyAdvanced'))
            ipa = ipa_nodes and ip_models_ready()
            pose = pose_nodes and model_file(OPENPOSE_NAME, 'controlnet')
            html = ''.join([
                f'<span class="badge">GPU：{"✓ "+gn if g else "无卡"}</span>',
                f'<span class="badge">内存：{ma}/{mt} MB</span>',
                f'<span class="badge">ComfyUI：{"在线" if com else "离线"}</span>',
                f'<span class="badge">Qwen：{"在线" if qwen_model() else "离线/休眠"}</span>',
                f'<span class="badge">人物参考：{"可用" if ipa else "待修复"}</span>',
                f'<span class="badge">动作参考：{"可用" if pose else "待修复"}</span>',
                f'<span class="badge">动作深度增强：{"已加载" if depth_ready() else "未安装"}</span>',
                f'<span class="badge">动作构图增强：{"已加载" if composition_ready() else "未安装"}</span>',
                f'<span class="badge">画风去污染：{"v3 已加载" if style_v3_ready() else ("v2 已加载" if style_v2_ready() else "旧版（已降权+临时去光环/双丸子）")}</span>',
                f'<span class="badge">负面提示词：稳定器 v2</span>',
                f'<span class="badge">参考图解析：v0.3.4.22</span>',
                f'<span class="badge">固定画风 LoRA：{"已加载" if style_lora_ready() else "未训练/未安装"}</span>',
                f'<span class="badge">数据盘：{df}/{dt} GB 可用</span>',
                f'<span class="badge">端口：{PANEL_PORT}</span>'
            ])
            return self.jo({'html': html, 'model': MODEL})
        return self.jo({'error': 'not found'}, 404)

    def do_POST(self):
        if not self.auth():
            self.send_response(401); self.end_headers(); return
        try:
            n = int(self.headers.get('Content-Length', '0'))
            d = json.loads(self.rfile.read(n).decode('utf-8')) if n else {}

            if self.path == '/api/cancel':
                with LEGACY_PIDS_LOCK: owned=list(LEGACY_PIDS)
                results={pid:cancel_legacy_prompt(pid) for pid in owned}
                return self.jo({'message': '只取消本 companion 创建的兼容任务；不会全局打断其它 ComfyUI 任务', 'results':results})

            if self.path == '/api/preview_pose':
                if not d.get('pose'):
                    return self.jo({'error':'请上传 B 动作参考图'},400)
                ok2,_=ensure_comfy()
                if not ok2: return self.jo({'error':'ComfyUI 不在线'},409)
                if not nodes_ready('DWPreprocessor','DepthAnythingV2Preprocessor'):
                    return self.jo({'error':'动作预处理节点不完整，请重新运行 v3.4 安装脚本'},409)
                name=upload_dataurl(d['pose'])
                pid=queue(pose_preview_wf(name))
                imgs=wait_all_images(pid)
                items=[]
                for it in imgs:
                    label='DWPose 骨架' if it['node']=='91' else ('Depth 深度' if it['node']=='92' else '预览')
                    items.append({'label':label,'image':it['image']})
                return self.jo({'items':items,'note':'先看骨架是否接近 B 图。骨架对但成图不对时，Depth+Composition 会继续锁透视和构图。'})

            if self.path == '/api/optimize':
                if not str(d.get('prompt', '')).strip():
                    return self.jo({'error': '请输入提示词/描述'}, 400)
                p, ng, note = prompt_prepare(d.get('prompt', ''), d.get('negative', ''), d.get('mode', 'txt'), d.get('prompt_mode', 'qwen'))
                return self.jo({'positive': p, 'negative': ng, 'note': note})

            if self.path == '/api/repair':
                p = subprocess.run([str(CTL), 'repair'], capture_output=True, text=True, timeout=150)
                return self.jo({'message': (p.stdout + p.stderr)[-3000:] or '修复命令已执行'})

            if self.path == '/api/backup':
                p = subprocess.run([str(BACKUP), '--auto'] if BACKUP else ['false'], capture_output=True, text=True, timeout=180)
                if p.returncode != 0:
                    return self.jo({'error': (p.stdout + p.stderr)[-2000:]}, 409)
                return self.jo({'message': (p.stdout + p.stderr)[-2500:]})

            if self.path == '/api/generate':
                if not GEN_LOCK.acquire(blocking=False):
                    return self.jo({'error': '已有生成任务在运行，请等待或点“停止当前生成”'}, 409)
                try:
                    ok2, repair_note = ensure_comfy()
                    if not ok2:
                        return self.jo({'error': repair_note}, 409)
                    if not style_lora_ready():
                        return self.jo({'error': '固定画风 LoRA 还没有安装。先运行 /root/WAI_v33/一键训练并安装固定画风.sh'}, 409)
                    mode = d.get('mode', 'txt')
                    rawp = d.get('prompt', '')
                    if not str(rawp).strip():
                        return self.jo({'error': '请输入提示词/描述'}, 400)
                    p, ng, note = prompt_prepare(rawp, d.get('negative', ''), 'person_pose' if mode == 'pp' else mode, d.get('prompt_mode', 'qwen'))
                    body_exposure = prompt_requests_body_exposure(rawp)

                    if mode == 'txt':
                        wf = txt_wf(p, ng, d.get('width', 1024), d.get('height', 1344), body_exposure)
                    elif mode == 'img':
                        if not d.get('image'):
                            return self.jo({'error': '请上传原图'}, 400)
                        denoise = min(0.72, max(0.35, float(d.get('denoise', 0.58))))
                        wf = img_wf(p, ng, upload_dataurl(d['image']), denoise, body_exposure)
                    elif mode == 'ref':
                        if not d.get('image'):
                            return self.jo({'error': '请上传人物参考图'}, 400)
                        if not nodes_ready('IPAdapterUnifiedLoader', 'IPAdapterAdvanced', 'PrepImageForClipVision') or not ip_models_ready():
                            return self.jo({'error': '人物参考依赖不完整，请运行 /root/WAI_v32_修复依赖.sh'}, 409)
                        outfit_override = prompt_requests_outfit_override(rawp)
                        baseline_lock = bool(d.get('baseline_lock', True))
                        prep = reference_lock.prepare_reference(d['image'])
                        full_name = upload_dataurl(prep['full_dataurl'])
                        face_name = upload_dataurl(prep['face_dataurl'])
                        wf = ref_wf(p, ng, full_name, face_name, d.get('width', 1024), d.get('height', 1344), bool(d.get('style_lock', True)), outfit_override, body_exposure, baseline_lock)
                        image, fn, audit = generate_with_audit(wf, prep.get('profile') if baseline_lock else None, auto_retry=(1 if baseline_lock else 0))
                        hist({'time': datetime.now().isoformat(), 'mode': mode, 'prompt_mode': d.get('prompt_mode', 'qwen'), 'raw': rawp, 'positive': p, 'negative': ng, 'file': fn, 'audit': audit})
                        audit_note = ('；参考验收通过' if audit.get('pass') else ('；参考验收未通过但已返回最后结果：' + ', '.join(audit.get('reasons', []))))
                        return self.jo({'image': image, 'positive': p, 'negative': ng, 'note': f'{repair_note}；{note}；A 图已本地去污染并单独裁脸；参考锁定已启用{audit_note}；生成成功：{fn}'})
                    elif mode == 'pp':
                        if not d.get('person') or not d.get('pose'):
                            return self.jo({'error': '人物图和动作图都要上传'}, 400)
                        if not nodes_ready('IPAdapterUnifiedLoader', 'IPAdapterAdvanced', 'IPAdapterModelLoader', 'CLIPVisionLoader', 'PrepImageForClipVision', 'DWPreprocessor', 'DepthAnythingV2Preprocessor', 'ControlNetLoader', 'ControlNetApplyAdvanced') or not ip_models_ready() or not model_file(OPENPOSE_NAME, 'controlnet') or not depth_ready() or not composition_ready():
                            return self.jo({'error': '人物+动作增强依赖不完整，请重新运行 v3.4 安装脚本'}, 409)
                        w, h = d.get('width'), d.get('height')
                        if not w or not h:
                            w, h = fit_pose_dims(d.get('pose_width'), d.get('pose_height'))
                        outfit_override = prompt_requests_outfit_override(rawp)
                        baseline_lock = bool(d.get('baseline_lock', True))
                        prep = reference_lock.prepare_reference(d['person'])
                        person_full = upload_dataurl(prep['full_dataurl'])
                        person_face = upload_dataurl(prep['face_dataurl'])
                        pose_name = upload_dataurl(d['pose'])
                        wf = person_pose_wf(p, ng, person_full, person_face, pose_name, w, h, bool(d.get('strict', False)), bool(d.get('style_lock', True)), outfit_override, body_exposure, baseline_lock)
                        image, fn, audit = generate_with_audit(wf, prep.get('profile') if baseline_lock else None, auto_retry=(1 if baseline_lock else 0))
                        hist({'time': datetime.now().isoformat(), 'mode': mode, 'prompt_mode': d.get('prompt_mode', 'qwen'), 'raw': rawp, 'positive': p, 'negative': ng, 'file': fn, 'audit': audit})
                        audit_note = ('；参考验收通过' if audit.get('pass') else ('；参考验收未通过但已返回最后结果：' + ', '.join(audit.get('reasons', []))))
                        return self.jo({'image': image, 'positive': p, 'negative': ng, 'note': f'{repair_note}；{note}；A 图已本地去污染并单独裁脸；B 图只提供动作；Depth 在基准人物锁定时默认关闭{audit_note}；生成成功：{fn}'})
                    else:
                        return self.jo({'error': '未知模式'}, 400)

                    pid = queue(wf)
                    image, fn = wait_image(pid)
                    hist({'time': datetime.now().isoformat(), 'mode': mode, 'prompt_mode': d.get('prompt_mode', 'qwen'), 'raw': rawp, 'positive': p, 'negative': ng, 'file': fn})
                    return self.jo({'image': image, 'positive': p, 'negative': ng, 'note': f'{repair_note}；{note}；固定画风按净化版本自动调权；负面提示词已稳定化；生成成功：{fn}'})
                finally:
                    GEN_LOCK.release()

            return self.jo({'error': 'not found'}, 404)
        except Exception as e:
            log(repr(e))
            return self.jo({'error': f'{type(e).__name__}: {e}'}, 500)


if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', PANEL_PORT), H).serve_forever()
