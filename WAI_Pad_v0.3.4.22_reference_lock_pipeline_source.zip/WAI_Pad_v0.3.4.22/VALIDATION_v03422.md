# v0.3.4.22 Validation

- Python syntax compile: server/engine_v34.py, server/job_api.py, server/reference_lock.py.
- Android embedded server copies match root server copies for engine_v34.py / job_api.py / reference_lock.py.
- Reference workflows now require two reference images internally: cleaned full-body crop and explicit face crop.
- `person_pose` baseline-lock path sets Depth strength/end to zero.
- Android metadata: versionCode 28 / versionName 0.3.4.22.
