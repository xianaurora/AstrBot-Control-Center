# WAI Pad v0.3.4.22 — 参考图解析 + 精确裁脸 + 轻量体型验收

- 参考人物 A 图新增本地解析预处理：先估计主体区域，去掉大部分纯色背景污染，再输出干净的人物裁切图。
- 参考人物 A 图不再依赖 `crop_position=top` 猜脸，改为本地估计头部/脸部方形裁切，再单独送入 PLUS FACE IPAdapter。
- `ref` / `person+pose` 两种模式都改为“双参考输入”：`A-全身清洗图 + A-脸部裁切图`。
- 基准人物锁定下，人物+动作模式默认关闭 Depth 强约束，避免 B 图深度轮廓继续偷偷带入体型和比例。
- 新增轻量参考验收：成图后自动比较基准图与结果图的头身比例/主体纵横比例；出现明显大头或矮胖漂移时自动换 seed 重试一次。
- 新增 `server/reference_lock.py`，集中管理参考图去污染、裁脸与轻量验收逻辑。
- Android 资源内置 server 脚本同步到 v0.3.4.22，并新增 `reference_lock.py`。
- Android versionCode 28 / versionName 0.3.4.22。
