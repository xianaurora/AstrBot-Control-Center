# v0.3.4.21 Validation

- Python syntax compile: server/engine_v34.py, server/job_api.py.
- Android embedded server copies match root server copies.
- Reference prompt no longer contains `preserve key hairstyle details` / `preserve key outfit details`.
- Reference artifact negative guard present and conditioned on explicit user requests.
- Android metadata: versionCode 27 / versionName 0.3.4.21.
