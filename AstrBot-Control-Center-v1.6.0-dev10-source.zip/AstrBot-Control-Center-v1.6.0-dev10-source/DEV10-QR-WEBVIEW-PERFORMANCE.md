# dev10: console readiness, QR fallback, rendering performance

This revision is based on the 2026-08-11 diagnostic bundle and current Android/noVNC/x11vnc/Chromium documentation.

- The native console waits for the matching `*_WEB_READY` state before navigating the WebView, reducing startup races that previously produced blank AstrBot/SnowLuma pages.
- QR WebViews use no-cache mode and fall back from `astrbot_qr.html` to stock noVNC `vnc.html` if the custom page returns an HTTP error or the center-region framebuffer probe still sees an unusable canvas.
- The stock fallback preserves the same loopback session and requests `autoconnect`, `resize=scale`, `quality=9`, `compression=0`, `logging=warn`, and `path=websockify`.
- The custom QR client also uses `compressionLevel=0` and `qualityLevel=9`. Since this path is loopback-only and short-lived, it favors lower encode/decode CPU over network compression.
- x11vnc QR transport uses `-nowf -wait 10 -defer 10`: wireframe is disabled and polling/defer latency is reduced for the temporary login desktop.
- dev8 automatic blank-frame recovery could persist the plain render state `compat`. dev7 treats that legacy value as stale. New explicit compatibility requests are stored as `compat-manual` instead.
- Compatibility rendering explicitly selects Chromium's legacy SwiftShader GL path (`--use-gl=swiftshader`) so it does not repeatedly attempt the unavailable Vulkan path seen in the diagnostic log.
- The overview “下一步” area is now an animated beacon card rather than a low-contrast text row.
