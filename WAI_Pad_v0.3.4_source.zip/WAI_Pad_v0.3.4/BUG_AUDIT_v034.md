# v0.3.4 Bug 排查

## Bug A：人物参考后画风明显变淡/漂移
根因：人物参考模式原来的 Standard IPAdapter 权重 0.32、Face IPAdapter 0.74，且持续到采样 42%/74%。参考图的颜色、笔触和渲染方式会长期参与去噪，压过固定 Style LoRA。

修复：默认开启人物参考画风锁定；大幅降低整体参考权重并提前退出；Face 只保留身份信息；提高固定 Style LoRA 权重，并改变 embeddings scaling 以减少风格泄漏。

## Bug B：不同 GitHub Actions 构建的 APK 不能覆盖安装
根因：每台 GitHub Runner 生成的默认 Android debug keystore 不同，因此 APK 虽然包名一样，签名证书却不同。

修复：工程内固定个人 Beta 更新签名。v0.3.4 之后所有构建使用同一证书。

## Bug C：为了换签名卸载 App 后图库全没了
根因：旧版图片只保存在 `context.filesDir`，这是 Android App 私有目录，卸载时系统必须删除。

修复：成图额外写入本机 MediaStore `Pictures/WAI Pad/`。该目录不属于云端，也不随卸载清理。重装后可重新扫描导入。
