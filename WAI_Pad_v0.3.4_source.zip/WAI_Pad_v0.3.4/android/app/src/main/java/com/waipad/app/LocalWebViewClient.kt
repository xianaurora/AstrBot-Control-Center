package com.waipad.app

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient

class LocalWebViewClient(private val store: LocalImageStore) : WebViewClient() {
    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        val u = request?.url ?: return null
        if (u.host == "app.local" && u.path?.startsWith("/local-images/") == true) {
            val name = u.lastPathSegment ?: return null
            val opened = store.open(name) ?: return WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), "missing".byteInputStream())
            return WebResourceResponse(opened.mime, null, opened.stream)
        }
        return super.shouldInterceptRequest(view, request)
    }
}
