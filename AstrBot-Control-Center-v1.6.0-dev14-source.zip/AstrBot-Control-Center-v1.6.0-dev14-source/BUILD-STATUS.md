# Build status — v1.6.0-dev14

- Android App: `1.6.0-dev14` / `161200`
- 内置核心组件: `1.6.0-dev11` / `16011`（本次未修改 core）。
- AstrBot 白屏修复：立即创建 WebView；probe 旁路执行；AstrBot 独立 `LOAD_NO_CACHE` + no-cache headers；核心 JS/CSS 失败直接报错；持续空白最多一次 cache-busted 重载。
- 第二次仍空白：停止自动 reload，显示 JS / 静态资源 / DOM 挂载摘要 / WebView provider，并提供系统浏览器旁路。
- SnowLuma 默认扫码仍为 FFmpeg x11grab → PNG → Compose Image；SnowLuma/NapCat 普通控制台缓存策略不变。
- SPA-safe 导航保持：Compose 只跟踪请求 URL，不把 AstrBot 自己的 history/hash 变化当成 root reload 条件。
- 最终 APK 仍需 Android SDK 构建环境执行 `:app:testDebugUnitTest :app:assembleDebug`。
