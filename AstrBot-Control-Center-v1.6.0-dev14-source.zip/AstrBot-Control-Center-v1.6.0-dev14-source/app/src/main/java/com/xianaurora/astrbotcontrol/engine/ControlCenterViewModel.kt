package com.xianaurora.astrbotcontrol.engine

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xianaurora.astrbotcontrol.model.ConsoleState
import com.xianaurora.astrbotcontrol.model.ConsoleTarget
import com.xianaurora.astrbotcontrol.model.ControlCenterUiState
import com.xianaurora.astrbotcontrol.model.ControlDestination
import com.xianaurora.astrbotcontrol.model.DiagnosticExportState
import com.xianaurora.astrbotcontrol.model.LogCategory
import com.xianaurora.astrbotcontrol.model.LogSource
import com.xianaurora.astrbotcontrol.model.OperationsSection
import com.xianaurora.astrbotcontrol.model.RuntimeStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ControlCenterViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = ControlCenterRepository()
    private val _ui = MutableStateFlow(ControlCenterUiState())
    val ui: StateFlow<ControlCenterUiState> = _ui.asStateFlow()

    private var statusJob: Job? = null
    private var logJob: Job? = null
    private var exportJob: Job? = null
    private var loginJob: Job? = null
    private var loginFrameJob: Job? = null
    private var qrRefreshJob: Job? = null
    private var active = false
    private var refreshTick = 0

    fun start() {
        if (active) return
        active = true
        statusJob = viewModelScope.launch {
            repository.keepConsoleActive()
            loadLogSources()
            refreshExportState()
            while (active) {
                val state = _ui.value
                val forceLive = refreshTick == 0 || state.actionBusy || state.status.actionRunning || state.status.stackStarting || refreshTick % 5 == 0
                refreshStatus(forceLive)
                refreshTick++
                if (refreshTick % 4 == 0) repository.keepConsoleActive()
                delay(
                    when {
                        _ui.value.actionBusy || _ui.value.status.actionRunning || _ui.value.status.stackStarting -> 1400
                        _ui.value.destination == ControlDestination.OPERATIONS -> 3600
                        _ui.value.destination == ControlDestination.CONSOLE -> 4200
                        else -> 3000
                    }
                )
            }
        }
        syncLogPolling()
        resumeQqLoginPollingIfNeeded()
    }

    fun stop() {
        active = false
        statusJob?.cancel()
        statusJob = null
        logJob?.cancel()
        logJob = null
        loginJob?.cancel()
        loginJob = null
        loginFrameJob?.cancel()
        loginFrameJob = null
        qrRefreshJob?.cancel()
        qrRefreshJob = null
    }

    fun setDestination(destination: ControlDestination) {
        if (_ui.value.destination == destination) return
        _ui.update { it.copy(destination = destination, transientMessage = "") }
        syncLogPolling()
        if (destination == ControlDestination.CONSOLE && _ui.value.console.url.isBlank() && _ui.value.console.target != ConsoleTarget.QQ_LOGIN) {
            openConsole(ConsoleTarget.ASTRBOT)
        }
    }

    fun setOperationsSection(section: OperationsSection) {
        if (_ui.value.operationsSection == section) return
        _ui.update { it.copy(operationsSection = section, transientMessage = "") }
        syncLogPolling()
        if (section == OperationsSection.LOGS && _ui.value.logText.isBlank()) {
            viewModelScope.launch { refreshSelectedLog() }
        }
    }

    fun clearMessages() {
        _ui.update { it.copy(transientMessage = "", errorMessage = "") }
    }

    fun refresh() = viewModelScope.launch {
        _ui.update { it.copy(refreshing = true, errorMessage = "") }
        refreshStatus(true)
        if (_ui.value.destination == ControlDestination.OPERATIONS && _ui.value.operationsSection == OperationsSection.LOGS) refreshSelectedLog()
        if (_ui.value.exportState.running) refreshExportState()
        _ui.update { it.copy(refreshing = false) }
    }

    fun setLogRedaction(enabled: Boolean) {
        _ui.update { it.copy(redactLogs = enabled) }
    }

    fun selectLogCategory(category: LogCategory) {
        val sources = _ui.value.logSources.filter { it.category == category }
        val next = sources.firstOrNull { it.id == preferredSource(category) } ?: sources.firstOrNull()
        _ui.update {
            it.copy(
                logCategory = category,
                selectedLogId = next?.id ?: it.selectedLogId,
                logText = if (next != null) "" else it.logText,
                redactedLogText = if (next != null) "" else it.redactedLogText,
                logLoading = next != null,
                errorMessage = ""
            )
        }
        if (next != null) viewModelScope.launch { refreshSelectedLog() }
    }

    fun selectLog(id: String) {
        val source = _ui.value.logSources.firstOrNull { it.id == id }
        _ui.update {
            it.copy(
                selectedLogId = id,
                logCategory = source?.category ?: it.logCategory,
                logText = "",
                redactedLogText = "",
                logLoading = true,
                errorMessage = ""
            )
        }
        viewModelScope.launch { refreshSelectedLog() }
    }

    fun runAction(action: String) {
        if (_ui.value.actionBusy || _ui.value.status.actionRunning) return
        val label = when (action) {
            "start" -> "正在启动全部服务"
            "stop" -> "正在停止全部服务"
            "restart" -> "正在重启全部服务"
            "heal" -> "正在自动恢复"
            "repair" -> "正在修复运行环境"
            "environment-reinstall" -> "正在重新安装运行环境"
            "plugin-deps" -> "正在修复插件依赖"
            "bridge-repair" -> "正在修复 OneBot"
            "engine-snowluma" -> "正在切换到 SnowLuma"
            "engine-napcat" -> "正在切换到 NapCat"
            "napcat-reset-login" -> "正在准备 NapCat 重新登录"
            else -> "正在执行"
        }
        _ui.update { it.copy(actionBusy = true, actionLabel = label, transientMessage = "", errorMessage = "") }
        viewModelScope.launch {
            val result = repository.queue(action)
            if (!result.ok) {
                _ui.update {
                    it.copy(
                        actionBusy = false,
                        actionLabel = "",
                        errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "操作没有提交成功" } }
                    )
                }
                return@launch
            }
            if (result.stdout.lineSequence().any { it.startsWith("QUEUED|busy|") }) {
                refreshStatus(true)
                _ui.update {
                    it.copy(
                        actionBusy = false,
                        actionLabel = "",
                        transientMessage = "已有操作正在执行，状态会自动更新"
                    )
                }
                return@launch
            }
            _ui.update { it.copy(transientMessage = "操作已提交，正在验证结果") }
            for (attempt in 0 until 14) {
                refreshStatus(true)
                if (!_ui.value.status.actionRunning && !_ui.value.status.stackStarting && attempt >= 2) break
                delay(1150)
            }
            _ui.update { it.copy(actionBusy = false, actionLabel = "") }
            refreshStatus(true)
            if (action.startsWith("engine-")) {
                _ui.update { it.copy(transientMessage = "QQ 运行方式已切换并完成状态检查") }
                selectLogCategory(LogCategory.QQ)
            }
        }
    }

    fun setUserFeature(feature: String, enabled: Boolean) {
        if (_ui.value.actionBusy || _ui.value.status.actionRunning) return
        val label = when (feature) {
            "autostart" -> if (enabled) "正在开启开机自动上线" else "正在关闭开机自动上线"
            "watchdog" -> if (enabled) "正在开启异常自动恢复" else "正在关闭异常自动恢复"
            "rescue" -> if (enabled) "正在开启严重异常救援" else "正在关闭严重异常救援"
            "message_guard" -> if (enabled) "正在开启消息链保活" else "正在关闭消息链保活"
            else -> "正在更新设置"
        }
        _ui.update { it.copy(actionBusy = true, actionLabel = label, errorMessage = "", transientMessage = "") }
        viewModelScope.launch {
            val result = repository.setUserFeature(feature, enabled)
            if (!result.ok) {
                _ui.update { it.copy(actionBusy = false, actionLabel = "", errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "设置没有保存" } }) }
                return@launch
            }
            refreshStatus(true)
            _ui.update { it.copy(actionBusy = false, actionLabel = "", transientMessage = "设置已更新") }
        }
    }

    fun disableAllUserAutomation() {
        if (_ui.value.actionBusy || _ui.value.status.actionRunning) return
        _ui.update { it.copy(actionBusy = true, actionLabel = "正在关闭自动运行", errorMessage = "", transientMessage = "") }
        viewModelScope.launch {
            val result = repository.disableAllUserAutomation()
            if (!result.ok) {
                _ui.update { it.copy(actionBusy = false, actionLabel = "", errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "自动运行设置没有完全关闭" } }) }
                return@launch
            }
            refreshStatus(true)
            _ui.update { it.copy(actionBusy = false, actionLabel = "", transientMessage = "自动运行与自动恢复已关闭") }
        }
    }

    fun setDownloadSource(profile: String) {
        if (_ui.value.actionBusy || _ui.value.status.actionRunning || profile == _ui.value.status.downloadSource) return
        _ui.update { it.copy(actionBusy = true, actionLabel = "正在切换资源来源", errorMessage = "", transientMessage = "") }
        viewModelScope.launch {
            val result = repository.setDownloadSource(profile)
            if (!result.ok) {
                _ui.update { it.copy(actionBusy = false, actionLabel = "", errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "资源来源没有保存" } }) }
                return@launch
            }
            refreshStatus(true)
            _ui.update { it.copy(actionBusy = false, actionLabel = "", transientMessage = "资源来源已更新") }
        }
    }

    fun runHealthCheck() {
        if (_ui.value.healthCheckBusy) return
        _ui.update { it.copy(healthCheckBusy = true, healthCheckMessage = "正在检查机器人状态…", errorMessage = "") }
        viewModelScope.launch {
            val result = repository.healthCheck()
            refreshStatus(true)
            val status = _ui.value.status
            val message = when {
                !result.ok && !status.coreReady -> "运行环境还没有准备完整。先打开“环境”，执行检查与修复；只有修复无效时才需要重新安装。"
                !status.coreReady -> "运行环境需要处理。它负责让机器人和 QQ 在设备上正常运行；先到“环境”检查并修复。"
                !status.astrbotUp -> "机器人服务目前没有运行。环境已经正常，可以直接启动机器人。"
                status.qqNeedsLogin -> "机器人服务已经启动，但 QQ 还没有登录。完成扫码后，消息才能交给机器人处理。"
                status.oneBotAuthFailed -> "QQ 已登录，但消息还不能交给机器人。可以自动修复消息连接。"
                status.qqOnline && status.oneBotConnected <= 0 -> "QQ 已登录，正在等待消息连接完成。通常不需要操作；如果长时间没有完成，再使用“帮我修复”。"
                status.oneBotConnected > 0 -> "检查完成：机器人、QQ 和消息连接都已就绪，可以正常收发消息。"
                !result.ok -> "检查没有完全完成，但没有发现需要重装环境的证据。可以先重启机器人；仍异常时再导出诊断包。"
                else -> "检查完成：当前没有发现明确的阻断问题。可以按总览中的“下一步”继续。"
            }
            _ui.update { it.copy(healthCheckBusy = false, healthCheckMessage = message) }
        }
    }

    fun rebootDevice() {
        if (_ui.value.actionBusy) return
        _ui.update { it.copy(actionBusy = true, actionLabel = "正在重启设备", errorMessage = "") }
        viewModelScope.launch {
            val result = repository.rebootDevice()
            if (!result.ok) {
                _ui.update {
                    it.copy(
                        actionBusy = false,
                        actionLabel = "",
                        errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "重启命令没有成功提交" } }
                    )
                }
            }
        }
    }

    fun startExport(mode: String = "redacted") {
        if (_ui.value.exportState.running) return
        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            val safeMode = if (mode == "raw") "raw" else "redacted"
            _ui.update {
                it.copy(
                    exportState = DiagnosticExportState(state = "queued", phase = "queued", percent = 1, detail = "正在准备诊断包", mode = safeMode, running = true),
                    transientMessage = if (safeMode == "redacted") "正在生成脱敏诊断包" else "正在生成完整诊断包",
                    errorMessage = ""
                )
            }
            repository.exportStart(safeMode).onFailure { error ->
                _ui.update { it.copy(exportState = DiagnosticExportState(mode = safeMode), errorMessage = "诊断导出失败：${error.message ?: "未知错误"}") }
                return@launch
            }
            repeat(240) {
                val result = repository.exportStatus()
                result.onSuccess { state -> _ui.update { it.copy(exportState = state) } }
                    .onFailure { error ->
                        _ui.update { it.copy(errorMessage = "读取导出进度失败：${error.message ?: "未知错误"}") }
                        return@launch
                    }
                val state = _ui.value.exportState
                if (!state.running && state.state !in setOf("queued", "running")) {
                    _ui.update {
                        it.copy(
                            transientMessage = if (state.finished) {
                                if (state.path.isNotBlank()) "诊断包已保存：${state.path}" else "诊断包已生成"
                            } else if (state.state == "cancelled") "诊断导出已取消" else "诊断导出已结束"
                        )
                    }
                    return@launch
                }
                delay(1500)
            }
            _ui.update { it.copy(errorMessage = "诊断导出耗时较长，请稍后刷新查看") }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            val result = repository.exportCancel()
            if (!result.ok) {
                _ui.update { it.copy(errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "取消导出失败" } }) }
            }
            refreshExportState()
        }
    }

    fun openConsole(target: ConsoleTarget) {
        if (target == ConsoleTarget.QQ_LOGIN) {
            openQqLogin()
            return
        }
        loginJob?.cancel()
        loginJob = null
        loginFrameJob?.cancel()
        loginFrameJob = null
        val engine = _ui.value.status.qqEngine
        val title = when (target) {
            ConsoleTarget.ASTRBOT -> "AstrBot 控制台"
            ConsoleTarget.QQ -> if (engine == "snowluma") "SnowLuma 控制台" else "NapCat 控制台"
            ConsoleTarget.QQ_LOGIN -> "QQ 扫码登录"
        }
        val requestId = System.nanoTime()
        _ui.update {
            it.copy(
                destination = ControlDestination.CONSOLE,
                console = ConsoleState(target = target, title = title, loading = true, requestId = requestId, phase = "loading", detail = "正在连接本机控制台"),
                errorMessage = ""
            )
        }
        syncLogPolling()
        viewModelScope.launch {
            val consoleKind = if (target == ConsoleTarget.ASTRBOT) "astrbot" else engine
            val readinessLabel = if (target == ConsoleTarget.ASTRBOT) "AstrBot WebUI" else if (engine == "snowluma") "SnowLuma 页面" else "NapCat 页面"
            suspend fun waitUntilConsoleReady(): Boolean {
                fun ready(status: RuntimeStatus): Boolean = when (target) {
                    ConsoleTarget.ASTRBOT -> status.astrbotWebReady
                    ConsoleTarget.QQ -> status.activeQqWebReady
                    else -> true
                }
                val first = _ui.value.status
                if (ready(first)) return true
                repeat(8) { attempt ->
                    if (_ui.value.console.requestId != requestId) return false
                    _ui.update { state ->
                        if (state.console.requestId != requestId) state
                        else state.copy(
                            console = state.console.copy(
                                loading = true,
                                phase = "warming",
                                detail = "$readinessLabel 正在启动，等待本机页面就绪（${attempt + 1}/8）"
                            )
                        )
                    }
                    val snapshot = repository.status(forceLive = attempt % 4 == 3).getOrNull()
                    if (snapshot != null) {
                        _ui.update { state -> state.copy(status = snapshot) }
                        if (ready(snapshot)) return true
                    }
                    delay(if (attempt < 4) 250 else 450)
                }
                return ready(_ui.value.status)
            }
            val ready = waitUntilConsoleReady()
            if (_ui.value.console.requestId != requestId) return@launch
            if (!ready) {
                // Do not turn a status-cache delay into a synthetic page failure.
                // Load the loopback URL once and let WebView's real HTTP/network
                // callbacks decide whether the service is reachable.
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(console = state.console.copy(
                        loading = true,
                        phase = "loading",
                        detail = "$readinessLabel 尚未报告 ready，正在直接尝试本机页面"
                    ))
                }
            }
            val urlResult = repository.webUrl(consoleKind, "admin")
            val consoleUrl = urlResult.getOrNull()
            if (consoleUrl.isNullOrBlank()) {
                val error = urlResult.exceptionOrNull()
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(console = state.console.copy(
                        loading = false,
                        error = error?.message ?: "控制台暂不可用",
                        phase = "failed"
                    ))
                }
                return@launch
            }

            if (target == ConsoleTarget.ASTRBOT) {
                // Publish the URL immediately. The HTTP/static-resource probe is
                // diagnostic only and must never delay construction of the real
                // WebView. This also keeps a slow root-shell probe from looking like
                // an app-side white screen.
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(console = state.console.copy(
                        url = consoleUrl,
                        loading = true,
                        phase = "ready",
                        detail = "正在打开 AstrBot；同时检查前端资源",
                        error = ""
                    ))
                }
                val probeResult = repository.astrbotWebProbe()
                val probeDetail = probeResult.getOrNull().orEmpty()
                val probeHint = probeResult.exceptionOrNull()?.message.orEmpty()
                _ui.update { state ->
                    if (state.console.requestId != requestId || state.console.error.isNotBlank()) state
                    else state.copy(console = state.console.copy(
                        detail = probeDetail.ifBlank {
                            if (probeHint.isNotBlank()) "AstrBot 资源检查未完全通过；内嵌页面仍继续加载" else state.console.detail
                        }
                    ))
                }
            } else {
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(console = state.console.copy(
                        url = consoleUrl,
                        loading = true,
                        error = "",
                        phase = "ready",
                        detail = ""
                    ))
                }
            }
        }
    }

    fun openQqLogin() {
        loginJob?.cancel()
        loginFrameJob?.cancel()
        loginFrameJob = null
        val engine = _ui.value.status.qqEngine
        val wasDesktop = _ui.value.console.qrDesktopMode
        val requestId = System.nanoTime()
        _ui.update {
            it.copy(
                destination = ControlDestination.CONSOLE,
                console = ConsoleState(
                    target = ConsoleTarget.QQ_LOGIN,
                    title = "QQ 扫码登录",
                    loading = true,
                    requestId = requestId,
                    phase = "preparing",
                    detail = if (engine == "snowluma") "正在准备 QQ 登录窗口与原生扫码画面" else "正在准备 NapCat 登录页面",
                    qrCompatAttempted = false,
                    qrFrameVerified = false,
                    qrImageBytes = ByteArray(0),
                    qrImageWidth = 0,
                    qrImageHeight = 0,
                    qrDesktopMode = false,
                    qrExpired = false,
                    qrRefreshBusy = false,
                    qrRefreshAvailableAtMs = 0L
                ),
                errorMessage = ""
            )
        }
        syncLogPolling()
        loginJob = viewModelScope.launch {
            if (engine == "snowluma" && wasDesktop) repository.qqLoginDesktopStop()
            repeat(90) { attempt ->
                val result = repository.qqLoginSession(engine)
                var done = false
                var startNativeFrames = false
                result.onSuccess { session ->
                    _ui.update { state ->
                        if (state.console.requestId != requestId) state
                        else if (session.failed) {
                            done = true
                            state.copy(console = state.console.copy(loading = false, error = session.detail.ifBlank { "扫码准备失败" }, phase = "failed", detail = session.detail))
                        } else if (session.complete) {
                            done = true
                            state.copy(console = state.console.copy(loading = false, error = "", phase = "complete", detail = session.detail.ifBlank { "QQ 已登录" }, qrFrameVerified = true))
                        } else if (session.ready) {
                            done = true
                            startNativeFrames = engine == "snowluma"
                            state.copy(console = state.console.copy(
                                url = if (engine == "snowluma") "" else session.url,
                                loading = true,
                                error = "",
                                phase = if (engine == "snowluma") "capturing" else "ready",
                                detail = if (engine == "snowluma") "QQ 登录窗口已出现，正在读取原生画面" else session.detail.ifBlank { "登录页面已就绪" },
                                qrFrameVerified = engine != "snowluma",
                                qrDesktopMode = false
                            ))
                        } else {
                            state.copy(console = state.console.copy(url = "", loading = true, error = "", phase = session.state, detail = loginDetail(session.state, session.detail, attempt)))
                        }
                    }
                }.onFailure { error ->
                    done = true
                    _ui.update { state ->
                        if (state.console.requestId != requestId) state
                        else state.copy(console = state.console.copy(loading = false, error = error.message ?: "扫码准备失败", phase = "failed"))
                    }
                }
                if (startNativeFrames) startNativeQqFramePolling(requestId)
                if (done || _ui.value.console.requestId != requestId) return@launch
                delay(if (attempt < 12) 450 else 800)
            }
            _ui.update { state ->
                if (state.console.requestId != requestId) state
                else state.copy(console = state.console.copy(loading = false, error = "等待 QQ 登录窗口超时，请重试", phase = "failed"))
            }
        }
    }

    private fun startNativeQqFramePolling(requestId: Long) {
        loginFrameJob?.cancel()
        loginFrameJob = viewModelScope.launch {
            var attempt = 0
            while (active) {
                val snapshot = _ui.value
                if (snapshot.console.requestId != requestId || snapshot.console.target != ConsoleTarget.QQ_LOGIN || snapshot.console.qrDesktopMode) return@launch
                if (snapshot.console.qrRefreshBusy) {
                    delay(220)
                    continue
                }
                if (snapshot.status.qqOnline || snapshot.status.oneBotConnected > 0) {
                    _ui.update { state ->
                        if (state.console.requestId != requestId) state else state.copy(
                            console = state.console.copy(
                                loading = false,
                                phase = "complete",
                                detail = "QQ 已登录，正在等待 OneBot 完成连接",
                                qrFrameVerified = true
                            )
                        )
                    }
                    return@launch
                }

                if (attempt % 4 == 0) {
                    val session = repository.qqLoginSession("snowluma").getOrNull()
                    if (session?.complete == true) {
                        _ui.update { state ->
                            if (state.console.requestId != requestId) state else state.copy(
                                console = state.console.copy(
                                    loading = false,
                                    phase = "complete",
                                    detail = session.detail.ifBlank { "QQ 已登录" },
                                    qrFrameVerified = true
                                )
                            )
                        }
                        return@launch
                    }
                }

                repository.qqLoginFrame().onSuccess { frame ->
                    _ui.update { state ->
                        if (state.console.requestId != requestId || state.console.qrDesktopMode) state
                        else when {
                            frame.complete -> state.copy(console = state.console.copy(loading = false, phase = "complete", detail = frame.detail.ifBlank { "QQ 已登录" }, qrFrameVerified = true))
                            frame.ready -> state.copy(console = state.console.copy(
                                loading = false,
                                error = "",
                                phase = "ready",
                                detail = if (frame.expired) "二维码已过期，请手动刷新一次" else frame.detail.ifBlank { "QQ 登录画面已更新" },
                                qrFrameVerified = !frame.expired,
                                qrImageBytes = frame.png,
                                qrImageWidth = frame.width,
                                qrImageHeight = frame.height,
                                qrExpired = frame.expired
                            ))
                            frame.failed && state.console.qrImageBytes.isEmpty() && attempt >= 6 -> state.copy(console = state.console.copy(
                                loading = false,
                                phase = "failed",
                                error = frame.detail.ifBlank { "无法读取 QQ 登录画面" }
                            ))
                            else -> state.copy(console = state.console.copy(
                                loading = state.console.qrImageBytes.isEmpty(),
                                phase = if (state.console.qrImageBytes.isEmpty()) "capturing" else state.console.phase,
                                detail = frame.detail.ifBlank { "正在等待 QQ 登录画面刷新" }
                            ))
                        }
                    }
                }.onFailure { error ->
                    _ui.update { state ->
                        if (state.console.requestId != requestId || state.console.qrImageBytes.isNotEmpty()) state
                        else if (attempt >= 8) state.copy(console = state.console.copy(
                            loading = false,
                            phase = "failed",
                            error = "读取 QQ 登录画面失败：${error.message ?: "未知错误"}"
                        )) else state.copy(console = state.console.copy(detail = "正在重试读取 QQ 登录画面"))
                    }
                }
                attempt += 1
                delay(if (_ui.value.console.qrImageBytes.isEmpty()) 420 else 900)
            }
        }
    }

    private fun resumeQqLoginPollingIfNeeded() {
        if (!active) return
        val state = _ui.value
        val console = state.console
        if (console.target != ConsoleTarget.QQ_LOGIN || state.status.qqEngine != "snowluma" || console.qrDesktopMode || console.phase == "complete") return
        if (console.requestId == 0L) {
            openQqLogin()
            return
        }
        if (console.qrImageBytes.isNotEmpty() || console.phase in setOf("capturing", "ready")) {
            startNativeQqFramePolling(console.requestId)
        } else if (loginJob?.isActive != true) {
            openQqLogin()
        }
    }

    fun openQqDesktop() {
        val state = _ui.value
        if (state.console.target != ConsoleTarget.QQ_LOGIN || state.status.qqEngine != "snowluma") return
        loginFrameJob?.cancel()
        loginFrameJob = null
        val requestId = state.console.requestId
        _ui.update { current ->
            if (current.console.requestId != requestId) current else current.copy(
                console = current.console.copy(
                    url = "",
                    loading = true,
                    error = "",
                    phase = "desktop-starting",
                    detail = "正在启动高级完整 QQ 桌面",
                    qrDesktopMode = true
                )
            )
        }
        viewModelScope.launch {
            repository.qqLoginDesktopSession().onSuccess { session ->
                _ui.update { current ->
                    if (current.console.requestId != requestId) current
                    else if (session.failed || session.url.isBlank()) current.copy(console = current.console.copy(
                        loading = false,
                        phase = "failed",
                        error = session.detail.ifBlank { "完整 QQ 桌面启动失败" }
                    )) else current.copy(console = current.console.copy(
                        url = session.url,
                        loading = true,
                        error = "",
                        phase = "desktop",
                        detail = "高级完整 QQ 桌面已连接",
                        qrDesktopMode = true
                    ))
                }
            }.onFailure { error ->
                _ui.update { current ->
                    if (current.console.requestId != requestId) current else current.copy(console = current.console.copy(
                        loading = false,
                        phase = "failed",
                        error = "完整 QQ 桌面启动失败：${error.message ?: "未知错误"}"
                    ))
                }
            }
        }
    }

    fun refreshQqLoginCode() {
        val snapshot = _ui.value
        val now = System.currentTimeMillis()
        if (snapshot.console.target != ConsoleTarget.QQ_LOGIN || snapshot.status.qqEngine != "snowluma") return
        if (snapshot.console.qrDesktopMode || !snapshot.console.qrExpired || snapshot.console.qrRefreshBusy || now < snapshot.console.qrRefreshAvailableAtMs) return
        val requestId = snapshot.console.requestId
        qrRefreshJob?.cancel()
        _ui.update { state ->
            if (state.console.requestId != requestId) state
            else state.copy(console = state.console.copy(
                qrRefreshBusy = true,
                detail = "正在请求 QQ 刷新二维码；只发送一次用户主动触发的点击"
            ))
        }
        qrRefreshJob = viewModelScope.launch {
            val availableAt = System.currentTimeMillis() + 30_000L
            repository.qqLoginRefreshCode().onSuccess { detail ->
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(console = state.console.copy(
                        qrRefreshAvailableAtMs = availableAt,
                        qrExpired = true,
                        detail = detail.ifBlank { "已请求 QQ 刷新二维码，正在等待新画面" }
                    ))
                }
                // Keep the normal frame poller paused briefly so a stale pre-click
                // capture cannot overwrite the refresh state. After this delay the
                // single poller resumes and becomes the only writer of frame data.
                delay(1000)
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(console = state.console.copy(qrRefreshBusy = false))
                }
                if (active && loginFrameJob?.isActive != true) startNativeQqFramePolling(requestId)
            }.onFailure { error ->
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(
                        console = state.console.copy(
                            qrRefreshBusy = false,
                            qrRefreshAvailableAtMs = availableAt,
                            detail = error.message ?: "二维码刷新没有成功，请稍后再试"
                        ),
                        transientMessage = "刷新二维码失败：${error.message ?: "未知错误"}"
                    )
                }
            }
        }
    }

    fun openCurrentConsoleExternally() {
        val url = _ui.value.console.url
        if (url.isBlank()) return
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            getApplication<Application>().startActivity(intent)
        }.onFailure { error ->
            _ui.update { it.copy(transientMessage = "系统浏览器无法打开：${error.message ?: "未知错误"}") }
        }
    }

    fun recoverBlankQqLogin() {
        openQqDesktop()
    }

    fun confirmQqLoginFrame() {
        _ui.update { current ->
            if (current.console.target != ConsoleTarget.QQ_LOGIN) current
            else current.copy(console = current.console.copy(loading = false, error = "", phase = "ready", qrFrameVerified = true))
        }
    }

    fun retryConsole() {
        when (_ui.value.console.target) {
            ConsoleTarget.QQ_LOGIN -> openQqLogin()
            else -> openConsole(_ui.value.console.target)
        }
    }

    fun setConsoleLoading(loading: Boolean) {
        if (_ui.value.console.loading == loading) return
        _ui.update { it.copy(console = it.console.copy(loading = loading)) }
    }

    fun setConsoleError(message: String) {
        if (_ui.value.console.error == message && !_ui.value.console.loading) return
        _ui.update { it.copy(console = it.console.copy(loading = false, error = message, phase = "failed")) }
    }

    private fun loginDetail(state: String, detail: String, attempt: Int): String {
        if (detail.isNotBlank()) return detail
        return when (state) {
            "installing" -> "首次使用正在补齐原生截图组件"
            "starting" -> if (attempt < 4) "正在启动 QQ 登录环境" else "正在等待 QQ 登录窗口出现"
            "capturing" -> "QQ 登录窗口已出现，正在读取二维码画面"
            "rendering" -> "正在启动完整 QQ 桌面"
            "idle" -> "正在唤醒 QQ 登录窗口"
            else -> "正在准备 QQ 登录画面"
        }
    }

    private suspend fun refreshStatus(forceLive: Boolean) {
        val result = repository.status(forceLive)
        result.onSuccess { status ->
            _ui.update { state ->
                val sameVisibleStatus = state.status.copy(statusEpoch = 0L) == status.copy(statusEpoch = 0L)
                val nextError = if (state.errorMessage.startsWith("状态读取失败")) "" else state.errorMessage
                if (!state.loading && sameVisibleStatus && nextError == state.errorMessage) {
                    state
                } else {
                    state.copy(
                        loading = false,
                        status = status,
                        lastRefreshEpoch = System.currentTimeMillis() / 1000,
                        errorMessage = nextError
                    )
                }
            }
        }.onFailure { error ->
            _ui.update {
                it.copy(
                    loading = false,
                    errorMessage = "状态读取失败：${error.message ?: "未知错误"}"
                )
            }
        }
    }

    private suspend fun loadLogSources() {
        repository.logSources().onSuccess { raw ->
            val sources = raw.map { it.copy(category = categorize(it)) }
            val ordered = sources.sortedWith(compareBy<LogSource>({ it.category.ordinal }, { sourceRank(it) }, { it.label }))
            _ui.update { state ->
                val selected = if (ordered.any { it.id == state.selectedLogId }) state.selectedLogId else ordered.firstOrNull()?.id.orEmpty()
                val selectedCategory = ordered.firstOrNull { it.id == selected }?.category ?: LogCategory.OVERVIEW
                state.copy(logSources = ordered, selectedLogId = selected, logCategory = selectedCategory)
            }
            if (_ui.value.destination == ControlDestination.OPERATIONS && _ui.value.operationsSection == OperationsSection.LOGS) refreshSelectedLog()
        }
    }

    private fun categorize(source: LogSource): LogCategory {
        val value = "${source.id} ${source.label}".lowercase()
        return when {
            source.id == "health" || value.contains("健康") || value.contains("summary") -> LogCategory.OVERVIEW
            value.contains("astrbot") || value.contains("插件") || value.contains("plugin") || value.contains("model") -> LogCategory.ASTRBOT
            listOf("napcat", "snowluma", "onebot", "qq", "bridge", "xvfb", "novnc").any(value::contains) -> LogCategory.QQ
            else -> LogCategory.SYSTEM
        }
    }

    private fun sourceRank(source: LogSource): Int = when (source.id) {
        "health" -> 0
        "astrbot" -> 0
        "napcat", "snowluma" -> 0
        "action" -> 0
        "boot" -> 1
        else -> 5
    }

    private fun preferredSource(category: LogCategory): String = when (category) {
        LogCategory.OVERVIEW -> "health"
        LogCategory.ASTRBOT -> "astrbot"
        LogCategory.QQ -> if (_ui.value.status.qqEngine == "snowluma") "snowluma" else "napcat"
        LogCategory.SYSTEM -> "action"
    }

    private fun syncLogPolling() {
        logJob?.cancel()
        logJob = null
        if (!active || _ui.value.destination != ControlDestination.OPERATIONS || _ui.value.operationsSection != OperationsSection.LOGS) return
        logJob = viewModelScope.launch {
            refreshSelectedLog()
            while (active && _ui.value.destination == ControlDestination.OPERATIONS && _ui.value.operationsSection == OperationsSection.LOGS) {
                delay(3000)
                refreshSelectedLog()
            }
        }
    }

    private suspend fun refreshSelectedLog() {
        val id = _ui.value.selectedLogId.ifBlank { "health" }
        _ui.update { it.copy(logLoading = it.logText.isBlank()) }
        repository.log(id, 360).onSuccess { text ->
            if (_ui.value.selectedLogId != id) return@onSuccess
            if (text != _ui.value.logText) {
                val redacted = withContext(Dispatchers.Default) { LogRedactor.redact(text) }
                if (_ui.value.selectedLogId != id) return@onSuccess
                _ui.update { it.copy(logText = text, redactedLogText = redacted, logLoading = false) }
            } else {
                _ui.update { it.copy(logLoading = false) }
            }
        }.onFailure { error ->
            _ui.update { it.copy(logLoading = false, errorMessage = "日志读取失败：${error.message ?: "未知错误"}") }
        }
    }

    private suspend fun refreshExportState() {
        repository.exportStatus().onSuccess { state -> _ui.update { it.copy(exportState = state) } }
    }

    override fun onCleared() {
        stop()
        exportJob?.cancel()
        super.onCleared()
    }
}
