package com.xianaurora.astrbotcontrol.ui

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.ConsoleMessage
import android.webkit.DownloadListener
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.xianaurora.astrbotcontrol.BuildConfig

@Stable
enum class ConsoleWebPresentation {
    STANDARD,
    QR_DESKTOP
}

@Stable
class ConsoleWebController internal constructor() {
    internal var webView: WebView? = null
    var canGoBack by mutableStateOf(false)
        private set
    var canGoForward by mutableStateOf(false)
        private set

    internal fun sync() {
        canGoBack = webView?.canGoBack() == true
        canGoForward = webView?.canGoForward() == true
    }

    fun back() {
        webView?.takeIf { it.canGoBack() }?.goBack()
        sync()
    }

    fun forward() {
        webView?.takeIf { it.canGoForward() }?.goForward()
        sync()
    }

    fun refresh() {
        webView?.reload()
    }
}

@Composable
fun rememberConsoleWebController(): ConsoleWebController = remember { ConsoleWebController() }

/**
 * Intentionally boring WebView wrapper.
 *
 * dev7-dev10 tried to infer a blank SPA/noVNC canvas and automatically clear
 * cache, swap loopback hosts, reload, and rebuild transport. On the target
 * tablet those heuristics could fight a page that was still mounting. dev11
 * follows the platform callbacks for ordinary consoles. AstrBot additionally
 * opts into a bounded fresh-load path because its SPA is upgraded in place: it
 * bypasses stale HTTP cache, checks for a mounted UI after generous grace time,
 * and permits exactly one cache-busted rebuild before surfacing diagnostics.
 */
@Composable
fun EmbeddedConsoleWebView(
    url: String,
    controller: ConsoleWebController,
    modifier: Modifier = Modifier,
    presentation: ConsoleWebPresentation = ConsoleWebPresentation.STANDARD,
    freshLocalContent: Boolean = false,
    onLoadingChanged: (Boolean) -> Unit = {},
    onError: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val latestLoadingChanged by rememberUpdatedState(onLoadingChanged)
    val latestError by rememberUpdatedState(onError)
    var webViewGeneration by remember(presentation, freshLocalContent) { mutableStateOf(0) }
    var rendererRecoveryCount by remember(presentation, freshLocalContent) { mutableStateOf(0) }
    var blankRecoveryCount by remember(presentation, freshLocalContent) { mutableStateOf(0) }
    var lastRequestedUrl by remember(presentation, freshLocalContent, webViewGeneration) { mutableStateOf("") }
    var lastConsoleIssue by remember { mutableStateOf("") }
    var lastSubresourceIssue by remember { mutableStateOf("") }
    var uploadCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = uploadCallback
        uploadCallback = null
        val parsed = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            ?.filter { uri -> uri.scheme == "content" }
            ?.toTypedArray()
            ?.takeIf { it.isNotEmpty() }
        callback?.onReceiveValue(parsed)
    }

    val webView = remember(context, presentation, freshLocalContent, webViewGeneration) {
        WebView(context).apply {
            setBackgroundColor(if (presentation == ConsoleWebPresentation.QR_DESKTOP) 0xFF171A1D.toInt() else android.graphics.Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.allowContentAccess = true
            // AstrBot upgrades its SPA in place. Reusing an old WebView HTTP cache
            // can leave index.html and hashed JS/CSS from different releases, which
            // looks exactly like a healthy 6185 service followed by a white page.
            // Keep QQ/SnowLuma on the normal cache policy; only AstrBot asks for a
            // fresh local load.
            settings.cacheMode = if (presentation == ConsoleWebPresentation.QR_DESKTOP || freshLocalContent) {
                WebSettings.LOAD_NO_CACHE
            } else {
                WebSettings.LOAD_DEFAULT
            }
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = false
            if (Build.VERSION.SDK_INT >= 23) settings.offscreenPreRaster = true
            if (Build.VERSION.SDK_INT >= 26) {
                settings.safeBrowsingEnabled = true
                setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
            }
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)
        }
    }

    DisposableEffect(webView, controller) {
        controller.webView = webView
        onDispose {
            if (controller.webView === webView) controller.webView = null
            uploadCallback?.onReceiveValue(null)
            uploadCallback = null
            webView.stopLoading()
            webView.webChromeClient = null
            webView.webViewClient = WebViewClient()
            webView.destroy()
        }
    }

    BackHandler(enabled = controller.canGoBack) { controller.back() }

    key(webViewGeneration) {
        AndroidView(
            modifier = modifier,
            factory = {
                webView.apply {
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            latestLoadingChanged(newProgress < 100)
                        }

                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                            val message = consoleMessage?.message().orEmpty().trim()
                            val level = consoleMessage?.messageLevel()
                            if (message.isNotBlank() && (level == ConsoleMessage.MessageLevel.ERROR || level == ConsoleMessage.MessageLevel.WARNING)) {
                                val source = consoleMessage?.sourceId().orEmpty().substringAfterLast('/').take(48)
                                val line = consoleMessage?.lineNumber() ?: 0
                                lastConsoleIssue = buildString {
                                    append(message.take(240))
                                    if (source.isNotBlank()) append(" · ").append(source)
                                    if (line > 0) append(':').append(line)
                                }
                            }
                            return true
                        }

                        override fun onShowFileChooser(
                            webView: WebView?,
                            filePathCallback: ValueCallback<Array<Uri>>?,
                            fileChooserParams: FileChooserParams?
                        ): Boolean {
                            uploadCallback?.onReceiveValue(null)
                            uploadCallback = filePathCallback
                            val intent = runCatching { fileChooserParams?.createIntent() }.getOrNull()
                                ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                    addCategory(Intent.CATEGORY_OPENABLE)
                                    type = "*/*"
                                }
                            return runCatching {
                                fileLauncher.launch(intent)
                                true
                            }.getOrElse {
                                uploadCallback?.onReceiveValue(null)
                                uploadCallback = null
                                latestError("无法打开文件选择器：${it.message ?: "未知错误"}")
                                false
                            }
                        }
                    }

                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val target = request?.url ?: return false
                            if (isLocalConsoleUri(target)) return false
                            return runCatching {
                                context.startActivity(Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                true
                            }.getOrElse {
                                latestError("外部链接无法打开")
                                true
                            }
                        }

                        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                            latestLoadingChanged(true)
                            lastConsoleIssue = ""
                            lastSubresourceIssue = ""
                            controller.sync()
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            if (presentation == ConsoleWebPresentation.QR_DESKTOP) {
                                view?.evaluateJavascript(QR_DESKTOP_POLISH_JS, null)
                            }
                            latestLoadingChanged(false)
                            rendererRecoveryCount = 0
                            controller.sync()

                            // A successful HTTP main frame is not enough for AstrBot: a stale
                            // hashed bundle or a WebView-side JS failure can still leave an
                            // entirely white SPA. Wait well past onPageFinished, then check only
                            // whether real UI mounted. One cache-busted rebuild is allowed; a
                            // second blank result becomes an explicit error instead of an endless
                            // reload loop.
                            if (freshLocalContent && presentation == ConsoleWebPresentation.STANDARD && view != null) {
                                scheduleAstrBotMountCheck(
                                    view = view,
                                    requestedUrl = lastRequestedUrl.ifBlank { url.orEmpty() },
                                    controller = controller,
                                    recoveryCount = { blankRecoveryCount },
                                    markRecovered = { blankRecoveryCount = 1 },
                                    consoleIssue = { lastConsoleIssue },
                                    subresourceIssue = { lastSubresourceIssue },
                                    onLoadingChanged = latestLoadingChanged,
                                    onError = latestError
                                )
                            }
                        }

                        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                            rendererRecoveryCount += 1
                            latestLoadingChanged(true)
                            if (rendererRecoveryCount > 1) {
                                latestError(
                                    if (detail?.didCrash() == true)
                                        "控制台渲染进程连续崩溃，WebView 已重建。"
                                    else
                                        "控制台渲染进程被系统回收，WebView 已重建。"
                                )
                            }
                            if (controller.webView === view) controller.webView = null
                            webViewGeneration += 1
                            return true
                        }

                        override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                            controller.sync()
                        }

                        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                            if (request?.isForMainFrame == true) {
                                latestLoadingChanged(false)
                                val hint = lastConsoleIssue.takeIf { it.isNotBlank() }?.let { " · JS：$it" }.orEmpty()
                                latestError("控制台连接失败：${error?.description ?: "无法访问本机服务"}$hint")
                            } else if (freshLocalContent && request != null && isLocalConsoleUri(request.url) && isCoreFrontendAsset(request.url)) {
                                latestLoadingChanged(false)
                                latestError("AstrBot 前端资源加载失败：${request.url.encodedPath.orEmpty().takeLast(120)} · ${error?.description ?: "网络错误"}")
                            }
                        }

                        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                            val status = errorResponse?.statusCode ?: 0
                            if (request?.isForMainFrame == true && status >= 400) {
                                latestLoadingChanged(false)
                                val hint = lastConsoleIssue.takeIf { it.isNotBlank() }?.let { " · JS：$it" }.orEmpty()
                                latestError("控制台 HTTP $status：${errorResponse?.reasonPhrase.orEmpty().ifBlank { "本机服务返回错误" }}$hint")
                            } else if (status >= 400 && request != null && isLocalConsoleUri(request.url)) {
                                val resource = request.url.encodedPath.orEmpty().takeLast(120)
                                if (lastSubresourceIssue.isBlank()) lastSubresourceIssue = "HTTP $status $resource"
                                if (freshLocalContent && isCoreFrontendAsset(request.url)) {
                                    latestLoadingChanged(false)
                                    latestError("AstrBot 前端资源 HTTP $status：$resource")
                                }
                            }
                        }
                    }
                    setDownloadListener(localDownloadListener(context))
                }
            },
            update = { view ->
                // Load only when the URL requested by Compose actually changes.
                // Never compare against view.url here: AstrBot is an SPA and may
                // legitimately change its hash/history after mounting. Comparing
                // view.url to the original root caused every Compose recomposition
                // to send it back to '/', creating an invisible reload loop.
                if (url.isNotBlank() && lastRequestedUrl != url) {
                    lastRequestedUrl = url
                    blankRecoveryCount = 0
                    if (freshLocalContent) {
                        view.loadUrl(url, ASTRBOT_NO_CACHE_HEADERS)
                    } else {
                        view.loadUrl(url)
                    }
                }
                if (presentation == ConsoleWebPresentation.QR_DESKTOP && url.isNotBlank()) {
                    view.evaluateJavascript(QR_DESKTOP_POLISH_JS, null)
                }
                controller.sync()
            }
        )
    }
}

private val ASTRBOT_NO_CACHE_HEADERS = mapOf(
    "Cache-Control" to "no-cache, no-store, max-age=0",
    "Pragma" to "no-cache"
)

private fun scheduleAstrBotMountCheck(
    view: WebView,
    requestedUrl: String,
    controller: ConsoleWebController,
    recoveryCount: () -> Int,
    markRecovered: () -> Unit,
    consoleIssue: () -> String,
    subresourceIssue: () -> String,
    onLoadingChanged: (Boolean) -> Unit,
    onError: (String) -> Unit
) {
    if (requestedUrl.isBlank()) return
    val firstDelay = if (recoveryCount() == 0) 2600L else 3400L
    view.postDelayed({
        if (controller.webView !== view) return@postDelayed
        view.evaluateJavascript(ASTRBOT_MOUNT_PROBE_JS) { firstResult ->
            if (controller.webView !== view || decodeJsString(firstResult).startsWith("ok|")) return@evaluateJavascript
            // Give slow devices a second grace window before deciding the SPA is
            // genuinely blank. This is intentionally not the old fixed 4.5 s
            // failure probe and it never loops indefinitely.
            view.postDelayed({
                if (controller.webView !== view) return@postDelayed
                view.evaluateJavascript(ASTRBOT_MOUNT_PROBE_JS) { secondResult ->
                    if (controller.webView !== view) return@evaluateJavascript
                    val decoded = decodeJsString(secondResult)
                    if (decoded.startsWith("ok|")) return@evaluateJavascript
                    if (recoveryCount() == 0) {
                        markRecovered()
                        onLoadingChanged(true)
                        view.settings.cacheMode = WebSettings.LOAD_NO_CACHE
                        view.loadUrl(withAstrBotCacheBuster(requestedUrl), ASTRBOT_NO_CACHE_HEADERS)
                    } else {
                        val hints = buildList {
                            consoleIssue().takeIf { it.isNotBlank() }?.let { add("JS：$it") }
                            subresourceIssue().takeIf { it.isNotBlank() }?.let { add("资源：$it") }
                            decoded.takeIf { it.isNotBlank() }?.let { add("挂载：$it") }
                            WebView.getCurrentWebViewPackage()?.let { add("WebView：${it.packageName} ${it.versionName}") }
                        }.joinToString(" · ")
                        onError(
                            "AstrBot 已连接到本机服务，但页面连续两次没有渲染出界面。已自动绕过前端缓存重载 1 次" +
                                if (hints.isBlank()) "。" else " · $hints"
                        )
                    }
                }
            }, 3000L)
        }
    }, firstDelay)
}

private fun withAstrBotCacheBuster(url: String): String {
    val separator = if ('?' in url) '&' else '?'
    return "$url${separator}acc_fresh=${System.currentTimeMillis()}"
}

private fun decodeJsString(value: String?): String {
    val raw = value.orEmpty()
    if (raw.length >= 2 && raw.first() == '"' && raw.last() == '"') {
        return raw.substring(1, raw.length - 1)
            .replace("\\n", " ")
            .replace("\\r", " ")
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
    }
    return raw
}

private fun isCoreFrontendAsset(uri: Uri): Boolean {
    val path = uri.encodedPath.orEmpty().lowercase()
    return path.endsWith(".js") || path.endsWith(".mjs") || path.endsWith(".css")
}

private val ASTRBOT_MOUNT_PROBE_JS = """
(function() {
  try {
    var body = document.body;
    if (!body) return 'blank|no-body';
    var root = document.querySelector('#app, #root, [data-v-app]') || body;
    var text = ((root.innerText || root.textContent || '') + '').trim();
    var nodes = root.querySelectorAll('*:not(script):not(style):not(link):not(meta):not(noscript)').length;
    var rect = root.getBoundingClientRect ? root.getBoundingClientRect() : {width:0,height:0};
    var visual = root.querySelector('canvas, img, svg, video, input, button, [role="button"], [class*="card"], [class*="menu"], [class*="layout"]');
    var mounted = (text.length >= 2 || nodes >= 4 || !!visual) && (rect.width > 2 || rect.height > 2 || root === body);
    return (mounted ? 'ok|' : 'blank|') + 'text=' + text.length + ',nodes=' + nodes + ',size=' + Math.round(rect.width) + 'x' + Math.round(rect.height);
  } catch (e) {
    return 'blank|probe=' + ((e && e.message) ? e.message : 'error');
  }
})();
""".trimIndent()

private val QR_DESKTOP_POLISH_JS = """
(function() {
  try {
    var id = 'astrbot-qr-polish';
    var style = document.getElementById(id);
    if (!style) {
      style = document.createElement('style');
      style.id = id;
      style.textContent = `
        html, body { margin:0 !important; padding:0 !important; width:100% !important; height:100% !important; overflow:hidden !important; background:#171a1d !important; }
        #top_bar, #status_bar, #sendCtrlAltDelButton, #noVNC_status_bar, #noVNC_control_bar_anchor,
        #noVNC_control_bar, #noVNC_mobile_buttons, .noVNC_status, .noVNC_logo { display:none !important; }
        canvas { max-width:100vw !important; max-height:100vh !important; visibility:visible !important; opacity:1 !important; }
      `;
      (document.head || document.documentElement).appendChild(style);
    }
  } catch (e) {}
})();
""".trimIndent()

private fun isLocalConsoleUri(uri: Uri): Boolean {
    val host = uri.host?.lowercase().orEmpty()
    return uri.scheme in setOf("http", "https") && host in setOf("127.0.0.1", "localhost", "::1")
}

private fun localDownloadListener(context: Context) = DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
    if (url.isNullOrBlank()) return@DownloadListener
    val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return@DownloadListener
    if (!isLocalConsoleUri(uri)) return@DownloadListener
    runCatching {
        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        val request = DownloadManager.Request(uri)
            .setTitle(fileName)
            .setDescription("AstrBot Control Center")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
        if (!mimeType.isNullOrBlank()) request.setMimeType(mimeType)
        if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
        CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }?.let { request.addRequestHeader("Cookie", it) }
        if (Build.VERSION.SDK_INT >= 29) {
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        } else {
            request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
        }
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    }
}
