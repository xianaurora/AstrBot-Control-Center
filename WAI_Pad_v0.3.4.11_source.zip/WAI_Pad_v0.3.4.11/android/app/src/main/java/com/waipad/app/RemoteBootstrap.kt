package com.waipad.app

import android.content.Context
import com.jcraft.jsch.Session
import java.security.MessageDigest
import java.util.Base64
import java.util.UUID
import java.util.concurrent.locks.ReentrantLock

object RemoteBootstrap {
    private val files = listOf("engine_v34.py", "job_api.py", "maintenance.py", "guard.sh", "bootstrap.sh")
    private val installLock = ReentrantLock(true)

    private fun sha256(data: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(data).joinToString("") { "%02x".format(it) }

    fun installAndStart(context: Context, session: Session): String {
        installLock.lockInterruptibly()
        try {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("初始化已取消")
            val localData = files.associateWith { name -> context.assets.open("wai/server/$name").use { it.readBytes() } }
            val digestInput = java.io.ByteArrayOutputStream().use { out ->
                files.forEach { out.write(localData.getValue(it)) }
                out.toByteArray()
            }
            val releaseHash = sha256(digestInput).take(16)

            // Do not upload five files over SFTP while guard/repair already owns the mutation lock.
            // v0.3.4.9 could accidentally let job_api inherit fd 9, keeping service.lock forever.
            // Detect that exact legacy condition through /proc and restart ONLY the companion when
            // there is no durable active prompt. Never touch ComfyUI here.
            val preflight = """
                set -u
                LOCK=/root/WAI_Pad/runtime/service.lock
                RUNTIME=/root/WAI_Pad/runtime
                mkdir -p "${'$'}RUNTIME"
                if flock -w 2 "${'$'}LOCK" -c true; then exit 0; fi
                active=0
                if curl -fsS --max-time 2 http://127.0.0.1:6027/v1/health 2>/dev/null | grep -Eq '"current"[[:space:]]*:[[:space:]]*"[^" ]+'; then active=1; fi
                if [ "${'$'}active" -eq 0 ] && [ -f "${'$'}RUNTIME/jobs_state.json" ] && grep -Eq '"status"[[:space:]]*:[[:space:]]*"(claimed|submitting|running|repairing)"' "${'$'}RUNTIME/jobs_state.json" 2>/dev/null; then active=1; fi
                leaked=''
                for pid in ${'$'}(pgrep -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' 2>/dev/null || true); do
                  holds=0
                  for fd in /proc/${'$'}pid/fd/*; do
                    [ "${'$'}(readlink "${'$'}fd" 2>/dev/null || true)" = "${'$'}LOCK" ] && holds=1 && break
                  done
                  [ "${'$'}holds" -eq 1 ] && leaked="${'$'}leaked ${'$'}pid"
                done
                if [ -n "${'$'}leaked" ]; then
                  if [ "${'$'}active" -eq 1 ]; then
                    echo 'WAI_PAD_UPDATE_BUSY=1 [WAI Pad] 旧 companion 持有维护锁且存在活动任务；等待任务结束后自动迁移。'
                    exit 75
                  fi
                  echo '[WAI Pad] 检测到 v0.3.4.9 companion 遗留的维护锁，安全重启 companion 释放锁。'
                  for pid in ${'$'}leaked; do kill -TERM "${'$'}pid" 2>/dev/null || true; done
                  sleep 2
                  for pid in ${'$'}leaked; do kill -KILL "${'$'}pid" 2>/dev/null || true; done
                  sleep 1
                  if flock -w 4 "${'$'}LOCK" -c true; then exit 0; fi
                fi
                echo 'WAI_PAD_UPDATE_BUSY=1 [WAI Pad] 服务器维护正在进行；保持 SSH 隧道，稍后自动重试。'
                exit 75
            """.trimIndent()
            val probe = SshClient.exec(session, preflight, 14_000)
            if (probe.first != 0) return probe.second.ifBlank { "WAI_PAD_UPDATE_BUSY=1 [WAI Pad] 服务器维护正在进行；保持 SSH 隧道，稍后自动重试。" }

            val token = UUID.randomUUID().toString().replace("-", "").take(12)
            val stage = "/root/WAI_Pad/runtime/staging/${releaseHash}_$token"
            val mk = SshClient.exec(session, "mkdir -p '$stage' /root/WAI_Pad/runtime/staging", 20_000)
            if (mk.first != 0) throw IllegalStateException("无法创建远端更新暂存目录：${mk.second.takeLast(800)}")

            try {
                for (name in files) {
                    SshClient.putBytesAtomic(session, "$stage/$name", localData.getValue(name))
                }

                // The remote lock is shared with bootstrap.sh, guard.sh and maintenance.py.
                // Files are validated in staging first; replacement is rollback-protected and each
                // final rename is atomic. If a job is active, code replacement is deferred entirely.
                val d = '$'
                val script = """
                    set -Eeuo pipefail
                    BASE=/root/WAI_Pad
                    STAGE='$stage'
                    FILES='${files.joinToString(" ")}'
                    mkdir -p "${d}BASE/runtime"
                    exec 9>"${d}BASE/runtime/service.lock"
                    flock -w 12 9 || { echo 'WAI_PAD_UPDATE_BUSY=1 [WAI Pad] 服务器维护锁繁忙；稍后自动重试。'; exit 0; }
                    cleanup_stage(){ rm -rf "${d}STAGE" 2>/dev/null || true; }
                    trap cleanup_stage EXIT

                    active_job=0
                    if curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health 2>/dev/null | grep -Eq '"current"[[:space:]]*:[[:space:]]*"[^" ]+'; then active_job=1; fi
                    changed=0
                    for f in ${d}FILES; do cmp -s "${d}STAGE/${d}f" "${d}BASE/${d}f" || changed=1; done
                    if [ "${d}changed" -eq 1 ] && [ "${d}active_job" -eq 1 ]; then
                      echo 'WAI_PAD_UPDATE_DEFERRED_ACTIVE_JOB=1 [WAI Pad] 检测到正在生成任务；companion 更新整套延后，绝不热替换运行中代码。'
                      exit 0
                    fi

                    PY=/root/venv/bin/python; [ -x "${d}PY" ] || PY="${d}(command -v python3 || command -v python)"
                    "${d}PY" -m py_compile "${d}STAGE/job_api.py" "${d}STAGE/engine_v34.py" "${d}STAGE/maintenance.py"
                    bash -n "${d}STAGE/bootstrap.sh" "${d}STAGE/guard.sh"

                    if [ "${d}changed" -eq 1 ]; then
                      BACKUP="${d}BASE/runtime/install_backup_${d}${d}"
                      mkdir -p "${d}BACKUP"
                      for f in ${d}FILES; do [ -f "${d}BASE/${d}f" ] && cp -p "${d}BASE/${d}f" "${d}BACKUP/${d}f" || true; done
                      rollback(){
                        echo '[WAI Pad] 更新事务失败，正在恢复上一套 companion 文件。' >&2
                        for f in ${d}FILES; do
                          if [ -f "${d}BACKUP/${d}f" ]; then cp -p "${d}BACKUP/${d}f" "${d}BASE/.${d}f.rollback.${d}${d}" && mv -f "${d}BASE/.${d}f.rollback.${d}${d}" "${d}BASE/${d}f"; fi
                        done
                      }
                      trap 'rc=${d}?; rollback; exit ${d}rc' ERR
                      for f in ${d}FILES; do
                        cp "${d}STAGE/${d}f" "${d}BASE/.${d}f.new.${d}${d}"
                        case "${d}f" in *.sh) chmod 700 "${d}BASE/.${d}f.new.${d}${d}";; *) chmod 600 "${d}BASE/.${d}f.new.${d}${d}";; esac
                        mv -f "${d}BASE/.${d}f.new.${d}${d}" "${d}BASE/${d}f"
                      done
                      trap - ERR
                      rm -rf "${d}BACKUP"
                      echo '[WAI Pad] companion 整套文件已事务更新。'
                    else
                      echo '[WAI Pad] companion 已是最新版。'
                    fi

                    WAI_PAD_LOCK_HELD=1 bash "${d}BASE/bootstrap.sh"
                """.trimIndent()
                val encoded = Base64.getEncoder().encodeToString(script.toByteArray(Charsets.UTF_8))
                val r = SshClient.exec(session, "printf '%s' '$encoded' | base64 -d | timeout -k 5s 100s bash", 115_000)
                if (r.first != 0) throw IllegalStateException("自动初始化失败(${r.first})：${r.second.takeLast(2200)}")
                return r.second
            } catch (e: Exception) {
                try { SshClient.exec(session, "rm -rf '$stage'", 12_000) } catch (_: Exception) {}
                throw e
            }
        } finally {
            installLock.unlock()
        }
    }
}
