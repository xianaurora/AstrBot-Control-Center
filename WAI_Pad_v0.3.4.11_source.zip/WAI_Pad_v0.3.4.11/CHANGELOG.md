# WAI Pad Changelog



## v0.3.4.11 — Split character/action prompts

- Added separate positive inputs for character traits and action/scene.
- Added separate negative inputs for character issues and action/anatomy issues.
- Generation combines the fields deterministically while preserving all four originals in job/local metadata.
- Prompt optimization now previews the final merged prompt without overwriting the separated inputs.

## v0.3.4.10 — Startup deadlock / background repair fix

- Companion 6027 starts before Panel/Comfy recovery; core recovery is asynchronous and bounded.
- Fix inherited `service.lock` FD and migrate legacy v0.3.4.9 companion lock holders safely.
- Remote service failure no longer causes needless SSH tunnel rebuilds.
- Console shows connection/bootstrap state instead of probing the dead legacy Panel during startup.

## v0.3.4.9 — Android build fix

- Fixes the real Gradle `compileDebugKotlin` failure caused by a nonexistent `WebView.isDestroyed` reference.
- Uses an explicit bridge lifecycle/disposal flag so asynchronous Native callbacks cannot touch a WebView after teardown.
- Corrects the local validation harness assumption that masked the Android SDK API error.

## v0.3.4.8 — Reliability hardening

- 原子 job 幂等/领取、定向取消、Comfy 断流恢复，杜绝重复生成和误取消。
- 启动/SSH/guard/bootstrap/repair 统一互斥与恢复状态机，SSH 指纹在认证前校验。
- WebView origin 隔离、Native 有界线程池/真实取消、连接 finally 释放。
- 本机图片与远端 ACK 清理改为可恢复事务；未 ACK 成图 TTL 调整为 72 小时。
- companion 整套 staging 校验/事务替换；server 与 APK assets 保持同版。


## v0.3.4.7
- 修复 HTTP 分片并发/崩溃重试造成的重复写入：分片改为原子文件并在 finalize 重组校验。
- 动作骨架 / Depth 预览改为 Native SFTP + SSH exec，不再让大 Base64 请求/响应经过 16027 HTTP 转发。
- 修复 SSH 端口转发部分成功时的新 session 泄漏与后续端口占用重连失败。
- SFTP 失败改用新 SSH 连接清理，janitor 可回收无 metadata 孤儿图及 `.wai-upload-*`。
- ComfyUI 提交前持久化 client_id；崩溃后可从 queue/history 恢复 prompt_id。
- GitHub Actions 支持 `_source(1).zip`；修复 NativeBridge 重复下载重试循环。

## v0.3.4.5 — 修复：参考图一直卡在“正在安全上传”
- 不再把整张 PNG/JPG 作为一个巨大的 Base64 JSON 请求一次性塞进 SSH 隧道。
- 改为可续传分片：每段约 768 KiB Base64（约 576 KiB 原图数据），逐段落盘并 `fsync`。
- UI 显示真实上传进度，例如 `人物参考图 A 63% · 7/11 段`，不再只有一条静止状态。
- 单段超过约 45～50 秒没有响应就判定连接异常，自动重建 SSH 隧道并从当前段续传。
- 如果“服务端已经写入该段，但返回包刚好丢了”，重复提交同一段不会重复写入，直接从下一段继续。
- A 图上传成功、B 图上传失败时自动清理 A 图临时数据。
- 批量生成 2～4 张仍然只上传 A/B 图各一次。
- 临时分片 1 小时无人使用会由 AutoDL companion 自动清理。

## 签名
- 沿用 v0.3.4.2 起的固定签名 keystore；可直接覆盖同签名的 v0.3.4.4。

## v0.3.4.6
- 参考图改为 Native SFTP 直传，修复 `unexpected end of stream`。
- HTTP 分片仅作为回退，并缩小到 256 KiB。
- 扩展隧道异常识别与自动重连。
