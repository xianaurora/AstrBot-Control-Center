# WAI Pad v0.3.4.11 Validation

Static/regression checks performed in this environment:

- `bash -n` on `bootstrap.sh` and `guard.sh`: PASS.
- Python `py_compile` on companion modules: PASS.
- Node `--check` on `app.js`: PASS.
- Server files and Android asset copies are byte-identical: PASS.
- `RemoteBootstrap.kt` compiles against minimal language stubs after the new preflight/migration script changes: PASS.
- Android metadata: `versionName 0.3.4.11`, `versionCode 17`.
- GitHub Actions artifact name: `WAI-Pad-v0.3.4.11-debug`.

Important: this environment still does not contain a real Android SDK/AGP installation. The authoritative Android API/build check remains GitHub Actions `:app:assembleDebug`; do not treat handwritten stubs as a substitute for that build.
