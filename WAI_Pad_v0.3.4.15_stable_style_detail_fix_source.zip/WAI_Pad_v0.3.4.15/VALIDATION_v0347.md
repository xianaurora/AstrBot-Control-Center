# WAI Pad v0.3.4.7 Validation

已在当前源码环境执行：

- `server/job_api.py` / `engine_v34.py` / `maintenance.py`: Python `py_compile` 通过。
- `android/app/src/main/assets/wai/app.js`: Node `--check` 通过。
- `bootstrap.sh` / `guard.sh`: `bash -n` 通过。
- 修改过的 `NativeBridge.kt`、`TunnelService.kt`: 使用 Kotlin 编译器配合最小 Android/JSch/JSON API stubs 进行语法与类型检查，通过。
- server 根目录与 APK assets 中 `job_api.py` / `engine_v34.py` / `maintenance.py` / `bootstrap.sh` / `guard.sh`: `cmp` 一致。
- 分片并发重试测试：两个线程同时提交同一 index，最终只生成一份正确字节，PASS。
- 分片崩溃边界测试：模拟 chunk 原子落盘后 session 尚未更新即进程死亡；重试同一 index 被识别为 duplicate，最终图片字节完全一致，PASS。
- 不同内容重复 index 测试：拒绝并报错，不允许静默覆盖，PASS。
- 孤儿 SFTP 文件 janitor 测试：无 metadata 图片及 `.wai-upload-*` 临时文件过期后均被清理，PASS。
- ComfyUI client_id 恢复测试：queue 与 history 两种记录形态均能找回 prompt_id，PASS。
- GitHub Actions glob 测试：`WAI_Pad_v0.3.4.6_source(1).zip` 可被新规则匹配，PASS。

当前执行环境没有完整 Android SDK/Gradle，因此没有在本机执行真实 `assembleDebug`。GitHub Actions 配置仍会在具备 Android SDK 的 runner 上执行完整 APK 构建与签名校验。
