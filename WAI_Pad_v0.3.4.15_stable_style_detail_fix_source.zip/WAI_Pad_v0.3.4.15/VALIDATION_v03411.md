# WAI Pad v0.3.4.11 Validation

- Android metadata: `versionName 0.3.4.11`, `versionCode 17`.
- GitHub Actions artifact name: `WAI-Pad-v0.3.4.11-debug`.
- `app.js` passes `node --check`.
- `job_api.py`, `engine_v34.py`, `maintenance.py` pass Python bytecode compilation.
- `bootstrap.sh` and `guard.sh` pass `bash -n`.
- Root `server/` companion files are byte-identical to APK assets copies.
- Split prompt merge tests cover Chinese mode, English mode, negative fields, action-only positive input, and legacy single-field fallback.
- DOM reference scan confirms all four prompt inputs and four clear buttons exist.

Real Android SDK/AGP compilation remains authoritative and is performed by the GitHub Actions `assembleDebug` job.
