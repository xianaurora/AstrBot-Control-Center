# WAI Pad v0.3.4.2

## 签名修复
- 修复 v0.3.4 与 v0.3.4.1 之间误生成了不同 `waipad-dev.jks` 的问题。
- 从本版起永久固定使用 v0.3.4.1 的同一份 keystore 字节，不再重新生成。
- 固定 keystore SHA-256：`ddf36386ece50ee8af273c7595799f62c89aaa85efb69df6d690358e26dc8d7c`。
- 固定证书 SHA-256：`A3:FE:05:ED:D1:03:C3:EF:A6:DB:CC:B6:EB:46:28:F8:8C:C8:CD:32:77:2F:20:3F:B2:C2:F5:6D:2A:48:C4:A0`。
- GitHub Actions 在编译前校验 keystore 文件哈希和证书指纹；任何变化直接停止构建。
- APK 编译后再次用 `apksigner` 校验证书指纹，防止 Gradle 意外改用系统 debug key。

## 重要
如果平板当前安装的是 v0.3.3 或更早的随机 GitHub debug 签名版本，它的私钥已经不存在于源码中，Android 无法用新证书直接覆盖安装。这种旧版只需要最后迁移一次；v0.3.4.2 及以后都使用同一固定证书，可以直接覆盖升级。
