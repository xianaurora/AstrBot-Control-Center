package com.waipad.app

import android.content.Context
import android.content.Intent
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.jcraft.jsch.Session
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.FutureTask
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

class NativeBridge(
    private val context: Context,
    private val webView: WebView,
    private val store: LocalImageStore
) {
    private val prefs = SecurePrefs(context)
    private val exec = ThreadPoolExecutor(
        2, 4, 30L, TimeUnit.SECONDS,
        ArrayBlockingQueue(24),
        ThreadPoolExecutor.AbortPolicy()
    )
    private val operations = ConcurrentHashMap<String, FutureTask<Unit>>()
    private val connections = ConcurrentHashMap<String, HttpURLConnection>()
    private val sessions = ConcurrentHashMap<String, Session>()
    private val disposed = AtomicBoolean(false)

    private fun callback(script: String) {
        if (disposed.get()) return
        webView.post {
            if (disposed.get()) return@post
            try {
                webView.evaluateJavascript(script, null)
            } catch (_: IllegalStateException) {
                // Activity/WebView teardown won the race with this async callback.
            }
        }
    }

    private fun submitOp(
        id: String,
        finish: (Boolean, String) -> Unit,
        block: () -> String
    ) {
        if (id.isBlank()) return
        val task = FutureTask<Unit> {
            var ok = false
            val payload = try {
                val value = block()
                if (Thread.currentThread().isInterrupted) throw InterruptedException("操作已取消")
                ok = true
                value
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                JSONObject().put("error", "操作已取消").toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "operation failed").toString()
            } finally {
                connections.remove(id)?.let { try { it.disconnect() } catch (_: Exception) {} }
                sessions.remove(id)?.let { try { it.disconnect() } catch (_: Exception) {} }
                operations.remove(id)
            }
            finish(ok, payload)
        }
        operations.put(id, task)?.cancel(true)
        try {
            exec.execute(task)
        } catch (_: RejectedExecutionException) {
            operations.remove(id)
            finish(false, JSONObject().put("error", "后台操作繁忙，请稍后重试").toString())
        }
    }

    private fun setSession(id: String, session: Session) {
        sessions.put(id, session)?.let { old -> if (old !== session) try { old.disconnect() } catch (_: Exception) {} }
        if (Thread.currentThread().isInterrupted) {
            try { session.disconnect() } catch (_: Exception) {}
            throw InterruptedException("操作已取消")
        }
    }

    @JavascriptInterface
    fun cancelOperation(id: String) {
        operations.remove(id)?.cancel(true)
        connections.remove(id)?.let { try { it.disconnect() } catch (_: Exception) {} }
        sessions.remove(id)?.let { try { it.disconnect() } catch (_: Exception) {} }
    }

    fun shutdown() {
        if (!disposed.compareAndSet(false, true)) return
        operations.keys.toList().forEach { cancelOperation(it) }
        exec.shutdownNow()
    }

    @JavascriptInterface fun getConfig(): String = JSONObject()
        .put("host", prefs.get("host", "connect.nmb2.seetacloud.com"))
        .put("port", prefs.get("port", "28823"))
        .put("user", prefs.get("user", "root"))
        .put("autodlUrl", prefs.get("autodlUrl", "https://www.autodl.com/console/instance/list"))
        .put("jupyterUrl", prefs.get("jupyterUrl", ""))
        .put("sshFingerprint", prefs.get("sshFingerprint", ""))
        .put("version", "0.3.4.15")
        .put("hasPassword", prefs.get("password").isNotBlank())
        .toString()

    @JavascriptInterface fun saveConfig(json: String): String {
        return try {
            val o = JSONObject(json)
            val oldHost = prefs.get("host", "connect.nmb2.seetacloud.com")
            val oldPort = prefs.get("port", "28823")
            val oldUser = prefs.get("user", "root")
            val host = o.optString("host", oldHost).trim()
            val portText = o.optString("port", oldPort).trim()
            val user = o.optString("user", oldUser).trim()
            val password = if (o.has("password")) o.optString("password", "") else ""
            val port = portText.toIntOrNull()
                ?: return JSONObject().put("ok", false).put("error", "SSH 端口必须是数字").toString()
            if (host.isBlank() || user.isBlank()) return JSONObject().put("ok", false).put("error", "主机和用户不能为空").toString()
            if (port !in 1..65535) return JSONObject().put("ok", false).put("error", "SSH 端口必须在 1-65535").toString()

            val identityChanged = host != oldHost || portText != oldPort || user != oldUser
            val hasExistingPassword = prefs.get("password").isNotBlank()
            if ((identityChanged || !hasExistingPassword) && password.isBlank()) {
                return JSONObject().put("ok", false)
                    .put("error", if (identityChanged) "服务器身份已改变，请重新输入 SSH 密码确认" else "首次连接需要 SSH 密码")
                    .toString()
            }

            if (identityChanged) prefs.remove("sshFingerprint")
            prefs.put("host", host)
            prefs.put("port", port.toString())
            prefs.put("user", user)
            if (password.isNotBlank()) prefs.put("password", password)
            prefs.put("autodlUrl", o.optString("autodlUrl", "https://www.autodl.com/console/instance/list").trim())
            prefs.put("jupyterUrl", o.optString("jupyterUrl", "").trim())

            // Keep one Service instance alive.  Reconfigure by tearing down its owned
            // SSH session instead of stop/start, which previously raced on onDestroy().
            TunnelService.forceReconnect("连接设置已更新，正在重连")
            TunnelService.start(context)
            JSONObject().put("ok", true).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", e.message ?: "设置无效").toString()
        }
    }

    @JavascriptInterface fun clearFingerprint(): String {
        prefs.remove("sshFingerprint")
        TunnelService.forceReconnect("主机指纹已清除，请重新验证")
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface fun connectionStatus(): String = JSONObject()
        .put("connected", TunnelService.connected)
        .put("bridgeReady", TunnelService.bridgeReady)
        .put("stackReady", TunnelService.stackReady)
        .put("bootstrapBusy", TunnelService.bootstrapBusy)
        .put("phase", TunnelService.phase)
        .put("message", TunnelService.message)
        .put("fingerprint", prefs.get("sshFingerprint", ""))
        .put("jupyterForwarded", TunnelService.jupyterForwarded)
        .put("jupyterRemotePort", TunnelService.jupyterRemotePort)
        .put("lastConnectedAt", TunnelService.lastConnectedAt)
        .toString()

    @JavascriptInterface fun bootstrapLog(): String = TunnelService.lastBootstrapOutput
    @JavascriptInterface fun startConnection() { TunnelService.start(context) }
    @JavascriptInterface fun stopConnection() { TunnelService.stop(context) }
    @JavascriptInterface fun forceReconnect() { TunnelService.forceReconnect("主界面检测到连接异常") }

    @JavascriptInterface fun listImages(): String = store.list().toString()
    @JavascriptInterface fun localStats(): String {
        val s = store.stats()
        return JSONObject().put("count", s.optInt("count", 0)).put("bytes", s.optLong("used_bytes", 0)).put("free_bytes", s.optLong("free_bytes", 0)).toString()
    }
    @JavascriptInterface fun storageStats(): String = store.stats().toString()
    @JavascriptInterface fun imageMetadata(name: String): String = store.metadata(name).toString()
    @JavascriptInterface fun toggleFavorite(name: String): String = store.toggleFavorite(name).toString()
    @JavascriptInterface fun deleteImage(name: String): Boolean = store.delete(name)
    @JavascriptInterface fun hasLocalJob(jobId: String): Boolean = store.hasJob(jobId)

    @JavascriptInterface fun importLocalAlbum(id: String) {
        submitOp(id, { ok, payload ->
            callback("window.WAI_NATIVE&&window.WAI_NATIVE.onAlbumImported(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});")
        }) { store.importFromAlbum().toString() }
    }

    @JavascriptInterface fun saveImage(dataUrl: String, suggested: String, metadataJson: String): String {
        val meta = try { JSONObject(metadataJson) } catch (_: Exception) { JSONObject() }
        return store.saveDataUrl(dataUrl, suggested, meta).toString()
    }

    @JavascriptInterface fun downloadJobImage(id: String, jobId: String, localMetaJson: String) {
        fetchAndSaveJob(id, jobId, localMetaJson)
    }

    private fun cleanupRemoteUpload(uid: String) {
        if (!Regex("^[a-f0-9]{32}$").matches(uid)) return
        var session: Session? = null
        try {
            session = SshClient.connect(prefs)
            SshClient.exec(
                session,
                "find /root/WAI_Pad/runtime/uploads -maxdepth 1 -type f -name '${uid}*' -delete 2>/dev/null || true",
                12_000
            )
        } catch (_: Exception) {
            // Server janitor is the final privacy safety net while offline.
        } finally {
            try { session?.disconnect() } catch (_: Exception) {}
        }
    }

    private fun stageReferenceSftp(id: String, dataUrl: String, kind: String): JSONObject {
        val comma = dataUrl.indexOf(',')
        if (comma < 6) throw IllegalArgumentException("参考图数据无效")
        val header = dataUrl.substring(0, comma)
        val m = Regex("^data:(image/[^;]+);base64$", RegexOption.IGNORE_CASE).find(header)
            ?: throw IllegalArgumentException("参考图格式无法识别")
        val mime = m.groupValues[1].lowercase()
        val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
        if (bytes.isEmpty()) throw IllegalArgumentException("参考图为空")
        if (bytes.size > 40 * 1024 * 1024) throw IllegalArgumentException("参考图超过 40MB")

        val uid = UUID.randomUUID().toString().replace("-", "")
        val ext = when {
            mime.contains("jpeg") || mime.contains("jpg") -> "jpg"
            mime.contains("webp") -> "webp"
            else -> "png"
        }
        val remoteDir = "/root/WAI_Pad/runtime/uploads"
        val remoteImage = "$remoteDir/$uid.$ext"
        val remoteMeta = "$remoteDir/$uid.json"
        val meta = JSONObject()
            .put("id", uid).put("path", remoteImage).put("mime", mime)
            .put("kind", kind.take(32)).put("created_at", System.currentTimeMillis() / 1000.0)
            .put("size", bytes.size).toString().toByteArray(Charsets.UTF_8)

        var last: Exception? = null
        for (attempt in 1..2) {
            var session: Session? = null
            try {
                if (Thread.currentThread().isInterrupted) throw InterruptedException("操作已取消")
                session = SshClient.connect(prefs)
                setSession(id, session)
                val mk = SshClient.exec(session, "mkdir -p '$remoteDir'", 12_000)
                if (mk.first != 0) throw IOException("无法创建远端临时目录：${mk.second.takeLast(240)}")
                SshClient.putBytesAtomic(session, remoteImage, bytes)
                SshClient.putBytesAtomic(session, remoteMeta, meta)
                return JSONObject().put("id", uid).put("size", bytes.size).put("kind", kind)
                    .put("mime", mime).put("transport", "sftp")
            } catch (e: Exception) {
                last = e
                if (e is InterruptedException || Thread.currentThread().isInterrupted) throw e
            } finally {
                if (sessions.remove(id, session)) try { session?.disconnect() } catch (_: Exception) {}
                else try { session?.disconnect() } catch (_: Exception) {}
            }
            cleanupRemoteUpload(uid)
            if (attempt < 2) Thread.sleep(900L)
        }
        cleanupRemoteUpload(uid)
        throw last ?: IOException("SFTP 上传失败")
    }

    @JavascriptInterface fun uploadReferenceSftp(id: String, dataUrl: String, kind: String) {
        submitOp(id, { ok, payload -> finishReferenceUpload(id, ok, payload) }) {
            stageReferenceSftp(id, dataUrl, kind).toString()
        }
    }

    private fun finishReferenceUpload(id: String, ok: Boolean, payload: String) {
        callback("window.WAI_NATIVE&&window.WAI_NATIVE.onReferenceUploaded(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});")
    }

    @JavascriptInterface fun previewPoseSftp(id: String, dataUrl: String) {
        submitOp(id, { ok, payload -> finishPosePreview(id, ok, payload) }) {
            var uid: String? = null
            try {
                val staged = stageReferenceSftp(id, dataUrl, "pose-preview")
                uid = staged.getString("id")
                val session = SshClient.connect(prefs)
                setSession(id, session)
                try {
                    val body = "{\"pose_id\":\"${uid}\"}"
                    val cmd = "curl -fsS --max-time 240 -H 'Content-Type: application/json' --data '$body' http://127.0.0.1:6027/v1/pose/preview"
                    val r = SshClient.exec(session, cmd, 270_000)
                    if (r.first != 0) throw IOException("动作预览远端调用失败(${r.first})：${r.second.takeLast(600)}")
                    JSONObject(r.second) // validate untrusted response
                    r.second
                } finally {
                    sessions.remove(id, session)
                    try { session.disconnect() } catch (_: Exception) {}
                }
            } finally {
                uid?.let { cleanupRemoteUpload(it) }
            }
        }
    }

    private fun finishPosePreview(id: String, ok: Boolean, payload: String) {
        callback("window.WAI_NATIVE&&window.WAI_NATIVE.onPosePreview(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});")
    }

    @JavascriptInterface fun openTerminal() {
        context.startActivity(Intent(context, TerminalActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @JavascriptInterface fun openEmbedded(target: String) {
        val url = when (target) {
            "wai" -> "http://127.0.0.1:16017/"
            "comfy", "manager" -> "http://127.0.0.1:16006/"
            "backend" -> "http://127.0.0.1:16027/v1/health"
            "autodl" -> prefs.get("autodlUrl", "https://www.autodl.com/console/instance/list")
            "jupyter" -> if (TunnelService.jupyterForwarded) "http://127.0.0.1:18888/lab" else prefs.get("jupyterUrl", "")
            else -> return
        }
        if (url.isBlank()) return
        val i = Intent(context, EmbeddedWebActivity::class.java).putExtra("url", url).putExtra("title", target)
        context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private data class TextResp(val ok: Boolean, val code: Int, val text: String)
    private data class BinResp(val ok: Boolean, val code: Int, val bytes: ByteArray, val contentType: String)

    private fun baseFor(path: String): String {
        require(path.startsWith("/") && !path.contains("\\") && !path.contains("\n") && !path.contains("\r")) { "非法 API 路径" }
        return if (path.startsWith("/v1/")) "http://127.0.0.1:16027" else "http://127.0.0.1:16017"
    }

    private fun http(id: String, method: String, path: String, body: String = "", timeoutMs: Int = 120_000): TextResp {
        val conn = URL(baseFor(path) + path).openConnection() as HttpURLConnection
        connections.put(id, conn)?.let { old -> try { old.disconnect() } catch (_: Exception) {} }
        try {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("操作已取消")
            conn.requestMethod = method.uppercase()
            conn.connectTimeout = 8_000
            conn.readTimeout = timeoutMs
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Cache-Control", "no-store")
            conn.setRequestProperty("Connection", "close")
            if (method.uppercase() !in listOf("GET", "DELETE") && body.isNotEmpty()) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val input = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = BufferedReader(InputStreamReader(input ?: "".byteInputStream())).use { it.readText() }
            return TextResp(code in 200..299, code, text)
        } finally {
            connections.remove(id, conn)
            try { conn.disconnect() } catch (_: Exception) {}
        }
    }

    private fun httpBytes(id: String, path: String, timeoutMs: Int = 180_000): BinResp {
        val conn = URL(baseFor(path) + path).openConnection() as HttpURLConnection
        connections.put(id, conn)?.let { old -> try { old.disconnect() } catch (_: Exception) {} }
        try {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("操作已取消")
            conn.requestMethod = "GET"
            conn.connectTimeout = 8_000
            conn.readTimeout = timeoutMs
            conn.setRequestProperty("Cache-Control", "no-store")
            conn.setRequestProperty("Connection", "close")
            val code = conn.responseCode
            val ct = conn.contentType ?: "image/png"
            val input = if (code in 200..299) conn.inputStream else conn.errorStream
            val bos = ByteArrayOutputStream()
            input?.use { it.copyTo(bos) }
            return BinResp(code in 200..299, code, bos.toByteArray(), ct)
        } finally {
            connections.remove(id, conn)
            try { conn.disconnect() } catch (_: Exception) {}
        }
    }

    @JavascriptInterface fun apiRequest(id: String, method: String, path: String, body: String) {
        submitOp(id, { ok, payload ->
            callback("window.WAI_NATIVE&&window.WAI_NATIVE.onApi(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});")
        }) {
            val timeout = when {
                path == "/v1/images/init" || path.startsWith("/v1/images/") -> 45_000
                path.startsWith("/v1/images") -> 120_000
                path.contains("pose/preview") -> 300_000
                else -> 120_000
            }
            val r = http(id, method, path, body, timeout)
            if (!r.ok) throw IOException(if (r.text.isNotBlank()) r.text else "HTTP ${r.code}")
            r.text
        }
    }

    @JavascriptInterface fun fetchAndSaveJob(id: String, jobId: String, localMetaJson: String) {
        submitOp(id, { ok, payload ->
            callback("window.WAI_NATIVE&&window.WAI_NATIVE.onImageSaved(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});")
        }) {
            val jr = http(id, "GET", "/v1/jobs/$jobId", "", 30_000)
            if (!jr.ok) throw IllegalStateException("无法读取任务元数据：HTTP ${jr.code}")
            val job = JSONObject(jr.text)
            var img: BinResp? = null
            var lastDownloadError = ""
            for (attempt in 1..3) {
                if (Thread.currentThread().isInterrupted) throw InterruptedException("操作已取消")
                try {
                    val one = httpBytes(id, "/v1/jobs/$jobId/image", 180_000)
                    if (one.ok && one.bytes.isNotEmpty()) { img = one; break }
                    val detail = try { String(one.bytes, Charsets.UTF_8).take(240) } catch (_: Exception) { "" }
                    lastDownloadError = "HTTP ${one.code}${if (detail.isNotBlank()) ": $detail" else ""}"
                } catch (e: InterruptedException) { throw e }
                catch (e: Exception) { lastDownloadError = e.message ?: "网络异常" }
                Thread.sleep(1200L * attempt)
            }
            val imageResp = img ?: throw IllegalStateException("生成已完成，但本机下载失败：$lastDownloadError")
            val meta = try { JSONObject(localMetaJson) } catch (_: Exception) { JSONObject() }
            val req = job.optJSONObject("request")
            val result = job.optJSONObject("result")
            meta.put("job_id", jobId)
                .put("mode", req?.optString("mode", meta.optString("mode", "txt")) ?: meta.optString("mode", "txt"))
                .put("seed", job.optLong("seed", -1)).put("steps", job.optInt("steps", 0))
                .put("cfg", job.optDouble("cfg", 0.0)).put("positive", job.optString("positive", ""))
                .put("negative", job.optString("negative", "")).put("prompt_character", req?.optString("prompt_character", "") ?: "").put("prompt_action", req?.optString("prompt_action", "") ?: "").put("negative_character", req?.optString("negative_character", "") ?: "").put("negative_action", req?.optString("negative_action", "") ?: "").put("server_note", job.optString("note", ""))
                .put("remote_filename", result?.optString("filename", "") ?: "")
            val saved = store.saveBytes(imageResp.bytes, imageResp.contentType, "wai_${meta.optString("mode", "img")}_$jobId", meta)
            if (saved.optBoolean("durable_local", false)) {
                val ack = http(id, "POST", "/v1/jobs/$jobId/ack-local", "{}", 30_000)
                saved.put("remote_cleanup_ok", ack.ok)
                if (!ack.ok) saved.put("warning", "本机已安全保存；远端清理将在服务器后台继续重试")
            } else {
                saved.put("remote_cleanup_ok", false)
                saved.put("warning", "已写入 App 私有缓存，但 Pictures/WAI Pad 落盘失败；AutoDL 成图暂不删除")
            }
            saved.toString()
        }
    }

    @JavascriptInterface fun bootstrapServer(id: String) {
        submitOp(id, { ok, payload ->
            callback("window.WAI_NATIVE&&window.WAI_NATIVE.onBootstrap(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});")
        }) {
            val s = SshClient.connect(prefs)
            setSession(id, s)
            try {
                RemoteBootstrap.installAndStart(context, s)
            } catch (e: Exception) {
                val trace = SshClient.recentTrace(2600)
                throw IllegalStateException((e.message ?: "自动初始化失败") +
                    if (trace.isBlank()) "" else "\n[SSH 阶段追踪]\n$trace", e)
            } finally { sessions.remove(id, s); try { s.disconnect() } catch (_: Exception) {} }
        }
    }

    @JavascriptInterface fun restartServerFromDisk(id: String) {
        submitOp(id, { ok, payload ->
            callback("window.WAI_NATIVE&&window.WAI_NATIVE.onBootstrap(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});")
        }) {
            val s = SshClient.connect(prefs)
            setSession(id, s)
            try {
                val r = SshClient.exec(s, "chmod 700 /root/WAI_Pad/*.sh; WAI_PAD_LOCK_HELD=0 bash /root/WAI_Pad/bootstrap.sh", 340_000)
                if (r.first != 0) throw IllegalStateException("恢复后重启失败(${r.first})：${r.second.takeLast(1600)}")
                r.second
            } finally {
                sessions.remove(id, s)
                try { s.disconnect() } catch (_: Exception) {}
            }
        }
    }
}
