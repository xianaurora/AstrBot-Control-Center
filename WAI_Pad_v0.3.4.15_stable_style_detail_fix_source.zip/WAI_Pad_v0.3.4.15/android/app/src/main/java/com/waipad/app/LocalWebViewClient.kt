package com.waipad.app

import android.content.Context
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.FileInputStream

/**
 * The main UI is exposed through one synthetic HTTPS origin only.  Keeping the
 * Javascript bridge on this origin prevents an accidental external navigation
 * from inheriting Native's privileged methods.
 */
class LocalWebViewClient(
    private val context: Context,
    private val store: LocalImageStore
) : WebViewClient() {
    private val allowedAssets = mapOf(
        "/" to "wai/index.html",
        "/index.html" to "wai/index.html",
        "/app.js" to "wai/app.js",
        "/styles.css" to "wai/styles.css",
        "/icon.png" to "wai/icon.png"
    )

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
        val u = request?.url ?: return true
        return !(u.scheme == "https" && u.host == "app.local")
    }

    @Suppress("DEPRECATION")
    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
        val u = try { android.net.Uri.parse(url ?: "") } catch (_: Exception) { null }
        return !(u?.scheme == "https" && u.host == "app.local")
    }

    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        val u = request?.url ?: return null
        if (u.scheme != "https" || u.host != "app.local") {
            return denied()
        }

        val path = u.path ?: "/"
        allowedAssets[path]?.let { asset ->
            return try {
                val mime = when {
                    asset.endsWith(".html") -> "text/html"
                    asset.endsWith(".js") -> "application/javascript"
                    asset.endsWith(".css") -> "text/css"
                    asset.endsWith(".png") -> "image/png"
                    else -> "application/octet-stream"
                }
                WebResourceResponse(mime, "utf-8", context.assets.open(asset))
            } catch (_: Exception) { notFound() }
        }

        if (path.startsWith("/local-images/")) {
            val name = u.lastPathSegment ?: return notFound()
            val file = store.resolve(name) ?: return notFound()
            val ext = file.extension.lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: when (ext) {
                    "jpg", "jpeg" -> "image/jpeg"
                    "webp" -> "image/webp"
                    else -> "image/png"
                }
            return WebResourceResponse(mime, null, FileInputStream(file))
        }
        return notFound()
    }

    private fun denied() = WebResourceResponse(
        "text/plain", "utf-8", 403, "Forbidden",
        mapOf("Cache-Control" to "no-store"), "blocked".byteInputStream()
    )

    private fun notFound() = WebResourceResponse(
        "text/plain", "utf-8", 404, "Not Found",
        mapOf("Cache-Control" to "no-store"), "missing".byteInputStream()
    )
}
