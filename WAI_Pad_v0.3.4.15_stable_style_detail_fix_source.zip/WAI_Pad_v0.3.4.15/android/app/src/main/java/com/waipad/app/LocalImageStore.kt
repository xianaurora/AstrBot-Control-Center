package com.waipad.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LocalImageStore(private val context: Context) {
    private val dir = File(context.filesDir, "wai_images").apply { mkdirs() }
    private val metaDir = File(context.filesDir, "wai_images_meta").apply { mkdirs() }

    private fun atomicWrite(file: File, bytes: ByteArray) {
        bytes.inputStream().use { atomicCopy(file, it) }
    }

    private fun atomicCopy(file: File, input: InputStream) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        try {
            FileOutputStream(tmp).use { out ->
                input.copyTo(out)
                out.flush()
                out.fd.sync()
            }
            if (!tmp.renameTo(file)) {
                file.delete()
                if (!tmp.renameTo(file)) throw IllegalStateException("本地文件落盘失败: ${file.name}")
            }
        } finally {
            if (tmp.exists()) tmp.delete()
        }
    }

    private fun atomicWriteText(file: File, text: String) = atomicWrite(file, text.toByteArray(Charsets.UTF_8))

    private fun findByJobId(jobId: String): JSONObject? {
        if (jobId.isBlank()) return null
        metaDir.listFiles()?.asSequence()?.filter { it.isFile && it.name.endsWith(".json") }?.forEach { mf ->
            try {
                val m = JSONObject(mf.readText(Charsets.UTF_8))
                if (m.optString("job_id") == jobId) {
                    val f = resolve(m.optString("name"))
                    if (f != null) return decorate(f, m).put("deduplicated", true)
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun existingDurable(displayName: String): JSONObject? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.RELATIVE_PATH)
            val selection = "${MediaStore.Images.Media.DISPLAY_NAME}=? AND ${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Images.Media.IS_PENDING}=0"
            val args = arrayOf(displayName, "${Environment.DIRECTORY_PICTURES}/WAI Pad%")
            return try {
                context.contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection, selection, args,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    if (!c.moveToFirst()) return@use null
                    val id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID))
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
                    JSONObject().put("durable_local", true).put("durable_uri", uri.toString()).put("album", "Pictures/WAI Pad")
                }
            } catch (_: Exception) { null }
        }
        val album = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "WAI Pad")
        val out = File(album, displayName)
        return if (out.exists() && out.isFile) JSONObject().put("durable_local", true).put("durable_path", out.absolutePath).put("album", "Pictures/WAI Pad") else null
    }

    private fun exportDurable(source: File, mime: String, displayName: String): JSONObject {
        existingDurable(displayName)?.let { return it.put("deduplicated_album", true) }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Images.Media.MIME_TYPE, mime)
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/WAI Pad")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建本机相册文件")
            try {
                context.contentResolver.openOutputStream(uri, "w")?.use { out ->
                    FileInputStream(source).use { input -> input.copyTo(out) }
                    out.flush()
                } ?: throw IllegalStateException("无法写入本机相册")
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                return JSONObject().put("durable_local", true).put("durable_uri", uri.toString()).put("album", "Pictures/WAI Pad")
            } catch (e: Exception) {
                try { context.contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                throw e
            }
        }

        return try {
            val album = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "WAI Pad").apply { mkdirs() }
            val out = File(album, displayName)
            val tmp = File(album, ".$displayName.wai-tmp")
            FileInputStream(source).use { input -> FileOutputStream(tmp).use { sink -> input.copyTo(sink); sink.flush(); sink.fd.sync() } }
            if (!tmp.renameTo(out)) {
                out.delete()
                if (!tmp.renameTo(out)) throw IllegalStateException("相册文件原子替换失败")
            }
            JSONObject().put("durable_local", true).put("durable_path", out.absolutePath).put("album", "Pictures/WAI Pad")
        } catch (e: Exception) {
            JSONObject().put("durable_local", false).put("durable_error", e.message ?: "shared storage unavailable")
        }
    }

    private fun mergeDurable(m: JSONObject, durable: JSONObject): JSONObject = m
        .put("durable_local", durable.optBoolean("durable_local", false))
        .put("album", durable.optString("album", ""))
        .put("durable_uri", durable.optString("durable_uri", ""))
        .put("durable_path", durable.optString("durable_path", ""))
        .put("durable_error", durable.optString("durable_error", ""))
        .put("transaction_state", if (durable.optBoolean("durable_local", false)) "complete" else "private_saved")

    @Synchronized
    fun saveBytes(bytes: ByteArray, mime: String, suggested: String = "wai", metadata: JSONObject = JSONObject()): JSONObject {
        require(bytes.isNotEmpty()) { "图片内容为空" }
        val jobId = metadata.optString("job_id").trim()
        val existing = findByJobId(jobId)
        if (existing != null) {
            if (existing.optBoolean("durable_local", false)) return existing
            val existingFile = resolve(existing.optString("name")) ?: return existing
            val fixed = try { exportDurable(existingFile, mime, existingFile.name) }
                catch (e: Exception) { JSONObject().put("durable_local", false).put("durable_error", e.message ?: "album export failed") }
            val m = mergeDurable(readMeta(existingFile), fixed)
            atomicWriteText(File(metaDir, existingFile.name + ".json"), m.toString())
            return decorate(existingFile, m).put("deduplicated", true)
        }

        val ext = when {
            mime.contains("jpeg", true) -> "jpg"
            mime.contains("webp", true) -> "webp"
            else -> "png"
        }
        val safe = suggested.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(96).ifBlank { "wai" }
        // Jobs get a deterministic name. If the process dies after album export but
        // before metadata commit, the retry finds the same display name and repairs
        // the transaction instead of producing another Pictures copy.
        val filename = if (jobId.isNotBlank()) "$safe.$ext" else {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
            "${safe}_${stamp}.$ext"
        }
        val f = File(dir, filename)
        val mf = File(metaDir, filename + ".json")
        var m = JSONObject(metadata.toString())
            .put("name", filename)
            .put("favorite", metadata.optBoolean("favorite", false))
            .put("storage", "app_private_plus_local_album")
            .put("cloud_sync", false)
            .put("durable_local", false)
            .put("transaction_state", "saving")
            .put("transaction_started_at", System.currentTimeMillis())
        atomicWriteText(mf, m.toString())

        atomicWrite(f, bytes)
        m.put("size", f.length()).put("time", f.lastModified()).put("transaction_state", "private_saved")
        atomicWriteText(mf, m.toString())

        val durable = try { exportDurable(f, mime, f.name) }
            catch (e: Exception) { JSONObject().put("durable_local", false).put("durable_error", e.message ?: "album export failed") }
        m = mergeDurable(m, durable)
        atomicWriteText(mf, m.toString())
        return decorate(f, m)
    }

    fun saveDataUrl(dataUrl: String, suggested: String = "wai", metadata: JSONObject = JSONObject()): JSONObject {
        val comma = dataUrl.indexOf(',')
        require(comma > 0) { "图片数据无效" }
        val header = dataUrl.substring(0, comma)
        val mime = when {
            header.contains("image/jpeg") -> "image/jpeg"
            header.contains("image/webp") -> "image/webp"
            else -> "image/png"
        }
        return saveBytes(Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT), mime, suggested, metadata)
    }

    private fun readMeta(f: File): JSONObject {
        val mf = File(metaDir, f.name + ".json")
        return try { if (mf.exists()) JSONObject(mf.readText(Charsets.UTF_8)) else JSONObject() } catch (_: Exception) { JSONObject() }
    }

    private fun decorate(f: File, m: JSONObject = readMeta(f)): JSONObject = JSONObject(m.toString())
        .put("name", f.name).put("size", f.length()).put("time", f.lastModified())
        .put("url", "https://app.local/local-images/${f.name}")

    fun list(): JSONArray {
        val a = JSONArray()
        dir.listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") }
            ?.sortedByDescending { it.lastModified() }?.take(2000)?.forEach { a.put(decorate(it)) }
        return a
    }

    fun resolve(name: String): File? {
        val clean = File(name).name
        if (clean != name || clean.endsWith(".tmp")) return null
        val f = File(dir, clean)
        return if (f.exists() && f.isFile && f.parentFile == dir) f else null
    }

    fun metadata(name: String): JSONObject {
        val f = resolve(name) ?: return JSONObject().put("error", "not found")
        return decorate(f)
    }

    fun toggleFavorite(name: String): JSONObject {
        val f = resolve(name) ?: return JSONObject().put("error", "not found")
        val m = readMeta(f)
        m.put("favorite", !m.optBoolean("favorite", false))
        atomicWriteText(File(metaDir, f.name + ".json"), m.toString())
        return decorate(f, m)
    }

    fun hasJob(jobId: String): Boolean = findByJobId(jobId)?.optBoolean("durable_local", false) == true

    fun delete(name: String): Boolean {
        val f = resolve(name) ?: return false
        File(metaDir, f.name + ".json").delete()
        // Intentional: deleting inside WAI Pad removes only the app-private index/copy.
        // The durable Pictures/WAI Pad copy is retained against accidental loss.
        return f.delete()
    }

    private fun safeImportedName(displayName: String): String {
        val clean = File(displayName).name.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(120).ifBlank { "recovered.png" }
        val base = clean.substringBeforeLast('.', clean)
        val ext = clean.substringAfterLast('.', "png")
        var candidate = clean
        var n = 1
        while (File(dir, candidate).exists()) candidate = "${base}_imported_${n++}.$ext"
        return candidate
    }

    private fun knownDurableUris(): MutableSet<String> {
        val out = HashSet<String>()
        metaDir.listFiles()?.asSequence()?.filter { it.isFile && it.name.endsWith(".json") }?.forEach { mf ->
            try { JSONObject(mf.readText(Charsets.UTF_8)).optString("durable_uri").takeIf { it.isNotBlank() }?.let(out::add) }
            catch (_: Exception) {}
        }
        return out
    }

    fun importFromAlbum(limit: Int = 2000): JSONObject {
        var imported = 0
        var skipped = 0
        var failed = 0
        val errors = JSONArray()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val known = knownDurableUris()
            val projection = arrayOf(
                MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.RELATIVE_PATH,
                MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED
            )
            val selection = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Images.Media.IS_PENDING}=0"
            val args = arrayOf("${Environment.DIRECTORY_PICTURES}/WAI Pad%")
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args,
                "${MediaStore.Images.Media.DATE_ADDED} ASC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val pathCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                while (c.moveToNext() && imported + skipped + failed < limit) {
                    val displayName = c.getString(nameCol) ?: continue
                    val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol))
                    if (known.contains(uri.toString())) { skipped++; continue }
                    try {
                        val targetName = safeImportedName(displayName)
                        val f = File(dir, targetName)
                        context.contentResolver.openInputStream(uri)?.use { input -> atomicCopy(f, input) }
                            ?: throw IllegalStateException("无法读取 $displayName")
                        if (f.length() <= 0L) throw IllegalStateException("$displayName 内容为空")
                        val m = JSONObject().put("name", targetName).put("size", f.length()).put("time", f.lastModified())
                            .put("favorite", false).put("storage", "app_private_plus_local_album").put("cloud_sync", false)
                            .put("durable_local", true).put("durable_uri", uri.toString())
                            .put("album", c.getString(pathCol) ?: "Pictures/WAI Pad")
                            .put("source_display_name", displayName).put("source_mime", c.getString(mimeCol) ?: "image/png")
                            .put("source_size", c.getLong(sizeCol)).put("imported_from_album", true).put("recovered", true)
                            .put("transaction_state", "complete")
                        atomicWriteText(File(metaDir, targetName + ".json"), m.toString())
                        known.add(uri.toString())
                        imported++
                    } catch (e: Exception) {
                        failed++
                        if (errors.length() < 20) errors.put("$displayName: ${e.message ?: "读取失败"}")
                    }
                }
            }
        } else {
            val album = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "WAI Pad")
            val all = if (album.exists()) album.walkTopDown().filter { it.isFile && it.extension.lowercase() in setOf("png", "jpg", "jpeg", "webp") }.take(limit).toList() else emptyList()
            for (src in all) {
                try {
                    if (File(dir, src.name).exists()) { skipped++; continue }
                    val f = File(dir, safeImportedName(src.name))
                    src.inputStream().use { atomicCopy(f, it) }
                    val m = JSONObject().put("name", f.name).put("size", f.length()).put("time", f.lastModified())
                        .put("favorite", false).put("storage", "app_private_plus_local_album").put("cloud_sync", false)
                        .put("durable_local", true).put("durable_path", src.absolutePath).put("album", "Pictures/WAI Pad")
                        .put("source_display_name", src.name).put("imported_from_album", true).put("recovered", true)
                        .put("transaction_state", "complete")
                    atomicWriteText(File(metaDir, f.name + ".json"), m.toString())
                    imported++
                } catch (e: Exception) {
                    failed++
                    if (errors.length() < 20) errors.put("${src.name}: ${e.message}")
                }
            }
        }
        return JSONObject().put("ok", failed == 0).put("imported", imported).put("skipped", skipped)
            .put("failed", failed).put("errors", errors).put("source", "Pictures/WAI Pad").put("cloud_sync", false)
    }

    fun stats(): JSONObject {
        val files = dir.listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") }.orEmpty()
        val used = files.sumOf { it.length() }
        return JSONObject().put("count", files.size).put("used_bytes", used).put("bytes", used)
            .put("free_bytes", context.filesDir.usableSpace).put("path_hint", "本机 Pictures/WAI Pad + App 私有索引")
            .put("cloud_sync", false).put("survives_uninstall", Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
    }
}
