package com.waipad.app

import com.jcraft.jsch.Channel
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.HostKey
import com.jcraft.jsch.HostKeyRepository
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.UserInfo
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.util.ArrayDeque
import java.util.Base64
import java.util.Properties
import java.util.concurrent.atomic.AtomicBoolean

object SshClient {
    private const val CHANNEL_OPEN_WATCHDOG_MS = 30_000L
    private const val SFTP_TRANSFER_WATCHDOG_MS = 180_000L
    private const val TRACE_MAX_LINES = 96
    private val traceLock = Any()
    private val traceLines = ArrayDeque<String>()

    private fun trace(message: String) {
        val line = "[${System.currentTimeMillis()}] $message"
        synchronized(traceLock) {
            traceLines.addLast(line)
            while (traceLines.size > TRACE_MAX_LINES) traceLines.removeFirst()
        }
    }

    fun recentTrace(maxChars: Int = 3200): String {
        val joined = synchronized(traceLock) { traceLines.joinToString("\n") }
        return if (joined.length <= maxChars) joined else joined.takeLast(maxChars)
    }

    private fun fingerprint(rawKey: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(rawKey)
        return "SHA256:" + Base64.getEncoder().withoutPadding().encodeToString(digest)
    }

    private class PinnedHostKeyRepository(private val expected: String) : HostKeyRepository {
        override fun check(host: String?, key: ByteArray?): Int {
            if (key == null) return HostKeyRepository.CHANGED
            return if (fingerprint(key) == expected) HostKeyRepository.OK else HostKeyRepository.CHANGED
        }
        override fun add(hostkey: HostKey?, ui: UserInfo?) = Unit
        override fun remove(host: String?, type: String?) = Unit
        override fun remove(host: String?, type: String?, key: ByteArray?) = Unit
        override fun getKnownHostsRepositoryID(): String = "WAI Pad pinned fingerprint"
        override fun getHostKey(): Array<HostKey> = emptyArray()
        override fun getHostKey(host: String?, type: String?): Array<HostKey> = emptyArray()
    }

    fun connect(host: String, port: Int, user: String, password: String, pinnedFingerprint: String = ""): Session {
        require(host.isNotBlank()) { "SSH 主机为空" }
        require(port in 1..65535) { "SSH 端口无效" }
        require(user.isNotBlank()) { "SSH 用户为空" }
        require(password.isNotEmpty()) { "SSH 密码为空" }

        val jsch = JSch()
        if (pinnedFingerprint.isNotBlank()) {
            // Enforce the saved host key during key exchange, before password auth.
            jsch.setHostKeyRepository(PinnedHostKeyRepository(pinnedFingerprint))
        }
        val s = jsch.getSession(user, host, port)
        s.setPassword(password)
        val cfg = Properties()
        cfg["StrictHostKeyChecking"] = if (pinnedFingerprint.isBlank()) "no" else "yes"
        cfg["PreferredAuthentications"] = "password,keyboard-interactive,publickey"
        s.setConfig(cfg)
        s.serverAliveInterval = 20_000
        s.serverAliveCountMax = 3
        trace("session connect begin $host:$port user=$user pinned=${pinnedFingerprint.isNotBlank()}")
        return try {
            // Session.connect(timeout) is a socket/session handshake timeout and is intentionally
            // kept. The problematic behavior is Channel.connect(timeout), not Session.connect().
            s.connect(18_000)
            trace("session authenticated $host:$port fingerprint=${fingerprint(s)}")
            s
        } catch (e: Exception) {
            trace("session connect failed $host:$port ${e.javaClass.simpleName}: ${e.message ?: ""}")
            try { s.disconnect() } catch (_: Exception) {}
            throw e
        }
    }

    fun connect(prefs: SecurePrefs): Session {
        val host = prefs.get("host", "connect.nmb2.seetacloud.com")
        val portText = prefs.get("port", "28823")
        val port = portText.toIntOrNull() ?: throw IllegalArgumentException("SSH 端口不是有效数字: $portText")
        val user = prefs.get("user", "root")
        val password = prefs.get("password")
        val saved = prefs.get("sshFingerprint")
        val s = connect(host, port, user, password, saved)
        if (saved.isBlank()) {
            // TOFU only on the very first successful connection. Later connections are pinned
            // before authentication by PinnedHostKeyRepository above.
            prefs.put("sshFingerprint", fingerprint(s))
        }
        return s
    }

    fun fingerprint(session: Session): String {
        val raw = try { Base64.getDecoder().decode(session.hostKey.key) } catch (_: Exception) { session.hostKey.key.toByteArray() }
        return fingerprint(raw)
    }

    /**
     * Open a JSch channel WITHOUT using Channel.connect(timeout).
     *
     * JSch changes request/reply behavior when a non-zero channel connect timeout is supplied.
     * On some SSH gateways this manifests as an exact "channel request: timeout" even though the
     * SSH session and port forwards are healthy. We therefore call connect() with no JSch channel
     * timeout and enforce our own watchdog outside JSch by tearing down the disposable session.
     *
     * All callers must use a short-lived control session (the forwarding session is never passed
     * here). Disconnecting the session is therefore the safest way to break a channel open that is
     * stuck inside JSch.
     */
    fun connectChannel(
        session: Session,
        channel: Channel,
        label: String,
        watchdogMs: Long = CHANNEL_OPEN_WATCHDOG_MS
    ) {
        check(session.isConnected) { "SSH session is down" }
        val finished = AtomicBoolean(false)
        val timedOut = AtomicBoolean(false)
        val watchdog = Thread({
            try {
                Thread.sleep(watchdogMs)
                if (finished.compareAndSet(false, true)) {
                    timedOut.set(true)
                    trace("$label channel watchdog timeout after ${watchdogMs}ms; disconnect disposable session")
                    try { channel.disconnect() } catch (_: Exception) {}
                    try { session.disconnect() } catch (_: Exception) {}
                }
            } catch (_: InterruptedException) {
                // Normal completion cancels the watchdog.
            }
        }, "wai-ssh-channel-watchdog").apply { isDaemon = true; start() }

        trace("$label channel open begin using Channel.connect() without internal timeout")
        try {
            // IMPORTANT: do not change this back to channel.connect(timeout).
            channel.connect()
            if (!finished.compareAndSet(false, true) || timedOut.get()) {
                throw SocketTimeoutException("$label SSH channel 建立超时（外层 watchdog ${watchdogMs}ms）")
            }
            trace("$label channel open success")
        } catch (e: Exception) {
            val wasTimeout = timedOut.get()
            if (!wasTimeout) finished.set(true)
            trace("$label channel open failed ${e.javaClass.simpleName}: ${e.message ?: ""}")
            if (wasTimeout && e !is SocketTimeoutException) {
                val wrapped = SocketTimeoutException("$label SSH channel 建立超时（外层 watchdog ${watchdogMs}ms）")
                wrapped.initCause(e)
                throw wrapped
            }
            throw e
        } finally {
            finished.set(true)
            watchdog.interrupt()
        }
    }

    private fun <T> withSessionWatchdog(
        session: Session,
        label: String,
        timeoutMs: Long,
        block: () -> T
    ): T {
        val finished = AtomicBoolean(false)
        val timedOut = AtomicBoolean(false)
        val watchdog = Thread({
            try {
                Thread.sleep(timeoutMs)
                if (finished.compareAndSet(false, true)) {
                    timedOut.set(true)
                    trace("$label operation watchdog timeout after ${timeoutMs}ms; disconnect disposable session")
                    try { session.disconnect() } catch (_: Exception) {}
                }
            } catch (_: InterruptedException) {}
        }, "wai-ssh-operation-watchdog").apply { isDaemon = true; start() }
        try {
            val result = block()
            if (timedOut.get()) throw SocketTimeoutException("$label SSH 操作超时（外层 watchdog ${timeoutMs}ms）")
            return result
        } catch (e: Exception) {
            if (timedOut.get() && e !is SocketTimeoutException) {
                val wrapped = SocketTimeoutException("$label SSH 操作超时（外层 watchdog ${timeoutMs}ms）")
                wrapped.initCause(e)
                throw wrapped
            }
            throw e
        } finally {
            finished.set(true)
            watchdog.interrupt()
        }
    }

    fun exec(session: Session, command: String, timeoutMs: Long = 90_000): Pair<Int, String> {
        check(session.isConnected) { "SSH session is down" }
        val ch = session.openChannel("exec") as ChannelExec
        val out = ByteArrayOutputStream(); val err = ByteArrayOutputStream()
        try {
            ch.setCommand(command); ch.setInputStream(null)
            ch.setOutputStream(out); ch.setErrStream(err)
            connectChannel(session, ch, "exec", CHANNEL_OPEN_WATCHDOG_MS)
            trace("exec request running commandLength=${command.length} timeoutMs=$timeoutMs")
            val start = System.currentTimeMillis()
            while (!ch.isClosed && System.currentTimeMillis() - start < timeoutMs) {
                if (Thread.currentThread().isInterrupted) throw InterruptedException("SSH 操作已取消")
                Thread.sleep(80)
            }
            val timedOut = !ch.isClosed
            val text = out.toString(Charsets.UTF_8.name()) + err.toString(Charsets.UTF_8.name())
            if (timedOut) {
                // This session is disposable. Tear it down so a remote exec that ignored channel
                // close cannot keep a half-open JSch session around.
                trace("exec command timeout after ${timeoutMs}ms; disconnect disposable session")
                try { session.disconnect() } catch (_: Exception) {}
                return 124 to text
            }
            trace("exec request complete exit=${ch.exitStatus}")
            return ch.exitStatus to text
        } finally {
            try { ch.disconnect() } catch (_: Exception) {}
        }
    }

    fun putBytes(session: Session, remotePath: String, data: ByteArray, timeoutMs: Long = SFTP_TRANSFER_WATCHDOG_MS) {
        check(session.isConnected) { "SSH session is down" }
        val ch = session.openChannel("sftp") as ChannelSftp
        try {
            connectChannel(session, ch, "sftp", CHANNEL_OPEN_WATCHDOG_MS)
            if (Thread.currentThread().isInterrupted) throw InterruptedException("SFTP 操作已取消")
            trace("sftp put begin bytes=${data.size} path=$remotePath")
            withSessionWatchdog(session, "sftp put", timeoutMs) {
                ch.put(ByteArrayInputStream(data), remotePath)
            }
            trace("sftp put complete bytes=${data.size} path=$remotePath")
        } finally {
            try { ch.disconnect() } catch (_: Exception) {}
        }
    }

    fun putBytesAtomic(session: Session, remotePath: String, data: ByteArray, timeoutMs: Long = SFTP_TRANSFER_WATCHDOG_MS) {
        check(session.isConnected) { "SSH session is down" }
        val ch = session.openChannel("sftp") as ChannelSftp
        val tmp = "$remotePath.wai-upload-${System.nanoTime()}"
        try {
            connectChannel(session, ch, "sftp", CHANNEL_OPEN_WATCHDOG_MS)
            if (Thread.currentThread().isInterrupted) throw InterruptedException("SFTP 操作已取消")
            trace("sftp atomic put begin bytes=${data.size} path=$remotePath")
            withSessionWatchdog(session, "sftp atomic put", timeoutMs) {
                ch.put(ByteArrayInputStream(data), tmp)
                try { ch.rm(remotePath) } catch (_: Exception) {}
                ch.rename(tmp, remotePath)
            }
            trace("sftp atomic put complete bytes=${data.size} path=$remotePath")
        } catch (e: Exception) {
            try { if (ch.isConnected) ch.rm(tmp) } catch (_: Exception) {}
            throw e
        } finally {
            try { ch.disconnect() } catch (_: Exception) {}
        }
    }
}
