#!/usr/bin/env python3
"""WAI Pad maintenance / diagnostics.

Safety rules:
- Never delete user models, training data, outputs, or the old WAI installation.
- Every repair creates a small restore point of WAI Pad companion/config files first.
- Safe repair only restarts services when health checks prove they are unhealthy.
- Deep repair is only called after explicit user confirmation in the app.
"""
import fcntl, json, os, shutil, subprocess, tarfile, threading, time
from datetime import datetime
from pathlib import Path
from urllib import request

BASE = Path('/root/WAI_Pad')
RUNTIME = BASE / 'runtime'
RESTORE = RUNTIME / 'restore_points'
REPAIR_LOG = RUNTIME / 'repairs.jsonl'
LOCK = threading.Lock()
LAST_REPAIR = {'at': 0.0}
UPDATE_LOCK = RUNTIME / 'update.lock'
CORE_LOCK = RUNTIME / 'core.lock'


def _config_path():
    for p in (Path('/root/WAI_v31/config.json'), Path('/root/WAI_v3/config.json'), Path('/root/WAI_v34_fullfix/config.json')):
        if p.exists(): return p
    return Path('/root/WAI_v31/config.json')




def _ctl_path():
    for p in (Path('/root/WAI_v31/WAI_ctl.sh'), Path('/root/WAI_v3/WAI_ctl.sh'), Path('/root/WAI_v34_fullfix/WAI_ctl.sh')):
        if p.exists(): return p
    return Path('/root/WAI_v31/WAI_ctl.sh')


def _try_process_lock(path):
    RUNTIME.mkdir(parents=True, exist_ok=True)
    f = path.open('a+')
    try:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return f
    except BlockingIOError:
        f.close(); return None


def _release_process_lock(f):
    if not f: return
    try: fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except Exception: pass
    try: f.close()
    except Exception: pass


def _run(cmd, timeout=90):
    try:
        p=subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout+p.stderr)[-12000:]
    except Exception as e:
        return 124, str(e)


def _up(url, timeout=3):
    try:
        with request.urlopen(url, timeout=timeout) as r:
            return 200 <= getattr(r, 'status', 200) < 400
    except Exception:
        return False


def _record(kind, ok, summary, actions=None, snapshot=None):
    item={'time':time.time(),'kind':kind,'ok':bool(ok),'summary':summary,'actions':actions or [],'snapshot':snapshot}
    try:
        RUNTIME.mkdir(parents=True, exist_ok=True)
        with REPAIR_LOG.open('a', encoding='utf-8') as f: f.write(json.dumps(item,ensure_ascii=False)+'\n')
    except Exception: pass
    return item


def repair_history(limit=20):
    try:
        rows=REPAIR_LOG.read_text('utf-8',errors='replace').splitlines()[-max(1,min(100,int(limit))):]
        return [json.loads(x) for x in rows if x.strip()][::-1]
    except Exception:
        return []


def create_restore_point(label='auto'):
    RESTORE.mkdir(parents=True, exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    out=RESTORE/f'{stamp}_{label}.tar.gz'
    candidates=[BASE/'job_api.py',BASE/'engine_v34.py',BASE/'maintenance.py',BASE/'guard.sh',BASE/'bootstrap.sh',_config_path()]
    with tarfile.open(out,'w:gz') as tf:
        for f in candidates:
            if f.exists() and f.is_file():
                arc=('WAI_Pad/'+f.name) if f.parent==BASE else ('WAI_CONFIG/'+f.name)
                tf.add(f, arcname=arc, recursive=False)
    points=sorted(RESTORE.glob('*.tar.gz'), key=lambda x:x.stat().st_mtime, reverse=True)
    for old in points[5:]:
        try: old.unlink()
        except Exception: pass
    return str(out)


def restore_latest():
    if not LOCK.acquire(blocking=False):
        return {'ok':False,'busy':True,'summary':'已有维护操作正在执行，请稍后再试。','actions':[]}
    proc_lock=None
    try:
        proc_lock=_try_process_lock(UPDATE_LOCK)
        if not proc_lock:
            return {'ok':False,'busy':True,'summary':'companion 文件更新/回滚正在执行，请稍后再试。','actions':[]}
        points=sorted(RESTORE.glob('*.tar.gz'), key=lambda x:x.stat().st_mtime, reverse=True)
        if not points:
            return {'ok':False,'summary':'没有可用恢复点','actions':[]}
        src=points[0]
        staging=RUNTIME/'rollback_staging'
        shutil.rmtree(staging, ignore_errors=True); staging.mkdir(parents=True, exist_ok=True)
        current_backup=RUNTIME/f'rollback_current_{os.getpid()}'
        shutil.rmtree(current_backup, ignore_errors=True); current_backup.mkdir(parents=True, exist_ok=True)
        names=('job_api.py','engine_v34.py','maintenance.py','guard.sh','bootstrap.sh')
        try:
            with tarfile.open(src,'r:gz') as tf:
                for m in tf.getmembers():
                    if m.name.startswith('/') or '..' in Path(m.name).parts: raise RuntimeError('恢复包路径异常')
                tf.extractall(staging)
            wp=staging/'WAI_Pad'
            py=[wp/'job_api.py',wp/'engine_v34.py',wp/'maintenance.py']
            if all(x.exists() for x in py):
                rc,out=_run(f"python3 -m py_compile {' '.join(str(x) for x in py)}",30)
                if rc!=0: raise RuntimeError('恢复点 Python 校验失败: '+out[-1000:])
            rc,out=_run(f"bash -n {wp/'guard.sh'} {wp/'bootstrap.sh'}",15)
            if rc!=0: raise RuntimeError('恢复点 Shell 校验失败: '+out[-1000:])

            for name in names:
                cur=BASE/name
                if cur.exists(): shutil.copy2(cur,current_backup/name)
            cfg=_config_path()
            if cfg.exists(): shutil.copy2(cfg,current_backup/'config.json')

            try:
                for name in names:
                    f=wp/name
                    if f.exists():
                        tmp=BASE/f'.{name}.rollback.{os.getpid()}'
                        shutil.copy2(f,tmp); os.chmod(tmp,0o700 if name.endswith('.sh') else 0o600); os.replace(tmp,BASE/name)
                oldcfg=staging/'WAI_CONFIG'/'config.json'
                if oldcfg.exists():
                    cfg.parent.mkdir(parents=True,exist_ok=True)
                    tmp=cfg.parent/f'.config.json.rollback.{os.getpid()}'
                    shutil.copy2(oldcfg,tmp); os.replace(tmp,cfg)
            except Exception:
                for name in names:
                    b=current_backup/name
                    if b.exists():
                        tmp=BASE/f'.{name}.restore-current.{os.getpid()}'
                        shutil.copy2(b,tmp); os.replace(tmp,BASE/name)
                b=current_backup/'config.json'
                if b.exists():
                    tmp=cfg.parent/f'.config.json.restore-current.{os.getpid()}'
                    shutil.copy2(b,tmp); os.replace(tmp,cfg)
                raise
            _record('rollback',True,f'已恢复 {src.name}', ['事务恢复 companion/config；服务将在下次初始化时加载'], str(src))
            return {'ok':True,'summary':f'已恢复到 {src.name}','snapshot':str(src),'restart_required':True}
        except Exception as e:
            _record('rollback',False,str(e),[],str(src))
            return {'ok':False,'summary':f'恢复失败：{e}','snapshot':str(src)}
        finally:
            shutil.rmtree(staging, ignore_errors=True); shutil.rmtree(current_backup, ignore_errors=True)
    finally:
        _release_process_lock(proc_lock); LOCK.release()


def diagnose(engine=None):
    issues=[]; checks=[]
    def add(name, ok, detail='', severity='error', suggestion=''):
        checks.append({'name':name,'ok':bool(ok),'detail':detail})
        if not ok: issues.append({'name':name,'severity':severity,'detail':detail,'suggestion':suggestion})

    comfy='http://127.0.0.1:6006/system_stats' if engine is None else engine.COMFY+'/system_stats'
    panel='http://127.0.0.1:6017/api/health'
    jobs='http://127.0.0.1:6027/v1/health'
    qwen='http://127.0.0.1:8011/v1/models'
    add('WAI Panel 6017',_up(panel),'面板健康检查',suggestion='安全修复会尝试 wai restart')
    add('ComfyUI 6006',_up(comfy),'生图引擎健康检查',suggestion='安全修复会优先重启服务')
    add('WAI Pad Jobs 6027',_up(jobs),'异步任务服务',suggestion='Android 守护/guard 会自动重启 companion')
    add('Qwen 8011',_up(qwen),'离线时会自动回退中文轻量模式',severity='warning',suggestion='不阻止生图；需要智能提示词时再修复')

    rc,gpu=_run('nvidia-smi -L',8); add('GPU',rc==0 and bool(gpu.strip()),gpu.strip().splitlines()[0] if gpu.strip() else '未检测到 GPU',suggestion='检查 AutoDL 实例/GPU 状态')
    try:
        du=shutil.disk_usage('/root/autodl-tmp'); free=du.free/1024**3
        add('数据盘空间',free>=8,f'{free:.1f} GB 可用',severity='warning' if free>=3 else 'error',suggestion='低于 8GB 建议清理无用缓存/旧输出；WAI Pad 不会自动删除模型或训练素材')
    except Exception as e: add('数据盘空间',False,str(e),suggestion='检查 /root/autodl-tmp')

    rc,ports=_run("ss -ltnp 2>/dev/null | grep -E ':(6006|6017|6027|8011)\\b' || true",8)
    checks.append({'name':'监听端口','ok':True,'detail':ports.strip() or '未读取到端口信息'})
    rc,dups=_run("ps -eo pid,args | grep -E '[p]ython.*(main.py|server.py|job_api.py)' | tail -40",8)
    checks.append({'name':'相关进程','ok':True,'detail':dups.strip() or '未读取到进程信息'})

    if engine is not None:
        model_checks=[
            ('基础模型', engine.model_file(engine.MODEL,'checkpoints'), engine.MODEL),
            ('Style LoRA', engine.style_lora_ready(), engine.active_style_lora()),
            ('IPAdapter', engine.ip_models_ready(), '人物参考依赖'),
            ('OpenPose ControlNet', engine.model_file(engine.OPENPOSE_NAME,'controlnet'), engine.OPENPOSE_NAME),
            ('Depth ControlNet', engine.depth_ready(), getattr(engine,'DEPTH_CONTROLNET','depth')),
            ('Composition', engine.composition_ready(), getattr(engine,'COMPOSITION_IP','composition')),
        ]
        for name,ok,detail in model_checks:
            add(name,ok,detail,suggestion='模型缺失不会自动删除/替换；请在依赖检查中确认后再补齐')

    return {'ok':not any(i['severity']=='error' for i in issues),'time':time.time(),'checks':checks,'issues':issues,'summary':('全部关键检查通过' if not issues else f'发现 {len(issues)} 项需要注意')}


def repair(engine=None, level='safe', active_job=False, reason='manual'):
    level='deep' if level=='deep' else 'safe'
    if active_job:
        return {'ok':False,'busy':True,'summary':'当前有生图任务运行，为避免中断任务，本次修复已延后。','actions':[]}
    if not LOCK.acquire(blocking=False):
        return {'ok':False,'busy':True,'summary':'已有修复正在执行，请稍后再试。','actions':[]}
    proc_lock=None
    try:
        proc_lock=_try_process_lock(CORE_LOCK)
        if not proc_lock:
            return {'ok':False,'busy':True,'summary':'已有核心 WAI 修复正在执行；companion 控制面不受影响。','actions':[]}
        # Prevent repair loops caused by repeated UI taps / guard overlap.
        if time.time()-LAST_REPAIR['at'] < 12:
            return {'ok':False,'busy':True,'summary':'刚完成过一次修复，正在观察服务稳定性。','actions':[]}
        LAST_REPAIR['at']=time.time()
        before=diagnose(engine)
        snap=create_restore_point('before_'+level)
        actions=[]
        comfy='http://127.0.0.1:6006/system_stats' if engine is None else engine.COMFY+'/system_stats'
        panel='http://127.0.0.1:6017/api/health'
        qwen='http://127.0.0.1:8011/v1/models'

        core_bad=not _up(panel) or not _up(comfy)
        if core_bad:
            rc,out=_run('wai restart',180); actions.append({'action':'wai restart','ok':rc==0,'output':out[-2000:]})
            time.sleep(7)
        else:
            actions.append({'action':'核心服务','ok':True,'output':'Panel/ComfyUI 正常，无需重启'})

        # Safe level escalates to the existing controlled repair only if restart failed.
        still_bad=not _up(panel) or not _up(comfy)
        ctl=_ctl_path()
        if (still_bad or level=='deep') and ctl.exists():
            rc,out=_run(f"{ctl} repair",220); actions.append({'action':'WAI_ctl.sh repair','ok':rc==0,'output':out[-3000:]})
            time.sleep(8)

        # Qwen is non-critical. Try wai start only when it is down and core is already healthy;
        # do not make Qwen failure turn an otherwise usable app into a repair loop.
        if not _up(qwen) and _up(panel) and _up(comfy):
            actions.append({'action':'Qwen','ok':False,'output':'Qwen 当前离线；保留中文轻量回退，不重复重启核心服务'})

        after=diagnose(engine)
        ok=after['ok']
        summary='修复完成，关键服务正常' if ok else '修复已执行，但仍有项目需要处理'
        _record(level,ok,summary,actions,snap)
        return {'ok':ok,'level':level,'summary':summary,'snapshot':snap,'before':before,'after':after,'actions':actions}
    except Exception as e:
        _record(level,False,f'修复异常：{e}',[],None)
        return {'ok':False,'summary':f'修复异常：{e}','actions':[]}
    finally:
        _release_process_lock(proc_lock)
        LOCK.release()
