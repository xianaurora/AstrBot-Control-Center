(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const qsa = s => Array.from(document.querySelectorAll(s));
  const pending = new Map(), bootPending = new Map(), savePending = new Map(), albumImportPending = new Map(), refUploadPending = new Map(), posePreviewPending = new Map();
  let mode = 'txt', bootstrapped = false, companionAvailable = false, jobsAvailable = false, currentJobIds = [], localTasks = new Map(), lastBootstrapAttempt = 0, loadedConfig = {};

  window.WAI_NATIVE = {
    onApi(id, ok, payload) {
      const p = pending.get(id); if (!p) return; pending.delete(id);
      let data = payload; try { data = JSON.parse(payload); } catch (_) {}
      ok ? p.resolve(data) : p.reject(data);
    },
    onBootstrap(id, ok, output) {
      const p = bootPending.get(id); if (!p) return; bootPending.delete(id);
      ok ? p.resolve(output) : p.reject(output);
    },
    onImageSaved(id, ok, payload) {
      const p = savePending.get(id); if (!p) return; savePending.delete(id);
      let data = payload; try { data = JSON.parse(payload); } catch (_) {}
      ok ? p.resolve(data) : p.reject(data);
    },
    onAlbumImported(id, ok, payload) {
      const p = albumImportPending.get(id); if (!p) return; albumImportPending.delete(id);
      let data = payload; try { data = JSON.parse(payload); } catch (_) {}
      ok ? p.resolve(data) : p.reject(data);
    },
    onReferenceUploaded(id, ok, payload) {
      const p = refUploadPending.get(id); if (!p) return; refUploadPending.delete(id);
      let data = payload; try { data = JSON.parse(payload); } catch (_) {}
      ok ? p.resolve(data) : p.reject(data);
    },
    onPosePreview(id, ok, payload) {
      const p = posePreviewPending.get(id); if (!p) return; posePreviewPending.delete(id);
      let data = payload; try { data = JSON.parse(payload); } catch (_) {}
      ok ? p.resolve(data) : p.reject(data);
    }
  };

  function errText(e) {
    if (!e) return '未知错误';
    if (typeof e === 'string') return e;
    if (e.error || e.message || e.summary || e.suggestion) return e.error || e.message || e.summary || e.suggestion;
    if (typeof Event !== 'undefined' && e instanceof Event) {
      const t = e.type || 'error';
      if (t === 'abort') return '操作被中断';
      if (t === 'timeout') return '连接或本地读写超时';
      return '本机与 WAI Pad 服务之间发生网络或文件读写错误';
    }
    const text = String(e);
    return /^\[object .+Event\]$/.test(text) ? '本机与 WAI Pad 服务之间发生网络或文件读写错误' : text;
  }
  function esc(v){ return String(v ?? '').replace(/[&<>'"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
  function log(s) {
    const el = $('log'); if (!el) return;
    el.textContent += `[${new Date().toLocaleTimeString()}] ${s}\n`;
    el.scrollTop = el.scrollHeight;
  }
  function cancelNative(id){ try{ if(Native && typeof Native.cancelOperation==='function') Native.cancelOperation(id); }catch(_){} }
  function timeoutPending(map,id,reject,message,ms){
    setTimeout(()=>{ if(map.has(id)){ map.delete(id); cancelNative(id); reject({error:message}); } },ms);
  }
  function api(method, path, body = {}) {
    return new Promise((resolve, reject) => {
      const id = 'r' + Math.random().toString(36).slice(2);
      pending.set(id, {resolve, reject});
      try { Native.apiRequest(id, method, path, JSON.stringify(body)); }
      catch(e){ pending.delete(id); return reject({error:errText(e)}); }
      const timeout = (path === '/v1/images/init' || path.startsWith('/v1/images/')) ? 50000 : (path === '/v1/images' ? 330000 : (path.includes('/jobs/') ? 220000 : 200000));
      timeoutPending(pending,id,reject,'请求超时',timeout);
    });
  }
  function bootstrap() {
    return new Promise((resolve, reject) => {
      const id = 'b' + Math.random().toString(36).slice(2);
      bootPending.set(id, {resolve, reject}); Native.bootstrapServer(id);
      timeoutPending(bootPending,id,reject,'服务器初始化超时',380000);
    });
  }
  function restartFromDisk() {
    return new Promise((resolve, reject) => {
      const id = 'rb' + Math.random().toString(36).slice(2);
      bootPending.set(id, {resolve, reject}); Native.restartServerFromDisk(id);
      timeoutPending(bootPending,id,reject,'恢复后重启超时',380000);
    });
  }
  function saveJob(jobId, metadata) {
    return new Promise((resolve, reject) => {
      const id = 's' + Math.random().toString(36).slice(2);
      savePending.set(id, {resolve, reject}); Native.downloadJobImage(id, jobId, JSON.stringify(metadata || {}));
      timeoutPending(savePending,id,reject,'保存到本机超时',230000);
    });
  }
  function importLocalAlbum() {
    return new Promise((resolve, reject) => {
      const id = 'a' + Math.random().toString(36).slice(2);
      albumImportPending.set(id, {resolve, reject}); Native.importLocalAlbum(id);
      timeoutPending(albumImportPending,id,reject,'本机保险库导入超时',240000);
    });
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function isConnError(e){ const t=errText(e).toLowerCase(); return /connection reset|failed to connect|broken pipe|timed out|timeout|请求超时|连接|unexpected end of stream|end of stream|stream was reset|socket closed|socket.*closed|eof|connection aborted/.test(t); }
  async function recoverTunnel(reason='连接异常'){
    log(`${reason}，请求 WAI Pad 重建 SSH 隧道…`);
    try { Native.forceReconnect(); } catch (_) {}
    companionAvailable=false; jobsAvailable=false; bootstrapped=false;
    const end=Date.now()+35000;
    while(Date.now()<end){ await sleep(1200); await detectJobs(); if(jobsAvailable)return true; }
    return false;
  }
  function fmtBytes(n) { n = Number(n || 0); if (n < 1024*1024) return `${(n/1024).toFixed(1)} KB`; if (n < 1024*1024*1024) return `${(n/1024/1024).toFixed(1)} MB`; return `${(n/1024/1024/1024).toFixed(2)} GB`; }

  const titles = {create:'创作',tasks:'任务',gallery:'图库',console:'控制台',tools:'工具',embed:'内嵌',settings:'设置'};
  qsa('.nav button').forEach(b => b.addEventListener('click', () => {
    qsa('.nav button').forEach(x => x.classList.remove('active')); b.classList.add('active');
    qsa('.page').forEach(x => x.classList.remove('on')); $(b.dataset.page).classList.add('on');
    $('pageTitle').textContent = titles[b.dataset.page] || 'WAI Pad';
    if (b.dataset.page === 'gallery') refreshGallery();
    if (b.dataset.page === 'console') { refreshStatus(); refreshLogs(); refreshRepairHistory(); }
    if (b.dataset.page === 'tasks') refreshTasks();
  }));

  function fileControls() {
    const box = $('fileArea'); box.innerHTML = '';
    const mk = (id, label) => { const w=document.createElement('div'); w.innerHTML=`<div class="label">${label}</div><input id="${id}" type="file" accept="image/*">`; box.appendChild(w); };
    if (mode === 'img') mk('imageA','原图');
    if (mode === 'ref') mk('imageA','人物参考图 A');
    if (mode === 'pp') { mk('imageA','人物参考图 A'); mk('imageB','动作参考图 B'); }
    $('imgAdvanced').classList.toggle('hidden', mode !== 'img');
    $('strictWrap').classList.toggle('hidden', mode !== 'pp'); $('styleLockWrap').classList.toggle('hidden', !['ref','pp'].includes(mode));
    $('posePreview').classList.toggle('hidden', mode !== 'pp');
    $('steps').value = mode === 'pp' ? ($('strict').checked ? '36':'32') : '30';
    $('cfg').value = '4.6';
  }
  fileControls();
  qsa('#modeTabs button').forEach(b => b.addEventListener('click', () => { qsa('#modeTabs button').forEach(x=>x.classList.remove('on')); b.classList.add('on'); mode=b.dataset.mode; fileControls(); }));
  $('strict').addEventListener('change',()=>{ if(mode==='pp') $('steps').value=$('strict').checked?'36':'32'; });
  $('denoise').addEventListener('input',()=> $('denoiseVal').textContent=Number($('denoise').value).toFixed(2));


  // Android WebView + some Chinese IMEs can leave a textarea in a broken composing state
  // after Select all -> Delete. Intercept a full-selection delete and perform the clear
  // ourselves, then keep the caret in a valid editable position.
  function installAndroidEditableRecovery(el) {
    if (!el) return;
    let composing = false;
    el.addEventListener('compositionstart', () => { composing = true; });
    el.addEventListener('compositionend', () => {
      composing = false;
      if (!el.disabled && !el.readOnly) {
        const n = el.value.length;
        try { el.setSelectionRange(n, n); } catch (_) {}
      }
    });
    el.addEventListener('beforeinput', ev => {
      const isDelete = String(ev.inputType || '').startsWith('delete');
      const allSelected = el.value.length > 0 && el.selectionStart === 0 && el.selectionEnd === el.value.length;
      if (isDelete && allSelected) {
        ev.preventDefault();
        composing = false;
        el.value = '';
        try { el.setSelectionRange(0, 0); } catch (_) {}
        el.dispatchEvent(new Event('input', {bubbles:true}));
        requestAnimationFrame(() => { if (document.activeElement !== el) el.focus(); try { el.setSelectionRange(0,0); } catch (_) {} });
      }
    });
    el.addEventListener('input', ev => {
      // Safety net for WebViews where beforeinput is not delivered by the IME.
      if (el.value === '' && !composing && String(ev.inputType || '').startsWith('delete')) {
        el.disabled = false; el.readOnly = false;
        requestAnimationFrame(() => { try { el.setSelectionRange(0,0); } catch (_) {} });
      }
    });
    el.addEventListener('focus', () => { el.disabled = false; el.readOnly = false; });
  }
  ['prompt','actionPrompt','negative','actionNegative'].forEach(id=>installAndroidEditableRecovery($(id)));

  function clearEditable(id) { const el=$(id); if(!el)return; el.value=''; el.disabled=false; el.readOnly=false; el.focus(); try{el.setSelectionRange(0,0)}catch(_){} el.dispatchEvent(new Event('input',{bubbles:true})); }
  $('clearPrompt').addEventListener('click',()=>clearEditable('prompt'));
  $('clearActionPrompt').addEventListener('click',()=>clearEditable('actionPrompt'));
  $('clearNegative').addEventListener('click',()=>clearEditable('negative'));
  $('clearActionNegative').addEventListener('click',()=>clearEditable('actionNegative'));

  function joinPromptParts(a,b){
    const parts=[String(a||'').trim(),String(b||'').trim()].filter(Boolean);
    if(!parts.length)return '';
    const sep=$('promptMode').value==='english'?', ':'，';
    return parts.join(sep);
  }
  function splitPromptFields(){
    const promptCharacter=$('prompt').value.trim(), promptAction=$('actionPrompt').value.trim();
    const negativeCharacter=$('negative').value.trim(), negativeAction=$('actionNegative').value.trim();
    return {prompt_character:promptCharacter,prompt_action:promptAction,negative_character:negativeCharacter,negative_action:negativeAction,prompt:joinPromptParts(promptCharacter,promptAction),negative:joinPromptParts(negativeCharacter,negativeAction)};
  }

  function readFile(id) {
    return new Promise((resolve, reject) => {
      const el=$(id); if(!el || !el.files || !el.files[0]) return resolve(null);
      const f=el.files[0], objectUrl=URL.createObjectURL(f), img=new Image();
      img.onload=()=>resolve({file:f,objectUrl,w:img.naturalWidth||0,h:img.naturalHeight||0,name:f.name||'',size:Number(f.size||0),mime:f.type||''});
      img.onerror=()=>resolve({file:f,objectUrl,w:0,h:0,name:f.name||'',size:Number(f.size||0),mime:f.type||'',dimensionWarning:true});
      img.src=objectUrl;
    });
  }

  function fileToDataUrl(file){
    return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>typeof r.result==='string'?resolve(r.result):reject({error:'图片读取结果无效'});r.onerror=()=>reject({error:`读取图片 ${file?.name||''} 失败`});r.onabort=()=>reject({error:'图片读取被中断'});try{r.readAsDataURL(file)}catch(e){reject({error:errText(e)})}});
  }

  function approxDataBytes(data){
    if(!data || typeof data!=='string')return 0;
    const i=data.indexOf(','),n=(i>=0?data.length-i-1:data.length);
    return Math.floor(n*3/4);
  }

  async function prepareReference(info,kind,label){
    if(!info || !info.file)return info;
    const before=Number(info.size||0), maxSide=kind==='pose'?1600:(kind==='character'?1792:2048), threshold=kind==='pose'?3*1024*1024:4*1024*1024;
    const mustResize=!!(info.w&&info.h&&(before>threshold||Math.max(info.w,info.h)>maxSide));
    try{
      if(!mustResize) return {...info,data:await fileToDataUrl(info.file)};
      $('genMsg').textContent=`正在优化${label}，减少上传等待…`;
      const result=await new Promise((resolve,reject)=>{
        const img=new Image();
        img.onload=()=>{try{const scale=Math.min(1,maxSide/Math.max(img.naturalWidth||1,img.naturalHeight||1));const w=Math.max(1,Math.round(img.naturalWidth*scale)),h=Math.max(1,Math.round(img.naturalHeight*scale));const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d',{alpha:false});ctx.drawImage(img,0,0,w,h);let data=c.toDataURL('image/webp',kind==='pose'?0.90:0.94);if(!data.startsWith('data:image/webp'))data=c.toDataURL('image/jpeg',0.94);const after=approxDataBytes(data);log(`${label}上传优化：${fmtBytes(before)} → ${fmtBytes(after)}，${info.w}×${info.h} → ${w}×${h}`);resolve({...info,data,w,h,size:after,optimized:true})}catch(e){reject(e)}};
        img.onerror=()=>reject({error:`${label}无法解码`});img.src=info.objectUrl;
      });
      return result;
    }catch(e){log(`${label}优化失败，改用原图：${errText(e)}`);return {...info,data:await fileToDataUrl(info.file)};}
    finally{try{URL.revokeObjectURL(info.objectUrl)}catch(_){}}
  }

  async function buildRequest(){
    const parts=splitPromptFields();
    if(!parts.prompt)throw{error:'请在“人物特征”或“动作 / 场景”里至少输入一项正面提示词'};
    const [w,h]=$('size').value.split('x').map(Number);
    const d={mode,prompt_mode:$('promptMode').value,...parts,width:w,height:h,seed:Number($('seed').value||-1),steps:Number($('steps').value||28),cfg:Number($('cfg').value||4.8)};
    if(mode==='img'){let a=await readFile('imageA');if(!a)throw{error:'请选择原图'};a=await prepareReference(a,'image','原图');d.image=a.data;d.denoise=Number($('denoise').value)}
    if(mode==='ref'){let a=await readFile('imageA');if(!a)throw{error:'请选择人物参考图'};a=await prepareReference(a,'character','人物参考图');d.image=a.data;d.style_lock=$('styleLock').checked}
    if(mode==='pp'){let a=await readFile('imageA'),b=await readFile('imageB');if(!a||!b)throw{error:'人物图 A 和动作图 B 都要选择'};a=await prepareReference(a,'character','人物参考图 A');b=await prepareReference(b,'pose','动作参考图 B');d.person=a.data;d.pose=b.data;d.pose_width=b.w;d.pose_height=b.h;d.strict=$('strict').checked;d.style_lock=$('styleLock').checked}
    return d;
  }

  async function optimizePrompt() {
    const parts=splitPromptFields();
    if(!parts.prompt) return $('genMsg').textContent='请先输入人物特征或动作提示词';
    $('genMsg').textContent='正在整理并预览合并后的提示词…';
    const body={mode,prompt_mode:$('promptMode').value,...parts};
    try {
      let j; try { j=await api('POST','/v1/prompts/optimize',body); } catch(_) { j=await api('POST','/api/optimize',{...body,mode:mode==='pp'?'person_pose':mode}); }
      $('promptPreviewPositive').value=j.positive||parts.prompt; $('promptPreviewNegative').value=j.negative||parts.negative; $('promptPreviewWrap').classList.remove('hidden'); $('promptPreviewWrap').open=true; $('genMsg').textContent=(j.note||'整理完成')+'；四个输入框保持分开，不会被合并覆盖';
    } catch(e) { $('genMsg').textContent='整理失败：'+errText(e); }
  }
  $('optimize').addEventListener('click', optimizePrompt);

  function setMainProgress(job) {
    const p=Math.max(0,Math.min(100,Number(job.progress||0))); $('bar').style.width=p+'%';
    const stage=job.detail||job.stage||job.status||''; $('taskStage').textContent=stage; $('genMsg').textContent=`${stage}${p?` · ${p}%`:''}`;
  }

  async function saveCompletedJob(jobId, meta, attempts = 3) {
    let lastErr = null;
    for (let i = 1; i <= attempts; i++) {
      try {
        const saved = await saveJob(jobId, meta);
        $('retrySave').classList.add('hidden');
        return saved;
      } catch (e) {
        lastErr = e;
        log(`任务 ${jobId} 本机保存第 ${i}/${attempts} 次失败：${errText(e)}`);
        if (i < attempts) {
          $('genMsg').textContent = `图片已生成，保存到平板失败，正在自动重试 ${i}/${attempts - 1}…`;
          await sleep(1400 * i);
        }
      }
    }
    $('retrySave').classList.remove('hidden');
    throw {generated:true, kind:'local_save', job_id:jobId, error:'图片已经生成成功，但还没有保存到平板本机', suggestion:'远端成图会暂时保留。恢复连接后点“重试保存到本机”，不需要重新生成。', cause:errText(lastErr)};
  }

  async function pollJob(jobId) {
    let last={id:jobId,status:'queued',progress:0,detail:'等待 GPU'}, failures=0;
    for (;;) {
      try { last=await api('GET',`/v1/jobs/${jobId}`); failures=0; localTasks.set(jobId,last); renderTasks(); setMainProgress(last); }
      catch(e) { failures++; const t=errText(e); if(/404|job not found|not found/i.test(t)) throw {error:`任务 ${jobId} 已不存在，停止轮询`}; if(failures>=12) throw {error:`连续无法读取任务状态：${t}`,suggestion:'任务仍可能在服务器运行，可稍后到“任务”页刷新恢复。'}; await sleep(Math.min(5000,900+failures*350)); continue; }
      if (last.status==='completed') {
        const req=last.request||{}; const meta={job_id:jobId,mode:req.mode||mode,prompt:req.prompt||'',prompt_character:req.prompt_character||'',prompt_action:req.prompt_action||'',negative_character:req.negative_character||'',negative_action:req.negative_action||'',negative:last.negative||req.negative||'',positive:last.positive||'',seed:last.seed,steps:last.steps,cfg:last.cfg,time:Date.now(),favorite:false};
        $('genMsg').textContent='图片已生成，正在保存到 WAI Pad 本机图库…';
        const saved=await saveCompletedJob(jobId,meta);
        $('result').src=saved.url; $('result').style.display='block'; $('placeholder').style.display='none';
        $('taskStage').textContent='本机保存完成'; $('genMsg').textContent=saved.remote_cleanup_ok===false?'已保存到本机 Pictures/WAI Pad；远端临时成图将在连接恢复后自动清理':'已保存到本机 Pictures/WAI Pad；AutoDL 临时成图已清理';
        log(`任务 ${jobId} 已本地保存：${saved.name}`); refreshGallery(); return saved;
      }
      if (last.status==='failed') throw {error:last.error||'生成失败',suggestion:last.suggestion||''};
      if (last.status==='cancelled') throw {error:'任务已取消'};
      await sleep(900);
    }
  }

  function uploadReferenceNative(data, kind, label='参考图') {
    return new Promise((resolve, reject) => {
      if (!Native || typeof Native.uploadReferenceSftp !== 'function') return reject({error:'native-sftp-unavailable'});
      const id='u'+Math.random().toString(36).slice(2);
      refUploadPending.set(id,{resolve,reject});
      try { Native.uploadReferenceSftp(id,data,kind); }
      catch(e) { refUploadPending.delete(id); return reject({error:errText(e)}); }
      timeoutPending(refUploadPending,id,reject,`${label} SFTP 上传超时`,210000);
    });
  }

  function previewPoseNative(data) {
    return new Promise((resolve, reject) => {
      if (!Native || typeof Native.previewPoseSftp !== 'function') return reject({error:'native-pose-preview-unavailable'});
      const id='p'+Math.random().toString(36).slice(2);
      posePreviewPending.set(id,{resolve,reject});
      try { Native.previewPoseSftp(id,data); }
      catch(e) { posePreviewPending.delete(id); return reject({error:errText(e)}); }
      timeoutPending(posePreviewPending,id,reject,'动作预览 SSH 通道超时',330000);
    });
  }

  async function requestPosePreview(data){
    // v0.3.4.7 primary path: no multi-megabyte request OR response crosses the
    // localhost HttpURLConnection/SSH port-forward. Native uses SFTP + SSH exec.
    if (Native && typeof Native.previewPoseSftp === 'function') {
      let last=null;
      for(let attempt=1;attempt<=2;attempt++){
        try { return await previewPoseNative(data); }
        catch(e){
          last=e;
          if(attempt<2){
            $('genMsg').textContent='动作预览连接中断，正在重新初始化安全通道…';
            try{await bootstrap();}catch(_){}
            await sleep(900);
            continue;
          }
        }
      }
      throw last||{error:'动作预览失败'};
    }

    // Compatibility fallback: stage input first so at least the large request body
    // is never sent through the HTTP tunnel. New APKs never need this branch.
    if (jobsAvailable) {
      const staged=await uploadReference(data,'pose-preview','动作参考图 B');
      try { return await api('POST','/v1/pose/preview',{pose_id:staged.id}); }
      finally { await cleanupStagedUploads([staged.id]); }
    }
    return await api('POST','/api/preview_pose',{pose:data});
  }

  async function uploadReference(data, kind, label='参考图'){
    if(!data)return null;
    const comma=data.indexOf(',');
    if(comma<6)throw{error:`${label}数据无效，请重新选择`};
    const head=data.slice(0,comma), payload=data.slice(comma+1);
    const mm=head.match(/^data:(image\/[^;]+);base64$/i);
    if(!mm)throw{error:`${label}不是可识别的图片文件`};
    const mime=mm[1].toLowerCase();
    const approxBytes=Math.floor(payload.length*3/4);
    if(!payload || approxBytes>40*1024*1024)throw{error:`${label}为空或超过 40MB`};

    // v0.3.4.7: reference bytes use a dedicated SSH/SFTP channel instead of the
    // localhost HTTP port-forward. This avoids Android's flaky
    // "unexpected end of stream" on multi-megabyte request bodies.
    if (Native && typeof Native.uploadReferenceSftp === 'function') {
      $('genMsg').textContent=`正在通过 SSH 安全上传${label}…`;
      try {
        const done=await uploadReferenceNative(data,kind,label);
        if(done&&done.id){
          $('genMsg').textContent=`${label}上传完成 · ${fmtBytes(done.size||approxBytes)} · SSH直传`;
          $('bar').style.width='18%';
          return done;
        }
      } catch(e) {
        log(`${label} SSH直传失败，自动回退分片上传：${errText(e)}`);
        if(isConnError(e)){ try{await recoverTunnel(`${label} SSH直传异常`);}catch(_){} }
        $('genMsg').textContent=`${label} SSH直传未完成，自动切换兼容上传…`;
      }
    }

    // Fallback for old APKs / unusual SSH failures. Keep each HTTP request small.
    // 256 KiB is divisible by 4, so every non-final Base64 slice decodes independently.
    const CHUNK_CHARS=256*1024;
    const totalChunks=Math.ceil(payload.length/CHUNK_CHARS);
    let session=null, last=null;
    for(let attempt=1;attempt<=2;attempt++){
      try {
        session=await api('POST','/v1/images/init',{kind,mime,total_chunks:totalChunks,total_chars:payload.length});
        break;
      } catch(e) {
        last=e; const t=errText(e);
        if(attempt<2 && /404|not found/.test(t)){
          $('genMsg').textContent='正在更新参考图上传服务…';
          try{await bootstrap();}catch(_){} await sleep(1200); continue;
        }
        if(attempt<2 && isConnError(e)){await recoverTunnel('初始化参考图上传失败');continue;}
        throw e;
      }
    }
    if(!session||!session.id)throw last||{error:'无法建立参考图上传会话'};
    const uid=session.id;
    try {
      let index=Math.max(0,Number(session.next_index||0));
      while(index<totalChunks){
        const chunk=payload.slice(index*CHUNK_CHARS,Math.min(payload.length,(index+1)*CHUNK_CHARS));
        let result=null;
        for(let attempt=1;attempt<=3;attempt++){
          try {
            result=await api('POST',`/v1/images/${uid}/chunk`,{index,data:chunk});
            break;
          } catch(e) {
            last=e;
            if(attempt<3 && isConnError(e)){
              $('genMsg').textContent=`${label}上传中断，正在续传 ${index+1}/${totalChunks}…`;
              await recoverTunnel(`${label}上传连接中断`); continue;
            }
            throw e;
          }
        }
        if(!result)throw last||{error:`${label}分片上传失败`};
        const next=Math.max(index+1,Number(result.next_index||0));
        index=Math.min(totalChunks,next);
        const sentChars=Math.min(payload.length,index*CHUNK_CHARS);
        const pct=Math.max(1,Math.min(99,Math.round(sentChars*100/payload.length)));
        $('genMsg').textContent=`正在安全上传${label} ${pct}% · ${index}/${totalChunks} 段`;
        $('bar').style.width=`${Math.max(3,Math.min(18,3+pct*0.15))}%`;
      }
      const done=await api('POST',`/v1/images/${uid}/finalize`,{});
      if(!done||!done.id)throw{error:`${label}上传完成但服务器没有返回图片 ID`};
      $('genMsg').textContent=`${label}上传完成 · ${fmtBytes(done.size||approxBytes)}`;
      return done;
    } catch(e) {
      try{await api('DELETE',`/v1/images/${uid}`,{});}catch(_){}
      throw e;
    }
  }

  async function stageJobImages(d){
    const out={...d}, uploadIds=[];
    try {
      if(out.image){ const u=await uploadReference(out.image,out.mode==='ref'?'character':'image',out.mode==='ref'?'人物参考图 A':'原图'); delete out.image; out.image_id=u.id; uploadIds.push(u.id); }
      if(out.person){ const u=await uploadReference(out.person,'character','人物参考图 A'); delete out.person; out.person_id=u.id; uploadIds.push(u.id); }
      if(out.pose){ const u=await uploadReference(out.pose,'pose','动作参考图 B'); delete out.pose; out.pose_id=u.id; uploadIds.push(u.id); }
      return {request:out,uploadIds};
    } catch(e) {
      await cleanupStagedUploads(uploadIds);
      throw e;
    }
  }

  async function cleanupStagedUploads(ids){
    await Promise.allSettled((ids||[]).map(id=>api('DELETE',`/v1/images/${id}`,{})));
  }

  async function submitJob(one, clientId){
    one.client_request_id=clientId;
    let last=null;
    for(let attempt=1;attempt<=2;attempt++){
      try { return await api('POST','/v1/jobs',one); }
      catch(e){ last=e; if(attempt<2 && isConnError(e)){ await recoverTunnel('提交任务连接中断'); continue; } if(!isConnError(e))throw e; }
    }
    // Both POST responses may be lost even though the first request committed. Query by the
    // persisted idempotency key before ever telling the user the submit failed.
    try{await recoverTunnel('提交响应丢失');const found=await api('GET',`/v1/jobs?client_request_id=${encodeURIComponent(clientId)}&limit=1`,{});if(found.items&&found.items[0])return {id:found.items[0].id,status:found.items[0].status,deduplicated:true};}catch(_){}
    throw last||{error:'提交任务失败'};
  }

  async function asyncGenerate(d, count) {
    $('genMsg').textContent='正在安全上传参考图…';
    const staged=await stageJobImages(d), base=staged.request, ids=[];
    let submitError=null;
    try {
      for(let i=0;i<count;i++) {
        const one={...base}; if(Number.isFinite(base.seed)&&base.seed>=0) one.seed=base.seed+i;
        const clientId=`pad_${Date.now()}_${i}_${Math.random().toString(36).slice(2,10)}`;
        try {
          const j=await submitJob(one,clientId); ids.push(j.id); currentJobIds=ids.slice();
          localTasks.set(j.id,{id:j.id,status:'queued',progress:0,detail:`第 ${i+1}/${count} 张等待 GPU`,request:{mode:base.mode,prompt:base.prompt,prompt_character:base.prompt_character||'',prompt_action:base.prompt_action||''}}); renderTasks();
        } catch(e) { submitError=e; break; }
      }
    } finally { await cleanupStagedUploads(staged.uploadIds); }
    if(!ids.length) throw submitError||{error:'没有任务成功提交'};
    let completed=0;
    const settled=await Promise.allSettled(ids.map(async id=>{try{const saved=await pollJob(id);completed++;$('taskStage').textContent=`本机保存 ${completed}/${ids.length}`;$('genMsg').textContent=`已完成 ${completed}/${ids.length}，图片已保存到本机 Pictures/WAI Pad`;return saved;}finally{currentJobIds=currentJobIds.filter(x=>x!==id);}}));
    const failures=settled.filter(x=>x.status==='rejected');
    if(failures.length) throw failures[0].reason;
    if(submitError) throw {error:`仅成功提交 ${ids.length}/${count} 个任务；已提交任务均已跟踪并保存`,cause:errText(submitError)};
  }

  async function legacyGenerate(d, count) {
    log('异步 companion 暂未就绪，使用旧 WAI 兼容模式。');
    for(let i=0;i<count;i++) {
      $('genMsg').textContent=`兼容模式生成 ${i+1}/${count}…`;
      const j=await api('POST','/api/generate',d);
      if(!j.image) throw {error:'旧后端没有返回图片'};
      const meta={mode:d.mode,prompt:d.prompt,prompt_character:d.prompt_character||'',prompt_action:d.prompt_action||'',negative_character:d.negative_character||'',negative_action:d.negative_action||'',negative:j.negative||d.negative,positive:j.positive||'',seed:d.seed,steps:d.steps,cfg:d.cfg,time:Date.now(),legacy:true};
      const saved=JSON.parse(Native.saveImage(j.image,'wai',JSON.stringify(meta))); $('result').src=saved.url; $('result').style.display='block'; $('placeholder').style.display='none'; refreshGallery();
    }
  }

  $('generate').addEventListener('click', async () => {
    $('generate').disabled=true; $('bar').style.width='3%'; $('taskStage').textContent='准备任务';
    try { const d=await buildRequest(), count=Math.max(1,Math.min(4,Number($('count').value||1))); if(!jobsAvailable){$('genMsg').textContent='正在等待 WAI Pad 自动启动/修复服务…';await waitForJobs(25000);} if(!jobsAvailable){$('genMsg').textContent='自动服务仍未就绪，执行一次重新初始化…';await doBootstrap();await waitForJobs(10000);} if(!jobsAvailable)throw{error:'WAI Pad 隐私任务服务未就绪。为保证参考图/成图不会长期留在 AutoDL，主界面不会降级到旧同步生图。'}; $('genMsg').textContent=`提交 ${count} 个任务…`; await asyncGenerate(d,count); $('bar').style.width='100%'; setTimeout(()=>$('bar').style.width='0',1600); }
    catch(e) {
      $('bar').style.width='0';
      const extra=e&&e.suggestion?`；${e.suggestion}`:'';
      const prefix=e&&e.generated?'本地保存待恢复：':'生成失败：';
      const cause=e&&e.cause?`（${e.cause}）`:'';
      $('genMsg').textContent=prefix+errText(e)+extra+cause;
      log(prefix+errText(e)+extra+cause);
      if(e&&e.generated) { $('retrySave').classList.remove('hidden'); $('taskStage').textContent='成图已完成 · 等待本机续存'; setTimeout(refreshTasks,800); }
    }
    finally { $('generate').disabled=false; currentJobIds=[]; }
  });

  $('cancel').addEventListener('click', async()=>{
    try {
      if(companionAvailable && currentJobIds.length) { await Promise.allSettled(currentJobIds.map(id=>api('DELETE',`/v1/jobs/${id}`,{}))); $('genMsg').textContent='已发送定向取消请求'; }
      else { $('genMsg').textContent='当前没有由主界面跟踪的可取消任务；不会发送全局 ComfyUI interrupt。'; }
    } catch(e){ $('genMsg').textContent='取消失败：'+errText(e); }
  });

  $('posePreview').addEventListener('click', async()=>{
    if(mode!=='pp')return; let b=await readFile('imageB'); if(!b)return $('genMsg').textContent='请先选择动作参考图 B';
    $('genMsg').textContent='正在通过 SSH 检查动作骨架和 Depth…'; $('posePreview').disabled=true;
    try { b=await prepareReference(b,'pose','动作参考图 B'); const j=await requestPosePreview(b.data); const box=$('posePreviewBox'); box.replaceChildren(); (j.items||[]).forEach(it=>{if(typeof it.image!=='string'||!/^data:image\/(png|jpeg|webp);base64,/i.test(it.image))return;const f=document.createElement('figure'),cap=document.createElement('figcaption'),img=document.createElement('img');cap.textContent=String(it.label||'预览');img.src=it.image;img.alt=String(it.label||'预览');f.append(cap,img);box.appendChild(f)}); $('genMsg').textContent=j.note||'动作预览完成'; }
    catch(e){$('genMsg').textContent='动作预览失败：'+errText(e);} finally {$('posePreview').disabled=false;}
  });

  function taskBadge(status){ const map={queued:'排队',claimed:'已领取',submitting:'提交中',running:'运行',repairing:'自动恢复',completed:'完成',failed:'失败',cancelled:'取消'}; return map[status]||status||'未知'; }
  function renderTasks(items) {
    if(items) { localTasks.clear(); items.forEach(j=>localTasks.set(j.id,j)); }
    const box=$('taskList'), arr=Array.from(localTasks.values()).sort((a,b)=>(b.created_at||0)-(a.created_at||0)); box.innerHTML='';
    if(!arr.length){box.innerHTML='<div class="muted">还没有任务。</div>';return;}
    arr.forEach(j=>{const row=document.createElement('div');row.className='task-row'; const req=j.request||{}; row.innerHTML=`<div><b>${esc(j.id||'')}</b><div class="muted">${esc(req.mode||'')} ${esc(new Date((j.created_at||Date.now()/1000)*1000).toLocaleTimeString())}</div></div><div>${esc(taskBadge(j.status))}</div><div><div>${esc(j.detail||j.error||'')}</div><div class="mini-progress"><i style="width:${Math.max(0,Math.min(100,Number(j.progress)||0))}%"></i></div>${j.suggestion?`<div class="warn">${esc(j.suggestion)}</div>`:''}</div><div>${['queued','claimed','submitting','running','repairing'].includes(j.status)?`<button class="secondary danger" data-cancel-job="${esc(j.id)}">取消</button>`:''}</div>`; box.appendChild(row);});
    qsa('[data-cancel-job]').forEach(b=>b.addEventListener('click',async()=>{try{await api('DELETE',`/v1/jobs/${b.dataset.cancelJob}`,{});setTimeout(refreshTasks,500)}catch(e){log(errText(e))}}));
  }
  const savingJobs=new Set();
  async function recoverCompleted(items){
    for(const job of items||[]){
      if(job.status!=='completed'||job.acked_local||savingJobs.has(job.id)) continue;
      savingJobs.add(job.id);
      try{
        // If the image was already written locally but the ACK failed because the tunnel dropped,
        // only retry the remote cleanup ACK. Never download/save the same result twice.
        if (Native.hasLocalJob && Native.hasLocalJob(job.id)) {
          await api('POST',`/v1/jobs/${job.id}/ack-local`,{});
          log(`任务 ${job.id} 已在本机，补发远端清理确认，避免重复存图`);
          continue;
        }
        const req=job.request||{};
        const meta={job_id:job.id,mode:req.mode||'txt',prompt:req.prompt||'',prompt_character:req.prompt_character||'',prompt_action:req.prompt_action||'',negative_character:req.negative_character||'',negative_action:req.negative_action||'',negative:job.negative||req.negative||'',positive:job.positive||'',seed:job.seed,steps:job.steps,cfg:job.cfg,time:Date.now(),recovered:true};
        const saved=await saveCompletedJob(job.id,meta,2); log(`恢复未保存任务 ${job.id} → ${saved.name}`); refreshGallery();
      }catch(e){ log(`恢复任务 ${job.id} 失败：${errText(e)}`); } finally { savingJobs.delete(job.id); }
    }
  }
  async function refreshTasks(){ if(!companionAvailable)return renderTasks(); try{const j=await api('GET','/v1/jobs?limit=60');const items=j.items||[];renderTasks(items);recoverCompleted(items);}catch(e){log('任务列表读取失败：'+errText(e));} }
  $('retrySave').addEventListener('click', async()=>{
    $('retrySave').disabled=true;
    $('genMsg').textContent='正在重新连接并寻找已生成但未保存的图片…';
    try {
      await detectJobs();
      if(!companionAvailable) await waitForJobs(12000);
      if(!companionAvailable) throw {error:'WAI Pad companion 仍未连接'};
      await refreshTasks();
      $('genMsg').textContent='已执行续存检查；如果图片已生成，会自动写入本机图库。';
    } catch(e) {
      $('genMsg').textContent='重试保存失败：'+errText(e)+'；远端结果仍会保留，稍后可继续重试。';
    } finally { $('retrySave').disabled=false; }
  });
  $('refreshTasks').addEventListener('click',refreshTasks);
  $('cleanTasks').addEventListener('click',async()=>{try{await api('POST','/v1/jobs/cleanup',{});refreshTasks()}catch(e){log(errText(e))}});

  function refreshGallery(){
    let list=[]; try{list=JSON.parse(Native.listImages()||'[]')}catch(_){} const g=$('galleryGrid');g.innerHTML='';
    let st={}; try{st=JSON.parse(Native.localStats()||'{}')}catch(_){} $('galleryStats').textContent=`${st.count||0} 张 · ${fmtBytes(st.used_bytes||st.bytes||0)}`;
    if(!list.length){const e=document.createElement('div');e.className='muted';e.textContent='还没有本地图片。生成完成后会自动出现在这里。';g.appendChild(e);return;}
    list.forEach(it=>{if(typeof it.url!=='string'||!it.url.startsWith('https://app.local/local-images/'))return;const d=document.createElement('div'),img=document.createElement('img'),acts=document.createElement('div'),fav=document.createElement('button'),del=document.createElement('button');d.className='thumb';img.src=it.url;img.alt=String(it.name||'');img.dataset.view=String(it.name||'');acts.className='thumb-actions';fav.dataset.fav=String(it.name||'');fav.textContent=it.favorite?'★':'☆';del.dataset.del=String(it.name||'');del.textContent='删除';acts.append(fav,del);d.append(img,acts);g.appendChild(d)});
    qsa('[data-del]').forEach(b=>b.addEventListener('click',()=>{if(confirm('只删除 WAI Pad 本机这张图片？')){Native.deleteImage(b.dataset.del);refreshGallery();}}));
    qsa('[data-fav]').forEach(b=>b.addEventListener('click',()=>{Native.toggleFavorite(b.dataset.fav);refreshGallery();}));
    qsa('[data-view]').forEach(img=>img.addEventListener('click',()=>{const it=list.find(x=>x.name===img.dataset.view);if(!it)return;$('viewerImg').src=it.url;$('viewerMeta').textContent=[it.name,it.mode||'',`Seed: ${it.seed??'-'}`,it.prompt_character?`人物：${it.prompt_character}`:'',it.prompt_action?`动作：${it.prompt_action}`:'',(!it.prompt_character&&!it.prompt_action&&it.prompt)?`提示词：${it.prompt}`:'',it.negative_character?`人物负面：${it.negative_character}`:'',it.negative_action?`动作负面：${it.negative_action}`:''].filter(Boolean).join('\n');$('viewer').classList.remove('hidden');}));
  }
  $('viewerClose').addEventListener('click',()=> $('viewer').classList.add('hidden')); $('refreshGallery').addEventListener('click',refreshGallery);
  $('importGallery').addEventListener('click', async()=>{
    const b=$('importGallery'),m=$('galleryImportMsg'); b.disabled=true; m.textContent='正在从平板 Pictures/WAI Pad 导回 App 图库…';
    try{const r=await importLocalAlbum();m.textContent=`恢复完成：导入 ${r.imported||0} 张，已存在 ${r.skipped||0} 张${r.failed?`，失败 ${r.failed} 张`:''}`;refreshGallery();}
    catch(e){m.textContent='导入失败：'+errText(e)+'。请确认已允许 WAI Pad 读取图片。';}
    finally{b.disabled=false;}
  });

  function statusCard(title,value,cls=''){const safeCls=['good','bad','warn'].includes(cls)?cls:'';return `<div class="status-card"><b>${esc(title)}</b><span class="${safeCls}">${esc(value)}</span></div>`}
  async function refreshStatus(){
    try {
      if(companionAvailable){const j=await api('GET','/v1/system/status');const g=j.gpu||{},s=j.services||{},m=j.models||{},d=j.disk||{};$('systemStatus').innerHTML=[statusCard('GPU',g.ok?`${g.name||'GPU'} · ${g.utilization??'?'}% · ${g.memory_used_mb??'?'} / ${g.memory_total_mb??'?'} MB`:'不可用',g.ok?'good':'bad'),statusCard('核心服务',`Panel ${s.panel?'✓':'×'} · ComfyUI ${s.comfy?'✓':'×'} · Qwen ${s.qwen?'✓':'休眠'} · Jobs ${s.job_api?'✓':'×'}`,s.panel&&s.comfy?'good':'bad'),statusCard('固定画风',`${m.style_lora||'-'} · ${m.style_ready?'就绪':'缺失'}${m.style_v3?' · v3':''}`,m.style_ready?'good':'bad'),statusCard('人物 / 动作',`IPAdapter ${m.ipadapter?'✓':'×'} · Pose ${m.pose?'✓':'×'} · Depth ${m.depth?'✓':'×'} · Composition ${m.composition?'✓':'×'}`,(m.ipadapter&&m.pose&&m.depth&&m.composition)?'good':'warn'),statusCard('数据盘',`${d.free_gb??'?'} / ${d.total_gb??'?'} GB 可用`),statusCard('隐私清理','参考图任务后清理 · 成图本机确认后清理','good')].join('');}
      else {const cs=connState();const text=cs.connected?(cs.message||'SSH 隧道已连接，等待 companion…'):(cs.message||'正在连接 AutoDL…');$('systemStatus').innerHTML=statusCard('启动状态',text,cs.connected?'warn':'bad');}
    } catch(e){$('systemStatus').innerHTML=statusCard('状态','暂时无法读取：'+errText(e),'bad');}
  }
  async function refreshLogs(){if(!companionAvailable)return;try{const j=await api('GET','/v1/logs?lines=160');$('log').textContent=(j.text||'暂无日志')+'\n';$('log').scrollTop=$('log').scrollHeight}catch(e){log('日志读取失败：'+errText(e))}}
  $('health').addEventListener('click',refreshStatus); $('toolStatus').addEventListener('click',refreshStatus); $('refreshLogs').addEventListener('click',refreshLogs);

  function formatDiagnosis(j){
    const lines=[];
    lines.push(`${j.ok?'✓':'!'} ${j.summary||'诊断完成'}`);
    for(const c of (j.checks||[])) lines.push(`${c.ok?'[OK]':'[!!]'} ${c.name}: ${c.detail||''}`);
    if((j.issues||[]).length){
      lines.push('', '需要处理：');
      for(const it of j.issues) lines.push(`- ${it.severity==='warning'?'提醒':'异常'} · ${it.name}: ${it.detail||''}${it.suggestion?`\n  建议：${it.suggestion}`:''}`);
    }
    return lines.join('\n');
  }
  async function refreshRepairHistory(){
    if(!companionAvailable)return;
    try{const j=await api('GET','/v1/system/repairs?limit=8'); const box=$('repairHistory'); box.innerHTML='';
      for(const it of (j.items||[])){const row=document.createElement('div');row.className='repair-event';
        const when=new Date((it.time||0)*1000).toLocaleString();
        row.innerHTML=`<span>${esc(when)}</span><b class="${it.ok?'ok':'fail'}">${esc(it.kind||'repair')}</b><span>${esc(it.summary||'')}</span>`;box.appendChild(row);}
      if(!(j.items||[]).length)box.innerHTML='<div class="muted">还没有修复记录。</div>';
    }catch(e){log('修复记录读取失败：'+errText(e));}
  }
  async function diagnose(){
    if(!companionAvailable){$('diagnosticReport').textContent='companion 尚未就绪，WAI Pad 正在自动连接/初始化。';return;}
    $('diagnosticReport').textContent='正在检查服务、GPU、端口、进程、模型和磁盘…';
    try{const j=await api('GET','/v1/system/diagnose');$('diagnosticReport').textContent=formatDiagnosis(j);return j;}
    catch(e){$('diagnosticReport').textContent='诊断失败：'+errText(e);throw e;}
  }
  async function repair(level='safe'){
    if(!companionAvailable)return log('修复中心等待 WAI Pad companion 就绪');
    if(level==='deep'&&!confirm('深度修复会在创建恢复点后调用现有 WAI 受控 repair，可能重启 ComfyUI。确认当前没有正在生成的重要任务，并继续？'))return;
    $('diagnosticReport').textContent=`正在执行${level==='deep'?'深度':'安全'}修复；修复前会自动创建恢复点…`;
    try{const j=await api('POST','/v1/system/repair',{level});
      const acts=(j.actions||[]).map(a=>`[${a.ok?'OK':'WARN'}] ${a.action}\n${a.output||''}`).join('\n\n');
      $('diagnosticReport').textContent=`${j.summary||'修复完成'}\n恢复点：${j.snapshot||'-'}\n\n${acts}\n\n${j.after?formatDiagnosis(j.after):''}`;
      log(j.summary||'修复完成'); await refreshStatus(); await refreshRepairHistory();
    }catch(e){$('diagnosticReport').textContent='修复没有完成：'+errText(e)+'\n\n为保护正在运行的任务，WAI Pad 可能主动拒绝了修复。';log('修复失败/延后：'+errText(e));await refreshStatus();}
  }
  async function rollback(){
    if(!confirm('恢复最近一次修复前的 WAI Pad companion/config 快照？不会删除模型、训练素材或本机图库。'))return;
    $('diagnosticReport').textContent='正在恢复最近恢复点…';
    try{const j=await api('POST','/v1/system/rollback',{});$('diagnosticReport').textContent=(j.summary||'恢复完成')+'\n正在从恢复后的服务器文件重启（不会重新上传当前版本覆盖恢复点）…';log(j.summary||'恢复完成');const out=await restartFromDisk();log(out);companionAvailable=false;jobsAvailable=false;await waitForJobs(18000);await diagnose();await refreshRepairHistory();}
    catch(e){$('diagnosticReport').textContent='回滚失败：'+errText(e);}
  }
  $('repair').addEventListener('click',()=>repair('safe')); $('toolRepair').addEventListener('click',()=>repair('safe'));
  $('repairSafe').addEventListener('click',()=>repair('safe')); $('repairDeep').addEventListener('click',()=>repair('deep'));
  $('diagnose').addEventListener('click',diagnose); $('toolDiagnose').addEventListener('click',diagnose); $('rollback').addEventListener('click',rollback);

  function connState(){let s={};try{s=JSON.parse(Native.connectionStatus()||'{}')}catch(_){}return s;}
  async function doBootstrap(){
    $('bootstrap').disabled=true;
    try {
      const cs=connState();
      if(cs.connected&&cs.bootstrapBusy){
        log('后台初始化正在运行，不重复启动；先等待当前独立 SSH 控制连接完成…');
        if(await waitForCompanion(12000)){bootstrapped=true;await refreshStatus();refreshLogs();return;}
        const bl=(()=>{try{return Native.bootstrapLog()||''}catch(_){return ''}})();
        log('后台仍在执行。'+(bl?`最近状态：${bl.slice(-900)}`:'当前控制连接尚未结束。'));
        return;
      }
      if(cs.connected&&cs.phase==='repairing') log('自动初始化当前未在执行；立即使用新的独立 SSH 控制连接重试…');
      log('正在快速初始化 WAI Pad companion；Panel/Comfy 恢复将在后台进行…');
      const out=await bootstrap(); log(out); bootstrapped=true; await sleep(1000); await detectJobs(); refreshStatus();
    }
    catch(e){ log('初始化未完成：'+errText(e)); bootstrapped=false; }
    finally{$('bootstrap').disabled=false;}
  }
  $('bootstrap').addEventListener('click',doBootstrap);
  $('terminal').addEventListener('click',()=>Native.openTerminal()); $('toolTerminal').addEventListener('click',()=>Native.openTerminal()); $('openWai').addEventListener('click',()=>Native.openEmbedded('wai')); qsa('[data-open]').forEach(b=>b.addEventListener('click',()=>Native.openEmbedded(b.dataset.open)));

  function loadConfig(){let c={};try{c=JSON.parse(Native.getConfig()||'{}')}catch(_){};loadedConfig={...c};$('host').value=c.host||'connect.nmb2.seetacloud.com';$('port').value=c.port||'28823';$('user').value=c.user||'root';$('autodlUrl').value=c.autodlUrl||'https://www.autodl.com/console/instance/list';$('jupyterUrl').value=c.jupyterUrl||'';$('password').placeholder=c.hasPassword?'已安全保存；不修改可留空':'输入 AutoDL SSH 密码（只保存在本机）';$('fingerprint').textContent=c.sshFingerprint||'首次成功连接后自动记录';if(!c.hasPassword){setTimeout(()=>{const b=document.querySelector('.nav button[data-page="settings"]');if(b)b.click();$('settingsMsg').textContent='首次使用只需要输入一次 AutoDL SSH 密码，之后全部自动运行。';},80);}}
  loadConfig();
  $('saveSettings').addEventListener('click',()=>{const c={host:$('host').value.trim(),port:$('port').value.trim(),user:$('user').value.trim(),password:$('password').value,autodlUrl:$('autodlUrl').value.trim(),jupyterUrl:$('jupyterUrl').value.trim()};const port=Number(c.port),identityChanged=c.host!==(loadedConfig.host||'')||String(c.port)!==String(loadedConfig.port||'')||c.user!==(loadedConfig.user||'');if(!c.host||!c.user||!Number.isInteger(port)||port<1||port>65535)return $('settingsMsg').textContent='请填写有效主机、用户和 1-65535 的 SSH 端口';if((identityChanged||!loadedConfig.hasPassword)&&!c.password)return $('settingsMsg').textContent=identityChanged?'服务器身份发生变化，请重新输入 SSH 密码确认':'首次连接需要 SSH 密码';let r={};try{r=JSON.parse(Native.saveConfig(JSON.stringify(c))||'{}')}catch(e){return $('settingsMsg').textContent='保存失败：'+errText(e)};if(!r.ok)return $('settingsMsg').textContent='保存失败：'+(r.error||'设置无效');$('password').value='';$('settingsMsg').textContent='已保存。WAI Pad 正在安全重连。';bootstrapped=false;lastBootstrapAttempt=0;loadConfig();});
  $('disconnect').addEventListener('click',()=>{Native.stopConnection();$('settingsMsg').textContent='已断开；下次可重新自动连接';});
  $('clearFingerprint').addEventListener('click',()=>{if(confirm('只有在 AutoDL 更换 SSH 主机或你确认指纹变化时才重置。继续？')){Native.clearFingerprint();$('fingerprint').textContent='已重置；下次连接会重新固定';$('settingsMsg').textContent='SSH 指纹已重置，下次连接将重新记录。';}});

  async function detectJobs(){try{const h=await api('GET','/v1/health');companionAvailable=!!h.ok;jobsAvailable=!!(h.ok&&h.ready);if(jobsAvailable)log(`异步任务服务就绪 v${h.version||''}`);else if(companionAvailable)log(`companion v${h.version||''} 已连接，核心服务后台恢复中：${h.detail||''}`);}catch(_){companionAvailable=false;jobsAvailable=false;}}
  async function waitForCompanion(ms=12000){const end=Date.now()+ms;while(Date.now()<end){await detectJobs();if(companionAvailable)return true;await sleep(900);}return false;}
  async function waitForJobs(ms=25000){const end=Date.now()+ms;while(Date.now()<end){await detectJobs();if(jobsAvailable)return true;await sleep(1200);}return false;}
  function connectionTick(){const s=connState();$('connDot').classList.toggle('on',!!s.stackReady);$('connText').textContent=s.connected?(s.message||'AutoDL 已连接'):(s.message||'未连接');if(s.bridgeReady){companionAvailable=true;if(!bootstrapped){bootstrapped=true;detectJobs().then(()=>{refreshStatus();refreshTasks();});}else if(companionAvailable && !$('retrySave').classList.contains('hidden')){refreshTasks();}}else if(!s.connected){bootstrapped=false;companionAvailable=false;jobsAvailable=false;}}

  connectionTick(); setInterval(connectionTick,3000); setInterval(()=>{if(companionAvailable)refreshStatus();},20000); setTimeout(async()=>{await detectJobs();refreshStatus();refreshTasks();if(companionAvailable)refreshRepairHistory();},2200); refreshGallery();
})();
