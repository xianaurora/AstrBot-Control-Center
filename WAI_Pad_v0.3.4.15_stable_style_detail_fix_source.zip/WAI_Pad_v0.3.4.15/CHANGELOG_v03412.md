# WAI Pad v0.3.4.12

## 启动卡死修复

- Android SSH 隧道监控与服务器初始化完全解耦。`TunnelService` 不再同步等待 `RemoteBootstrap.installAndStart()`，因此远端维护锁、SFTP 更新或 WAI 核心服务恢复变慢时，连接状态机不会停在“正在检查服务”。
- companion 更新事务只负责校验/原子替换文件；完成后以独立后台进程启动 `bootstrap.sh`，不再在持有更新链路时同步等待 bootstrap。
- `guard.sh` 在任何可能耗时数分钟的 `wai start/restart/repair` 之前优先恢复 6027 companion，使控制面、日志、诊断和任务恢复接口尽快可用。
- bootstrap 不再额外并发启动 `guard.sh once`；只保留单一 daemon 状态机，减少 repair 竞争。
- 前端新增“等待 companion”与“等待完整 Jobs 就绪”两个不同条件。控制面不再错误等待 Panel+Comfy 全部恢复后才认为 companion 可用。
- connectionStatus 新增 `bootstrapBusy`；重复点击“重新初始化”不会再启动第二套更新。
- `/v1/logs` 增加 `bootstrap.nohup.log`，以后能直接看到后台初始化停在哪一步。
- 针对已经卡住的 v0.3.4.11：若确认维护锁只被旧 guard 持有、且没有活动任务，会先启动现有 companion 控制面，再等待锁释放后完成版本更新；不会因此重启 ComfyUI。

## 版本

- versionName: 0.3.4.12
- versionCode: 18
