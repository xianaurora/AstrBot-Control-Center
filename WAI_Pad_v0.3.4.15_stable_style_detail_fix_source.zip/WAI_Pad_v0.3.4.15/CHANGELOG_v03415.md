# WAI Pad v0.3.4.15

版本：0.3.4.15 / versionCode 21

## 主要修复

- 移除新架构对旧全局 `runtime/service.lock` 的运行时依赖。
- 新增 `runtime/companion.lock`：仅保护 6027 companion 的启动/重启，持锁时间很短。
- 新增 `runtime/core.lock`：仅保护 `wai start/restart` 与 `WAI_ctl.sh repair` 这类耗时核心修复。
- 新增 `runtime/update.lock`：仅保护 companion 文件事务更新/回滚。
- v0.3.4.14 或更老 guard 正持有 `service.lock` 时，新 APK 会先恢复已有 companion，再继续安装 split-lock 版本，不再返回永久 `WAI_PAD_UPDATE_BUSY=1`。
- 如果旧 guard 正在核心修复，不直接杀父进程造成 repair 孤儿；后台 watcher 等旧锁释放后再切换新版 guard。
- companion 启动不再因 `jobs_state.json` 中的旧 `running/repairing` 条目而被禁止；job_api 重启后由持久化状态自行重新接管 Comfy prompt。
