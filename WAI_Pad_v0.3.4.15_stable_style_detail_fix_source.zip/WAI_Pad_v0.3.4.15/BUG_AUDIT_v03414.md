# WAI Pad v0.3.4.14 Bug Audit

## 已修复：AutoDL 上 exec/SFTP `channel request: timeout`

根因集中在 JSch channel 层，而不是 SSH Session 登录层：旧代码对 `ChannelExec` / `ChannelSftp` / `ChannelShell` 使用非零 `connect(timeout)`。在部分 SSH 网关链路上会进入 JSch 等待 channel request reply 的 timeout 路径，并在约 10 秒后抛出 `channel request: timeout`，即使 TCP、认证和端口转发都正常。

v0.3.4.14 取消所有业务 channel 的非零 JSch connect timeout，改为无参数 `connect()` + App 层 watchdog。watchdog 超时会销毁本次短连接 SSH session，保证调用有界且不会拖累长期端口转发 session。


另外同步修复 `ChannelSftp` 与 `ChannelShell` 的同类调用，避免初始化修好后上传或终端再次命中相同 JSch timeout 路径。
