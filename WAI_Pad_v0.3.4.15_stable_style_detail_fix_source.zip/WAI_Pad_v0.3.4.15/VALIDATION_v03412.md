# v0.3.4.12 validation

已在当前修复环境执行：

- `python -m py_compile`：job_api / engine / maintenance 通过。
- `bash -n`：bootstrap / guard 通过。
- `node --check app.js` 通过。
- server 与 APK assets 五个 companion 文件逐字节一致。
- Kotlin 语言/类型级 stub 编译：TunnelService + RemoteBootstrap 通过（不是 Android SDK/Gradle 的替代）。
- guard 慢核心恢复模拟：模拟 `wai` 长时间阻塞时，6027 companion 在约 0.6 秒内先恢复，而 guard 仍继续后台修复核心，验证控制面与重修复解耦。
- bootstrap 全核心离线模拟：companion 可先启动，bootstrap 快速返回，Panel/Comfy 留给后台 guard。
- 旧 guard 长修复迁移逻辑为保守模式：仅当锁文件所有打开者都识别为 `/root/WAI_Pad/guard.sh` 且 durable state 无活动任务时才允许先恢复 companion。

最终 Android API/AGP 编译以 GitHub Actions `:app:assembleDebug` 为准。
