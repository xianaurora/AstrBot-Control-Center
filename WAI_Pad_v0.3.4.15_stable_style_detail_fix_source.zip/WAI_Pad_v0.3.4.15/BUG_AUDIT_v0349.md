# WAI Pad v0.3.4.9 Build Audit

## Confirmed v0.3.4.8 failure

GitHub Actions failed at `:app:compileDebugKotlin` with:

`NativeBridge.kt:40:37 Unresolved reference 'isDestroyed'`

Root cause: Android `WebView` exposes `destroy()` but the application API used here does not provide the `isDestroyed` property referenced by v0.3.4.8. A hand-written local test stub had incorrectly included that member and masked the defect.

## Fix

`NativeBridge` now owns a disposal flag. `MainActivity.onDestroy()` calls `bridge.shutdown()` before removing the JavaScript interface and destroying the WebView. Native callbacks check the disposal flag both before posting and on the UI runnable, eliminating the teardown race without calling a nonexistent SDK API.
