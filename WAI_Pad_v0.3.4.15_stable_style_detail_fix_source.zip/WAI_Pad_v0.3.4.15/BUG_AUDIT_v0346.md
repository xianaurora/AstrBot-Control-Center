# WAI Pad v0.3.4.6 Bug 排查：unexpected end of stream

## 真机现象
点击带参考图的生成后，Android 报：
`unexpected end of stream on com.android.okhttp.Address@...`
任务没有进入 GPU 队列。

## 根因
v0.3.4.5 已把大图拆成 HTTP 分片，但参考图字节仍然经过：
Android HttpURLConnection -> 127.0.0.1:16027 -> JSch 本地端口转发 -> AutoDL 6027。
当 Wi-Fi/SSH 本地转发在请求体传输期间短暂重建时，Android 的旧 HttpURLConnection/OkHttp 实现会直接抛 `unexpected end of stream`。
此外前端的连接异常识别没有把该错误归类为可重连错误，所以没有进入续传分支。

## v0.3.4.6 修复
1. 参考图默认不再经过 HTTP 端口转发上传。
2. Android Native 直接建立 SSH/SFTP 通道，把优化后的参考图原子写入 `/root/WAI_Pad/runtime/uploads`。
3. 图片文件和 metadata 都采用“临时文件 -> 完成后 rename”的原子落盘，断线不会留下半张可用文件。
4. SFTP 自动重试一次；失败后才回退到 HTTP 分片兼容通道。
5. HTTP 回退分片从 768 KiB 降到 256 KiB。
6. `unexpected end of stream / EOF / socket closed / stream reset` 全部纳入连接异常识别，可触发自动重建 SSH 隧道。
7. 人物参考/动作参考的上传优化上限略收紧，降低 JavaScript -> Native 桥接的内存和传输压力，不修改平板原图。

## 隐私
SFTP 临时参考图仍只进入 AutoDL 的 `/root/WAI_Pad/runtime/uploads`，由任务物化/清理逻辑删除；不会上传任何第三方云存储。
