# WAI Pad v0.3.4.3

- 新增“导入本机保险库”：从 `Pictures/WAI Pad` / `Pictures/WAI Pad/Recovered` 重建 App 私有图库。
- 用于固定签名迁移、卸载重装后的图片恢复。
- 导入只发生在平板本地，不上传云端，也不会删除保险库原图。
- 继续沿用 v0.3.4.2 固定签名 keystore，后续可覆盖安装。
