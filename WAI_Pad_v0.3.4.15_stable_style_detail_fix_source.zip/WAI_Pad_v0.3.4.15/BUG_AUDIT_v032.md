# v0.3.2 Bug Audit

本轮针对真机反馈重点检查两条链路。

## 1. `[object ProgressEvent]`

根因类别：浏览器/WebView 的 FileReader、Image 或网络错误对象被直接字符串化。

处理：
- `errText()` 统一识别 Event/ProgressEvent。
- FileReader 使用显式 `onerror/onabort` 文案。
- Image 仅用于读取参考图尺寸；解码尺寸失败不再丢弃已有 Data URL。
- “GPU 已成功出图”和“Android 本机落盘失败”拆成不同状态。

## 2. 全选删除后不能继续输入

根因类别：部分 Android System WebView + 中文 IME 在整段选区删除后残留 composition/editable 状态。

处理：
- 对 Prompt / Negative textarea 监听 composition + beforeinput。
- 整段删除由页面自己清空并重置 selection/caret。
- 保留“清空”按钮，不依赖系统长按菜单即可稳定清空。

## 静态验证

- `node --check app.js`
- Python `py_compile`
- Shell `bash -n`
- 检查 NativeBridge 版本号和前端按钮/handler 一致性。

仍需要真机验证：不同 Android System WebView/输入法版本对 `beforeinput` 的行为会有差异，因此 v0.3.2 保留了清空按钮作为稳定兜底。
