# WAI Pad v0.3.4.8

本版是 v0.3.4.7 之后的一次可靠性/安全边界加固，重点不是新增生图功能，而是把启动、SSH、任务队列、取消、恢复、文件事务和 WebView 权限收敛成更可恢复的状态机。

## 任务队列与取消
- `client_request_id` 幂等检查、参考图物化和任务插入合并到同一提交临界区；连接断流重试不会创建两份任务。
- worker 在执行前原子领取 `queued -> claimed`；重复 wake/requeue 不会让同一任务执行两遍。
- 提交 ComfyUI 前持久化 `comfy_client_id`；`/prompt` 响应丢失时按 client id 从队列/历史重新接管，不盲目判失败。
- ComfyUI 状态查询增加短暂故障容忍；不再因为一次 API 抖动清空 prompt 所有权并触发核心重启。
- 优先使用新版 ComfyUI 的定向 job cancel；旧版回退按 prompt id 删除 pending，只有确认目标正在 running 时才做受控 interrupt。
- 取消结果不确定时保留任务所有权和输入，等待 ComfyUI 恢复后确认，避免“本地显示取消但远端继续跑”。
- 主界面删除 legacy global cancel；批量提交每成功一个任务立即登记，部分提交失败时仍可追踪/取消已提交任务。

## 启动、SSH 与自愈
- `TunnelService` session 改为实例所有权，配置保存通过断开当前 session 触发重连，不再 stop/start 抢生命周期。
- `bridgeReady` 与 `stackReady` 分离：6027 companion 存活不再被误报成 Panel/ComfyUI 全部正常。
- Jupyter 探测移动到 companion 可用之后，不阻塞核心启动。
- 重连增加有界指数退避；半建端口转发失败会关闭当前 session。
- 已固定的 SSH SHA-256 主机指纹在 password auth 之前参与 host-key 校验；服务器身份变化会阻止认证。
- host/port/user 改变时要求重新输入密码确认，避免旧密码自动发送到误配置的新主机。
- Android 自动 bootstrap、远端 `bootstrap.sh`、`guard.sh`、maintenance/rollback 共用 `service.lock`。
- companion 更新先完整 staging + Python/Shell 校验，再事务替换；活动任务存在时延后更新。
- guard 脚本 hash 改变时只重启 guard 自身；ComfyUI 短暂不可达需持续复核后才允许核心恢复。

## 文件与隐私事务
- 分片上传继续采用每片原子文件 + finalize 重组，保持并发重试/进程崩溃幂等。
- 参考图 SFTP 使用临时文件 + rename；失败时额外清理，server janitor 作为最终兜底。
- job 参考图由任务 ownership 管理，janitor 不再按裸 mtime 删除仍属于 queued/running/recovering 的输入。
- 终态任务如果 Comfy 输入清理失败，会保留 `comfy_inputs` 所有权并由 janitor/cleanup API 重试；清理未确认前不会丢弃任务记录。
- `ack-local` 拆分为本机已保存、远端清理待办、已删除三个状态；远端删除失败不会丢失 result 路径，并由 janitor 重试。
- 未确认本机保存的远端成图 TTL 从 6 小时调整为 72 小时，降低平板长时间离线导致唯一副本丢失的风险。
- Android 本地保存采用确定性 job 文件名和事务 metadata；崩溃发生在私有落盘/相册导出/metadata 提交之间时，重试会修复事务而不是重复存图。
- Pictures/WAI Pad 导入改为流式复制并一次建立 URI 索引，避免原来的 O(N²) metadata 扫描。

## WebView / Native 边界
- 主 WebView 只允许 `https://app.local` 合成 origin；外部导航和非本地资源请求直接阻断。
- 关闭主 WebView file/content/mixed-content/third-party-cookie 权限，并加入 CSP。
- 服务器/文件元数据输出默认 escape 或 DOM `textContent`，图库与动作预览不再把不受信任字符串直接拼成 HTML。
- Native 后台操作改为 2–4 线程有界池；JS timeout 会调用 `cancelOperation()`，关闭对应 HttpURLConnection/SSH Session。
- HTTP/SSH/SFTP 资源释放统一放到 finally；动作预览继续走 SFTP + SSH exec，不把多 MB 图片穿过 16027 HTTP 请求。
- 参考图先通过 Blob/object URL 解码和按尺寸/体积压缩，再生成最终待传 Base64，避免直接把原始大文件一开始就放大成 Data URL。

## 版本
- Android `versionCode`: 14
- Android / companion `versionName`: 0.3.4.8
- 继续使用 v0.3.4.2 起固定的私人更新签名 key。
