# WAI Pad v0.3.4.14 验证

- 源码扫描确认 Android 业务代码中不存在 `Channel.connect(10_000)` / `Channel.connect(10000)`。
- `SshClient` stub Kotlin 编译通过；新的 `connectChannel()` 仅调用无参数 `channel.connect()`。
- watchdog 设计：30 秒未完成 channel open 时断开 channel + 当前 disposable session 并抛 `SocketTimeoutException`。
- `Session.connect(18_000)` 保留并与 channel timeout 明确区分。
- Terminal shell 已迁移到 `SshClient.connectChannel()`。
- `server/` 与 APK assets 五个 companion 文件逐字节同步。
- Python `py_compile`、Shell `bash -n`、JS `node --check` 在打包前重新执行。
- 真实 Android SDK/Gradle 编译仍以 GitHub Actions `:app:assembleDebug` 为最终验证。

- watchdog JVM 回归：模拟 `Channel.connect()` 永久阻塞，120ms 外层 watchdog 能断开 disposable session，并以 `SocketTimeoutException` 退出；实测约 130ms。
- `TunnelService + RemoteBootstrap` 针对性 Kotlin stub 编译通过。
