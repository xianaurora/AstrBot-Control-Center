# WAI Pad 签名规则（必须遵守）

WAI Pad 从 v0.3.4.2 起把下面这份 key 视为永久开发/个人更新 key：

- 文件：`android/app/waipad-dev.jks`
- 文件 SHA-256：`ddf36386ece50ee8af273c7595799f62c89aaa85efb69df6d690358e26dc8d7c`
- alias：`waipad`
- 证书 SHA-256：`A3:FE:05:ED:D1:03:C3:EF:A6:DB:CC:B6:EB:46:28:F8:8C:C8:CD:32:77:2F:20:3F:B2:C2:F5:6D:2A:48:C4:A0`

以后版本必须复制同一个 keystore 文件，禁止重新运行 keytool 生成新 key。
GitHub Actions 已经增加双重保护：编译前检查 keystore 哈希/证书，编译后检查 APK 证书。

注意：把私钥放进源码包适合当前“个人自用/私有构建”的阶段，不适合公开发布到公共仓库。正式公开发布时应改用 GitHub Secrets 中的私有签名材料，并继续保持同一证书。
