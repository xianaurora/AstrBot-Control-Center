# WAI Pad v0.3.4.14

## JSch channel request timeout 修复

- `exec`、`sftp`、持久 shell 不再调用 `Channel.connect(10_000)`。
- 所有 SSH channel 改用无参数 `connect()`；超时由 App 外层 30 秒 watchdog 控制。
- channel open 超时时会断开本次短生命周期 SSH session，让 JSch 阻塞可靠退出；不会污染负责端口转发的长期 tunnel session。
- `Session.connect(18_000)` 保留，因为本问题只涉及 channel request 的 timeout/reply 语义，不涉及 SSH TCP/认证连接超时。
- 后台初始化失败时附带最近约 2.6KB 的 SSH 阶段轨迹（session 连接、channel open、watchdog/exit 状态；不记录命令正文、密码或上传内容）。
- SSH 终端同样改用新的 channel open watchdog，避免 shell/PTY 走回旧 timeout 路径。

版本：0.3.4.14 / versionCode 20

- 为隔离变量，本版暂不升级 JSch 依赖版本；修复点只改变 channel connect 的调用语义。
