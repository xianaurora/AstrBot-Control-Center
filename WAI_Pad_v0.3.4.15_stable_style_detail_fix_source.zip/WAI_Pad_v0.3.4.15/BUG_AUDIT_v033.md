# v0.3.3 Bug Audit — 人物+动作画风漂移

## 现象
人物参考 A + 动作参考 B 时，身份和姿势能工作，但最终画风明显偏离固定 Style LoRA。

## 根因
`person_pose_wf()` 同时把动作图 B 送入 Composition IPAdapter。Composition 模型虽然用于构图，但仍会携带 B 图的颜色、渲染质感、明暗和局部风格特征；同时 A 的 STANDARD IPAdapter 权重/持续区间也会带入参考图自身画法。多路视觉条件叠加后会压过固定 Style LoRA。

## 修复
- 新增“固定画风锁定”，人物+动作默认开启。
- 开启时：B 仅进入 DWPose/OpenPose + Depth，完全绕过 Composition IPAdapter。
- A 的整体 IPAdapter 降权，只保留低权重整体身份；PLUS FACE 继续负责脸部身份。
- person_pose 的 Style LoRA 权重提高：clean LoRA 1.06；legacy 0.82。
- 严格模式仍控制姿势/透视强度，不再等价于加强 B 图视觉风格。
- 如有特殊构图需求，可手动关闭“固定画风锁定”恢复低权重 Composition。

## 预期
人物+动作模式输出画风应更接近普通文生图/人物参考模式和固定 LoRA，而 B 图只决定骨架、透视和构图几何。
