# WAI Pad v0.3.4.9

## Android build/API fix

- Fixed `NativeBridge.callback()` using the nonexistent Android `WebView.isDestroyed` API, which caused the real Gradle task `:app:compileDebugKotlin` to fail.
- Replaced the check with an explicit `AtomicBoolean` lifecycle flag owned by `NativeBridge`.
- `shutdown()` now marks the bridge disposed before cancelling native work, and queued UI callbacks re-check that flag before touching the WebView.
- Async callbacks racing Activity teardown are therefore dropped safely instead of relying on a fabricated WebView API.

## Validation-process correction

- The previous v0.3.4.8 local Kotlin stub accidentally declared `WebView.isDestroyed`; that made the local stub compile a false positive. This release removes that assumption and records real Gradle/Android SDK compilation as the authoritative Android API check.

## Version

- Android `versionName`: `0.3.4.9`
- Android `versionCode`: `15`
- Companion version: `0.3.4.9`
