# v0.3.4.5 Validation

- Python `job_api.py`: py_compile 通过
- 前端 `app.js`: Node syntax check 通过
- `bootstrap.sh` / `guard.sh`: bash -n 通过
- 768 KiB Base64 分片：对 1B、1KiB、777777B、5MB、12MB 随机数据重组校验通过
- 固定签名 keystore 与 v0.3.4.4 字节完全一致
- 分片接口具备 init / chunk / finalize / DELETE 清理路径
- 客户端对 chunk 请求使用约 45-50 秒超时并支持 SSH 重建后续传
