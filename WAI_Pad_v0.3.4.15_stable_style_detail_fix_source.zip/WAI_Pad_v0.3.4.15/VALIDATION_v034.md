# WAI Pad v0.3.4 Validation

已执行的静态/本地检查：
- Python `py_compile`：server 与 APK 内置 companion 通过。
- server/job_api.py 与 APK assets 内置 job_api.py 镜像一致。
- Shell `bash -n`：bootstrap/guard 通过。
- 前端 `node --check`：app.js 通过。
- 固定签名 keystore：`keytool -list` 可读取 alias `waipad-dev`。
- GitHub workflow：Java 17 + Gradle 8.10.2 + Android SDK + 稳定签名校验 + APK 签名校验。

仍需真机/CI 验证：
- Android Gradle/Kotlin 完整编译（当前容器没有 Android SDK/Gradle）。
- Android MediaStore 本机保险库在你的平板 ROM 上的读写、卸载后重装扫描。
- 真实 AutoDL 隧道下的大参考图上传一次、多任务排队和 worker watchdog。
