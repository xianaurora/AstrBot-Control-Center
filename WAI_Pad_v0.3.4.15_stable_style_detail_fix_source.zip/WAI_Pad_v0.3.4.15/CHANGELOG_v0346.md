# WAI Pad v0.3.4.6

- 修复 Android `unexpected end of stream` 导致参考图生成直接失败。
- 参考图主传输改为 Native SSH/SFTP 直传，不再依赖 16027 HTTP 隧道承载大请求体。
- SFTP 原子上传 + 自动重试；失败自动回退 HTTP 分片。
- HTTP 兼容分片降至 256 KiB，并补齐 EOF/stream reset/socket closed 自动重连识别。
- 保持固定签名 keystore 不变，可覆盖 v0.3.4.2+ 固定签名版本。
