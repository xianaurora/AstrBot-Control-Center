# WAI Pad v0.3.4.7 Bug Audit

## 已关闭问题

1. HTTP 分片在并发重试 / fsync 后崩溃边界可能重复 append，导致 finalize 成功但图片损坏。
2. 动作预览仍把大 Base64 B 图及预览结果走 16027 HTTP 隧道。
3. `TunnelService` 在部分本地端口转发成功、后续转发失败时可能泄漏新 SSH session。
4. SFTP 图片成功、metadata 失败且连接已断时可能留下无 JSON 孤儿文件；旧 janitor 无法发现。
5. companion 在 ComfyUI 接受 prompt 后、`prompt_id` 持久化前崩溃，会留下不可恢复的 running 任务。
6. GitHub Actions 不识别 `_source(1).zip` 形式的源码包。
7. `NativeBridge.kt` 成图下载重试存在重复 `for` 行，已删除。

## 设计结果

- HTTP 分片回退现在是 crash-safe / retry-idempotent，而不是依靠“先 append、再写 next_index”。
- 动作预览主路径从 WebView 到 AutoDL 的大数据传输改为 SSH 原生通道。
- 上传目录清理由 metadata 驱动改为“目录级陈旧文件兜底”，覆盖断线时产生的无 metadata 残留。
- ComfyUI 提交使用持久化 client_id 作为 prompt_id 写入前的恢复锚点。
