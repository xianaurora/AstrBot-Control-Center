# v0.3.4.4 连接/超时 Bug 排查

## 现场
- UI 显示“隧道已连接”，但 `/v1/health`、任务列表、日志连续 `Connection reset`。
- 参考图 + 批量任务曾在约 120 秒后 `timeout`。

## 根因 1：JSch Session 活着不代表本地端口转发还可用
旧 `TunnelService` 只判断 `Session.isConnected`。当 16027 本地 forwarding channel 异常时，代码仍在同一个坏 Session 上反复 bootstrap，因此无法自愈。

## 根因 2：前端没有使用已经存在的 `/v1/images` API
人物参考/动作参考的 Base64 被直接塞进 `/v1/jobs`。数量=2 时同一 A/B 图会完整上传两次，既慢又放大断线概率。

## 修复
1. 同时检查远端 6027 与本地 16027；远端活而本地死 -> 强制重建 SSH 隧道。
2. bootstrap 连续失败/IO 异常 -> 放弃坏 Session，全连接重建。
3. 参考图先一次上传，任务只传 image ID；提交完成后清理 staging 上传。
4. client_request_id 保证重试幂等。
