# WAI Pad v0.3.4.15 Bug Audit

## 根因

v0.3.4.14 的 guard、bootstrap、RemoteBootstrap 与 maintenance 仍共用 `runtime/service.lock`。guard 在执行 `wai start/restart/repair` 时可能持锁数分钟；Android 更新预检看到该锁繁忙便停止安装，guard 自身又先等核心修复完成才重新检查 companion，形成控制面饥饿/迁移死锁。

## 修复

锁职责拆分为 companion/core/update 三层。旧 service.lock 只用于迁移期观察旧 guard 是否仍在运行，不再阻止 6027 恢复或新版文件安装。耗时核心修复无论持续多久，都不能阻止 companion 启动。
