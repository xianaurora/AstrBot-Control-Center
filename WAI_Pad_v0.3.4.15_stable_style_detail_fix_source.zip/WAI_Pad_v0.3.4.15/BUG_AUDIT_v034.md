# WAI Pad v0.3.4 真机 Bug 修复

## 1. 批量人物参考任务卡在“提交 2 个任务”
### 根因
v0.3.3 每创建一个任务，都会把完整参考图 Data URL/base64 再通过 Android WebView -> Native -> SSH Tunnel -> AutoDL 发送一次。数量=2 时同一张图被重复发送两次；人物+动作则 A/B 两图会按任务数重复发送。大图情况下，Native 单线程 HTTP 队列长时间被大 JSON 占用，UI 就停在“提交 N 个任务 / 等待 GPU”。

### v0.3.4
先调用 `/v1/images` 上传一次参考图，取得一次性 `image_id`。随后 1~4 个生成任务只发送几十字节的 token。服务端在创建任务时把该临时图复制为任务独立的短期副本，避免第一张任务清理后影响第二张。全部任务创建完成后立刻删除一次性上传 token；任务副本在使用完成后删除，异常残留也会自动过期清理。

## 2. APK 每次签名不同，无法覆盖安装
### 根因
GitHub Actions 每台临时 Runner 默认生成自己的 debug keystore，所以每次构建的 `app-debug.apk` 可能不是同一证书。Android 不允许不同签名的 APK 覆盖同一个 applicationId。

### v0.3.4
项目改为显式使用固定 `waipad-dev.keystore`。因此从 v0.3.4 开始后续 v0.3.5/v0.4 等开发 APK 可直接覆盖升级。

注意：v0.3.3 及以前使用过随机 debug key，因此安装 v0.3.4 时可能仍需最后卸载一次旧版。从 v0.3.4 之后不应再需要因为签名变化而卸载。

## 3. 卸载后本地图片消失
### 根因
之前存储位置是 Android `context.filesDir`，这是应用私有目录。Android 卸载应用时会按设计删除这个目录，因此“只在本机”并不等于“卸载后还在”。

### v0.3.4
Android 10+ 改为设备本地持久保险库：
- 图片：`Pictures/WAI Pad`
- 参数元数据：`Documents/WAI Pad/Metadata`

两者都是平板本地存储，不做任何云同步。卸载 WAI Pad 后文件仍在；重装同一 App 后图库通过 MediaStore 自动扫描回来。

已经在上次卸载中被 Android 删除的旧 app-private 文件无法由新版本恢复；这是系统已经执行的删除操作。
