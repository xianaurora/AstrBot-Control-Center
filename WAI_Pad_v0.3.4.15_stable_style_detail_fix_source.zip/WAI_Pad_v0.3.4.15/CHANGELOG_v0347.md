# WAI Pad v0.3.4.7

本版集中修复 v0.3.4.6 排查出的传输、恢复和重连可靠性问题。

## 修复

- HTTP 参考图回退上传改为“每分片原子文件 + 幂等重试 + finalize 重组校验”。
  - 同一分片并发重试不会重复写入。
  - 服务器在分片落盘后、session 元数据更新前崩溃，重启后可从已提交分片恢复，不会重复 append。
  - 重复分片内容不一致时直接拒绝，避免静默损坏图片。
  - finalize 重新解码全部分片并校验字符数、原始字节数及 40MB 上限。
- 动作骨架 / Depth 预览改走 Native SFTP + SSH exec 主通道。
  - 大尺寸 B 图不再通过 16027 的 HttpURLConnection 请求体发送。
  - 预览返回数据也不再经过本机 HTTP 端口转发，消除该路径的 `unexpected end of stream` 风险。
  - 服务端同时支持 `pose_id` 小请求作为兼容回退，并在预览结束后删除临时上传。
- SSH 隧道重连修复半初始化 session 泄漏。
  - 新 SSH session 在设置本地端口转发前即登记；任一端口映射失败，外层异常处理均能断开正确 session。
  - 新一轮连接开始时显式清理旧 session 并将 connected 置为 false。
- SFTP 上传失败后的隐私清理增强。
  - 不再依赖已经断开的失败 session 删除临时文件，而是重新建立独立 SSH 清理连接。
  - server janitor 扫描 uploads 目录下全部陈旧文件，可清理无 JSON 的孤儿图片、旧 `.part`、分片文件及 `.wai-upload-*` 临时文件。
- ComfyUI 提交崩溃窗口恢复。
  - `/prompt` 提交前持久化 `comfy_client_id` 和 Comfy input 文件名。
  - companion 重启后即使 `prompt_id` 尚未来得及写入，也会按 client_id 从 ComfyUI queue/history 找回原 prompt，不重复提交未知状态任务。
  - 找不回时明确失败并清理临时输入，而不是永久卡在 running。
- GitHub Actions 源码包匹配由 `WAI_Pad_v*_source.zip` 放宽为 `WAI_Pad_v*_source*.zip`，支持浏览器产生的 `_source(1).zip` 等重复下载文件名。
- 修复 `NativeBridge.kt` 成图下载重试中重复嵌套的一行 `for (attempt in 1..3)`。

## 版本

- Android `versionCode`: 13
- Android / companion `versionName`: 0.3.4.7
- APK 内置 server 副本与源码根目录 server 文件保持一致。
