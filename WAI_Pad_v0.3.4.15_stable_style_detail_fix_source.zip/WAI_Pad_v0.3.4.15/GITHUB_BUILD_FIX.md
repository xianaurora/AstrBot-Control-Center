# GitHub Actions 构建修复（v0.3.1）

本次修复两个会直接导致构建失败的问题：

1. 删除旧 workflow 的“修复源码兼容问题”步骤。该步骤用 `sed` 搜索一个当前源码里根本不存在的 `window.isFrameRateBoostOnTouchEnabled = true`，随后在 `set -e` 下执行裸 `grep`。匹配不到时 `grep` 返回 1，Actions 因此直接失败，实际上还没有进入 Kotlin/Gradle 编译。
2. Gradle 从 9.5.0 改为 8.10.2。当前工程使用 Android Gradle Plugin 8.7.3，不应该临时强行切到 Gradle 9.5.0。工程原始构建配置也指定 8.10.2。

新版 workflow 不再在线修改 Kotlin 源码，只做：Checkout -> Java 17 -> Android SDK -> Gradle 8.10.2 -> 找到 Android 工程 -> assembleDebug -> 上传 APK。
