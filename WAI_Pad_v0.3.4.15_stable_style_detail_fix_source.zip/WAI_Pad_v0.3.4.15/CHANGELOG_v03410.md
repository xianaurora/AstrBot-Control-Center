# WAI Pad v0.3.4.10

- 修复启动卡在“隧道已连接，正在检查服务”：companion 6027 优先启动，Panel/Comfy 由 guard 后台恢复。
- bootstrap 不再同步执行可能长时间阻塞的 `wai start/restart`。
- guard 的 `wai start/restart/repair` 增加硬超时，避免维护锁被无限占用。
- 后台 shell 启动前显式释放 `service.lock` fd，避免锁被 daemon 继承。
- 远端服务离线不再被误判为 SSH 隧道故障；仅“远端 6027 正常、本地 16027 异常”才重建隧道。
- 自动恢复增加退避；维护锁繁忙时保持 SSH 隧道而不是反复断线重连。
- 控制台 bootstrap 阶段不再访问旧 Panel `/api/status`，避免把 `Connection reset` 当系统主状态。
- 手工“重新初始化”检测到后台初始化已运行时不再启动第二套更新。
- 修复 `service.lock` FD 被 job_api / wai 子进程继承导致永久锁死；所有后台/可能 daemonize 的子进程显式 `9>&-`。
- 增加 v0.3.4.9 遗留锁自动迁移：仅当无活动任务且检测到 job_api 确实持有 lock FD 时，安全重启 companion 释放锁。
