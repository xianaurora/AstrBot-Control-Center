# WAI Pad v0.3.4.13 验证

- TunnelService forwarding session 静态不变量：不再传入 `SshClient.exec`、SFTP 或 `RemoteBootstrap.installAndStart`。
- bootstrap / remote health / Jupyter control traffic 均使用独立短连接，并在 finally 中断开。
- 控制通道串行 executor，bootstrap 与探测不会并发挤压 SSH gateway。
- repairing 状态且 bootstrapBusy=false 时，手动“重新初始化”会真实发起新控制连接。
- Kotlin 语言级检查（TunnelService + RemoteBootstrap + stubs）通过。
- Python `py_compile`、Shell `bash -n`、JS `node --check` 通过。
- `server/` 与 APK assets 五个 companion 文件逐字节一致。
- 真实 Android SDK/Gradle 编译仍以 GitHub Actions `:app:assembleDebug` 为最终验证。
