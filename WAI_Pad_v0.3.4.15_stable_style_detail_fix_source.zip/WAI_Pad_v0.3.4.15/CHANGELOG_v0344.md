# WAI Pad v0.3.4.4

- 修复已连接但 `127.0.0.1:16027` 持续 `Connection reset`：检测到本地 SSH 转发失效后不再在坏连接上循环修复，直接重建整个 SSH Session 和端口转发。
- 修复参考图生图易超时：A/B 图先上传一次到 6027 临时图片接口，再用 `image_id/person_id/pose_id` 创建任务；批量 2~4 张不再重复发送数 MB Base64。
- 参考图上传/任务提交遇到连接重置会请求 App 自动重建隧道并安全重试。
- `/v1/jobs` 增加 `client_request_id` 幂等去重，断线重试不会重复创建同一张任务。
- HTTP 请求显式 `Connection: close`，降低远端 companion 重启后复用坏连接导致的 reset。
- 继续沿用 v0.3.4.2 固定签名，可覆盖后续固定签名版。
