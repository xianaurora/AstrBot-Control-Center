# WAI Pad v0.3.4.8 Reliability Audit

本轮针对 v0.3.4.7 做的是异常边界审计：启动重连、任务原子性、取消语义、ComfyUI 短暂不可达、SSH host-key 校验时机、WebView bridge 权限、远端更新互斥、本地/远端图片事务和长时间离线恢复。

## 已封堵的高风险路径
1. 同一 `client_request_id` 并发 POST 产生两个 job。
2. watchdog 与 worker 交错导致同一 queued job 被执行两次。
3. `/prompt` 已被 ComfyUI 接收但 HTTP 响应丢失，companion 误判失败并删除输入。
4. global `/interrupt` 误停其他正在运行的 ComfyUI prompt；pending prompt 未 dequeue 后又继续执行。
5. 取消时 ComfyUI 离线，本地先标 cancelled/清输入，远端 prompt 恢复后继续跑。
6. ComfyUI 单次 history/API 抖动触发 repair，并在清除 CURRENT pid 后误重启仍在采样的核心服务。
7. 保存设置 `stopService()` 紧接 `startForegroundService()` 与共享静态 session/running 交错。
8. companion 6027 正常但 Panel/ComfyUI 未就绪时界面“假绿灯”。
9. 自动 bootstrap、手动 bootstrap、guard、repair/rollback 并发改动同一组 server 文件/服务。
10. guard.sh 磁盘已更新但旧 bash daemon 永远不重载。
11. SSH 已保存指纹在密码认证后才比较；服务器替换时密码可能先发送。
12. WebView 意外导航到外部页面后仍持有高权限 `Native` bridge。
13. `ack-local` 删除远端失败却清空 result，导致孤儿成图失去重试路径。
14. 本地相册已成功写入但 metadata 未提交时崩溃，恢复后重复保存同一任务成图。
15. job 参考图仅按 mtime 清理，超长排队时仍在使用的输入可能被 janitor 删除。
16. JS timeout 只丢 Promise，不终止 Native 后台 HTTP/SSH 操作，弱网下可堆积线程/重复操作。
17. 大图一开始直接 `readAsDataURL()`，造成 WebView/Base64 多份内存放大。
18. 批量提交中途失败时，已成功提交的 job id 未及时进入主界面跟踪状态。
19. job 404/长期状态读取异常无限 poll。
20. 配置端口非法时 Native 静默回退默认端口，以及切换服务器身份时沿用旧密码。
21. 终态任务删除 Comfy 输入失败后丢失所有权记录，导致隐私残留无法重试。

## 仍需真实环境覆盖的项目
本源码环境无法模拟真实 Android WebView/JSch/AutoDL/ComfyUI GPU 全栈，因此以下项目只能靠 Android/GitHub 构建与实机验证最终确认：
- targetSdk 35 上 Foreground Service 的真实生命周期和系统杀进程恢复。
- JSch 与 AutoDL 当前 SSH server 的 host-key algorithm/keyboard-interactive 兼容性。
- ComfyUI 具体版本是否提供 `/api/jobs/{id}/cancel`；代码已带旧接口定向回退。
- MediaStore 在不同 Android ROM 上的 Pictures/WAI Pad 权限/重复 display name 行为。
- 真实长图/大图在低内存平板上的峰值内存。
