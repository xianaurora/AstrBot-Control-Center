# WAI Pad v0.3.4.15 验证

已执行：

- `bash -n server/guard.sh server/bootstrap.sh`：通过。
- `python3 -m py_compile server/job_api.py server/engine_v34.py server/maintenance.py`：通过。
- `node --check android/app/src/main/assets/wai/app.js`：通过。
- `RemoteBootstrap.kt + TunnelService.kt` Kotlin stub 类型/语法编译：0 error（仅 stub 未使用参数等 warning）。
- legacy `service.lock` 被持续持有时执行 v0.3.4.15 迁移预检：返回 0，成功先拉起 companion，并报告 `WAI_PAD_LEGACY_CORE_BUSY=1` 而不是阻塞更新。
- legacy `service.lock` 持有时：`companion.lock`、`update.lock` 均可独立获取。
- `core.lock` 持有时：`companion.lock` 可独立获取。
- server 五个 companion 文件与 APK assets 逐字节一致。
- JSch 业务 channel 仍未恢复非零 `Channel.connect(timeout)`；仅 SSH Session 登录保留 `Session.connect(18_000)`。

限制：当前环境没有完整 Android SDK/AGP，因此真实 `assembleDebug` 仍以 GitHub Actions 为最终 Android API 编译验证。
