# WAI Pad v0.3.4.1

## 构建修复
- 修复 Android Kotlin 编译错误：`LocalWebViewClient.kt` 调用了不存在的 `LocalImageStore.open()`。
- 改为使用现有的 `LocalImageStore.resolve()` 获取本地图片文件，再通过 `FileInputStream` 提供给 WebView。
- 根据文件扩展名正确返回 PNG/JPEG/WebP MIME 类型。
- 版本升级为 `0.3.4.1` / versionCode 7。

## 影响范围
仅修复 APK 编译与本地图库图片读取桥接，不改生图工作流、人物参考参数或 AutoDL 后端逻辑。
