# WAI Pad v0.3.4.8 Validation

## 已在当前环境执行
- Python: `python3 -m py_compile server/job_api.py server/engine_v34.py server/maintenance.py` — PASS
- Shell: `bash -n server/bootstrap.sh server/guard.sh` — PASS
- Frontend: `node --check android/app/src/main/assets/wai/app.js` — PASS
- `server/*` 与 `android/app/src/main/assets/wai/server/*` 五个 companion 文件逐字节一致 — PASS
- MainActivity 通过 Kotlin stub 类型/语法编译 — PASS
- SshClient + RemoteBootstrap 当前代码通过 Kotlin stub 类型/语法编译 — PASS
- NativeBridge 当前代码通过 Kotlin stub 类型/语法编译 — PASS
- TunnelService 当前代码通过 Kotlin stub 类型/语法编译 — PASS
- LocalWebViewClient 当前代码通过 Kotlin stub 类型/语法编译 — PASS
- LocalImageStore 当前代码通过 Kotlin stub 类型/语法编译 — PASS

## 服务端关键回归
- 5 MiB + 777 B 随机输入，按 App 实际 256 KiB Base64 slice 共 27 分片；并发重复首片 + finalize，输出字节精确等于原输入 — PASS
- 24 个并发相同 `client_request_id` POST，只创建 1 个 job — PASS
- 同一 job 重复进入 `WORK_Q`，原子 claim 后只调用 1 次 `run_job` — PASS
- 新 ComfyUI 原子 cancel 路径优先，不调用 global interrupt — PASS
- 旧 ComfyUI pending prompt 回退只发送 `queue delete [target_prompt]`，不调用 global interrupt — PASS
- cancel 时 ComfyUI 状态 unknown，job 保持 `repairing/cancelling`、输入不清理并重新排队接管 — PASS

## 打包/版本检查
- Android versionName `0.3.4.8`, versionCode `14`。
- GitHub Actions artifact 名称 `WAI-Pad-v0.3.4.8-debug`。
- 源码 ZIP 搜索规则仍接受浏览器产生的 `_source(1).zip` / `_source*.zip`。
- 固定私人 keystore SHA-256 与 v0.3.4.7 相同；`keytool` 实测证书 SHA-256 与 `SIGNING_FINGERPRINT.txt` 一致。

## 当前环境限制
当前运行环境没有完整 Android SDK/AGP 依赖缓存，无法在本地诚实执行 `assembleDebug` 或安装到平板。项目内 GitHub Actions 会安装 Android SDK + Gradle、构建 APK，并用 pinned certificate 再验签。
