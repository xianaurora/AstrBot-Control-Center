# Build status — v1.6.0-dev12

- Android App: `1.6.0-dev12` / `161000`
- 内置核心组件: `1.6.0-dev9` / `16009`
- SnowLuma 默认扫码：FFmpeg x11grab → PNG → 原生 Compose Image；不经过 VNC/noVNC/WebView。
- 二维码过期：仅检测状态并显示“刷新二维码”；只有用户主动点击时才向 QQ 窗口发送一次点击，App + Core 双层 30 秒冷却，不自动循环刷新。
- 高级完整 QQ 桌面：保留 noVNC，用户显式打开时才启动。
- AstrBot：打开前做首页 + JS/CSS + MIME 实际 HTTP 健康检查。
- AstrBot WebView：使用 `lastRequestedUrl` 跟踪 Compose 请求，不再拿 SPA 自身的 `view.url` 导航变化触发 root reload。
- WebView 继续使用平台 loading / HTTP / JS console / renderer 回调；保留一次只读的“挂载可见性”诊断（仅报错，不 reload），不再做 host 切换、清缓存或自动重载。
- 本地源码门禁校验核心清单、Shell/JSON、原生扫码、人工刷新、AstrBot probe 和 SPA-safe WebView 约束。

当前执行环境没有完整 Android SDK / Gradle Wrapper JAR，因此不能在这里声称 `assembleDebug` 已完成；最终 APK 编译仍由 GitHub Actions / Android 构建环境验证。
