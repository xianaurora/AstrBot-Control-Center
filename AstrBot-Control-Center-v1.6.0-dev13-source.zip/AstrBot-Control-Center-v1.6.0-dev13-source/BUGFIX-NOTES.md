# dev12.1 bugfix-only pass

This pass intentionally does not add the planned Environment page, source selector, feature switches, new progress UI, or operations redesign. It only fixes defects found in the dev12 source audit.

## Fixed

1. **Release/version drift**
   - App: `1.6.0-dev12.1 / 161001`
   - Core: `1.6.0-dev10 / 16010`
   - Installer model defaults, embedded Core target, app resource catalog release, CI workflow name/artifact name are aligned.
   - The stale `astrbot-core-v1.6.0-dev6.zip` cache filename is now derived from the target Core version.

2. **Rootfs verification used stale compiled constants**
   - Download verification, final import verification, local-file import, progress size, and completed `.part` reuse now use the same `RootfsCatalog` metadata.
   - A fully verified cached rootfs remains usable even if the current catalog has no network URL.
   - Oversized/corrupt completed partial files are discarded instead of being resumed incorrectly.

3. **Concurrent settings writes could overwrite each other**
   - Core `config_set()` now uses the bundled BusyBox `flock` and a per-process temporary file before atomic rename.
   - Concurrent-write behavior was exercised with 24 simultaneous writes in host validation.

4. **`stack_autostart` default disagreed across Core paths**
   - All remaining `config_get stack_autostart` fallbacks now use the canonical default `1`.

5. **Native QR polling silently stopped after about five minutes**
   - Removed the fixed `repeat(360)` lifetime.
   - Polling now follows the active screen/lifecycle and resumes when the app returns to foreground.

6. **QR refresh and normal frame polling could race**
   - The normal frame poller pauses while a user-triggered QR refresh is in progress.
   - The extra one-off frame writer was removed; normal polling is the single frame-state writer after the refresh delay.

7. **Operations logs were polling while the user was not on Logs**
   - Root log reads now run only while `Operations -> Logs` is actually visible.
   - Switching Operations sections starts/stops polling immediately.

8. **Root command timeout could leave child processes alive / output was unbounded**
   - Root commands run in a dedicated session/process group and expose the actual root command PID to the timeout path.
   - Timeout cleanup terminates the root process group best-effort before destroying the outer `su` process.
   - stdout/stderr capture is capped at 512 KiB each.

9. **Slow AstrBot SPA could be reported as failed after 4.5 seconds**
   - Removed the synthetic DOM mount timeout failure.
   - WebView errors now come from actual HTTP/network/renderer callbacks instead of an empty-DOM heuristic.

## Deliberately not changed

- No new mainland download mirrors were added in this pass.
- No new Environment/settings pages were added.
- No operations-page redesign was added.
- No QR-resolution redesign or interactive native desktop was added.
- No new automatic recovery behavior was added.
