package com.xianaurora.astrbotcontrol.engine

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xianaurora.astrbotcontrol.model.ControlCenterUiState
import com.xianaurora.astrbotcontrol.model.ControlDestination
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ControlCenterViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = ControlCenterRepository()
    private val _ui = MutableStateFlow(ControlCenterUiState())
    val ui: StateFlow<ControlCenterUiState> = _ui.asStateFlow()

    private var statusJob: Job? = null
    private var logJob: Job? = null
    private var active = false
    private var refreshTick = 0

    fun start() {
        if (active) return
        active = true
        statusJob = viewModelScope.launch {
            repository.keepConsoleActive()
            loadLogSources()
            while (active) {
                val forceLive = refreshTick == 0 || _ui.value.actionBusy || _ui.value.status.actionRunning || _ui.value.status.stackStarting || refreshTick % 5 == 0
                refreshStatus(forceLive)
                refreshTick++
                if (refreshTick % 4 == 0) repository.keepConsoleActive()
                delay(
                    when {
                        _ui.value.actionBusy || _ui.value.status.actionRunning || _ui.value.status.stackStarting -> 1600
                        _ui.value.destination == ControlDestination.LOGS -> 5200
                        else -> 3200
                    }
                )
            }
        }
        syncLogPolling()
    }

    fun stop() {
        active = false
        statusJob?.cancel()
        statusJob = null
        logJob?.cancel()
        logJob = null
    }

    fun setDestination(destination: ControlDestination) {
        if (_ui.value.destination == destination) return
        _ui.update { it.copy(destination = destination, transientMessage = "") }
        syncLogPolling()
    }

    fun clearMessages() {
        _ui.update { it.copy(transientMessage = "", errorMessage = "") }
    }

    fun refresh() = viewModelScope.launch {
        _ui.update { it.copy(refreshing = true, errorMessage = "") }
        refreshStatus(true)
        if (_ui.value.destination == ControlDestination.LOGS) refreshSelectedLog()
        _ui.update { it.copy(refreshing = false) }
    }

    fun selectLog(id: String) {
        _ui.update { it.copy(selectedLogId = id, logLoading = true, errorMessage = "") }
        viewModelScope.launch { refreshSelectedLog() }
    }

    fun runAction(action: String) {
        if (_ui.value.actionBusy || _ui.value.status.actionRunning) return
        val label = when (action) {
            "start" -> "正在启动"
            "stop" -> "正在停止"
            "restart" -> "正在重启"
            "heal" -> "正在恢复"
            "repair" -> "正在修复"
            "plugin-deps" -> "正在修复插件依赖"
            "bridge-repair" -> "正在修复 OneBot"
            else -> "正在执行"
        }
        _ui.update { it.copy(actionBusy = true, actionLabel = label, transientMessage = "", errorMessage = "") }
        viewModelScope.launch {
            val result = repository.queue(action)
            if (!result.ok) {
                _ui.update {
                    it.copy(
                        actionBusy = false,
                        actionLabel = "",
                        errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "操作没有提交成功" } }
                    )
                }
                return@launch
            }
            if (result.stdout.lineSequence().any { it.startsWith("QUEUED|busy|") }) {
                refreshStatus(true)
                _ui.update {
                    it.copy(
                        actionBusy = false,
                        actionLabel = "",
                        transientMessage = "已有操作正在执行，状态会自动更新"
                    )
                }
                return@launch
            }
            _ui.update { it.copy(transientMessage = "操作已提交，状态会自动更新") }
            for (attempt in 0 until 8) {
                refreshStatus(true)
                if (!_ui.value.status.actionRunning && !_ui.value.status.stackStarting && attempt >= 2) break
                delay(1400)
            }
            _ui.update { it.copy(actionBusy = false, actionLabel = "") }
            refreshStatus(true)
        }
    }

    fun requestWebUrl(kind: String, mode: String = "admin", onUrl: (String) -> Unit) {
        viewModelScope.launch {
            repository.webUrl(kind, mode)
                .onSuccess { url ->
                    runCatching { onUrl(url) }
                        .onFailure { error -> _ui.update { it.copy(errorMessage = "无法打开控制台：${error.message ?: "没有可用的浏览器"}") } }
                }
                .onFailure { error -> _ui.update { it.copy(errorMessage = "无法打开控制台：${error.message ?: "未知错误"}") } }
        }
    }

    fun requestQqLoginUrl(onUrl: (String) -> Unit) {
        val engine = _ui.value.status.qqEngine
        viewModelScope.launch {
            repository.qqLoginUrl(engine)
                .onSuccess { url ->
                    runCatching { onUrl(url) }
                        .onFailure { error -> _ui.update { it.copy(errorMessage = "QQ 登录入口暂不可用：${error.message ?: "没有可用的浏览器"}") } }
                }
                .onFailure { error -> _ui.update { it.copy(errorMessage = "QQ 登录入口暂不可用：${error.message ?: "未知错误"}") } }
        }
    }

    private suspend fun refreshStatus(forceLive: Boolean) {
        val result = repository.status(forceLive)
        result.onSuccess { status ->
            _ui.update {
                it.copy(
                    loading = false,
                    status = status,
                    lastRefreshEpoch = System.currentTimeMillis() / 1000,
                    errorMessage = if (it.errorMessage.startsWith("状态读取失败")) "" else it.errorMessage
                )
            }
        }.onFailure { error ->
            _ui.update {
                it.copy(
                    loading = false,
                    errorMessage = "状态读取失败：${error.message ?: "未知错误"}"
                )
            }
        }
    }

    private suspend fun loadLogSources() {
        repository.logSources().onSuccess { sources ->
            val ordered = sources.sortedWith(compareBy<com.xianaurora.astrbotcontrol.model.LogSource> {
                when (it.id) {
                    "health" -> 0
                    "astrbot" -> 1
                    "napcat" -> 2
                    "action" -> 3
                    "boot" -> 4
                    else -> 10
                }
            }.thenBy { it.label })
            _ui.update {
                val selected = if (ordered.any { source -> source.id == it.selectedLogId }) it.selectedLogId else ordered.firstOrNull()?.id.orEmpty()
                it.copy(logSources = ordered, selectedLogId = selected)
            }
        }
    }

    private fun syncLogPolling() {
        logJob?.cancel()
        logJob = null
        if (!active || _ui.value.destination != ControlDestination.LOGS) return
        logJob = viewModelScope.launch {
            refreshSelectedLog()
            while (active && _ui.value.destination == ControlDestination.LOGS) {
                delay(2800)
                refreshSelectedLog()
            }
        }
    }

    private suspend fun refreshSelectedLog() {
        val id = _ui.value.selectedLogId.ifBlank { "health" }
        _ui.update { it.copy(logLoading = it.logText.isBlank()) }
        repository.log(id, 280).onSuccess { text ->
            _ui.update { it.copy(logText = text, logLoading = false) }
        }.onFailure { error ->
            _ui.update { it.copy(logLoading = false, errorMessage = "日志读取失败：${error.message ?: "未知错误"}") }
        }
    }

    override fun onCleared() {
        stop()
        super.onCleared()
    }
}
