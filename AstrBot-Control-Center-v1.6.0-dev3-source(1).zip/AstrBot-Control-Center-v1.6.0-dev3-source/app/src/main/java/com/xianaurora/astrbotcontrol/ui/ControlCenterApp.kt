package com.xianaurora.astrbotcontrol.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.xianaurora.astrbotcontrol.engine.ControlCenterViewModel
import com.xianaurora.astrbotcontrol.model.ControlCenterUiState
import com.xianaurora.astrbotcontrol.model.ControlDestination
import com.xianaurora.astrbotcontrol.model.RuntimeHealth
import com.xianaurora.astrbotcontrol.model.RuntimeStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val ControlEasing = CubicBezierEasing(0.20f, 0f, 0f, 1f)
private const val ControlFast = 160
private const val ControlStandard = 320

private fun destinationRank(destination: ControlDestination) = when (destination) {
    ControlDestination.OVERVIEW -> 0
    ControlDestination.SERVICES -> 1
    ControlDestination.LOGS -> 2
    ControlDestination.MORE -> 3
}

@Composable
fun ControlCenterApp(
    vm: ControlCenterViewModel,
    onOpenHelp: () -> Unit
) {
    val ui by vm.ui.collectAsStateWithLifecycle()

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, vm) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> vm.start()
                Lifecycle.Event.ON_STOP -> vm.stop()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) vm.start()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            vm.stop()
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 760.dp
        if (wide) {
            Row(Modifier.fillMaxSize()) {
                ControlRail(
                    destination = ui.destination,
                    onDestination = vm::setDestination,
                    modifier = Modifier.width(104.dp).fillMaxHeight()
                )
                ControlContent(
                    ui = ui,
                    vm = vm,
                    onOpenHelp = onOpenHelp,
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    wide = true
                )
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                ControlContent(
                    ui = ui,
                    vm = vm,
                    onOpenHelp = onOpenHelp,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    wide = false
                )
                ControlBottomBar(
                    destination = ui.destination,
                    onDestination = vm::setDestination,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ControlContent(
    ui: ControlCenterUiState,
    vm: ControlCenterViewModel,
    onOpenHelp: () -> Unit,
    modifier: Modifier,
    wide: Boolean
) {
    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        AnimatedContent(
            targetState = ui.loading,
            transitionSpec = {
                (fadeIn(tween(ControlStandard, easing = ControlEasing)) + scaleIn(initialScale = .985f)) togetherWith
                    (fadeOut(tween(ControlFast)) + scaleOut(targetScale = .99f))
            },
            label = "control-initial-load"
        ) { loading ->
            if (loading) {
                ControlCenterLoading()
            } else {
                AnimatedContent(
                    targetState = ui.destination,
                    transitionSpec = {
                        val forward = destinationRank(targetState) >= destinationRank(initialState)
                        val enter = if (forward) 48 else -48
                        val exit = if (forward) -28 else 28
                        (
                            fadeIn(tween(ControlStandard, easing = ControlEasing)) +
                                slideInHorizontally(
                                    animationSpec = spring(dampingRatio = .88f, stiffness = 280f),
                                    initialOffsetX = { enter }
                                )
                        ) togetherWith (
                            fadeOut(tween(ControlFast)) +
                                slideOutHorizontally(
                                    animationSpec = spring(dampingRatio = .92f, stiffness = 340f),
                                    targetOffsetX = { exit }
                                )
                        )
                    },
                    label = "control-destination"
                ) { destination ->
                    when (destination) {
                        ControlDestination.OVERVIEW -> OverviewScreen(ui, vm, wide)
                        ControlDestination.SERVICES -> ServicesScreen(ui, vm, wide)
                        ControlDestination.LOGS -> LogsScreen(ui, vm, wide)
                        ControlDestination.MORE -> MoreScreen(ui, vm, onOpenHelp, wide)
                    }
                }
            }
        }

        ControlMessageOverlay(
            error = ui.errorMessage,
            message = ui.transientMessage,
            onDismiss = vm::clearMessages,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun ControlMessageOverlay(error: String, message: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    val text = error.ifBlank { message }
    val critical = error.isNotBlank()
    LaunchedEffect(text) {
        if (text.isNotBlank() && !text.startsWith("状态读取失败")) {
            delay(4800)
            onDismiss()
        }
    }
    AnimatedVisibility(
        visible = text.isNotBlank(),
        modifier = modifier.padding(horizontal = 18.dp, vertical = 16.dp),
        enter = fadeIn(tween(ControlStandard)) + slideInVertically { it / 2 } + scaleIn(initialScale = .96f),
        exit = fadeOut(tween(ControlFast)) + scaleOut(targetScale = .98f)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = if (critical) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.inverseSurface,
            shadowElevation = 5.dp
        ) {
            Row(Modifier.padding(horizontal = 15.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (critical) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.inverseOnSurface,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
                TextButton(onClick = onDismiss) { Text("知道了") }
            }
        }
    }
}

@Composable
private fun ControlCenterLoading() {
    val infinite = rememberInfiniteTransition(label = "control-loading")
    val pulse by infinite.animateFloat(
        initialValue = .86f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = ControlEasing), repeatMode = RepeatMode.Reverse),
        label = "control-loading-pulse"
    )
    Box(Modifier.fillMaxSize().padding(26.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Surface(
                shape = RoundedCornerShape(25.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(74.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("A", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Text("正在连接核心组件", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("读取运行状态与账号连接", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OverviewScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val contentPadding = if (wide) 30.dp else 18.dp
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = contentPadding, end = contentPadding, top = 22.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            ScreenHeader(
                eyebrow = "控制中心",
                title = greetingTitle(ui.status),
                subtitle = greetingSubtitle(ui.status),
                refreshing = ui.refreshing,
                onRefresh = vm::refresh
            )
        }
        item { RuntimeHero(ui, vm) }
        item {
            if (wide) {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
                    ServiceSummaryCard(
                        modifier = Modifier.weight(1f),
                        glyph = "A",
                        title = "AstrBot",
                        state = when {
                            ui.status.astrbotUp && ui.status.astrbotWebReady -> "运行正常"
                            ui.status.astrbotUp -> "正在启动"
                            ui.status.astrbotReady -> "已停止"
                            else -> "未就绪"
                        },
                        good = ui.status.astrbotUp && ui.status.astrbotWebReady,
                        working = ui.status.astrbotUp && !ui.status.astrbotWebReady,
                        detail = if (ui.status.astrbotPort > 0) "端口 ${ui.status.astrbotPort}" else "运行服务"
                    )
                    ServiceSummaryCard(
                        modifier = Modifier.weight(1f),
                        glyph = "QQ",
                        title = qqTitle(ui.status),
                        state = qqStateLabel(ui.status),
                        good = ui.status.qqOnline,
                        working = ui.status.qqStartingCount > 0,
                        detail = ui.status.mainQqReason.ifBlank { "账号与协议适配" }
                    )
                    ServiceSummaryCard(
                        modifier = Modifier.weight(1f),
                        glyph = "1B",
                        title = "OneBot",
                        state = if (ui.status.oneBotConnected > 0) "已连接" else if (ui.status.oneBotAuthFailed) "鉴权异常" else "等待连接",
                        good = ui.status.oneBotConnected > 0,
                        working = ui.status.stackStarting,
                        detail = if (ui.status.oneBotConnected > 0) "${ui.status.oneBotConnected} 个连接" else ui.status.oneBotReason.ifBlank { "反向 WebSocket" }
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ServiceSummaryCard(
                        modifier = Modifier.fillMaxWidth(),
                        glyph = "A",
                        title = "AstrBot",
                        state = when {
                            ui.status.astrbotUp && ui.status.astrbotWebReady -> "运行正常"
                            ui.status.astrbotUp -> "正在启动"
                            ui.status.astrbotReady -> "已停止"
                            else -> "未就绪"
                        },
                        good = ui.status.astrbotUp && ui.status.astrbotWebReady,
                        working = ui.status.astrbotUp && !ui.status.astrbotWebReady,
                        detail = if (ui.status.astrbotPort > 0) "端口 ${ui.status.astrbotPort}" else "运行服务"
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        ServiceSummaryCard(
                            modifier = Modifier.weight(1f),
                            glyph = "QQ",
                            title = qqTitle(ui.status),
                            state = qqStateLabel(ui.status),
                            good = ui.status.qqOnline,
                            working = ui.status.qqStartingCount > 0,
                            detail = ui.status.mainQqReason.ifBlank { "账号状态" }
                        )
                        ServiceSummaryCard(
                            modifier = Modifier.weight(1f),
                            glyph = "1B",
                            title = "OneBot",
                            state = if (ui.status.oneBotConnected > 0) "已连接" else "等待连接",
                            good = ui.status.oneBotConnected > 0,
                            working = ui.status.stackStarting,
                            detail = if (ui.status.oneBotConnected > 0) "${ui.status.oneBotConnected} 个连接" else "反向连接"
                        )
                    }
                }
            }
        }
        item { ActivityCard(ui.status) }
    }
}

@Composable
private fun RuntimeHero(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val status = ui.status
    val health = status.health
    val accent by animateColorAsState(
        targetValue = when (health) {
            RuntimeHealth.HEALTHY -> MaterialTheme.colorScheme.primary
            RuntimeHealth.WORKING -> MaterialTheme.colorScheme.tertiary
            RuntimeHealth.ATTENTION -> MaterialTheme.colorScheme.error
            RuntimeHealth.STOPPED -> MaterialTheme.colorScheme.secondary
            RuntimeHealth.UNKNOWN -> MaterialTheme.colorScheme.outline
        },
        animationSpec = tween(ControlStandard, easing = ControlEasing),
        label = "hero-accent"
    )
    val cardColor by animateColorAsState(
        targetValue = when (health) {
            RuntimeHealth.HEALTHY -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = .62f)
            RuntimeHealth.WORKING -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .62f)
            RuntimeHealth.ATTENTION -> MaterialTheme.colorScheme.errorContainer.copy(alpha = .72f)
            else -> MaterialTheme.colorScheme.surfaceContainerHigh
        },
        animationSpec = tween(ControlStandard, easing = ControlEasing),
        label = "hero-container"
    )

    Surface(
        modifier = Modifier.fillMaxWidth().animateContentSize(),
        color = cardColor,
        shape = RoundedCornerShape(34.dp)
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(22.dp)) {
            val compact = maxWidth < 540.dp
            if (compact) {
                Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
                    HeroStatusText(status, accent)
                    PrimaryRuntimeControl(ui, vm, Modifier.fillMaxWidth())
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    Box(Modifier.weight(1f)) { HeroStatusText(status, accent) }
                    PrimaryRuntimeControl(ui, vm, Modifier.widthIn(min = 210.dp, max = 260.dp))
                }
            }
        }
    }
}

@Composable
private fun HeroStatusText(status: RuntimeStatus, accent: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MotionStatusDot(status.health, accent)
            Text(
                heroLabel(status),
                style = MaterialTheme.typography.labelLarge,
                color = accent,
                fontWeight = FontWeight.SemiBold
            )
        }
        AnimatedContent(
            targetState = heroTitle(status),
            transitionSpec = {
                (fadeIn(tween(ControlStandard)) + slideInVertically { it / 5 }) togetherWith fadeOut(tween(ControlFast))
            },
            label = "hero-title"
        ) { title ->
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        }
        Text(
            heroDetail(status),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun MotionStatusDot(health: RuntimeHealth, accent: Color) {
    val moving = health == RuntimeHealth.WORKING
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(22.dp)) {
        if (moving) {
            val infinite = rememberInfiniteTransition(label = "status-pulse")
            val pulse by infinite.animateFloat(
                initialValue = .72f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(900, easing = ControlEasing), repeatMode = RepeatMode.Reverse),
                label = "status-pulse-value"
            )
            Surface(
                shape = CircleShape,
                color = accent.copy(alpha = .18f),
                modifier = Modifier.size(22.dp).graphicsLayer {
                    scaleX = pulse
                    scaleY = pulse
                }
            ) {}
        }
        Surface(shape = CircleShape, color = accent, modifier = Modifier.size(9.dp)) {}
    }
}

@Composable
private fun PrimaryRuntimeControl(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    val busy = ui.actionBusy || ui.status.actionRunning || ui.status.stackStarting
    val running = ui.status.stackRunning
    val needsLogin = ui.status.qqNeedsLogin
    val uriHandler = LocalUriHandler.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && !busy) .965f else 1f,
        animationSpec = spring(dampingRatio = .78f, stiffness = 520f),
        label = "main-control-scale"
    )
    Button(
        onClick = {
            if (!busy) {
                if (needsLogin) vm.requestQqLoginUrl(uriHandler::openUri)
                else vm.runAction(if (running) "stop" else "start")
            }
        },
        enabled = !busy,
        interactionSource = interaction,
        modifier = modifier.height(58.dp).graphicsLayer { scaleX = scale; scaleY = scale },
        shape = RoundedCornerShape(21.dp)
    ) {
        AnimatedContent(
            targetState = Triple(busy, running, ui.actionLabel),
            transitionSpec = { (fadeIn() + scaleIn(initialScale = .94f)) togetherWith (fadeOut() + scaleOut(targetScale = .96f)) },
            label = "main-control-label"
        ) { state ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (state.first) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Text(
                    when {
                        state.first -> state.third.ifBlank { "处理中" }
                        needsLogin -> "打开 QQ 登录"
                        state.second -> "停止服务"
                        else -> "启动服务"
                    },
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun ServiceSummaryCard(
    modifier: Modifier,
    glyph: String,
    title: String,
    state: String,
    good: Boolean,
    working: Boolean,
    detail: String
) {
    val stateColor by animateColorAsState(
        targetValue = when {
            good -> MaterialTheme.colorScheme.primary
            working -> MaterialTheme.colorScheme.tertiary
            else -> MaterialTheme.colorScheme.onSurfaceVariant
        },
        animationSpec = tween(ControlStandard, easing = ControlEasing),
        label = "service-state"
    )
    Surface(modifier = modifier, shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                GlyphTile(glyph)
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(state, style = MaterialTheme.typography.labelMedium, color = stateColor)
                }
            }
            Text(
                detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun GlyphTile(text: String) {
    Surface(
        shape = RoundedCornerShape(13.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHighest,
        modifier = Modifier.size(42.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(text, fontSize = if (text.length > 1) 11.sp else 17.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ActivityCard(status: RuntimeStatus) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("最近活动", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                if (status.lastStackSeconds > 0) {
                    Text("启动 ${status.lastStackSeconds}s", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            ActivityLine("收到消息", status.lastInbound)
            ActivityLine("发送消息", status.lastOutbound)
            ActivityLine("模型响应", status.lastModelOk)
            if (status.lastEvent.isNotBlank()) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f))
                Text(status.lastEvent, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun ActivityLine(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        Text(value.ifBlank { "暂无" }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ServicesScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val padding = if (wide) 30.dp else 18.dp
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = padding, end = padding, top = 22.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader("运行服务", "服务", "运行状态、常用操作和异常处理集中在这里。", ui.refreshing, vm::refresh) }
        item { ServiceActionBar(ui, vm) }
        if (wide) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    DetailedServiceCard(
                        modifier = Modifier.weight(1f),
                        title = "AstrBot",
                        subtitle = "机器人主服务",
                        running = ui.status.astrbotUp,
                        ready = ui.status.astrbotReady,
                        rows = listOf(
                            "WebUI" to if (ui.status.astrbotWebReady) "已监听" else "未监听",
                            "PID" to ui.status.astrbotPid.ifBlank { "—" },
                            "端口" to ui.status.astrbotPort.takeIf { it > 0 }?.toString().orEmpty().ifBlank { "—" }
                        )
                    )
                    DetailedServiceCard(
                        modifier = Modifier.weight(1f),
                        title = qqTitle(ui.status),
                        subtitle = "Linux QQ 与适配层",
                        running = if (ui.status.qqEngine == "snowluma") ui.status.snowlumaUp else ui.status.napcatUp,
                        ready = if (ui.status.qqEngine == "snowluma") ui.status.snowlumaReady else ui.status.napcatReady,
                        rows = listOf(
                            "主账号" to qqStateLabel(ui.status),
                            "在线账号" to ui.status.qqOnlineCount.toString(),
                            "实例" to "${ui.status.instanceRunning}/${ui.status.instanceEnabled} 运行"
                        )
                    )
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    DetailedServiceCard(
                        modifier = Modifier.weight(1f),
                        title = "OneBot",
                        subtitle = "反向 WebSocket",
                        running = ui.status.oneBotConnected > 0,
                        ready = ui.status.bridgeReady,
                        rows = listOf(
                            "监听" to if (ui.status.oneBotListen) "正常" else "未监听",
                            "连接" to ui.status.oneBotConnected.toString(),
                            "鉴权" to if (ui.status.oneBotAuthFailed) "异常" else "正常"
                        )
                    )
                    DetailedServiceCard(
                        modifier = Modifier.weight(1f),
                        title = "后台守护",
                        subtitle = "低频健康检查与安全唤醒",
                        running = ui.status.watchdogRunning || ui.status.messageGuardRunning,
                        ready = ui.status.watchdogEnabled || ui.status.messageGuardEnabled,
                        rows = listOf(
                            "服务守护" to stateOnOff(ui.status.watchdogEnabled, ui.status.watchdogRunning),
                            "消息守护" to stateOnOff(ui.status.messageGuardEnabled, ui.status.messageGuardRunning),
                            "快速启动" to if (ui.status.fastBootReady) "已就绪" else "待准备"
                        )
                    )
                }
            }
        } else {
            item {
                DetailedServiceCard(
                    modifier = Modifier.fillMaxWidth(),
                    title = "AstrBot",
                    subtitle = "机器人主服务",
                    running = ui.status.astrbotUp,
                    ready = ui.status.astrbotReady,
                    rows = listOf(
                        "WebUI" to if (ui.status.astrbotWebReady) "已监听" else "未监听",
                        "PID" to ui.status.astrbotPid.ifBlank { "—" },
                        "端口" to ui.status.astrbotPort.takeIf { it > 0 }?.toString().orEmpty().ifBlank { "—" }
                    )
                )
            }
            item {
                DetailedServiceCard(
                    modifier = Modifier.fillMaxWidth(),
                    title = qqTitle(ui.status),
                    subtitle = "Linux QQ 与适配层",
                    running = if (ui.status.qqEngine == "snowluma") ui.status.snowlumaUp else ui.status.napcatUp,
                    ready = if (ui.status.qqEngine == "snowluma") ui.status.snowlumaReady else ui.status.napcatReady,
                    rows = listOf(
                        "主账号" to qqStateLabel(ui.status),
                        "在线账号" to ui.status.qqOnlineCount.toString(),
                        "实例" to "${ui.status.instanceRunning}/${ui.status.instanceEnabled} 运行"
                    )
                )
            }
            item {
                DetailedServiceCard(
                    modifier = Modifier.fillMaxWidth(),
                    title = "OneBot",
                    subtitle = "反向 WebSocket",
                    running = ui.status.oneBotConnected > 0,
                    ready = ui.status.bridgeReady,
                    rows = listOf(
                        "监听" to if (ui.status.oneBotListen) "正常" else "未监听",
                        "连接" to ui.status.oneBotConnected.toString(),
                        "鉴权" to if (ui.status.oneBotAuthFailed) "异常" else "正常"
                    )
                )
            }
            item {
                DetailedServiceCard(
                    modifier = Modifier.fillMaxWidth(),
                    title = "后台守护",
                    subtitle = "低频健康检查与安全唤醒",
                    running = ui.status.watchdogRunning || ui.status.messageGuardRunning,
                    ready = ui.status.watchdogEnabled || ui.status.messageGuardEnabled,
                    rows = listOf(
                        "服务守护" to stateOnOff(ui.status.watchdogEnabled, ui.status.watchdogRunning),
                        "消息守护" to stateOnOff(ui.status.messageGuardEnabled, ui.status.messageGuardRunning),
                        "快速启动" to if (ui.status.fastBootReady) "已就绪" else "待准备"
                    )
                )
            }
        }
        if (ui.status.qqAlertReason.isNotBlank()) item { AlertStrip(ui.status.qqAlertReason, critical = ui.status.qqStalledCount > 0) }
        if (ui.status.oneBotAuthFailed) item { AlertStrip(ui.status.oneBotReason.ifBlank { "OneBot 鉴权失败" }, critical = true) }
    }
}

@Composable
private fun ServiceActionBar(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val busy = ui.actionBusy || ui.status.actionRunning || ui.status.stackStarting
    Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.padding(14.dp)) {
            if (maxWidth < 520.dp) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionButton("重启全部", enabled = !busy, primary = true, onClick = { vm.runAction("restart") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        ActionButton("自动恢复", enabled = !busy, onClick = { vm.runAction("heal") }, modifier = Modifier.weight(1f))
                        ActionButton("修复 OneBot", enabled = !busy, onClick = { vm.runAction("bridge-repair") }, modifier = Modifier.weight(1f))
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    ActionButton("重启全部", enabled = !busy, primary = true, onClick = { vm.runAction("restart") })
                    ActionButton("自动恢复", enabled = !busy, onClick = { vm.runAction("heal") })
                    ActionButton("修复 OneBot", enabled = !busy, onClick = { vm.runAction("bridge-repair") })
                    Spacer(Modifier.weight(1f))
                    if (busy) Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text(ui.actionLabel.ifBlank { "处理中" }, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionButton(
    text: String,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .97f else 1f, spring(dampingRatio = .78f, stiffness = 540f), label = "action-button-scale")
    if (primary) {
        Button(onClick, enabled = enabled, interactionSource = interaction, modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }, shape = RoundedCornerShape(17.dp)) { Text(text) }
    } else {
        OutlinedButton(onClick, enabled = enabled, interactionSource = interaction, modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }, shape = RoundedCornerShape(17.dp)) { Text(text) }
    }
}

@Composable
private fun DetailedServiceCard(
    modifier: Modifier,
    title: String,
    subtitle: String,
    running: Boolean,
    ready: Boolean,
    rows: List<Pair<String, String>>
) {
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer, shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(
                    text = when {
                        running -> "运行中"
                        ready -> "已停止"
                        else -> "未就绪"
                    },
                    good = running
                )
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
            rows.forEach { (label, value) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.weight(1f))
                    Text(value, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun LogsScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val logLines = remember(ui.logText) { ui.logText.lineSequence().toList() }
    val listState = rememberLazyListState()
    var followTail by rememberSaveable { mutableStateOf(true) }

    LaunchedEffect(ui.logText, followTail) {
        if (followTail && logLines.isNotEmpty()) listState.animateScrollToItem(logLines.lastIndex)
    }

    Column(Modifier.fillMaxSize().padding(top = 22.dp)) {
        Box(Modifier.padding(horizontal = if (wide) 30.dp else 18.dp)) {
            ScreenHeader("实时输出", "日志", "默认跟随最新输出；查看旧内容时可以暂停跟随。", ui.refreshing, vm::refresh)
        }
        Spacer(Modifier.height(14.dp))
        if (wide) {
            Row(Modifier.fillMaxSize().padding(horizontal = 30.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                LogSourcePane(ui, vm, Modifier.width(265.dp).fillMaxHeight())
                LogViewer(ui, logLines, listState, followTail, { followTail = !followTail }, Modifier.weight(1f).fillMaxHeight())
            }
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(ui.logSources, key = { it.id }) { source ->
                    LogChip(source.label, selected = source.id == ui.selectedLogId, onClick = { vm.selectLog(source.id) })
                }
            }
            Spacer(Modifier.height(10.dp))
            LogViewer(ui, logLines, listState, followTail, { followTail = !followTail }, Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 6.dp))
        }
    }
}

@Composable
private fun LogSourcePane(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        LazyColumn(contentPadding = PaddingValues(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(ui.logSources, key = { it.id }) { source ->
                val selected = source.id == ui.selectedLogId
                val color by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, label = "log-source-color")
                Surface(
                    color = color,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { vm.selectLog(source.id) }
                ) {
                    Text(source.label, modifier = Modifier.padding(horizontal = 13.dp, vertical = 11.dp), style = MaterialTheme.typography.bodyMedium, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

@Composable
private fun LogChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer, label = "log-chip")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable(onClick = onClick)) {
        Text(text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp), style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun LogViewer(
    ui: ControlCenterUiState,
    lines: List<String>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    followTail: Boolean,
    onToggleFollow: () -> Unit,
    modifier: Modifier
) {
    Surface(modifier = modifier, shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(ui.logSources.firstOrNull { it.id == ui.selectedLogId }?.label ?: "日志", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                if (ui.logLoading) CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp)
                TextButton(onClick = onToggleFollow) { Text(if (followTail) "暂停跟随" else "跟随最新") }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f))
            if (lines.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (ui.logLoading) "正在读取日志…" else "暂无日志", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                SelectionContainer {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        itemsIndexed(lines) { _, line ->
                            Text(
                                line.ifEmpty { " " },
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.5.sp,
                                lineHeight = 17.sp,
                                color = if (line.contains("error", true) || line.contains("失败") || line.contains("fatal", true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MoreScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, onOpenHelp: () -> Unit, wide: Boolean) {
    val uriHandler = LocalUriHandler.current
    val padding = if (wide) 30.dp else 18.dp
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = padding, end = padding, top = 22.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader("系统与维护", "更多", "环境信息、高级控制台和维护入口。", ui.refreshing, vm::refresh) }
        item {
            Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Text("设备与环境", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    InfoRow("核心组件", ui.status.moduleVersion.ifBlank { "未知" })
                    InfoRow("设备", ui.status.device.ifBlank { "未知" })
                    InfoRow("Android", ui.status.android.ifBlank { "未知" })
                    InfoRow("内核", ui.status.kernel.ifBlank { "未知" })
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Web 控制台", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("原 Web 页面继续保留，适合高级设置或暂未迁移到原生界面的功能。", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        if (maxWidth < 500.dp) {
                            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                OpenWebButton("AstrBot WebUI") { vm.requestWebUrl("astrbot", onUrl = uriHandler::openUri) }
                                OpenWebButton(if (ui.status.qqEngine == "snowluma") "SnowLuma WebUI" else "NapCat WebUI") {
                                    vm.requestWebUrl(if (ui.status.qqEngine == "snowluma") "snowluma" else "napcat", onUrl = uriHandler::openUri)
                                }
                            }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OpenWebButton("AstrBot WebUI") { vm.requestWebUrl("astrbot", onUrl = uriHandler::openUri) }
                                OpenWebButton(if (ui.status.qqEngine == "snowluma") "SnowLuma WebUI" else "NapCat WebUI") {
                                    vm.requestWebUrl(if (ui.status.qqEngine == "snowluma") "snowluma" else "napcat", onUrl = uriHandler::openUri)
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("维护", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    MaintenanceRow("自动恢复", "只重启真正退出的组件，不重新安装。") { vm.runAction("heal") }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
                    MaintenanceRow("修复插件依赖", "扫描并修复 AstrBot 插件依赖。") { vm.runAction("plugin-deps") }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
                    MaintenanceRow("安装与使用教程", "查看安装、恢复与常见问题。", onOpenHelp)
                }
            }
        }
    }
}

@Composable
private fun OpenWebButton(text: String, onClick: () -> Unit) {
    OutlinedButton(onClick, shape = RoundedCornerShape(16.dp)) { Text(text) }
}

@Composable
private fun MaintenanceRow(title: String, detail: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ScreenHeader(
    eyebrow: String,
    title: String,
    subtitle: String,
    refreshing: Boolean,
    onRefresh: () -> Unit
) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(eyebrow, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        PressableCircleButton(refreshing = refreshing, onClick = onRefresh)
    }
}

@Composable
private fun PressableCircleButton(refreshing: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .9f else 1f, spring(dampingRatio = .72f, stiffness = 600f), label = "refresh-scale")
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.size(46.dp).graphicsLayer { scaleX = scale; scaleY = scale }.clip(CircleShape).clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (refreshing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            else Text("↻", fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun ControlBottomBar(destination: ControlDestination, onDestination: (ControlDestination) -> Unit, modifier: Modifier) {
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .96f)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            ControlDestination.entries.forEach { item ->
                NavigationItem(item, selected = item == destination, onClick = { onDestination(item) }, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ControlRail(destination: ControlDestination, onDestination: (ControlDestination) -> Unit, modifier: Modifier) {
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .92f)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(52.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("A", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
            Spacer(Modifier.height(24.dp))
            ControlDestination.entries.forEach { item ->
                NavigationRailItem(item, item == destination, { onDestination(item) })
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun NavigationItem(item: ControlDestination, selected: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, tween(ControlStandard), label = "bottom-nav-bg")
    val scale by animateFloatAsState(if (selected) 1f else .94f, spring(dampingRatio = .86f, stiffness = 380f), label = "bottom-nav-scale")
    Box(
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick).padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(item.shortLabel, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun NavigationRailItem(item: ControlDestination, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, tween(ControlStandard), label = "rail-bg")
    val y by animateFloatAsState(if (selected) 0f else 1f, spring(dampingRatio = .86f, stiffness = 420f), label = "rail-y")
    Column(
        Modifier.fillMaxWidth().graphicsLayer { translationY = y }.clip(RoundedCornerShape(20.dp)).background(bg).clickable(onClick = onClick).padding(vertical = 13.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(navGlyph(item), fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Text(item.shortLabel, style = MaterialTheme.typography.labelSmall, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun StatePill(text: String, good: Boolean) {
    Surface(shape = CircleShape, color = if (good) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest) {
        Text(text, modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium, color = if (good) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AlertStrip(text: String, critical: Boolean) {
    Surface(
        color = if (critical) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 13.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = if (critical) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 460.dp))
    }
}

private fun greetingTitle(status: RuntimeStatus): String = when (status.health) {
    RuntimeHealth.HEALTHY -> "运行正常"
    RuntimeHealth.WORKING -> "正在准备服务"
    RuntimeHealth.ATTENTION -> if (status.qqNeedsLogin) "等待 QQ 登录" else "有一项需要处理"
    RuntimeHealth.STOPPED -> "服务已停止"
    RuntimeHealth.UNKNOWN -> "正在读取状态"
}

private fun greetingSubtitle(status: RuntimeStatus): String = when {
    status.health == RuntimeHealth.HEALTHY -> "AstrBot、QQ 与 OneBot 已建立完整运行链路。"
    status.qqNeedsLogin -> "核心服务已经准备好，完成 QQ 登录后会自动建立 OneBot 连接。"
    status.oneBotAuthFailed -> "OneBot 鉴权状态异常，可以在“服务”页尝试修复。"
    status.health == RuntimeHealth.STOPPED -> "运行环境已安装，可以随时启动。"
    status.health == RuntimeHealth.WORKING -> "服务正在启动或刷新状态，界面会自动更新。"
    else -> "正在从核心组件读取实时状态。"
}

private fun heroLabel(status: RuntimeStatus): String = when (status.health) {
    RuntimeHealth.HEALTHY -> "正常"
    RuntimeHealth.WORKING -> "处理中"
    RuntimeHealth.ATTENTION -> "需处理"
    RuntimeHealth.STOPPED -> "待启动"
    RuntimeHealth.UNKNOWN -> "检查中"
}

private fun heroTitle(status: RuntimeStatus): String = when {
    status.health == RuntimeHealth.HEALTHY -> "所有关键服务已连接"
    status.qqNeedsLogin -> "QQ 需要登录"
    status.oneBotAuthFailed -> "OneBot 鉴权异常"
    status.qqStalledCount > 0 -> "QQ 运行状态异常"
    status.stackStarting || status.actionRunning -> "服务正在变化"
    status.stackRunning -> "服务已启动，等待连接"
    status.coreReady -> "运行环境已就绪"
    else -> "正在检查运行环境"
}

private fun heroDetail(status: RuntimeStatus): String = when {
    status.qqAlertReason.isNotBlank() -> status.qqAlertReason
    status.oneBotReason.isNotBlank() && status.oneBotConnected == 0 -> status.oneBotReason
    status.health == RuntimeHealth.HEALTHY -> "${qqTitle(status)} 在线 · OneBot ${status.oneBotConnected} 个连接"
    status.coreReady -> "核心组件 ${status.moduleVersion.ifBlank { "已安装" }}，可以直接启动服务。"
    else -> "Ubuntu、AstrBot、QQ 与 OneBot 的状态会在这里汇总。"
}

private fun qqTitle(status: RuntimeStatus): String = if (status.qqEngine == "snowluma") "SnowLuma / QQ" else "NapCat / QQ"

private fun qqStateLabel(status: RuntimeStatus): String = when {
    status.qqOnline -> "在线"
    status.qqNeedsLogin -> "需要登录"
    status.qqStartingCount > 0 -> "正在启动"
    status.qqStalledCount > 0 -> "状态异常"
    status.mainQqState == "stopped" -> "已停止"
    else -> status.mainQqState.replace('_', ' ').ifBlank { "未知" }
}

private fun stateOnOff(enabled: Boolean, running: Boolean): String = when {
    running -> "运行中"
    enabled -> "已启用"
    else -> "关闭"
}

private fun navGlyph(destination: ControlDestination): String = when (destination) {
    ControlDestination.OVERVIEW -> "◎"
    ControlDestination.SERVICES -> "⌘"
    ControlDestination.LOGS -> "≋"
    ControlDestination.MORE -> "•••"
}
