package com.xianaurora.astrbotcontrol.engine

import com.xianaurora.astrbotcontrol.model.LogSource
import com.xianaurora.astrbotcontrol.model.RuntimeStatus

class ControlCenterRepository(
    private val shell: RootShell = RootShell()
) {
    companion object {
        private const val ASTRCTL = EngineRepository.ASTRCTL
    }

    suspend fun available(): Boolean = shell.root("test -x ${RootShell.q(ASTRCTL)}", 8).ok

    suspend fun keepConsoleActive(): ShellResult = shell.root(
        "${RootShell.q(ASTRCTL)} console-ping",
        10
    )

    suspend fun status(forceLive: Boolean = false): Result<RuntimeStatus> {
        val cmd = if (forceLive) "web-status-live" else "web-status"
        val result = shell.root("${RootShell.q(ASTRCTL)} $cmd", if (forceLive) 20 else 12)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "无法读取控制中心状态" } }))
        }
        return Result.success(ControlStatusParser.parse(result.stdout))
    }

    suspend fun queue(action: String): ShellResult {
        val safeAction = when (action) {
            "start", "stop", "restart", "heal", "repair", "plugin-deps", "bridge-repair" -> action
            else -> return ShellResult(2, "", "不支持的操作：$action")
        }
        return shell.root("${RootShell.q(ASTRCTL)} queue $safeAction app", 15)
    }

    suspend fun logSources(): Result<List<LogSource>> {
        val result = shell.root("${RootShell.q(ASTRCTL)} logs-list", 15)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "无法读取日志列表" } }))
        }
        val items = result.stdout.lineSequence().mapNotNull { line ->
            if (!line.startsWith("LOG|")) return@mapNotNull null
            val p = line.split('|', limit = 3)
            if (p.size < 3 || p[1].isBlank()) null else LogSource(p[1], p[2].ifBlank { p[1] })
        }.toList()
        return Result.success(items)
    }

    suspend fun log(key: String, lines: Int = 260): Result<String> {
        val safeKey = key.takeIf { it.matches(Regex("[A-Za-z0-9._-]+")) } ?: "health"
        val safeLines = lines.coerceIn(20, 1200)
        val result = shell.root("${RootShell.q(ASTRCTL)} log ${RootShell.q(safeKey)} $safeLines", 18)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "日志读取失败" } }))
        }
        return Result.success(result.stdout)
    }


    suspend fun qqLoginUrl(engine: String): Result<String> {
        if (engine != "snowluma") return webUrl("napcat", "login")
        val result = shell.root("${RootShell.q(ASTRCTL)} snowluma-login-request main", 15)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout }))
        val line = result.stdout.lineSequence().firstOrNull { it.startsWith("LOGIN|") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回扫码地址"))
        val parts = line.split('|', limit = 4)
        val url = parts.getOrNull(2).orEmpty()
        if (url.startsWith("http://") || url.startsWith("https://")) return Result.success(url)
        return Result.failure(IllegalStateException(parts.getOrNull(3).orEmpty().ifBlank { "扫码桌面还没有准备好，请稍后重试" }))
    }
    suspend fun webUrl(kind: String, mode: String = "admin"): Result<String> {
        val safeKind = when (kind) {
            "astrbot", "napcat", "snowluma" -> kind
            else -> return Result.failure(IllegalArgumentException("未知控制台：$kind"))
        }
        val safeMode = when (mode) {
            "admin", "login", "qr" -> mode
            else -> "admin"
        }
        val result = shell.root("${RootShell.q(ASTRCTL)} web-url $safeKind $safeMode", 10)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout }))
        val url = result.stdout.lineSequence().map { it.trim() }.firstOrNull { it.startsWith("http://") || it.startsWith("https://") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回可打开的地址"))
        return Result.success(url)
    }


}
