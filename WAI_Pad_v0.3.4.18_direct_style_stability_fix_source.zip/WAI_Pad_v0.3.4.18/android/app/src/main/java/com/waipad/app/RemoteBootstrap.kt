package com.waipad.app

import android.content.Context
import com.jcraft.jsch.Session
import java.security.MessageDigest
import java.util.Base64
import java.util.UUID
import java.util.concurrent.locks.ReentrantLock

object RemoteBootstrap {
    private val files = listOf("engine_v34.py", "job_api.py", "maintenance.py", "guard.sh", "bootstrap.sh")
    private val installLock = ReentrantLock(true)

    private fun sha256(data: ByteArray): String = MessageDigest.getInstance("SHA-256")
        .digest(data).joinToString("") { "%02x".format(it) }

    /**
     * Install/update the companion atomically and KICK bootstrap in the background.
     *
     * Important: this function must never synchronously wait for Panel/Comfy recovery.  The
     * TunnelService connection loop owns SSH health; guard.sh owns slow core recovery.
     */
    fun installAndStart(context: Context, session: Session): String {
        installLock.lockInterruptibly()
        try {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("初始化已取消")
            val localData = files.associateWith { name -> context.assets.open("wai/server/$name").use { it.readBytes() } }
            val digestInput = java.io.ByteArrayOutputStream().use { out ->
                files.forEach { out.write(localData.getValue(it)) }
                out.toByteArray()
            }
            val releaseHash = sha256(digestInput).take(16)

            // v0.3.4.18 migration preflight: the legacy service.lock is OBSERVATIONAL ONLY.
            // Old guards may legitimately hold it for minutes inside `wai repair`; that must never
            // prevent restoring the 6027 control plane or installing the split-lock release.
            val preflight = """
                set -u
                BASE=/root/WAI_Pad
                RUNTIME="${'$'}BASE/runtime"
                COMP_LOCK="${'$'}RUNTIME/companion.lock"
                LEGACY_LOCK="${'$'}RUNTIME/service.lock"
                mkdir -p "${'$'}RUNTIME"
                health(){ curl -fsS --max-time 2 http://127.0.0.1:6027/v1/health >/dev/null 2>&1; }

                # Restore the already-installed companion first, independently of any old core-repair
                # lock. Restarting job_api does not restart/interrupt ComfyUI; durable job state will
                # reattach to a prompt if one exists.
                exec 8>"${'$'}COMP_LOCK"
                if flock -w 4 8; then
                  if ! health; then
                    PY=/root/venv/bin/python; [ -x "${'$'}PY" ] || PY="${'$'}(command -v python3 || command -v python)"
                    if [ -f "${'$'}BASE/job_api.py" ] && "${'$'}PY" -m py_compile "${'$'}BASE/job_api.py" "${'$'}BASE/engine_v34.py" "${'$'}BASE/maintenance.py" >/dev/null 2>&1; then
                      pkill -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' 2>/dev/null || true
                      nohup "${'$'}PY" "${'$'}BASE/job_api.py" 8>&- 9>&- >>"${'$'}RUNTIME/job_api.nohup.log" 2>&1 </dev/null &
                      for _ in ${'$'}(seq 1 10); do health && { echo 'WAI_PAD_CONTROL_PLANE_KICKED=1 [WAI Pad] companion 已独立恢复。'; break; }; sleep 1; done
                    fi
                  fi
                  flock -u 8 2>/dev/null || true
                fi
                exec 8>&- 2>/dev/null || true

                # Report legacy activity for diagnostics, but DO NOT return busy. New update/core/
                # companion locks are independent and this is exactly how v0.3.4.14 deadlocks migrate.
                if ! flock -n "${'$'}LEGACY_LOCK" -c true 2>/dev/null; then
                  echo 'WAI_PAD_LEGACY_CORE_BUSY=1 [WAI Pad] 检测到旧版核心修复仍占 service.lock；已忽略该旧锁，companion/更新继续。'
                fi
                exit 0
            """.trimIndent()
            val probe = SshClient.exec(session, preflight, 28_000)
            if (probe.first != 0) {
                throw IllegalStateException("迁移预检失败(${probe.first})：${probe.second.takeLast(1200)}")
            }

            val token = UUID.randomUUID().toString().replace("-", "").take(12)
            val stage = "/root/WAI_Pad/runtime/staging/${releaseHash}_$token"
            val mk = SshClient.exec(session, "mkdir -p '$stage' /root/WAI_Pad/runtime/staging", 20_000)
            if (mk.first != 0) throw IllegalStateException("无法创建远端更新暂存目录：${mk.second.takeLast(800)}")

            try {
                for (name in files) SshClient.putBytesAtomic(session, "$stage/$name", localData.getValue(name))

                // File replacement only.  Do NOT run bootstrap.sh while this shell still owns fd 9.
                // v0.3.4.11 still waited synchronously here; a slow remote maintenance operation could
                // keep the Android connection loop stuck in phase=bootstrap for minutes.
                val d = '$'
                val script = """
                    set -Eeuo pipefail
                    BASE=/root/WAI_Pad
                    STAGE='$stage'
                    FILES='${files.joinToString(" ")}'
                    mkdir -p "${d}BASE/runtime"
                    exec 9>"${d}BASE/runtime/update.lock"
                    flock -w 12 9 || { echo 'WAI_PAD_UPDATE_BUSY=1 [WAI Pad] companion 更新锁繁忙；稍后自动重试。'; exit 0; }
                    cleanup_stage(){ rm -rf "${d}STAGE" 2>/dev/null || true; }
                    trap cleanup_stage EXIT

                    active_job=0
                    if curl -fsS --max-time 2 http://127.0.0.1:6027/v1/health >/dev/null 2>&1; then
                      if curl -fsS --max-time 3 'http://127.0.0.1:6027/v1/jobs?limit=120' 2>/dev/null | grep -Eq '"status"[[:space:]]*:[[:space:]]*"(claimed|submitting|running|repairing)"'; then active_job=1; fi
                    fi
                    changed=0
                    for f in ${d}FILES; do cmp -s "${d}STAGE/${d}f" "${d}BASE/${d}f" || changed=1; done
                    if [ "${d}changed" -eq 1 ] && [ "${d}active_job" -eq 1 ]; then
                      echo 'WAI_PAD_UPDATE_DEFERRED_ACTIVE_JOB=1 [WAI Pad] 检测到正在生成任务；companion 更新整套延后，绝不热替换运行中代码。'
                      exit 0
                    fi

                    PY=/root/venv/bin/python; [ -x "${d}PY" ] || PY="${d}(command -v python3 || command -v python)"
                    "${d}PY" -m py_compile "${d}STAGE/job_api.py" "${d}STAGE/engine_v34.py" "${d}STAGE/maintenance.py"
                    bash -n "${d}STAGE/bootstrap.sh" "${d}STAGE/guard.sh"

                    if [ "${d}changed" -eq 1 ]; then
                      BACKUP="${d}BASE/runtime/install_backup_${d}${d}"
                      mkdir -p "${d}BACKUP"
                      for f in ${d}FILES; do [ -f "${d}BASE/${d}f" ] && cp -p "${d}BASE/${d}f" "${d}BACKUP/${d}f" || true; done
                      rollback(){
                        echo '[WAI Pad] 更新事务失败，正在恢复上一套 companion 文件。' >&2
                        for f in ${d}FILES; do
                          if [ -f "${d}BACKUP/${d}f" ]; then cp -p "${d}BACKUP/${d}f" "${d}BASE/.${d}f.rollback.${d}${d}" && mv -f "${d}BASE/.${d}f.rollback.${d}${d}" "${d}BASE/${d}f"; fi
                        done
                      }
                      trap 'rc=${d}?; rollback; exit ${d}rc' ERR
                      for f in ${d}FILES; do
                        cp "${d}STAGE/${d}f" "${d}BASE/.${d}f.new.${d}${d}"
                        case "${d}f" in *.sh) chmod 700 "${d}BASE/.${d}f.new.${d}${d}";; *) chmod 600 "${d}BASE/.${d}f.new.${d}${d}";; esac
                        mv -f "${d}BASE/.${d}f.new.${d}${d}" "${d}BASE/${d}f"
                      done
                      trap - ERR
                      rm -rf "${d}BACKUP"
                      echo '[WAI Pad] companion 整套文件已事务更新。'
                    else
                      echo '[WAI Pad] companion 已是最新版。'
                    fi
                """.trimIndent()
                val encoded = Base64.getEncoder().encodeToString(script.toByteArray(Charsets.UTF_8))
                val r = SshClient.exec(session, "printf '%s' '$encoded' | base64 -d | timeout -k 5s 40s bash", 50_000)
                if (r.first != 0) throw IllegalStateException("自动更新失败(${r.first})：${r.second.takeLast(2200)}")
                if (r.second.contains("WAI_PAD_UPDATE_BUSY=1") || r.second.contains("WAI_PAD_UPDATE_DEFERRED_ACTIVE_JOB=1")) return (probe.second + "\n" + r.second).trim()

                // Start bootstrap as a detached job AFTER the update lock has been released.  The SSH
                // call only waits for the tiny launcher command, never for Panel/Comfy recovery.
                val kick = """
                    BASE=/root/WAI_Pad
                    RUNTIME="${'$'}BASE/runtime"
                    mkdir -p "${'$'}RUNTIME"
                    if pgrep -f '^bash /root/WAI_Pad/bootstrap.sh${'$'}' >/dev/null 2>&1; then
                      echo '[WAI Pad] 快速初始化已经在后台运行。'
                    else
                      nohup bash "${'$'}BASE/bootstrap.sh" >>"${'$'}RUNTIME/bootstrap.nohup.log" 2>&1 </dev/null &
                      echo ${'$'}! > "${'$'}RUNTIME/bootstrap.pid"
                      echo '[WAI Pad] 快速初始化已转入后台；连接线程不再等待核心服务恢复。'
                    fi
                """.trimIndent()
                val k = SshClient.exec(session, kick, 10_000)
                if (k.first != 0) throw IllegalStateException("无法启动后台初始化(${k.first})：${k.second.takeLast(1000)}")
                return (probe.second + "\n" + r.second + "\n" + k.second).trim()
            } catch (e: Exception) {
                try { SshClient.exec(session, "rm -rf '$stage'", 12_000) } catch (_: Exception) {}
                throw e
            }
        } finally {
            installLock.unlock()
        }
    }
}
