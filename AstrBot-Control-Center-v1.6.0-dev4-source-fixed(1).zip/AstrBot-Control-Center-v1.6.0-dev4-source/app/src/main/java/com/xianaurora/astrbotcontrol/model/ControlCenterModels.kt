package com.xianaurora.astrbotcontrol.model

enum class ControlDestination(val title: String, val shortLabel: String) {
    OVERVIEW("总览", "总览"),
    MAINTENANCE("维护", "维护"),
    LOGS("日志", "日志"),
    CONSOLE("控制台", "控制台")
}

enum class RuntimeHealth {
    HEALTHY,
    WORKING,
    ATTENTION,
    STOPPED,
    UNKNOWN
}

enum class LogCategory(val label: String) {
    OVERVIEW("概览"),
    ASTRBOT("AstrBot"),
    QQ("QQ"),
    SYSTEM("系统")
}

enum class ConsoleTarget(val label: String) {
    ASTRBOT("AstrBot"),
    QQ("QQ")
}

data class RuntimeStatus(
    val moduleVersion: String = "",
    val qqEngine: String = "napcat",
    val astrbotUp: Boolean = false,
    val astrbotWebReady: Boolean = false,
    val astrbotPid: String = "",
    val astrbotPort: Int = 0,
    val napcatUp: Boolean = false,
    val napcatWebReady: Boolean = false,
    val napcatPid: String = "",
    val snowlumaUp: Boolean = false,
    val snowlumaWebReady: Boolean = false,
    val oneBotListen: Boolean = false,
    val oneBotConnected: Int = 0,
    val oneBotAuthFailed: Boolean = false,
    val oneBotReason: String = "",
    val qqOnlineCount: Int = 0,
    val qqLoginRequiredCount: Int = 0,
    val qqStartingCount: Int = 0,
    val qqStalledCount: Int = 0,
    val qqAlertInstance: String = "",
    val qqAlertReason: String = "",
    val mainQqState: String = "unknown",
    val mainQqReason: String = "",
    val rootfsReady: Boolean = false,
    val astrbotReady: Boolean = false,
    val napcatReady: Boolean = false,
    val snowlumaReady: Boolean = false,
    val bridgeReady: Boolean = false,
    val fastBootReady: Boolean = false,
    val installReady: Boolean = false,
    val actionRunning: Boolean = false,
    val stackStarting: Boolean = false,
    val watchdogEnabled: Boolean = false,
    val watchdogRunning: Boolean = false,
    val messageGuardEnabled: Boolean = false,
    val messageGuardRunning: Boolean = false,
    val instanceTotal: Int = 0,
    val instanceEnabled: Int = 0,
    val instanceRunning: Int = 0,
    val lastBootResult: String = "unknown",
    val lastBootSeconds: Int = 0,
    val lastStackResult: String = "unknown",
    val lastStackSeconds: Int = 0,
    val device: String = "",
    val android: String = "",
    val kernel: String = "",
    val apiWarning: Boolean = false,
    val apiWarningReason: String = "",
    val toolWarning: Boolean = false,
    val pluginBlock: Boolean = false,
    val eventLoopWarning: Boolean = false,
    val lastInbound: String = "暂无",
    val lastOutbound: String = "暂无",
    val lastModelOk: String = "暂无",
    val lastEvent: String = "",
    val statusEpoch: Long = 0L
) {
    val qqOnline: Boolean get() = qqOnlineCount > 0 || mainQqState == "online"
    val qqNeedsLogin: Boolean get() = qqLoginRequiredCount > 0 || mainQqState == "login_required"
    val stackRunning: Boolean get() = astrbotUp && when (qqEngine) {
        "snowluma" -> snowlumaUp
        else -> napcatUp
    }
    val coreReady: Boolean get() = rootfsReady && astrbotReady && bridgeReady && (napcatReady || snowlumaReady)
    val health: RuntimeHealth get() = when {
        actionRunning || stackStarting || qqStartingCount > 0 -> RuntimeHealth.WORKING
        oneBotAuthFailed || qqStalledCount > 0 || apiWarning || toolWarning || pluginBlock || eventLoopWarning -> RuntimeHealth.ATTENTION
        stackRunning && oneBotConnected > 0 -> RuntimeHealth.HEALTHY
        stackRunning && qqNeedsLogin -> RuntimeHealth.ATTENTION
        stackRunning -> RuntimeHealth.WORKING
        coreReady -> RuntimeHealth.STOPPED
        else -> RuntimeHealth.UNKNOWN
    }
}

data class LogSource(
    val id: String,
    val label: String,
    val category: LogCategory = LogCategory.SYSTEM
)

data class DiagnosticExportState(
    val state: String = "idle",
    val phase: String = "idle",
    val percent: Int = 0,
    val detail: String = "",
    val path: String = "",
    val mode: String = "redacted",
    val running: Boolean = false
) {
    val finished: Boolean get() = state in setOf("done", "success", "completed") && !running
}

data class ConsoleState(
    val target: ConsoleTarget = ConsoleTarget.ASTRBOT,
    val url: String = "",
    val title: String = "AstrBot 控制台",
    val loading: Boolean = false,
    val error: String = "",
    val requestId: Long = 0L
)

data class ControlCenterUiState(
    val loading: Boolean = true,
    val refreshing: Boolean = false,
    val destination: ControlDestination = ControlDestination.OVERVIEW,
    val status: RuntimeStatus = RuntimeStatus(),
    val logSources: List<LogSource> = emptyList(),
    val logCategory: LogCategory = LogCategory.OVERVIEW,
    val selectedLogId: String = "health",
    val logText: String = "",
    val redactedLogText: String = "",
    val logLoading: Boolean = false,
    val redactLogs: Boolean = true,
    val actionBusy: Boolean = false,
    val actionLabel: String = "",
    val exportState: DiagnosticExportState = DiagnosticExportState(),
    val console: ConsoleState = ConsoleState(),
    val transientMessage: String = "",
    val errorMessage: String = "",
    val lastRefreshEpoch: Long = 0L
)
