package com.xianaurora.astrbotcontrol.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.xianaurora.astrbotcontrol.engine.ControlCenterViewModel
import com.xianaurora.astrbotcontrol.model.ConsoleTarget
import com.xianaurora.astrbotcontrol.model.ControlCenterUiState
import com.xianaurora.astrbotcontrol.model.ControlDestination
import com.xianaurora.astrbotcontrol.model.LogCategory
import com.xianaurora.astrbotcontrol.model.LogSource
import com.xianaurora.astrbotcontrol.model.RuntimeHealth
import com.xianaurora.astrbotcontrol.model.RuntimeStatus
import kotlinx.coroutines.delay

private const val FadeFast = 130

private data class UiLogLine(val text: String, val occurrence: Int)

private fun destinationRank(destination: ControlDestination) = when (destination) {
    ControlDestination.OVERVIEW -> 0
    ControlDestination.MAINTENANCE -> 1
    ControlDestination.LOGS -> 2
    ControlDestination.CONSOLE -> 3
}

@Composable
fun ControlCenterApp(
    vm: ControlCenterViewModel,
    onOpenHelp: () -> Unit
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner, vm) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> vm.start()
                Lifecycle.Event.ON_STOP -> vm.stop()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) vm.start()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            vm.stop()
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 760.dp
        if (wide) {
            Row(Modifier.fillMaxSize()) {
                ControlRail(
                    destination = ui.destination,
                    attention = ui.status.health == RuntimeHealth.ATTENTION,
                    onDestination = vm::setDestination,
                    modifier = Modifier.width(108.dp).fillMaxHeight()
                )
                ControlContent(ui, vm, onOpenHelp, Modifier.weight(1f).fillMaxHeight(), true)
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                ControlContent(ui, vm, onOpenHelp, Modifier.weight(1f).fillMaxWidth(), false)
                ControlBottomBar(
                    destination = ui.destination,
                    attention = ui.status.health == RuntimeHealth.ATTENTION,
                    onDestination = vm::setDestination,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ControlContent(
    ui: ControlCenterUiState,
    vm: ControlCenterViewModel,
    onOpenHelp: () -> Unit,
    modifier: Modifier,
    wide: Boolean
) {
    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        AnimatedContent(
            targetState = ui.loading,
            transitionSpec = {
                (fadeIn(spring(dampingRatio = .92f, stiffness = 520f)) + scaleIn(initialScale = .99f, animationSpec = spring(dampingRatio = .9f, stiffness = 430f))) togetherWith
                    (fadeOut(tween(FadeFast)) + scaleOut(targetScale = .995f, animationSpec = spring(dampingRatio = .92f, stiffness = 520f)))
            },
            label = "control-load"
        ) { loading ->
            if (loading) {
                ControlCenterLoading()
            } else {
                AnimatedContent(
                    targetState = ui.destination,
                    transitionSpec = {
                        val forward = destinationRank(targetState) >= destinationRank(initialState)
                        val enter = if (forward) 34 else -34
                        val exit = if (forward) -18 else 18
                        (
                            fadeIn(spring(dampingRatio = .94f, stiffness = 520f)) +
                                slideInHorizontally(
                                    animationSpec = spring(dampingRatio = .86f, stiffness = 430f),
                                    initialOffsetX = { enter }
                                )
                            ) togetherWith (
                            fadeOut(tween(FadeFast)) +
                                slideOutHorizontally(
                                    animationSpec = spring(dampingRatio = .92f, stiffness = 500f),
                                    targetOffsetX = { exit }
                                )
                            )
                    },
                    label = "control-destination"
                ) { destination ->
                    when (destination) {
                        ControlDestination.OVERVIEW -> OverviewScreen(ui, vm, wide)
                        ControlDestination.MAINTENANCE -> MaintenanceScreen(ui, vm, onOpenHelp, wide)
                        ControlDestination.LOGS -> LogsScreen(ui, vm, wide)
                        ControlDestination.CONSOLE -> ConsoleScreen(ui, vm, wide)
                    }
                }
            }
        }

        ControlMessageOverlay(
            error = ui.errorMessage,
            message = ui.transientMessage,
            onDismiss = vm::clearMessages,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun ControlCenterLoading() {
    val infinite = rememberInfiniteTransition(label = "control-loading")
    val pulse by infinite.animateFloat(
        initialValue = .9f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(820), repeatMode = RepeatMode.Reverse),
        label = "control-loading-pulse"
    )
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(
                shape = RoundedCornerShape(25.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(72.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("A", fontSize = 29.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Text("正在连接核心组件", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("读取运行状态与账号连接", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OverviewScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val padding = if (wide) 30.dp else 18.dp
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = padding, end = padding, top = 22.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)
    ) {
        item {
            ScreenHeader(
                eyebrow = "控制中心",
                title = greetingTitle(ui.status),
                subtitle = greetingSubtitle(ui.status),
                refreshing = ui.refreshing,
                onRefresh = vm::refresh
            )
        }
        item { OverviewHero(ui, vm) }
        item {
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KeyStatusCard(Modifier.weight(1f), "A", "AstrBot", astrbotState(ui.status), ui.status.astrbotUp && ui.status.astrbotWebReady, ui.status.astrbotUp && !ui.status.astrbotWebReady, astrbotDetail(ui.status))
                    KeyStatusCard(Modifier.weight(1f), "QQ", "QQ", qqStateLabel(ui.status), ui.status.qqOnline, ui.status.qqStartingCount > 0, qqEngineLabel(ui.status))
                    KeyStatusCard(Modifier.weight(1f), "1B", "OneBot", oneBotState(ui.status), ui.status.oneBotConnected > 0, ui.status.stackStarting, oneBotDetail(ui.status))
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    KeyStatusCard(Modifier.fillMaxWidth(), "A", "AstrBot", astrbotState(ui.status), ui.status.astrbotUp && ui.status.astrbotWebReady, ui.status.astrbotUp && !ui.status.astrbotWebReady, astrbotDetail(ui.status))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        KeyStatusCard(Modifier.weight(1f), "QQ", "QQ", qqStateLabel(ui.status), ui.status.qqOnline, ui.status.qqStartingCount > 0, qqEngineLabel(ui.status))
                        KeyStatusCard(Modifier.weight(1f), "1B", "OneBot", oneBotState(ui.status), ui.status.oneBotConnected > 0, ui.status.stackStarting, oneBotDetail(ui.status))
                    }
                }
            }
        }
        item { ActivityCard(ui.status) }
    }
}

@Composable
private fun OverviewHero(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val status = ui.status
    val health = status.health
    val accent by animateColorAsState(
        targetValue = when (health) {
            RuntimeHealth.HEALTHY -> MaterialTheme.colorScheme.primary
            RuntimeHealth.WORKING -> MaterialTheme.colorScheme.tertiary
            RuntimeHealth.ATTENTION -> MaterialTheme.colorScheme.error
            RuntimeHealth.STOPPED -> MaterialTheme.colorScheme.secondary
            RuntimeHealth.UNKNOWN -> MaterialTheme.colorScheme.outline
        },
        animationSpec = spring(dampingRatio = .9f, stiffness = 420f),
        label = "hero-accent"
    )
    val container by animateColorAsState(
        targetValue = when (health) {
            RuntimeHealth.HEALTHY -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = .64f)
            RuntimeHealth.WORKING -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .64f)
            RuntimeHealth.ATTENTION -> MaterialTheme.colorScheme.errorContainer.copy(alpha = .72f)
            else -> MaterialTheme.colorScheme.surfaceContainerHigh
        },
        animationSpec = spring(dampingRatio = .92f, stiffness = 380f),
        label = "hero-container"
    )
    Surface(Modifier.fillMaxWidth().animateContentSize(), color = container, shape = RoundedCornerShape(34.dp)) {
        BoxWithConstraints(Modifier.padding(22.dp)) {
            val compact = maxWidth < 520.dp
            val needsAction = health in setOf(RuntimeHealth.ATTENTION, RuntimeHealth.STOPPED)
            if (compact) {
                Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    HeroStatusText(status, accent)
                    if (needsAction) OverviewContextAction(status, ui.actionBusy, vm, Modifier.fillMaxWidth())
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Box(Modifier.weight(1f)) { HeroStatusText(status, accent) }
                    if (needsAction) OverviewContextAction(status, ui.actionBusy, vm, Modifier.widthIn(min = 190.dp, max = 240.dp))
                }
            }
        }
    }
}

@Composable
private fun HeroStatusText(status: RuntimeStatus, accent: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            MotionStatusDot(status.health, accent)
            Text(heroLabel(status), style = MaterialTheme.typography.labelLarge, color = accent, fontWeight = FontWeight.SemiBold)
        }
        AnimatedContent(
            targetState = heroTitle(status),
            transitionSpec = { (fadeIn(spring(stiffness = 480f)) + slideInVertically(animationSpec = spring(dampingRatio = .88f, stiffness = 440f)) { it / 7 }) togetherWith fadeOut(tween(FadeFast)) },
            label = "hero-title"
        ) { title -> Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold) }
        Text(heroDetail(status), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun OverviewContextAction(status: RuntimeStatus, busy: Boolean, vm: ControlCenterViewModel, modifier: Modifier) {
    when {
        status.qqNeedsLogin -> MotionButton("QQ 扫码登录", enabled = !busy, primary = true, modifier = modifier, onClick = vm::openQqLogin)
        status.health == RuntimeHealth.STOPPED -> MotionButton("启动全部服务", enabled = !busy, primary = true, modifier = modifier) { vm.runAction("start") }
        else -> MotionButton("前往维护", enabled = true, primary = true, modifier = modifier) { vm.setDestination(ControlDestination.MAINTENANCE) }
    }
}

@Composable
private fun MotionStatusDot(health: RuntimeHealth, accent: Color) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(22.dp)) {
        if (health == RuntimeHealth.WORKING) {
            val infinite = rememberInfiniteTransition(label = "status-pulse")
            val pulse by infinite.animateFloat(
                initialValue = .7f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(820), repeatMode = RepeatMode.Reverse),
                label = "status-pulse-value"
            )
            Box(Modifier.size(20.dp).graphicsLayer { scaleX = pulse; scaleY = pulse; alpha = 1f - pulse * .45f }.background(accent.copy(alpha = .22f), CircleShape))
        }
        Box(Modifier.size(9.dp).background(accent, CircleShape))
    }
}

@Composable
private fun KeyStatusCard(modifier: Modifier, glyph: String, title: String, state: String, good: Boolean, working: Boolean, detail: String) {
    val surface by animateColorAsState(
        targetValue = if (good) MaterialTheme.colorScheme.surfaceContainer else if (working) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .35f) else MaterialTheme.colorScheme.surfaceContainer,
        animationSpec = spring(dampingRatio = .92f, stiffness = 430f),
        label = "status-card"
    )
    Surface(modifier = modifier.heightIn(min = 130.dp), color = surface, shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceContainerHighest, modifier = Modifier.size(39.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text(glyph, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                }
                Spacer(Modifier.weight(1f))
                StatePill(state, good)
            }
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ActivityCard(status: RuntimeStatus) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("最近状态", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            ActivityLine("收到消息", status.lastInbound)
            ActivityLine("发出消息", status.lastOutbound)
            ActivityLine("模型响应", status.lastModelOk)
            if (status.lastEvent.isNotBlank()) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
                Text(status.lastEvent, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun ActivityLine(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        Text(value.ifBlank { "暂无" }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun MaintenanceScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, onOpenHelp: () -> Unit, wide: Boolean) {
    val padding = if (wide) 30.dp else 18.dp
    var switchTarget by remember { mutableStateOf<String?>(null) }
    var confirmReboot by remember { mutableStateOf(false) }

    switchTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { switchTarget = null },
            title = { Text("切换 QQ 运行方式") },
            text = { Text("将停止当前 QQ 运行方式，再启动 ${if (target == "snowluma") "SnowLuma" else "NapCat"}。AstrBot 本身不会重启，切换完成后会自动检查 OneBot。") },
            confirmButton = {
                TextButton(onClick = {
                    switchTarget = null
                    vm.runAction(if (target == "snowluma") "engine-snowluma" else "engine-napcat")
                }) { Text("确认切换") }
            },
            dismissButton = { TextButton(onClick = { switchTarget = null }) { Text("取消") } }
        )
    }
    if (confirmReboot) {
        AlertDialog(
            onDismissRequest = { confirmReboot = false },
            title = { Text("重启设备？") },
            text = { Text("这是整台 Android 设备重启，不是重启 AstrBot 服务。正在进行的任务会被中断。") },
            confirmButton = { TextButton(onClick = { confirmReboot = false; vm.rebootDevice() }) { Text("重启设备") } },
            dismissButton = { TextButton(onClick = { confirmReboot = false }) { Text("取消") } }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = padding, end = padding, top = 22.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { ScreenHeader("运维中心", "维护", "常用操作集中在这里；低频功能放到更下方。", ui.refreshing, vm::refresh) }
        item { MaintenancePrimary(ui, vm) }
        item { QqModeCard(ui, onSwitch = { switchTarget = it }) }
        if (wide) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    RepairCard(ui, vm, Modifier.weight(1f))
                    DiagnosticCard(ui, vm, Modifier.weight(1f))
                }
            }
        } else {
            item { RepairCard(ui, vm, Modifier.fillMaxWidth()) }
            item { DiagnosticCard(ui, vm, Modifier.fillMaxWidth()) }
        }
        item {
            Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("设备与帮助", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    MaintenanceRow("安装与使用教程", "安装、恢复与常见问题。", onClick = onOpenHelp)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
                    MaintenanceRow("重启设备", "重启整台 Android 设备。", critical = true) { confirmReboot = true }
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerLow, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("环境信息", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    InfoRow("核心组件", ui.status.moduleVersion.ifBlank { "未知" })
                    InfoRow("设备", ui.status.device.ifBlank { "未知" })
                    InfoRow("Android", ui.status.android.ifBlank { "未知" })
                    InfoRow("内核", ui.status.kernel.ifBlank { "未知" })
                }
            }
        }
    }
}

@Composable
private fun MaintenancePrimary(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val busy = ui.actionBusy || ui.status.actionRunning || ui.status.stackStarting
    Surface(shape = RoundedCornerShape(32.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .58f), modifier = Modifier.fillMaxWidth().animateContentSize()) {
        BoxWithConstraints(Modifier.padding(20.dp)) {
            val compact = maxWidth < 560.dp
            val primaryText = if (ui.status.stackRunning) "重启全部服务" else "启动全部服务"
            val primaryAction = if (ui.status.stackRunning) "restart" else "start"
            if (compact) {
                Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    MaintenancePrimaryText(ui)
                    MotionButton(primaryText, !busy, true, Modifier.fillMaxWidth()) { vm.runAction(primaryAction) }
                    MotionButton("QQ 扫码登录", !busy, false, Modifier.fillMaxWidth(), vm::openQqLogin)
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.weight(1f)) { MaintenancePrimaryText(ui) }
                    Column(Modifier.widthIn(min = 210.dp, max = 250.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        MotionButton(primaryText, !busy, true, Modifier.fillMaxWidth()) { vm.runAction(primaryAction) }
                        MotionButton("QQ 扫码登录", !busy, false, Modifier.fillMaxWidth(), vm::openQqLogin)
                    }
                }
            }
        }
    }
}

@Composable
private fun MaintenancePrimaryText(ui: ControlCenterUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("常用操作", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        AnimatedContent(ui.actionLabel.ifBlank { maintenanceHeadline(ui.status) }, label = "maintenance-action") { title ->
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        }
        Text(
            if (ui.actionBusy) "正在执行并验证结果，不需要重复点击。" else "服务重启、QQ 登录和运行方式切换都从这里开始。",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        AnimatedVisibility(ui.actionBusy) {
            LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 5.dp))
        }
    }
}

@Composable
private fun QqModeCard(ui: ControlCenterUiState, onSwitch: (String) -> Unit) {
    val current = ui.status.qqEngine
    val busy = ui.actionBusy || ui.status.actionRunning
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("QQ 运行方式", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("切换时保留 AstrBot 进程和账号数据。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(if (current == "snowluma") "SnowLuma" else "NapCat", good = true)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeChoice("NapCat", current == "napcat", enabled = !busy, Modifier.weight(1f)) { onSwitch("napcat") }
                ModeChoice("SnowLuma", current == "snowluma", enabled = !busy && ui.status.snowlumaReady, Modifier.weight(1f)) { onSwitch("snowluma") }
            }
            if (!ui.status.snowlumaReady) Text("SnowLuma 尚未安装时不会允许切换。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ModeChoice(text: String, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
        animationSpec = spring(dampingRatio = .88f, stiffness = 430f),
        label = "mode-bg"
    )
    val scale by animateFloatAsState(if (selected) 1f else .985f, spring(dampingRatio = .82f, stiffness = 480f), label = "mode-scale")
    Surface(
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(RoundedCornerShape(18.dp)).clickable(enabled = enabled && !selected, onClick = onClick),
        color = bg,
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (selected) "●" else "○", color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
        }
    }
}

@Composable
private fun RepairCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    val busy = ui.actionBusy || ui.status.actionRunning
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = modifier) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("诊断与修复", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("只在出现异常时使用。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(5.dp))
            MaintenanceRow("自动恢复", "只重启真正退出的组件。", enabled = !busy) { vm.runAction("heal") }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
            MaintenanceRow("修复 OneBot", "检查鉴权与反向连接。", enabled = !busy) { vm.runAction("bridge-repair") }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
            MaintenanceRow("修复插件依赖", "扫描并修复 AstrBot 插件依赖。", enabled = !busy) { vm.runAction("plugin-deps") }
        }
    }
}

@Composable
private fun DiagnosticCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    var showRawConfirm by remember { mutableStateOf(false) }
    if (showRawConfirm) {
        AlertDialog(
            onDismissRequest = { showRawConfirm = false },
            title = { Text("导出完整日志包？") },
            text = { Text("完整日志包可能包含 QQ 号、Token、网络地址和账号配置。只有在你明确需要完整原始数据时再导出。") },
            confirmButton = { TextButton(onClick = { showRawConfirm = false; vm.startExport("raw") }) { Text("继续导出") } },
            dismissButton = { TextButton(onClick = { showRawConfirm = false }) { Text("取消") } }
        )
    }
    val export = ui.exportState
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = modifier.animateContentSize()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("日志与诊断", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("默认导出脱敏日志包，并附带必要的非敏感诊断信息。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (export.running) {
                LinearProgressIndicator(progress = { export.percent / 100f }, modifier = Modifier.fillMaxWidth())
                Text(export.detail.ifBlank { "正在采集" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = vm::cancelExport) { Text("取消导出") }
            } else {
                MotionButton("导出脱敏日志包", enabled = true, primary = true, modifier = Modifier.fillMaxWidth()) { vm.startExport("redacted") }
                TextButton(onClick = { showRawConfirm = true }) { Text("需要完整原始日志包") }
            }
            if (!export.running && export.path.isNotBlank()) {
                Text(export.path, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun MaintenanceRow(
    title: String,
    detail: String,
    enabled: Boolean = true,
    critical: Boolean = false,
    onClick: () -> Unit
) {
    val rowAlpha = if (enabled) 1f else .45f
    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = rowAlpha }.clip(RoundedCornerShape(16.dp)).clickable(enabled = enabled, onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, color = if (critical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.headlineSmall, color = if (critical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LogsScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val displayText = if (ui.redactLogs) ui.redactedLogText else ui.logText
    val lines = remember(displayText) {
        val seen = HashMap<String, Int>()
        displayText.lineSequence().map { text ->
            val occurrence = seen[text] ?: 0
            seen[text] = occurrence + 1
            UiLogLine(text, occurrence)
        }.toList()
    }
    val listState = rememberLazyListState()
    var followTail by rememberSaveable { mutableStateOf(true) }
    val tailToken = lines.lastOrNull()?.hashCode() ?: 0

    LaunchedEffect(tailToken, followTail) {
        if (followTail && lines.isNotEmpty()) {
            val target = lines.lastIndex
            if (target - listState.firstVisibleItemIndex > 90) listState.scrollToItem(target)
            else listState.animateScrollToItem(target)
        }
    }

    Column(Modifier.fillMaxSize().padding(top = 22.dp)) {
        Box(Modifier.padding(horizontal = if (wide) 30.dp else 18.dp)) {
            ScreenHeader("实时输出", "日志", if (ui.redactLogs) "当前默认脱敏显示；需要原始内容时可以临时切换。" else "当前显示原始日志，请注意其中可能包含敏感信息。", ui.refreshing, vm::refresh)
        }
        Spacer(Modifier.height(13.dp))
        if (wide) {
            Row(Modifier.fillMaxSize().padding(horizontal = 30.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                LogCategoryPane(ui.logCategory, vm::selectLogCategory, Modifier.width(190.dp).fillMaxHeight())
                LogViewer(ui, lines, listState, followTail, { followTail = !followTail }, vm, Modifier.weight(1f).fillMaxHeight())
            }
        } else {
            LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(LogCategory.entries, key = { it.name }) { category ->
                    LogCategoryChip(category.label, selected = category == ui.logCategory) { vm.selectLogCategory(category) }
                }
            }
            Spacer(Modifier.height(9.dp))
            LogViewer(ui, lines, listState, followTail, { followTail = !followTail }, vm, Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 6.dp))
        }
    }
}

@Composable
private fun LogCategoryPane(selected: LogCategory, onSelect: (LogCategory) -> Unit, modifier: Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            LogCategory.entries.forEach { category ->
                LogCategoryRow(category, selected == category) { onSelect(category) }
            }
        }
    }
}

@Composable
private fun LogCategoryRow(category: LogCategory, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, spring(dampingRatio = .9f, stiffness = 430f), label = "log-category-bg")
    Surface(color = bg, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).clickable(onClick = onClick)) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(logCategoryGlyph(category), fontWeight = FontWeight.Bold)
            Text(category.label, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
        }
    }
}

@Composable
private fun LogCategoryChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer, spring(stiffness = 460f), label = "log-category-chip")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable(onClick = onClick)) {
        Text(text, modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp), style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun LogViewer(
    ui: ControlCenterUiState,
    lines: List<UiLogLine>,
    listState: androidx.compose.foundation.lazy.LazyListState,
    followTail: Boolean,
    onToggleFollow: () -> Unit,
    vm: ControlCenterViewModel,
    modifier: Modifier
) {
    var toolsOpen by remember { mutableStateOf(false) }
    val categorySources = remember(ui.logSources, ui.logCategory) { ui.logSources.filter { it.category == ui.logCategory } }
    Surface(modifier = modifier, shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(categorySources.firstOrNull { it.id == ui.selectedLogId }?.label ?: ui.logCategory.label, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (ui.logLoading) CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp)
                    PrivacyToggle(ui.redactLogs) { vm.setLogRedaction(it) }
                    TextButton(onClick = onToggleFollow) { Text(if (followTail) "暂停" else "跟随") }
                    Box {
                        TextButton(onClick = { toolsOpen = true }) { Text("•••") }
                        DropdownMenu(expanded = toolsOpen, onDismissRequest = { toolsOpen = false }) {
                            DropdownMenuItem(text = { Text("导出脱敏日志包") }, onClick = { toolsOpen = false; vm.startExport("redacted") })
                            DropdownMenuItem(text = { Text("前往维护") }, onClick = { toolsOpen = false; vm.setDestination(ControlDestination.MAINTENANCE) })
                        }
                    }
                }
                if (categorySources.size > 1) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(categorySources, key = { it.id }) { source ->
                            LogSourceChip(source, source.id == ui.selectedLogId) { vm.selectLog(source.id) }
                        }
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .52f))
            if (lines.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (ui.logLoading) "正在读取日志…" else "暂无日志", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                SelectionContainer {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(1.dp)
                    ) {
                        items(lines, key = { it }) { item ->
                            val line = item.text
                            Text(
                                line.ifEmpty { " " },
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.5.sp,
                                lineHeight = 17.sp,
                                color = if (line.contains("error", true) || line.contains("失败") || line.contains("fatal", true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PrivacyToggle(redacted: Boolean, onChanged: (Boolean) -> Unit) {
    val bg by animateColorAsState(if (redacted) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer, spring(stiffness = 450f), label = "privacy-bg")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable { onChanged(!redacted) }) {
        Text(
            if (redacted) "已脱敏" else "原始",
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (redacted) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun LogSourceChip(source: LogSource, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.surfaceContainerHighest else Color.Transparent, spring(stiffness = 460f), label = "log-source")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable(onClick = onClick)) {
        Text(source.label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun ConsoleScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val controller = rememberConsoleWebController()
    val padding = if (wide) 24.dp else 12.dp
    Column(Modifier.fillMaxSize().padding(start = padding, end = padding, top = 14.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ConsoleToolbar(ui, vm, controller)
        Surface(Modifier.fillMaxSize(), shape = RoundedCornerShape(if (wide) 28.dp else 22.dp), color = MaterialTheme.colorScheme.surfaceContainer, shadowElevation = 1.dp) {
            Box(Modifier.fillMaxSize()) {
                when {
                    ui.console.error.isNotBlank() -> ConsoleError(ui.console.error, vm::retryConsole, Modifier.align(Alignment.Center))
                    ui.console.url.isBlank() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    else -> EmbeddedConsoleWebView(
                        url = ui.console.url,
                        controller = controller,
                        modifier = Modifier.fillMaxSize(),
                        onLoadingChanged = vm::setConsoleLoading,
                        onError = vm::setConsoleError
                    )
                }
                if (ui.console.loading && ui.console.url.isNotBlank()) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.TopCenter)
                    )
                }
            }
        }
    }
}

@Composable
private fun ConsoleToolbar(ui: ControlCenterUiState, vm: ControlCenterViewModel, controller: ConsoleWebController) {
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            val compact = maxWidth < 580.dp
            if (compact) {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        ConsoleTargetChoice("AstrBot", ui.console.target == ConsoleTarget.ASTRBOT) { vm.openConsole(ConsoleTarget.ASTRBOT) }
                        Spacer(Modifier.width(7.dp))
                        ConsoleTargetChoice("QQ", ui.console.target == ConsoleTarget.QQ) { vm.openConsole(ConsoleTarget.QQ) }
                        Spacer(Modifier.weight(1f))
                        ConsoleNavControls(controller)
                    }
                    Text(ui.console.title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 5.dp))
                }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    ConsoleTargetChoice("AstrBot", ui.console.target == ConsoleTarget.ASTRBOT) { vm.openConsole(ConsoleTarget.ASTRBOT) }
                    ConsoleTargetChoice("QQ", ui.console.target == ConsoleTarget.QQ) { vm.openConsole(ConsoleTarget.QQ) }
                    Text(ui.console.title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 7.dp))
                    Spacer(Modifier.weight(1f))
                    if (ui.console.target == ConsoleTarget.QQ) TextButton(onClick = vm::openQqLogin) { Text("扫码登录") }
                    ConsoleNavControls(controller)
                }
            }
        }
    }
}

@Composable
private fun ConsoleTargetChoice(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, spring(dampingRatio = .88f, stiffness = 430f), label = "console-target")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable(onClick = onClick)) {
        Text(text, modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun ConsoleNavControls(controller: ConsoleWebController) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        CompactTool("‹", controller.canGoBack, controller::back)
        CompactTool("›", controller.canGoForward, controller::forward)
        CompactTool("↻", true, controller::refresh)
    }
}

@Composable
private fun CompactTool(text: String, enabled: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 5.dp)) {
        Text(text, fontSize = 19.sp)
    }
}

@Composable
private fun ConsoleError(message: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.padding(24.dp).widthIn(max = 440.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("控制台暂不可用", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = onRetry, shape = RoundedCornerShape(16.dp)) { Text("重新连接") }
    }
}

@Composable
private fun MotionButton(text: String, enabled: Boolean, primary: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .965f else 1f, spring(dampingRatio = .72f, stiffness = 620f), label = "motion-button")
    if (primary) {
        Button(onClick, enabled = enabled, interactionSource = interaction, modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }, shape = RoundedCornerShape(17.dp)) { Text(text) }
    } else {
        OutlinedButton(onClick, enabled = enabled, interactionSource = interaction, modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }, shape = RoundedCornerShape(17.dp)) { Text(text) }
    }
}

@Composable
private fun ScreenHeader(eyebrow: String, title: String, subtitle: String, refreshing: Boolean, onRefresh: () -> Unit) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(eyebrow, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        PressableCircleButton(refreshing, onRefresh)
    }
}

@Composable
private fun PressableCircleButton(refreshing: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .9f else 1f, spring(dampingRatio = .72f, stiffness = 620f), label = "refresh-scale")
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.size(46.dp).graphicsLayer { scaleX = scale; scaleY = scale }.clip(CircleShape).clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (refreshing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("↻", fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun ControlBottomBar(destination: ControlDestination, attention: Boolean, onDestination: (ControlDestination) -> Unit, modifier: Modifier) {
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .96f)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            ControlDestination.entries.forEach { item ->
                NavigationItem(item, item == destination, attention && item == ControlDestination.MAINTENANCE, { onDestination(item) }, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ControlRail(destination: ControlDestination, attention: Boolean, onDestination: (ControlDestination) -> Unit, modifier: Modifier) {
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .92f)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(52.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("A", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
            Spacer(Modifier.height(24.dp))
            ControlDestination.entries.forEach { item ->
                NavigationRailItem(item, item == destination, attention && item == ControlDestination.MAINTENANCE) { onDestination(item) }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun NavigationItem(item: ControlDestination, selected: Boolean, attention: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, spring(dampingRatio = .86f, stiffness = 430f), label = "nav-bg")
    val scale by animateFloatAsState(if (selected) 1f else .96f, spring(dampingRatio = .78f, stiffness = 500f), label = "nav-scale")
    Box(modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick = onClick).padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(item.shortLabel, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
            if (attention) Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.error, CircleShape))
        }
    }
}

@Composable
private fun NavigationRailItem(item: ControlDestination, selected: Boolean, attention: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent, spring(dampingRatio = .86f, stiffness = 430f), label = "rail-bg")
    val scale by animateFloatAsState(if (selected) 1f else .965f, spring(dampingRatio = .8f, stiffness = 480f), label = "rail-scale")
    Column(
        Modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale }.clip(RoundedCornerShape(20.dp)).background(bg).clickable(onClick = onClick).padding(vertical = 13.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box {
            Text(navGlyph(item), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (attention) Box(Modifier.align(Alignment.TopEnd).size(6.dp).background(MaterialTheme.colorScheme.error, CircleShape))
        }
        Text(item.shortLabel, style = MaterialTheme.typography.labelSmall, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun StatePill(text: String, good: Boolean) {
    Surface(shape = CircleShape, color = if (good) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium, color = if (good) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 460.dp))
    }
}

@Composable
private fun ControlMessageOverlay(error: String, message: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    val text = error.ifBlank { message }
    val critical = error.isNotBlank()
    LaunchedEffect(text) {
        if (text.isNotBlank() && !text.startsWith("状态读取失败") && !text.contains("已保存：")) {
            delay(4600)
            onDismiss()
        }
    }
    AnimatedVisibility(
        visible = text.isNotBlank(),
        modifier = modifier.padding(horizontal = 18.dp, vertical = 16.dp),
        enter = fadeIn(spring(stiffness = 500f)) + slideInVertically(animationSpec = spring(dampingRatio = .8f, stiffness = 470f)) { it / 2 } + scaleIn(initialScale = .97f, animationSpec = spring(dampingRatio = .8f, stiffness = 470f)),
        exit = fadeOut(tween(FadeFast)) + scaleOut(targetScale = .985f)
    ) {
        Surface(shape = RoundedCornerShape(20.dp), color = if (critical) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.inverseSurface, shadowElevation = 5.dp) {
            Row(Modifier.padding(horizontal = 15.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = if (critical) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.inverseOnSurface, maxLines = 3, overflow = TextOverflow.Ellipsis)
                TextButton(onClick = onDismiss) { Text("知道了") }
            }
        }
    }
}

private fun greetingTitle(status: RuntimeStatus): String = when (status.health) {
    RuntimeHealth.HEALTHY -> "运行正常"
    RuntimeHealth.WORKING -> "正在准备服务"
    RuntimeHealth.ATTENTION -> if (status.qqNeedsLogin) "等待 QQ 登录" else "有一项需要处理"
    RuntimeHealth.STOPPED -> "服务已停止"
    RuntimeHealth.UNKNOWN -> "正在读取状态"
}

private fun greetingSubtitle(status: RuntimeStatus): String = when {
    status.health == RuntimeHealth.HEALTHY -> "AstrBot、QQ 与 OneBot 已建立完整运行链路。"
    status.qqNeedsLogin -> "服务已经准备好，完成 QQ 登录后会自动建立 OneBot 连接。"
    status.oneBotAuthFailed -> "OneBot 鉴权异常，维护页可以直接修复。"
    status.health == RuntimeHealth.STOPPED -> "运行环境已安装，可以随时启动。"
    status.health == RuntimeHealth.WORKING -> "服务正在启动或刷新状态，界面会自动更新。"
    else -> "正在从核心组件读取实时状态。"
}

private fun heroLabel(status: RuntimeStatus): String = when (status.health) {
    RuntimeHealth.HEALTHY -> "正常"
    RuntimeHealth.WORKING -> "处理中"
    RuntimeHealth.ATTENTION -> "需处理"
    RuntimeHealth.STOPPED -> "待启动"
    RuntimeHealth.UNKNOWN -> "检查中"
}

private fun heroTitle(status: RuntimeStatus): String = when {
    status.health == RuntimeHealth.HEALTHY -> "所有关键服务已连接"
    status.qqNeedsLogin -> "QQ 需要登录"
    status.oneBotAuthFailed -> "OneBot 鉴权异常"
    status.qqStalledCount > 0 -> "QQ 运行状态异常"
    status.stackStarting || status.actionRunning -> "服务正在变化"
    status.stackRunning -> "服务已启动，等待连接"
    status.coreReady -> "运行环境已就绪"
    else -> "正在检查运行环境"
}

private fun heroDetail(status: RuntimeStatus): String = when {
    status.qqAlertReason.isNotBlank() -> status.qqAlertReason
    status.oneBotReason.isNotBlank() && status.oneBotConnected == 0 -> status.oneBotReason
    status.health == RuntimeHealth.HEALTHY -> "${qqEngineLabel(status)} 在线 · OneBot ${status.oneBotConnected} 个连接"
    status.coreReady -> "核心组件 ${status.moduleVersion.ifBlank { "已安装" }}，运行状态会自动更新。"
    else -> "Ubuntu、AstrBot、QQ 与 OneBot 的状态会在这里汇总。"
}

private fun maintenanceHeadline(status: RuntimeStatus): String = when {
    status.qqNeedsLogin -> "QQ 等待登录"
    status.oneBotAuthFailed -> "OneBot 需要修复"
    status.stackRunning -> "服务正在运行"
    status.coreReady -> "运行环境已就绪"
    else -> "检查运行环境"
}

private fun astrbotState(status: RuntimeStatus): String = when {
    status.astrbotUp && status.astrbotWebReady -> "正常"
    status.astrbotUp -> "启动中"
    status.astrbotReady -> "已停止"
    else -> "未就绪"
}

private fun astrbotDetail(status: RuntimeStatus): String = if (status.astrbotPort > 0) "WebUI 端口 ${status.astrbotPort}" else "机器人主服务"
private fun oneBotState(status: RuntimeStatus): String = when {
    status.oneBotConnected > 0 -> "已连接"
    status.oneBotAuthFailed -> "鉴权异常"
    status.oneBotListen -> "等待连接"
    else -> "未连接"
}
private fun oneBotDetail(status: RuntimeStatus): String = if (status.oneBotConnected > 0) "${status.oneBotConnected} 个反向连接" else status.oneBotReason.ifBlank { "反向 WebSocket" }
private fun qqEngineLabel(status: RuntimeStatus): String = if (status.qqEngine == "snowluma") "SnowLuma" else "NapCat"
private fun qqStateLabel(status: RuntimeStatus): String = when {
    status.qqOnline -> "在线"
    status.qqNeedsLogin -> "需要登录"
    status.qqStartingCount > 0 -> "启动中"
    status.qqStalledCount > 0 -> "异常"
    status.mainQqState == "stopped" -> "已停止"
    else -> status.mainQqState.replace('_', ' ').ifBlank { "未知" }
}

private fun navGlyph(destination: ControlDestination): String = when (destination) {
    ControlDestination.OVERVIEW -> "◎"
    ControlDestination.MAINTENANCE -> "⚙"
    ControlDestination.LOGS -> "≋"
    ControlDestination.CONSOLE -> "▣"
}

private fun logCategoryGlyph(category: LogCategory): String = when (category) {
    LogCategory.OVERVIEW -> "◎"
    LogCategory.ASTRBOT -> "A"
    LogCategory.QQ -> "Q"
    LogCategory.SYSTEM -> "⌁"
}
