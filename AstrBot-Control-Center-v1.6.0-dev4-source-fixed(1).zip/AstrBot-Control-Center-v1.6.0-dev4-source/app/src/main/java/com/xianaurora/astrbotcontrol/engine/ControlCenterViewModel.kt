package com.xianaurora.astrbotcontrol.engine

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.xianaurora.astrbotcontrol.model.ConsoleState
import com.xianaurora.astrbotcontrol.model.ConsoleTarget
import com.xianaurora.astrbotcontrol.model.ControlCenterUiState
import com.xianaurora.astrbotcontrol.model.ControlDestination
import com.xianaurora.astrbotcontrol.model.DiagnosticExportState
import com.xianaurora.astrbotcontrol.model.LogCategory
import com.xianaurora.astrbotcontrol.model.LogSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ControlCenterViewModel(app: Application) : AndroidViewModel(app) {
    private val repository = ControlCenterRepository()
    private val _ui = MutableStateFlow(ControlCenterUiState())
    val ui: StateFlow<ControlCenterUiState> = _ui.asStateFlow()

    private var statusJob: Job? = null
    private var logJob: Job? = null
    private var exportJob: Job? = null
    private var active = false
    private var refreshTick = 0

    fun start() {
        if (active) return
        active = true
        statusJob = viewModelScope.launch {
            repository.keepConsoleActive()
            loadLogSources()
            refreshExportState()
            while (active) {
                val state = _ui.value
                val forceLive = refreshTick == 0 || state.actionBusy || state.status.actionRunning || state.status.stackStarting || refreshTick % 5 == 0
                refreshStatus(forceLive)
                refreshTick++
                if (refreshTick % 4 == 0) repository.keepConsoleActive()
                delay(
                    when {
                        _ui.value.actionBusy || _ui.value.status.actionRunning || _ui.value.status.stackStarting -> 1400
                        _ui.value.destination == ControlDestination.LOGS -> 4800
                        _ui.value.destination == ControlDestination.CONSOLE -> 4200
                        else -> 3000
                    }
                )
            }
        }
        syncLogPolling()
    }

    fun stop() {
        active = false
        statusJob?.cancel()
        statusJob = null
        logJob?.cancel()
        logJob = null
    }

    fun setDestination(destination: ControlDestination) {
        if (_ui.value.destination == destination) return
        _ui.update { it.copy(destination = destination, transientMessage = "") }
        syncLogPolling()
        if (destination == ControlDestination.CONSOLE && _ui.value.console.url.isBlank()) {
            openConsole(ConsoleTarget.ASTRBOT)
        }
    }

    fun clearMessages() {
        _ui.update { it.copy(transientMessage = "", errorMessage = "") }
    }

    fun refresh() = viewModelScope.launch {
        _ui.update { it.copy(refreshing = true, errorMessage = "") }
        refreshStatus(true)
        if (_ui.value.destination == ControlDestination.LOGS) refreshSelectedLog()
        if (_ui.value.exportState.running) refreshExportState()
        _ui.update { it.copy(refreshing = false) }
    }

    fun setLogRedaction(enabled: Boolean) {
        _ui.update { it.copy(redactLogs = enabled) }
    }

    fun selectLogCategory(category: LogCategory) {
        val sources = _ui.value.logSources.filter { it.category == category }
        val next = sources.firstOrNull { it.id == preferredSource(category) } ?: sources.firstOrNull()
        _ui.update {
            it.copy(
                logCategory = category,
                selectedLogId = next?.id ?: it.selectedLogId,
                logText = if (next != null) "" else it.logText,
                redactedLogText = if (next != null) "" else it.redactedLogText,
                logLoading = next != null,
                errorMessage = ""
            )
        }
        if (next != null) viewModelScope.launch { refreshSelectedLog() }
    }

    fun selectLog(id: String) {
        val source = _ui.value.logSources.firstOrNull { it.id == id }
        _ui.update {
            it.copy(
                selectedLogId = id,
                logCategory = source?.category ?: it.logCategory,
                logText = "",
                redactedLogText = "",
                logLoading = true,
                errorMessage = ""
            )
        }
        viewModelScope.launch { refreshSelectedLog() }
    }

    fun runAction(action: String) {
        if (_ui.value.actionBusy || _ui.value.status.actionRunning) return
        val label = when (action) {
            "start" -> "正在启动全部服务"
            "stop" -> "正在停止全部服务"
            "restart" -> "正在重启全部服务"
            "heal" -> "正在自动恢复"
            "repair" -> "正在修复运行环境"
            "plugin-deps" -> "正在修复插件依赖"
            "bridge-repair" -> "正在修复 OneBot"
            "engine-snowluma" -> "正在切换到 SnowLuma"
            "engine-napcat" -> "正在切换到 NapCat"
            "napcat-reset-login" -> "正在准备 NapCat 重新登录"
            else -> "正在执行"
        }
        _ui.update { it.copy(actionBusy = true, actionLabel = label, transientMessage = "", errorMessage = "") }
        viewModelScope.launch {
            val result = repository.queue(action)
            if (!result.ok) {
                _ui.update {
                    it.copy(
                        actionBusy = false,
                        actionLabel = "",
                        errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "操作没有提交成功" } }
                    )
                }
                return@launch
            }
            if (result.stdout.lineSequence().any { it.startsWith("QUEUED|busy|") }) {
                refreshStatus(true)
                _ui.update {
                    it.copy(
                        actionBusy = false,
                        actionLabel = "",
                        transientMessage = "已有操作正在执行，状态会自动更新"
                    )
                }
                return@launch
            }
            _ui.update { it.copy(transientMessage = "操作已提交，正在验证结果") }
            for (attempt in 0 until 14) {
                refreshStatus(true)
                if (!_ui.value.status.actionRunning && !_ui.value.status.stackStarting && attempt >= 2) break
                delay(1150)
            }
            _ui.update { it.copy(actionBusy = false, actionLabel = "") }
            refreshStatus(true)
            if (action.startsWith("engine-")) {
                _ui.update { it.copy(transientMessage = "QQ 运行方式已切换并完成状态检查") }
            }
        }
    }

    fun rebootDevice() {
        if (_ui.value.actionBusy) return
        _ui.update { it.copy(actionBusy = true, actionLabel = "正在重启设备", errorMessage = "") }
        viewModelScope.launch {
            val result = repository.rebootDevice()
            if (!result.ok) {
                _ui.update {
                    it.copy(
                        actionBusy = false,
                        actionLabel = "",
                        errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "重启命令没有成功提交" } }
                    )
                }
            }
        }
    }

    fun startExport(mode: String = "redacted") {
        if (_ui.value.exportState.running) return
        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            val safeMode = if (mode == "raw") "raw" else "redacted"
            _ui.update {
                it.copy(
                    exportState = DiagnosticExportState(state = "queued", phase = "queued", percent = 1, detail = "正在准备诊断包", mode = safeMode, running = true),
                    transientMessage = if (safeMode == "redacted") "正在生成脱敏诊断包" else "正在生成完整诊断包",
                    errorMessage = ""
                )
            }
            repository.exportStart(safeMode).onFailure { error ->
                _ui.update { it.copy(exportState = DiagnosticExportState(mode = safeMode), errorMessage = "诊断导出失败：${error.message ?: "未知错误"}") }
                return@launch
            }
            repeat(240) {
                val result = repository.exportStatus()
                result.onSuccess { state -> _ui.update { it.copy(exportState = state) } }
                    .onFailure { error ->
                        _ui.update { it.copy(errorMessage = "读取导出进度失败：${error.message ?: "未知错误"}") }
                        return@launch
                    }
                val state = _ui.value.exportState
                if (!state.running && state.state !in setOf("queued", "running")) {
                    _ui.update {
                        it.copy(
                            transientMessage = if (state.finished) {
                                if (state.path.isNotBlank()) "诊断包已保存：${state.path}" else "诊断包已生成"
                            } else if (state.state == "cancelled") "诊断导出已取消" else "诊断导出已结束"
                        )
                    }
                    return@launch
                }
                delay(1500)
            }
            _ui.update { it.copy(errorMessage = "诊断导出耗时较长，请稍后在维护页刷新查看") }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            val result = repository.exportCancel()
            if (!result.ok) {
                _ui.update { it.copy(errorMessage = result.stderr.ifBlank { result.stdout.ifBlank { "取消导出失败" } }) }
            }
            refreshExportState()
        }
    }

    fun openConsole(target: ConsoleTarget, mode: String = "admin") {
        val engine = _ui.value.status.qqEngine
        val title = when (target) {
            ConsoleTarget.ASTRBOT -> "AstrBot 控制台"
            ConsoleTarget.QQ -> if (engine == "snowluma") "SnowLuma 控制台" else "NapCat 控制台"
        }
        val requestId = System.nanoTime()
        _ui.update {
            it.copy(
                destination = ControlDestination.CONSOLE,
                console = ConsoleState(target = target, title = title, loading = true, requestId = requestId),
                errorMessage = ""
            )
        }
        syncLogPolling()
        viewModelScope.launch {
            val result = if (target == ConsoleTarget.QQ && mode in setOf("login", "qr")) {
                repository.qqLoginUrl(engine)
            } else {
                repository.webUrl(if (target == ConsoleTarget.ASTRBOT) "astrbot" else engine, mode)
            }
            result.onSuccess { url ->
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(console = state.console.copy(url = url, loading = false, error = ""))
                }
            }.onFailure { error ->
                _ui.update { state ->
                    if (state.console.requestId != requestId) state
                    else state.copy(console = state.console.copy(loading = false, error = error.message ?: "控制台暂不可用"))
                }
            }
        }
    }

    fun openQqLogin() = openConsole(ConsoleTarget.QQ, "login")

    fun retryConsole() = openConsole(_ui.value.console.target)

    fun setConsoleLoading(loading: Boolean) {
        if (_ui.value.console.loading == loading) return
        _ui.update { it.copy(console = it.console.copy(loading = loading)) }
    }

    fun setConsoleError(message: String) {
        if (_ui.value.console.error == message && !_ui.value.console.loading) return
        _ui.update { it.copy(console = it.console.copy(loading = false, error = message)) }
    }

    private suspend fun refreshStatus(forceLive: Boolean) {
        val result = repository.status(forceLive)
        result.onSuccess { status ->
            _ui.update { state ->
                // STATUS_TIME changes on every poll but is not rendered. Avoid emitting a new
                // whole-screen state when only that timestamp changed; this prevents periodic
                // recomposition spikes from colliding with navigation / press animations.
                val sameVisibleStatus = state.status.copy(statusEpoch = 0L) == status.copy(statusEpoch = 0L)
                val nextError = if (state.errorMessage.startsWith("状态读取失败")) "" else state.errorMessage
                if (!state.loading && sameVisibleStatus && nextError == state.errorMessage) {
                    state
                } else {
                    state.copy(
                        loading = false,
                        status = status,
                        lastRefreshEpoch = System.currentTimeMillis() / 1000,
                        errorMessage = nextError
                    )
                }
            }
        }.onFailure { error ->
            _ui.update {
                it.copy(
                    loading = false,
                    errorMessage = "状态读取失败：${error.message ?: "未知错误"}"
                )
            }
        }
    }

    private suspend fun loadLogSources() {
        repository.logSources().onSuccess { raw ->
            val sources = raw.map { it.copy(category = categorize(it)) }
            val ordered = sources.sortedWith(compareBy<LogSource>({ it.category.ordinal }, { sourceRank(it) }, { it.label }))
            _ui.update { state ->
                val selected = if (ordered.any { it.id == state.selectedLogId }) state.selectedLogId else ordered.firstOrNull()?.id.orEmpty()
                val selectedCategory = ordered.firstOrNull { it.id == selected }?.category ?: LogCategory.OVERVIEW
                state.copy(logSources = ordered, selectedLogId = selected, logCategory = selectedCategory)
            }
        }
    }

    private fun categorize(source: LogSource): LogCategory {
        val value = "${source.id} ${source.label}".lowercase()
        return when {
            source.id == "health" || value.contains("健康") || value.contains("summary") -> LogCategory.OVERVIEW
            value.contains("astrbot") || value.contains("插件") || value.contains("plugin") || value.contains("model") -> LogCategory.ASTRBOT
            listOf("napcat", "snowluma", "onebot", "qq", "bridge", "xvfb").any(value::contains) -> LogCategory.QQ
            else -> LogCategory.SYSTEM
        }
    }

    private fun sourceRank(source: LogSource): Int = when (source.id) {
        "health" -> 0
        "astrbot" -> 0
        "napcat", "snowluma" -> 0
        "action" -> 0
        "boot" -> 1
        else -> 5
    }

    private fun preferredSource(category: LogCategory): String = when (category) {
        LogCategory.OVERVIEW -> "health"
        LogCategory.ASTRBOT -> "astrbot"
        LogCategory.QQ -> if (_ui.value.status.qqEngine == "snowluma") "snowluma" else "napcat"
        LogCategory.SYSTEM -> "action"
    }

    private fun syncLogPolling() {
        logJob?.cancel()
        logJob = null
        if (!active || _ui.value.destination != ControlDestination.LOGS) return
        logJob = viewModelScope.launch {
            refreshSelectedLog()
            while (active && _ui.value.destination == ControlDestination.LOGS) {
                delay(2600)
                refreshSelectedLog()
            }
        }
    }

    private suspend fun refreshSelectedLog() {
        val id = _ui.value.selectedLogId.ifBlank { "health" }
        _ui.update { it.copy(logLoading = it.logText.isBlank()) }
        repository.log(id, 360).onSuccess { text ->
            // A source switch can finish while the previous root read is still in flight.
            // Ignore that stale result instead of flashing the old source in the new tab.
            if (_ui.value.selectedLogId != id) return@onSuccess
            if (text != _ui.value.logText) {
                val redacted = withContext(Dispatchers.Default) { LogRedactor.redact(text) }
                if (_ui.value.selectedLogId != id) return@onSuccess
                _ui.update { it.copy(logText = text, redactedLogText = redacted, logLoading = false) }
            } else {
                _ui.update { it.copy(logLoading = false) }
            }
        }.onFailure { error ->
            _ui.update { it.copy(logLoading = false, errorMessage = "日志读取失败：${error.message ?: "未知错误"}") }
        }
    }

    private suspend fun refreshExportState() {
        repository.exportStatus().onSuccess { state -> _ui.update { it.copy(exportState = state) } }
    }

    override fun onCleared() {
        stop()
        exportJob?.cancel()
        super.onCleared()
    }
}
