package com.waipad.rescue

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var manager: MigrationManager
    private lateinit var status: TextView
    private lateinit var inspectBtn: Button
    private lateinit var backupBtn: Button
    private lateinit var restoreBtn: Button
    private lateinit var uninstallBtn: Button
    private lateinit var openBtn: Button
    private lateinit var galleryBtn: Button
    private val io = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = MigrationManager(this)
        setContentView(buildUi())
        inspect(false)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        var n = bytes.toDouble(); var i = 0
        while (n >= 1024 && i < units.lastIndex) { n /= 1024; i++ }
        return DecimalFormat("0.##").format(n) + " " + units[i]
    }

    private fun label(text: String, size: Float, color: String = "#E8EEF8"): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.parseColor(color)); setLineSpacing(0f, 1.15f)
    }

    private fun button(text: String): Button = Button(this).apply {
        this.text = text; textSize = 16f; minHeight = dp(52); isAllCaps = false
    }

    private fun buildUi(): View {
        val root = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#08111F")) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(24), dp(28), dp(32))
        }
        box.addView(label("WAI Pad Rescue", 30f, "#BCA7FF"))
        box.addView(label("旧签名 → 固定签名迁移助手", 18f, "#94A3B8").apply { setPadding(0, dp(4), 0, dp(20)) })
        box.addView(label("用途：在卸载旧版 WAI Pad 前，把 App 私有图库迁到 Rescue 自己的本机空间，同时再复制一份到 Pictures/WAI Pad。全程不上传云端。", 16f).apply { setPadding(0, 0, 0, dp(16)) })

        status = label("正在检查…", 17f, "#DDE7F5").apply {
            setBackgroundColor(Color.parseColor("#101B2D")); setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        box.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        inspectBtn = button("检查旧图库").apply { setOnClickListener { inspect(true) } }
        backupBtn = button("① 一键迁出旧图库").apply { setOnClickListener { backup() } }
        uninstallBtn = button("迁出校验后 · 卸载旧 WAI Pad").apply { setOnClickListener {
            if (!manager.canSafelyUninstall()) show("还没有可验证的迁移备份。请先完成“① 一键迁出旧图库”。")
            else if (!manager.requestUninstallOld()) show("无法打开系统卸载确认页。")
        } }
        restoreBtn = button("② 恢复到新版 WAI Pad").apply { setOnClickListener { restore() } }
        openBtn = button("打开新版 WAI Pad 检查").apply { setOnClickListener { if (!manager.launchMainApp()) show("还没有安装新版 WAI Pad。") } }
        galleryBtn = button("打开本机相册保险副本").apply { setOnClickListener { if (!manager.openSharedBackup()) show("无法直接打开相册，请在系统图库中进入 WAI Pad 相册。") } }
        listOf(inspectBtn, backupBtn, uninstallBtn, restoreBtn, openBtn, galleryBtn).forEach { b ->
            box.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }

        box.addView(label("正确顺序", 20f, "#BCA7FF").apply { setPadding(0, dp(16), 0, dp(8)) })
        box.addView(label("1. 保持旧 WAI Pad 已安装，先运行“① 一键迁出旧图库”。\n2. 看到“校验完成”后，才卸载旧 WAI Pad。\n3. 安装固定签名的新 WAI Pad，并至少打开一次。\n4. 回到 Rescue，运行“② 恢复到新版 WAI Pad”。\n5. 打开 WAI Pad 检查图库。确认图片齐全后，才可以卸载 Rescue。", 16f, "#CBD5E1"))
        box.addView(label("安全规则：任何一步数量校验失败，Rescue 都会明确提示“不要卸载旧版/不要删除 Rescue”。", 15f, "#F9B4B4").apply { setPadding(0, dp(14), 0, 0) })
        root.addView(box)
        return root
    }

    private fun setBusy(busy: Boolean) {
        listOf(inspectBtn, backupBtn, uninstallBtn, restoreBtn, openBtn, galleryBtn).forEach { it.isEnabled = !busy }
    }

    private fun show(text: String) { runOnUiThread { status.text = text } }

    private fun inspect(user: Boolean) {
        setBusy(true)
        io.execute {
            val r = manager.inspect()
            val backup = manager.latestBackupPath()
            val text = buildString {
                append(if (r.root) "✅ Root：已授权\n" else "❌ Root：未授权（会弹出 Root 授权请求）\n")
                append(if (r.packageInstalled) "✅ WAI Pad：已安装\n" else "⚠️ WAI Pad：未安装\n")
                if (r.packageInstalled) {
                    append(if (r.stableSigned) "✅ 签名：固定签名版，可执行恢复\n" else "⚠️ 签名：旧/其他签名，当前只允许迁出\n")
                    if (r.installedCertSha256.isNotBlank()) append("证书：${r.installedCertSha256}\n")
                }
                append("WAI Pad 私有图库：${r.imageCount} 张 / ${formatBytes(r.bytes)}\n")
                if (backup.isNotBlank()) append("Rescue 已有备份：$backup\n")
                append("\n${r.detail}")
                if (user && !r.root) append("\n\n请在 Root 管理器弹窗中允许 WAI Pad Rescue 获得 Root。")
            }
            show(text); runOnUiThread { setBusy(false) }
        }
    }

    private fun backup() {
        setBusy(true); show("正在迁出旧图库…\n不要关闭应用，也不要卸载 WAI Pad。")
        io.execute {
            val r = manager.backup()
            val text = if (r.ok) {
                "✅ 迁出成功并通过校验\n\n图片：${r.imageCount} 张\n大小：${formatBytes(r.bytes)}\n\nRescue 本机备份：\n${r.privateBackup}\n\n系统相册保险副本：\n${r.sharedBackup}\n\n元数据保险副本：\n${r.metadataBackup}\n\n${r.detail}\n\n现在才可以卸载旧签名 WAI Pad。"
            } else {
                "❌ 迁出未完成\n\n${r.detail}\n\n不要卸载旧 WAI Pad。"
            }
            show(text); runOnUiThread { setBusy(false) }
        }
    }

    private fun restore() {
        setBusy(true); show("正在恢复到新版 WAI Pad…")
        io.execute {
            val r = manager.restore()
            val text = if (r.ok) {
                "✅ 恢复完成并通过数量校验\n\n备份图片：${r.restoredImages} 张\n新版图库：${r.targetImages} 张\n\n${r.detail}"
            } else {
                "❌ 恢复未通过校验\n\n${r.detail}\n\n请保留 Rescue 和 Pictures/WAI Pad 保险副本。"
            }
            show(text); runOnUiThread { setBusy(false) }
        }
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }
}
