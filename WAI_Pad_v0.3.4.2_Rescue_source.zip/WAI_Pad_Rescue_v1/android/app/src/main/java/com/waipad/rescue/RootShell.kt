package com.waipad.rescue

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

object RootShell {
    data class Result(val code: Int, val output: String) {
        val ok: Boolean get() = code == 0
    }

    fun run(command: String, timeoutMs: Long = 120_000L): Result {
        val process = ProcessBuilder("su", "-c", command)
            .redirectErrorStream(true)
            .start()
        val reader = Executors.newSingleThreadExecutor()
        val future = reader.submit<String> {
            process.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        }
        val finished = process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
        if (!finished) {
            process.destroyForcibly()
            reader.shutdownNow()
            return Result(124, "命令超时")
        }
        val output = try { future.get(3, TimeUnit.SECONDS) } catch (_: Exception) { "" }
        reader.shutdownNow()
        return Result(process.exitValue(), output.trim())
    }

    fun quote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
}
