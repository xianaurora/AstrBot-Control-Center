package com.waipad.rescue

import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MigrationManager(private val context: Context) {
    companion object {
        const val MAIN_PACKAGE = "com.waipad.app"
        private const val PREFS = "migration_state"
        private const val KEY_BACKUP = "latest_backup"
        private const val KEY_SHARED = "latest_shared"
        const val STABLE_CERT_SHA256 = "A3:FE:05:ED:D1:03:C3:EF:A6:DB:CC:B6:EB:46:28:F8:8C:C8:CD:32:77:2F:20:3F:B2:C2:F5:6D:2A:48:C4:A0"
    }

    data class InspectResult(
        val root: Boolean,
        val packageInstalled: Boolean,
        val imageCount: Int,
        val bytes: Long,
        val source: String,
        val detail: String,
        val installedCertSha256: String = "",
        val stableSigned: Boolean = false
    )

    data class BackupResult(
        val ok: Boolean,
        val imageCount: Int,
        val bytes: Long,
        val privateBackup: String,
        val sharedBackup: String,
        val metadataBackup: String,
        val detail: String
    )

    data class RestoreResult(
        val ok: Boolean,
        val restoredImages: Int,
        val targetImages: Int,
        val detail: String
    )

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)


    private fun installedMainCertSha256(): String {
        return try {
            val info = if (android.os.Build.VERSION.SDK_INT >= 28) {
                context.packageManager.getPackageInfo(MAIN_PACKAGE, android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES)
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(MAIN_PACKAGE, android.content.pm.PackageManager.GET_SIGNATURES)
            }
            val sig = if (android.os.Build.VERSION.SDK_INT >= 28) {
                info.signingInfo?.apkContentsSigners?.firstOrNull()
            } else {
                @Suppress("DEPRECATION")
                info.signatures?.firstOrNull()
            } ?: return ""
            val digest = MessageDigest.getInstance("SHA-256").digest(sig.toByteArray())
            digest.joinToString(":") { "%02X".format(it) }
        } catch (_: Exception) { "" }
    }

    private fun sourceDataDir(): String {
        val candidates = listOf(
            "/data/user/0/$MAIN_PACKAGE",
            "/data/data/$MAIN_PACKAGE"
        )
        for (p in candidates) {
            val r = RootShell.run("test -d ${RootShell.quote(p)}")
            if (r.ok) return p
        }
        return candidates.first()
    }

    fun hasRoot(): Boolean {
        val r = try { RootShell.run("id", 15_000) } catch (_: Exception) { return false }
        return r.ok && r.output.contains("uid=0")
    }

    fun inspect(): InspectResult {
        val root = hasRoot()
        val installed = try {
            context.packageManager.getApplicationInfo(MAIN_PACKAGE, 0)
            true
        } catch (_: Exception) { false }
        val cert = if (installed) installedMainCertSha256() else ""
        val stable = cert.equals(STABLE_CERT_SHA256, ignoreCase = true)
        if (!root) return InspectResult(false, installed, 0, 0, "", "没有获得 Root 授权", cert, stable)
        val data = sourceDataDir()
        val src = "$data/files/wai_images"
        val count = RootShell.run("if [ -d ${RootShell.quote(src)} ]; then find ${RootShell.quote(src)} -maxdepth 1 -type f ! -name '*.tmp' | wc -l; else echo 0; fi").output.trim().toIntOrNull() ?: 0
        val kb = RootShell.run("if [ -d ${RootShell.quote(src)} ]; then du -sk ${RootShell.quote(src)} | cut -f1; else echo 0; fi").output.trim().toLongOrNull() ?: 0L
        val bytes = kb * 1024L
        return InspectResult(root, installed, count, bytes, src, if (count > 0) "找到 WAI Pad 私有图库" else "没有发现 WAI Pad 私有图片", cert, stable)
    }

    fun backup(): BackupResult {
        if (!hasRoot()) return BackupResult(false, 0, 0, "", "", "", "未获得 Root 权限")
        val data = sourceDataDir()
        val images = "$data/files/wai_images"
        val meta = "$data/files/wai_images_meta"
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val rescueDir = File(context.filesDir, "migration/$stamp")
        rescueDir.mkdirs()
        val privatePath = rescueDir.absolutePath
        val sharedImages = "/sdcard/Pictures/WAI Pad/Legacy Backup $stamp"
        val sharedMeta = "/sdcard/Documents/WAI Pad Migration/$stamp"
        val rescueUid = context.applicationInfo.uid

        val qImages = RootShell.quote(images)
        val qMeta = RootShell.quote(meta)
        val qPrivateImages = RootShell.quote("$privatePath/wai_images")
        val qPrivateMeta = RootShell.quote("$privatePath/wai_images_meta")
        val qSharedImages = RootShell.quote(sharedImages)
        val qSharedMeta = RootShell.quote("$sharedMeta/wai_images_meta")
        val qPrivatePath = RootShell.quote(privatePath)
        val qSharedMetaBase = RootShell.quote(sharedMeta)
        val script = """
            set -e
            test -d $qImages
            mkdir -p $qPrivateImages $qPrivateMeta $qSharedImages $qSharedMeta
            cp -R $qImages/. $qPrivateImages/
            if [ -d $qMeta ]; then cp -R $qMeta/. $qPrivateMeta/; fi
            cp -R $qImages/. $qSharedImages/
            if [ -d $qMeta ]; then cp -R $qMeta/. $qSharedMeta/; fi
            chown -R $rescueUid:$rescueUid $qPrivatePath
            chmod -R u+rwX $qPrivatePath
            chmod -R a+rX $qSharedImages $qSharedMetaBase || true
            sync
        """.trimIndent()
        val r = RootShell.run(script, 180_000)
        if (!r.ok) return BackupResult(false, 0, 0, privatePath, sharedImages, sharedMeta, "迁出失败(${r.code})：${r.output.takeLast(1200)}")

        val privateImages = File(rescueDir, "wai_images")
        val count = privateImages.listFiles()?.count { it.isFile && !it.name.endsWith(".tmp") } ?: 0
        val bytes = privateImages.listFiles()?.filter { it.isFile }?.sumOf { it.length() } ?: 0L
        if (count <= 0 || bytes <= 0L) return BackupResult(false, count, bytes, privatePath, sharedImages, sharedMeta, "备份目录已创建，但没有验证到图片，禁止卸载旧版")

        val originalCount = inspect().imageCount
        val sharedCount = RootShell.run("find ${RootShell.quote(sharedImages)} -maxdepth 1 -type f ! -name '*.tmp' | wc -l").output.trim().toIntOrNull() ?: 0
        if (originalCount > 0 && (count < originalCount || sharedCount < originalCount)) {
            return BackupResult(false, count, bytes, privatePath, sharedImages, sharedMeta, "校验未通过：旧版 $originalCount 张，Rescue $count 张，相册保险副本 $sharedCount 张。请勿卸载旧版 WAI Pad。")
        }

        val manifest = JSONObject()
            .put("format", "wai-pad-migration-v1")
            .put("created_at", System.currentTimeMillis())
            .put("source_package", MAIN_PACKAGE)
            .put("image_count", count)
            .put("bytes", bytes)
            .put("shared_images", sharedImages)
            .put("shared_metadata", sharedMeta)
        File(rescueDir, "manifest.json").writeText(manifest.toString(2), Charsets.UTF_8)
        prefs.edit().putString(KEY_BACKUP, privatePath).putString(KEY_SHARED, sharedImages).apply()

        val scan = privateImages.listFiles()?.map { "$sharedImages/${it.name}" }?.toTypedArray() ?: emptyArray()
        if (scan.isNotEmpty()) {
            try { MediaScannerConnection.scanFile(context, scan, null, null) } catch (_: Exception) {}
        }
        return BackupResult(true, count, bytes, privatePath, sharedImages, sharedMeta, "迁出和校验完成。现在旧版即使卸载，图片仍有两份本机备份。")
    }

    fun latestBackupPath(): String = prefs.getString(KEY_BACKUP, "") ?: ""
    fun latestSharedPath(): String = prefs.getString(KEY_SHARED, "") ?: ""

    fun canSafelyUninstall(): Boolean {
        val backup = latestBackupPath()
        if (backup.isBlank()) return false
        val manifest = File(backup, "manifest.json")
        val images = File(backup, "wai_images")
        if (!manifest.isFile || !images.isDirectory) return false
        return try {
            val expected = JSONObject(manifest.readText(Charsets.UTF_8)).optInt("image_count", 0)
            val actual = images.listFiles()?.count { it.isFile && !it.name.endsWith(".tmp") } ?: 0
            expected > 0 && actual >= expected
        } catch (_: Exception) { false }
    }

    fun requestUninstallOld(): Boolean {
        if (!canSafelyUninstall()) return false
        return try {
            context.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$MAIN_PACKAGE")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (_: Exception) { false }
    }

    fun restore(): RestoreResult {
        if (!hasRoot()) return RestoreResult(false, 0, 0, "未获得 Root 权限")
        val backup = latestBackupPath()
        if (backup.isBlank() || !File(backup, "wai_images").isDirectory) return RestoreResult(false, 0, 0, "没有找到 Rescue 内部迁移备份")
        val appInfo = try { context.packageManager.getApplicationInfo(MAIN_PACKAGE, 0) } catch (_: Exception) {
            return RestoreResult(false, 0, 0, "还没有安装新版 WAI Pad")
        }
        val cert = installedMainCertSha256()
        if (!cert.equals(STABLE_CERT_SHA256, ignoreCase = true)) {
            return RestoreResult(false, 0, 0, "当前安装的 WAI Pad 仍不是固定签名版，Rescue 拒绝覆盖恢复。请先完成迁出，再卸载旧版并安装固定签名版。当前证书：${if (cert.isBlank()) "未知" else cert}")
        }
        val uid = appInfo.uid
        val targetBase = "/data/user/0/$MAIN_PACKAGE/files"
        val qBackupImages = RootShell.quote("$backup/wai_images")
        val qBackupMeta = RootShell.quote("$backup/wai_images_meta")
        val qTargetImages = RootShell.quote("$targetBase/wai_images")
        val qTargetMeta = RootShell.quote("$targetBase/wai_images_meta")
        val qTargetBase = RootShell.quote(targetBase)
        val qAppBase = RootShell.quote("/data/user/0/$MAIN_PACKAGE")
        val script = """
            set -e
            mkdir -p $qTargetImages $qTargetMeta
            cp -R -n $qBackupImages/. $qTargetImages/
            if [ -d $qBackupMeta ]; then cp -R -n $qBackupMeta/. $qTargetMeta/; fi
            chown -R $uid:$uid $qTargetImages $qTargetMeta
            chmod -R u+rwX,go-rwx $qTargetImages $qTargetMeta
            restorecon -RF $qAppBase >/dev/null 2>&1 || true
            sync
        """.trimIndent()
        val r = RootShell.run(script, 180_000)
        if (!r.ok) return RestoreResult(false, 0, 0, "恢复失败(${r.code})：${r.output.takeLast(1200)}")
        val backupCount = File(backup, "wai_images").listFiles()?.count { it.isFile && !it.name.endsWith(".tmp") } ?: 0
        val targetCount = RootShell.run("find ${RootShell.quote("$targetBase/wai_images")} -maxdepth 1 -type f ! -name '*.tmp' | wc -l").output.trim().toIntOrNull() ?: 0
        val ok = targetCount >= backupCount && backupCount > 0
        return RestoreResult(ok, backupCount, targetCount, if (ok) "恢复完成。请打开 WAI Pad 检查图库，确认后再卸载 Rescue。" else "恢复后数量校验异常：备份 $backupCount 张，新 WAI Pad $targetCount 张。请先保留 Rescue。")
    }

    fun launchMainApp(): Boolean {
        val i = context.packageManager.getLaunchIntentForPackage(MAIN_PACKAGE) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
        return true
    }

    fun openSharedBackup(): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "image/*"
                data = Uri.parse("content://media/external/images/media")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) { false }
    }
}
