# WAI Pad Rescue - no custom shrinking rules required.
