WAI Pad Rescue v1
=================

这是“旧随机签名 WAI Pad -> 固定签名 WAI Pad”的一次性迁移助手。
它使用你平板已有的 Root 权限，不需要输入任何终端命令。

最重要：
在 Rescue 显示“迁出成功并通过校验”以前，不要卸载旧 WAI Pad。

操作：
1. 保持当前旧 WAI Pad 安装着。
2. 安装 WAI Pad Rescue APK（包名 com.waipad.rescue，可与 WAI Pad 共存）。
3. 打开 Rescue，Root 管理器弹窗选择“允许”。
4. 点“① 一键迁出旧图库”。
5. 必须看到“迁出成功并通过校验”。
6. 此时图片有两份本机备份：
   - Rescue 自己的 App 私有目录（卸载旧 WAI Pad 不受影响）
   - 平板 Pictures/WAI Pad/Legacy Backup ...（系统相册保险副本）
7. 再卸载旧签名 WAI Pad。
8. 安装固定签名版 WAI Pad，至少打开一次。
9. 回到 Rescue，点“② 恢复到新版 WAI Pad”。
10. 打开 WAI Pad 检查图库，确认数量正确后再卸载 Rescue。

隐私：
- 不联网备份；
- 不上传 AutoDL；
- 不上传任何云盘；
- 图片只在平板本机搬运。

注意：
SecurePrefs 中的 SSH 密码由 Android Keystore 加密。旧 App 被卸载时原 Keystore 密钥会删除，
因此 Rescue 不尝试迁移 SSH 密码。新版 WAI Pad 第一次需要重新保存一次 AutoDL 登录配置。
