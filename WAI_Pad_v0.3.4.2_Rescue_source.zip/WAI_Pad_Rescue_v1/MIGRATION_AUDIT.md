# WAI Pad Rescue v1 迁移审计

## 解决的问题
旧版本 WAI Pad 使用 GitHub 临时 debug 签名；固定签名版无法覆盖安装。Android 在卸载 App 时会删除 `/data/user/0/com.waipad.app/files`，旧图库因此会丢失。

## 迁移策略
Rescue 使用独立包名 `com.waipad.rescue`，可和旧 WAI Pad 同时安装。获得 Root 后：

1. 从旧 App 私有目录读取：
   - `files/wai_images`
   - `files/wai_images_meta`
2. 同时创建两份本机备份：
   - Rescue 私有目录 `files/migration/<timestamp>`
   - `/sdcard/Pictures/WAI Pad/Legacy Backup <timestamp>`
3. 图片数量校验通过才提示可以卸载旧版。
4. 新固定签名 WAI Pad 安装后，用 Root 把图片和 metadata 恢复到新 App 私有目录。
5. `chown` 到新版 WAI Pad UID，并尝试 `restorecon` 修正 SELinux 标签。
6. 再次进行数量校验。

## 故障保护
- 迁出后数量少于旧图库：标记失败，明确禁止卸载旧版。
- 恢复数量异常：保留 Rescue 和共享 Pictures 副本，不删除任何备份。
- `cp -n` 恢复，避免覆盖新 WAI Pad 安装后已经生成的新图片。
- 不迁移 Android Keystore 加密的 SSH 密码，因为卸载旧 App 后密钥本身会销毁。

## 隐私
没有任何云端上传流程。共享副本位于平板本机 `/sdcard/Pictures/WAI Pad`。
