# AstrBot CC v1.6.0-dev21

Android App：`1.6.0-dev21 / 162100`。内嵌 core：`1.6.0-dev12 / 16012`。

本版重点：工作台三入口统一、环境设置保存栏固定显眼位置、SnowLuma 登录画面触摸坐标校准，以及 NapCat/SnowLuma 引擎切换的 BusyBox `flock -w` 兼容修复。

推荐运行仓库内 GitHub Actions：**Build dev21 APK**。Debug/Release 继续使用项目固定开发更新证书，并在 CI 中核对 APK 证书指纹。
