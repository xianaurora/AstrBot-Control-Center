# dev12 — 人工二维码刷新与 AstrBot WebUI 真诊断

## SnowLuma 原生扫码

- 默认扫码继续使用 `FFmpeg x11grab -> PNG -> Compose Image`，不把 noVNC 恢复成默认链路。
- Android 端只在原生 PNG 检测到 QQ 的红色“二维码已过期”状态后显示“刷新二维码”。
- 刷新必须由用户主动点击；不存在后台自动刷新循环。
- App 和 Core 都执行 30 秒冷却。
- Core 只发送一次鼠标点击：先激活 QQ 窗口，再把鼠标移动到窗口相对坐标中心下方，最后发送一次 `click 1`。
- 点击后仍保持“已过期”状态，直到新的 PNG 实际证明二维码已经更新，避免把 cooldown/点击失败误报成成功。
- 复杂交互仍使用显式“完整桌面”入口。

## AstrBot WebUI

- Core 新增 `web-probe astrbot`：真实请求 6185 首页，并验证首页引用的核心 JS/CSS 的 HTTP 状态、内容长度和 MIME。
- Android 在创建 AstrBot WebView 前执行该 probe；失败时直接显示具体静态资源问题，并保留“浏览器打开”作为旁路验证。
- 修复 dev11 的 SPA reload loop：旧代码在每次 Compose update 中比较 `view.url != requestedUrl`。AstrBot SPA 挂载后可能通过 history/hash 改变当前 URL，因此旧逻辑会在重组时不断重新加载 `/`。dev12 只跟踪“Compose 请求的 URL”是否发生变化，不再拿 WebView 当前 SPA URL 当重载依据。
- WebView 不恢复自动清缓存、host 来回切换或 DOM 黑屏自动 reload；保留平台网络/HTTP/JS console/renderer 诊断。

## 安全边界

二维码刷新不是自动登录、自动扫码或绕过 QQ 验证。Core 仅在用户主动操作后模拟一次当前 QQ 登录窗口中的“刷新二维码”点击，并执行双层冷却。
