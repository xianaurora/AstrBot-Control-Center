# dev12 implementation notes

## 1. Native QQ QR: manual refresh only

The default SnowLuma login path stays native:

`QQ/Xvfb -> FFmpeg x11grab -> PNG -> Root bridge -> Compose Image`

The PNG is intentionally not touch-through. dev12 detects QQ's expired-code state from the real frame and only then exposes an Android-side **刷新二维码** action.

The action is deliberately conservative:

- it is only reachable after the native frame is classified as expired;
- nothing refreshes automatically;
- one user tap sends one `xdotool click 1` to the existing QQ window;
- Core enforces a 30 second cooldown in addition to the Android UI cooldown;
- it does not enter a password, approve login, scan a code, or bypass QQ verification;
- advanced noVNC desktop remains available for exceptional/manual interaction.

The click point is relative to the current QQ window (50% width, 60% height), so it follows the 320x460 login window instead of hard-coding tablet coordinates.

## 2. Expired-code detection

The actual device screenshots show a strong red status line only in the expired state. dev12 samples a small central ROI of the decoded QQ PNG and counts red-dominant pixels. It does not OCR account text or inspect credentials.

Regression against the two supplied screenshots:

- valid QR screenshot: 0 red-dominant samples in the normalized ROI;
- expired QR screenshot: 164 red-dominant samples;
- current threshold: 12.

This detector only changes UI state and availability of the manual refresh button. It never triggers the click itself.

## 3. AstrBot WebUI: fix the SPA reload loop

The important Android-side change is not another GPU/compositor workaround.

The old `AndroidView(update = ...)` compared `view.url` to the original requested root URL. AstrBot is an SPA and may legitimately change its URL/hash/history after mounting. A Compose recomposition could therefore see a different `view.url` and call `loadUrl(root)` again, repeatedly interrupting the SPA.

dev12 now tracks the URL requested by Compose in `lastRequestedUrl` and loads only when that requested property changes. It never uses the page's current navigation URL as a reason to reload.

A delayed mount check is diagnostic-only: it may show an error/fallback hint if the page remains visually empty, but it never clears cache, swaps hosts, or reloads the page.

## 4. AstrBot WebUI: real HTTP/static-resource health probe

Before opening AstrBot, Core now probes:

1. `http://127.0.0.1:6185/` returns HTTP 200 and HTML;
2. local JS/CSS references from the returned HTML can be fetched;
3. those assets are non-empty;
4. JavaScript has a JavaScript/ECMAScript MIME type;
5. CSS has `text/css`.

This separates “port 6185 is listening” from “the dashboard can actually boot”. A failure is surfaced in the native UI before creating the WebView.

## 5. Versions

- Android app: `1.6.0-dev12` / `161000`
- Core: `1.6.0-dev9` / `16009`
