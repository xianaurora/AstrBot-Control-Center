# v1.6.0-dev2-hotfix2 — KernelSU CLI 路径修复

现场确认：设备已获得 uid=0，KernelSU 的 `ksud` 实际位于 `/data/adb/ksud`，但 App 的 root shell PATH 不包含 `/data/adb`，导致 `command -v ksud` 误判为未安装 Root 模块管理器。

本修复：

- Root 检测优先检查可执行文件 `/data/adb/ksud`；仅在不存在时回退到 `command -v ksud`。
- KernelSU 安装 Engine 时优先直接执行 `/data/adb/ksud module install <zip>`，不再依赖 PATH。
- Root 检查界面会同时展示探测到的 CLI 路径和版本，方便后续诊断。
- 保留 hotfix1 的重启验证、staged update 清理与失败导出 ZIP 机制。

现场设备已确认 `/data/adb/ksud --version` 返回 `ksud 4.1.1-3-gb3278525`，且 `/data/adb/ksud module --help` 包含 `install  Install module <ZIP>`。
