# v1.6.0-dev2-hotfix1 — Engine 安装/回退状态机修复

本 hotfix 不改变 Engine 目标版本，仍安装内置 `1.6.0-dev2` Engine；只修 Control Center 侧真实设备安装状态机与回退清理。

## 修复

1. **重启前误验证旧 Engine**：安装提交成功后记录 boot ID；若 boot ID 尚未变化，App 必须停留在“需要重启”，不得对仍在运行的 v1.5.6.5 执行 `app-protocol` / 版本验证。
2. **KernelSU/Magisk staged update 与回退冲突**：回退时清理 `/data/adb/modules_update/astrbot_standalone` 和活动模块的 `update` 标记，防止已恢复的旧 Engine 在下一次启动又被待应用的新模块覆盖。
3. **重启后恢复路径补版本校验**：协议通过仍需确认目标 Engine 版本。
4. **Root Manager 安装失败诊断**：错误信息包含 exit code / timeout，并把已校验 Engine ZIP 尝试导出到 Download 供 Root Manager 手动导入。
5. **Android 35 帧率 API 编译修复**：使用 `window.setFrameRateBoostOnTouchEnabled(true)`。

## 当前现场

如果旧 APK 已经进入“已恢复升级前 Engine / 重启并完成回退”，在重启前应先确认并清理同模块 ID 的 staged update；hotfix App 会在 rollbackPrepared 状态自动清理。

## GitHub Actions

源码包已附带 `.github/workflows/build-apk.yml`。推到 GitHub 后可直接在 Actions 里手动运行 `Build hotfix APK`，产物名为 `AstrBot-Control-Center-v1.6.0-dev2-hotfix1-debug`。
