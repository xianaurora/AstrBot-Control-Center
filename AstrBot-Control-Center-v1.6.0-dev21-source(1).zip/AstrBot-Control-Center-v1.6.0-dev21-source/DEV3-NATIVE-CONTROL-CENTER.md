# v1.6.0-dev3 — Native Control Center

这一版不照搬旧 Web / 模块控制台。安装流程保留，运行环境完成后直接进入重新设计的原生控制中心。

## 这一版做了什么

### 1. 全新的信息架构

完成安装后进入四个原生入口：

- **总览**：一句话告诉用户当前是否可用，再展示 AstrBot、QQ、OneBot 三个关键链路。
- **服务**：集中放启动、重启、自动恢复、OneBot 修复，以及各服务的运行细节。
- **日志**：原生日志源选择、自动刷新、跟随最新 / 暂停跟随。
- **更多**：设备环境、原 Web 控制台兼容入口、维护和教程。

旧控制台没有被当作布局模板，只复用了核心组件已经提供的稳定命令协议。界面结构、卡片层级、导航方式和动效均重新设计；Web 控制台只作为尚未原生化功能的兼容入口。

### 2. 原生状态通路

新增：

- `ControlCenterModels.kt`
- `ControlStatusParser.kt`
- `ControlCenterRepository.kt`
- `ControlCenterViewModel.kt`
- `ControlCenterApp.kt`

数据来源使用核心组件现有接口：

- `astrctl web-status`
- `astrctl web-status-live`
- `astrctl console-ping`
- `astrctl queue ... app`
- `astrctl logs-list`
- `astrctl log KEY N`
- `astrctl web-url ...`
- `astrctl snowluma-login-request main`

因此 dev3 App **不需要为了控制中心重新刷一次核心组件**，可直接与当前 `1.6.0-dev2 / protocol v1` 配合。

### 3. 动画系统

设计目标不是“动画越多越好”，而是让每个状态变化有连续的视觉关系：

- 页面切换：小幅主轴位移 + 淡入淡出，前进和返回方向一致。
- 状态卡：颜色、大小和内容变化使用可中断动画，不突然跳变。
- 主操作按钮：按压使用短 spring，操作提交后在原位转成进度状态，避免按钮消失造成错觉。
- 服务状态：只有真正处于 `WORKING` 时才使用呼吸脉冲；稳定状态不做无意义常驻动画。
- 初次进入控制中心：独立恢复动画，避免先绘制一堆“未知状态”再突然重排。
- 日志：跟随最新时平滑滚动；用户可暂停，避免读取旧日志时被抢走滚动位置。

参考方向：

- Material 3 / M3 Expressive motion physics：物理 spring、统一运动方向、状态变化连续性。
- Android Compose 官方动画与性能建议：高频动画尽量使用绘制层属性，避免无意义重排；Lazy 内容保持轻量。
- Apple HIG Motion：动画应该解释层级和状态变化，而不是装饰性地干扰任务。
- Android 官方 Compose Samples / Now in Android：自适应布局、状态驱动 UI、复杂 Compose App 的分层方式。

官方资料：

- https://m3.material.io/styles/motion/overview/how-it-works
- https://m3.material.io/styles/motion/transitions/applying-transitions
- https://developer.android.com/develop/ui/compose/animation/value-based
- https://developer.android.com/develop/ui/compose/performance/bestpractices
- https://developer.android.com/develop/ui/compose/build-adaptive-apps
- https://developer.apple.com/design/human-interface-guidelines/motion
- https://github.com/android/compose-samples
- https://github.com/android/nowinandroid

### 4. 横屏与大屏不是拉伸手机版

宽度达到控制中心阈值后：

- 底部导航切换为左侧 Rail。
- 服务卡使用双栏。
- 日志使用“日志源列表 + 日志内容”双栏。
- 内容区保留合理最大密度，不把手机卡片横向拉到整屏。

竖屏则保持单手可操作的底部导航和纵向内容层级。

### 5. 轮询和流畅度

- 控制中心只在 Activity `STARTED` 时轮询，进入后台后停止。
- 普通页面优先读取 `web-status` 缓存，周期性做实时刷新。
- 执行启动/停止/修复时短时间提高实时刷新频率，让操作反馈更快。
- 日志页降低状态轮询频率，避免日志读取与实时状态采集同时高频争抢 Root shell。
- 所有操作先在 ViewModel 里上锁，防止快速连点重复提交后台任务。

## 当前 dev3 范围

这一版先把“控制中心骨架”做实：

- 原生总览
- 原生服务控制
- QQ 状态 + 需要登录时直达登录入口
- 原生日志
- 环境与 Web 兼容入口
- 常用修复动作

后续 dev3.x / dev4 再逐步把账号管理、诊断结果、配置编辑等 Web 能力原生化，不会为了“看起来功能多”一次性把旧控制台塞回 APK。
