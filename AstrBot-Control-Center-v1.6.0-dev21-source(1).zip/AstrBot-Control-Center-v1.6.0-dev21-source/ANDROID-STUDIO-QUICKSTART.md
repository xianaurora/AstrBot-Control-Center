# Android Studio 快速构建 — v1.6.0-dev19

1. 用 Android Studio 打开源码根目录。
2. 等待 Gradle Sync 完成。
3. 选择 `app`，构建 Debug APK 或直接运行到设备。
4. 首次真机测试先进入 **QQ 登录**：确认完整 QQ 登录窗口能显示，并直接点击窗口底部“登录”或账号选择控件。
5. 再打开 **AstrBot**：确认原生返回栏没有进入状态栏区域，系统返回手势能直接回工作台。
6. 打开 **工具**：确认不再出现重复的“当前情况 / QQ 等待登录”大卡。

## 覆盖安装

dev19 与 dev17/dev18 使用同一固定开发更新证书。若设备已有固定证书版本，可直接覆盖；如果 Android 报 `INSTALL_FAILED_UPDATE_INCOMPATIBLE`，说明手机上仍是更早的随机 debug 签名，需要卸载旧 Control Center App 后再装一次固定证书版本。
