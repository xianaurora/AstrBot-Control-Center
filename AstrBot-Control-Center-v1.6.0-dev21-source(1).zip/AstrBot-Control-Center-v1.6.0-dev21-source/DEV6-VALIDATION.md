# dev6 验证记录

## 已在当前构建环境执行

- 内置核心组件 ZIP `unzip -t`。
- 核心组件 226 项 SHA-256 manifest 校验。
- 核心组件 shell/bash 语法扫描。
- `test-control-center-v1604-qr-rendering.sh`：24-bit Xvfb、软件渲染保留、兼容渲染命令、QQ 窗口门禁。
- Android XML 解析。
- `scripts/verify-source.sh`：版本、核心组件、重复扫码/重复导出、日志布局门禁、QR canvas 探针与兼容恢复 wiring。
- Kotlin 全源码解析级 smoke：检查 `expecting` / `unexpected tokens` / `unclosed` 等语法错误；当前容器无 Android/Compose classpath，因此 unresolved reference 不作为编译结果。
- Parser / LogRedactor 的纯 JVM smoke 与项目 JUnit 测试源保持。

## 仍必须由 GitHub Actions / 真机完成

- `:app:testDebugUnitTest :app:assembleDebug` 的完整 Android/Compose 类型检查与 APK 生成。
- WebView + noVNC canvas 实机像素探针。
- Linux QQ 在本机 Xvfb 下 normal/compat 两条渲染路径。
- 120 Hz 帧时间与扫码、日志快速切换的实际手感。

## 本次验证结果

- Engine shell/bash syntax: `79` files passed.
- Engine manifest: `226` entries passed.
- Android XML: `4` files parsed.
- Android/Kotlin source files in parse smoke: `16`.
- Embedded core SHA-256: `a2ddd40dea88ad6f3efc53ca9076821feb97f545546f003b3b3f0d02c50e841b`.
- Source gate result: `SOURCE_GATE_OK`.
