# v1.6.0-dev4 验证记录

验证日期：2026-08-10

## 已完成的静态与协议验证

1. 版本号：`versionName=1.6.0-dev4`，`versionCode=160200`。
2. Kotlin 源文件共 16 个。使用无 Android/Compose classpath 的 `kotlinc` 做解析级扫描；存在预期的 Android/Compose unresolved-reference / type-inference 连带错误，但没有发现 `expecting`、`unclosed`、`unexpected tokens` 这类语法解析错误。
3. 可脱离 Android 编译的 `ControlCenterModels.kt + ControlStatusParser.kt + LogRedactor.kt` 已由 `kotlinc` 真正编译并执行测试。
4. 脱敏测试已确认：同一 QQ 生成稳定匿名 ID；QQ、Token、Authorization、Cookie、非 loopback IP、QQ 扫码 URL、Android 私有路径不会保留原值。
5. `AndroidManifest.xml` 与所有 `res/xml/*.xml` 均通过 XML 解析。
6. 内置核心组件 `engine.zip` SHA-256 为：
   `85fe83dbc8c26c8dfbc4d85d42930bfbec96e144ad34654f7b73fc1da5715453`
   与 `engine.sha256` 内容一致；`unzip -t` 无压缩错误。
7. 解包后 76 个 `.sh` 文件与 `astrctl` 均通过 `bash -n` 语法检查。
8. 核心组件已核验存在 dev4 所需协议入口：
   `web-url`、`snowluma-login-request`、`engine-snowluma`、`engine-napcat`、`export-start`、`export-status`、`export-cancel`、`logs-list`、`log`。
9. dev4 未改变 `engine.zip`，所以从 dev3 更新 App 本体不要求再次刷核心组件。

## 本版重点代码检查

- 一级导航仅剩：总览 / 维护 / 日志 / 控制台。
- 维护页包含：启动或重启全部服务、QQ 扫码登录、NapCat/SnowLuma 切换、自动恢复、OneBot 修复、插件依赖修复、脱敏/完整诊断包导出、设备重启。
- 完整诊断包导出有敏感信息二次确认；脱敏包为默认入口。
- 日志一级仅四类，默认显示脱敏内容；UI 脱敏在 `Dispatchers.Default` 执行。
- 日志快速切换有 stale-result guard；相同状态轮询不再造成无意义整页状态发射。
- 内嵌 WebUI 只接受本机 URL；外部链接交给系统浏览器；文件读取能力默认关闭；文件上传结果只接收 `content://` URI。
- Android Activity 声明横竖屏相关 `configChanges`，用于避免旋转时重建整个 WebView 控制台。

## 尚需真机 / CI 验证

当前容器没有完整 Android SDK 与 Compose classpath，因此这里没有声称 APK 已完整编译通过。仓库中的 GitHub Actions 会安装 Android 37 平台并实际执行 `:app:assembleDebug`。

真机重点按 `DEV4-TESTING-CHECKLIST.md` 验证：

- 横/竖屏四个一级页面连续切换；
- 120 Hz 下页面转场、按钮按压和日志尾随的最低帧；
- NapCat / SnowLuma 双向切换；
- 两套 QQ 扫码流程；
- AstrBot / QQ WebUI 的 Cookie、输入法、文件选择、下载、旋转保活；
- 脱敏日志与诊断包是否遗漏业务实际出现的敏感字段。
