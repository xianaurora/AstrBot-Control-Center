# v1.6.0-dev21 静态验证报告

已在当前容器完成：

- 最终 `engine.zip` 与 `engine.sha256` 一致；内嵌 core 为 `1.6.0-dev12 / 16012`。
- `manifest/module-files.sha256` 全量校验通过。
- core Shell 文件语法检查通过。
- `scripts/verify-source.sh` 输出 `SOURCE_GATE_OK`。
- `ControlCenterModels.kt + ControlStatusParser.kt` 使用本机 `kotlinc` 实际编译通过。
- Android/Compose 源码额外做 Kotlin 解析检查；当前容器缺 Android SDK/Compose classpath，因此不声称本地 `assembleDebug` 已完成。
- 工作台旧的 `WorkbenchRail` 已移除，统一入口页和 focused workspace 返回栏已接入。
- 未保存操作栏只保留固定底部版本，不再在环境内容流或 QQ 引擎卡片中重复。
- QQ 登录触摸后端使用截图尺寸缩放并转换到当前 X11 窗口根坐标。
- core 中不存在 `flock -x -w`；设置锁使用 BusyBox 兼容的 `flock -xn` 有限重试。

完整 Android Compose/Kotlin 编译、资源链接、APK 打包和签名指纹校验仍由附带 GitHub Actions 完成。
