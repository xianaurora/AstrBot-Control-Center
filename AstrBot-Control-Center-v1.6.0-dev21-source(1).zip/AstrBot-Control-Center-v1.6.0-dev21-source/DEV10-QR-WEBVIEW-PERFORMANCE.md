# dev10: console readiness, QR fallback, rendering stability and motion

This revision is based on the 2026-08-11 diagnostic bundle and current Android, noVNC, x11vnc and Chromium documentation.

- Native AstrBot/QQ consoles wait for the matching `*_WEB_READY` state before navigating the WebView. If readiness does not arrive inside the bounded window, the app stops instead of opening a known blank page.
- QR WebViews use no-cache mode and fall back from `astrbot_qr.html` to stock noVNC `vnc.html` when the custom page returns a main-frame HTTP error or the center-region framebuffer probe remains unusable.
- The fallback is treated as the same QR session so Compose does not immediately navigate back to the failing custom page.
- Stock noVNC fallback requests `autoconnect`, `resize=scale`, `quality=9`, `compression=0`, `logging=warn`, and `path=websockify`. The custom client also uses `compressionLevel=0` and `qualityLevel=9` because this transport is loopback-only and short-lived.
- The custom QR HTML is written atomically before it is exposed through websockify, avoiding reconnects reading a partially-written page.
- x11vnc disables wireframe and uses `-wait 10 -defer 10 -nowait_bog -nonap` for the short-lived login desktop to favor responsiveness over idle CPU savings.
- dev8 automatic blank-frame recovery could persist the plain render state `compat`; dev7 treats that legacy value as stale. New explicit compatibility requests are stored as `compat-manual`.
- Compatibility rendering explicitly selects Chromium SwiftShader (`--use-gl=swiftshader`) and remains manual-only; normal QR recovery still does not restart QQ.
- Android WebView now handles renderer-process termination by discarding the dead instance and creating a new one, matching Android's documented recovery requirement instead of allowing the app to terminate with the renderer.
- The overview “下一步” area is an animated beacon card with a pulsing status dot and staggered character motion, making the immediate action visually dominant without turning the whole page into a looping animation.
