# Hotfix3: install tap lock + startup restore state

This hotfix addresses two field-observed UI/state issues after Hotfix2:

1. **Engine install button appeared unresponsive** because `existingEngineInfo()` performed a Root shell call before `busy=true` was published. Multiple taps could therefore launch concurrent install coroutines. Hotfix3 marks the UI busy before the first suspend point and enforces a single in-flight Engine install job.
2. **After reboot the app briefly showed the welcome/start page** because `InstallerUiState` defaulted to `WELCOME` while asynchronous restore detection queried boot id, protocol and Engine status. Hotfix3 adds a `RESTORING` startup screen and publishes the resolved READY/RUNTIME_PLAN destination before slower secondary detail queries finish.

The KernelSU absolute-path fix from Hotfix2 remains unchanged.
