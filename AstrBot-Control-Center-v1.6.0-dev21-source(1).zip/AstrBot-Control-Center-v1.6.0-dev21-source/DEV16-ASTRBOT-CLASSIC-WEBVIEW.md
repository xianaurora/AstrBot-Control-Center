# dev16 — AstrBot 白屏：移出 Compose WebView

## 诊断结论

- 2026-08-12 的诊断包显示 AstrBot 4.26.8 WebUI 已 ready，6185 服务存在；模块版本仍为独立的 `v1.6.0-dev11`。
- dev14 的 no-cache 与 dev15 的站点状态/软件层恢复均未改变用户看到的纯白页面。
- 诊断包此前只包含 root/core 日志，不包含 Android App 的 WebView console、HTTP、renderer 或实际像素信息，因此继续修改前端探针只是在猜。

## dev16 改动

1. AstrBot 不再使用 Compose `AndroidView` 中的 `EmbeddedConsoleWebView`。
2. 点击 AstrBot 后自动启动 `AstrBotWebActivity`；WebView 是 Activity 经典 View 树的直接子 View。
3. Activity 底部使用原生状态面板，WebView 即使整块白屏也不会再“什么都看不到”。
4. `onPageFinished` 后同时记录 DOM 探针和 WebView 实际像素；PixelCopy 前会隐藏原生诊断面板，避免把面板误当成网页内容。
5. WebView 区域采样达到 99.2% 近白时明确显示“检测到真实白屏”。
6. 记录 WebView provider/version、JS console warning/error、主框架与静态资源 HTTP 错误、renderer 退出、DOM/像素统计。
7. 发生真实白屏或错误时，将 App 日志复制到 `/data/adb/astrbot_standalone/logs/app-webview.log`，下一份诊断包可直接收集。
8. 默认回到正常硬件渲染和 `LOAD_DEFAULT`；“重新加载”才临时 no-cache，“切到兼容渲染”由用户显式触发，不再自动清登录/站点数据。

## 关于 405

诊断中有一条 `GET / -> 405`，但 AstrBot 同时运行 6185 WebUI 与 6199 OneBot，现有 access log 没有目标端口，不能证明该 405 来自 6185。官方 4.26.8 Dashboard 源码给 `/` 注册的是 GET 首页，因此 dev16 不以这条不确定日志为修复依据。
