# dev7 真机测试清单

## 总览 / 下一步
- [ ] SnowLuma/QQ 正在启动时，右侧胶囊显示“等待 QQ 登录窗口准备完成”，不出现“现在无需操作”。
- [ ] 服务启动中显示“等待服务启动完成”。
- [ ] OneBot 已连接且链路稳定时才允许出现“现在无需操作”。

## SnowLuma 扫码
- [ ] 日志出现 `SNOWLUMA_QQ_WINDOW_PLACED`，位置接近 1024×640 桌面中央。
- [ ] `snowluma-wm-main.log` 不再出现 `Invalid command line argument --display`。
- [ ] 正常二维码通过验证后才显示。
- [ ] 制造全黑 framebuffer 时触发一次 compat 恢复；第二次仍空明确报错，不循环重启。
- [ ] compat 恢复后的 SnowLuma 日志出现 `render=compat`。

## AstrBot / QQ 控制台
- [ ] AstrBot 6185 可用时正常渲染，不再长时间纯白。
- [ ] 故意让 SPA 不渲染时自动 reload 一次，仍为空出现明确错误卡。
- [ ] QQ WebUI 不受标准 DOM probe 误判。

## 性能
- [ ] 静止页面出现 0 FPS 不视作失败。
- [ ] 录制总览→运维→控制台连续 10 轮，重点看交互期间 P95 frame time / jank / >16.7ms（60Hz）或 >8.3ms（120Hz）的帧。
- [ ] 状态刷新时标题不再逐字符大规模重组；日志正文仍不做逐行动画。
