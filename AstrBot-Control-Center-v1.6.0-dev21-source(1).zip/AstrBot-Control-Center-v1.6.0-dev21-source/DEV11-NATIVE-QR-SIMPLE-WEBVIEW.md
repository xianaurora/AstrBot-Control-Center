# dev11 — 原生扫码 + 简化 WebView

## 设计变化

普通 SnowLuma 扫码不再把 Linux QQ 桌面经过 x11vnc → websockify → noVNC → Android WebView。核心在 Xvfb 中定位可见 QQ 窗口，使用 FFmpeg `x11grab` 截取窗口区域为 PNG，再由控制中心通过 Root Bridge 读取并直接用 Compose `Image` 显示。

noVNC 仍保留为“完整桌面”高级入口，用于验证码、异常确认等需要交互的场景。

AstrBot / SnowLuma 管理页 WebView 移除 DOM/canvas 空白启发式、自动清缓存、127.0.0.1/localhost 互换与自动 reload。现在只使用 WebView 原生页面生命周期、主框架 HTTP/网络错误、JS console 诊断以及 renderer process gone 恢复。

## 关键命令

- `astrctl snowluma-login-request main`：准备 QQ 登录窗口，不启动 noVNC。
- `astrctl snowluma-login-frame main`：刷新一张 PNG，返回 `FRAME|state|width|height|detail|base64`。
- `astrctl snowluma-login-desktop main`：显式启动高级 noVNC 完整桌面。

## 性能意图

扫码只需要稳定的静态二维码，不需要 60/120 FPS。正常路径约 0.9 秒刷新一次 PNG，显著减少 WebSocket/canvas/WebView 合成层和持续重绘。

## 预发布捕获自测

实现原生截图时额外发现并修复了一个会让 PNG 永远生成失败的问题：FFmpeg 会根据输出文件扩展名选择 muxer，`frame.png.tmp.<pid>` 末尾不是 `.png`，因此会报 `Unable to choose an output format`。dev11 改成 `frame.tmp.<pid>.png`，并显式使用 PNG 编码；X11 输入也统一为 `:<display>.0+<x>,<y>`。

该命令形态已经在本地 Xvfb + FFmpeg 上做过最小验证：旧临时文件名返回非零，新写法能生成有效 PNG。源码门禁同时固定检查临时文件扩展名、X11 display/screen/offset 写法和 PNG 编码参数，避免后续重构把这个问题带回来。

## 真机验证重点

1. 点击 SnowLuma 扫码时，默认页面应直接出现 QQ 登录窗口 PNG，不应启动 x11vnc/noVNC。
2. PNG 大约每秒更新一次即可；扫码不追求视频帧率。
3. 只有点击“完整桌面”时才启动 noVNC。
4. AstrBot 控制台只做一次正常 WebView 加载；页面报错应来自主框架 HTTP/网络回调或 JS console，而不是 DOM 空白猜测。
