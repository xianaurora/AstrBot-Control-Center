# v1.6.0-dev5 — 运维工作台、扫码桌面与 Motion System

## 这一版为什么重构

dev4 已经把 WebUI、维护和日志迁进了原生应用，但真机反馈暴露了四个问题：

1. 维护和日志被拆成两个一级入口，排障时需要来回切换。
2. 当前使用 SnowLuma 时，部分 OneBot 原因仍显示“NapCat 未运行”。
3. QQ 扫码页直接暴露 noVNC 默认蓝色工具栏，而且“远程桌面连通”被错误等同于“QQ 登录窗口已准备好”。
4. 日志页存在设备相关的 LazyColumn/选择/跟随时序崩溃风险；dev4 还出现过一次 Compose DSL receiver 编译错误。

## 新的信息架构

一级导航收敛为三个目的地：

- **总览**：只回答“现在怎么样”和“下一步做什么”。
- **运维**：把操作、实时日志、诊断放在同一任务空间。
- **控制台**：AstrBot WebUI、当前 QQ WebUI、QQ 扫码工作台。

横屏/大屏下，运维页默认采用“左侧操作 + 右侧实时日志”的并排布局；竖屏下使用“操作 / 日志 / 诊断”内部切换。这样重启、修复、切换 QQ 运行方式之后，可以在同一页立即观察日志。

## “当前情况 / 下一步”

总览顶部新增一个动态 Situation Card。它不是单纯的状态摘要，而是把底层状态翻译成用户能立即行动的信息：

- SnowLuma 正在运行但 QQ 需要登录 → 下一步“扫码登录”。
- OneBot 认证异常 → 下一步“OneBot 修复”。
- QQ 运行方式异常 → 下一步“进入运维”。
- 服务已停止 → 下一步“启动服务”。
- 全部正常 → 明确显示当前无需操作。

运维和扫码页也沿用同一语言，不再只靠 Toast 告知过程。

## SnowLuma / NapCat 状态分流

核心组件升级为 **1.6.0-dev3**。`astrctl` 的 OneBot 原因、认证日志、安装就绪判断和 bridge audit 都改为读取当前 `QQ_ENGINE`：

- `QQ_ENGINE=snowluma` 时只使用 SnowLuma 的运行状态和日志判断。
- `QQ_ENGINE=napcat` 时只使用 NapCat 的运行状态和日志判断。

Android 端 `ControlStatusParser` 还保留一道兼容防线：如果旧核心组件在 SnowLuma 模式下仍返回包含 NapCat 的 `ONEBOT_REASON`，UI 会使用当前 QQ 状态替代，避免首页继续出现误导文案。

## QQ 扫码工作台

扫码不再把 noVNC 默认页面原样塞进 App。

核心组件现在生成 `/usr/share/novnc/astrbot_qr.html`，该页面：

- 不显示 noVNC 蓝色顶部工具栏。
- 不显示 `Connected to localhost` 和 `Send CtrlAltDel`。
- 只保留远程画布和极简连接状态。
- 使用深色背景，交给 Android 原生圆角容器承载。

同时新增 `xdotool` 窗口探针。扫码流程只有在检测并拉起真正的 QQ 登录窗口后才返回 `LOGIN|ready|...`。如果 VNC 已通但 QQ 窗口没有出现，核心组件会返回失败原因，而不是让 App 展示一块“技术上连接成功、用户看起来却是灰屏”的桌面。

Android 端只在 `LOGIN|ready` 后创建 WebView；准备阶段显示原生进度卡，并明确“正在做什么 / 下一步是什么”。

## 日志页闪退加固

这一版把日志视图改成一个有界 `LazyColumn`，并移除了围绕实时 Lazy 列表的 `SelectionContainer`。复制通过顶部工具栏完成。

自动跟随尾部时：

1. 先等待 `LazyColumn` 的 item provider 真正包含目标行。
2. 近距离使用 `animateScrollToItem`，远距离直接 `scrollToItem`。
3. 日志源快速切换时，旧请求会被 request id 丢弃。
4. 如果日志快照在 measure 与 scroll 之间被替换，捕获 `IndexOutOfBoundsException`，等待下一次快照安全跟随；协程取消仍正常向上传递。

这不是对某一条未知 logcat 堆栈的“猜测修复”，而是把 dev4 日志页最容易出现布局/滚动竞态的路径直接消除并加固。

## 动画策略

这版不再把“动画多”当作“灵动”。动效按角色分层：

- **Press**：高频点击只做极轻的 0.96–0.98 缩放和快速回弹。
- **Spatial**：导航与页面层级用短距离位移 + fade，强调来源和方向。
- **State Morph**：当前情况、QQ 登录状态、运维过程在同一容器里连续变换。
- **Expressive**：只把更明显的 spring / scale 留给扫码准备、成功、低频状态完成等时刻。

横屏导航使用“单个选中指示器在项目间移动”，而不是每个导航项各自突然换底色。日志行本身不做逐行入场动画，以免在 120 Hz 设备上制造不必要的重组和绘制压力。

## 编译与源代码门禁

`scripts/verify-source.sh` 在构建前检查：

- 内置核心组件 ZIP SHA-256。
- ZIP 完整性及 `manifest/module-files.sha256`。
- 所有核心组件 shell 脚本 `bash -n`。
- XML 可解析。
- 核心组件版本必须是 1.6.0-dev3。
- 自定义扫码页和 QQ 窗口 readiness gate 必须存在。
- `ControlCenterApp.kt` 不允许重新引入 dev4 出错的 `AnimatedVisibility` DSL 模式。
- 不允许旧的 `SERVICES / LOGS / MORE` 一级导航重新出现。

GitHub Actions 进一步执行 `:app:testDebugUnitTest :app:assembleDebug`。Parser 和脱敏器已经有 JVM 单元测试，最终 APK 只有在真实 Android/Compose 编译通过后才会被上传为 artifact。
