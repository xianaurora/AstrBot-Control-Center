# dev19 — QQ 登录可触摸 / 原生完整桌面 / AstrBot 安全区 / 工具页去重

## 本轮真机回归

dev18 真机测试确认了四个问题：

1. SnowLuma 的“完整桌面 / noVNC”在目标平板上只显示黑画布。
2. 原生 QQ 登录画面能看到 QQ 自己的“登录”等控件，但触摸没有正确落到真实 QQ 窗口。
3. AstrBot 独立 WebView Activity 的返回栏仍可能压进 Android 16 状态栏。
4. 工具页仍重复显示“当前情况 / QQ 等待登录”卡。

## dev19 调整

- QQ 登录画面继续来自 Xvfb 中的真实 QQ 窗口，但触摸坐标现在先按 `ContentScale.Fit` 的实际绘制区域换算，再通过 SnowLuma `main` 实例的真实 DISPLAY 和 `xdotool` 点击对应窗口坐标。
- 不再从错误的 Android 配置路径猜 DISPLAY；Android 端直接读取 `snowluma-instance-list` 中 `main` 实例的 DISPLAY。
- “完整桌面”保留，但**不再打开 noVNC/WebView**。Android 直接从 SnowLuma Xvfb 抓取整张 1024×640 左右的桌面 JPEG，并把点击映射回 X11 桌面，因此黑 noVNC 画布不再参与这条路径。
- 完整桌面与 QQ 登录窗口都只有用户实际触摸时才发送一次点击，没有自动点击循环。
- AstrBot classic WebView 的加载/渲染实现保持不变，只加强 Activity 外壳：首帧先使用系统状态栏高度兜底，随后从 `window.decorView` 接收真实 WindowInsets，显式移动 toolbar/WebView/progress/诊断卡；renderer 重建后也沿用同一 inset。
- 工具页删除重复 `SituationCard`，该引导只在“总览”保留一份。

## 保持不变

- 内嵌 core 仍为 `v1.6.0-dev11 / 16011`，本轮不重打 engine.zip。
- AstrBot 已验证解决白屏的 classic Activity WebView 路径不改。
- dev17 起使用的固定开发更新证书继续沿用。
