# Build status — dev21

- Android App: `1.6.0-dev21` / `162100`
- Embedded core: `1.6.0-dev12` / `16012`
- Core change: BusyBox-compatible settings lock; fixes QQ engine switching rc=87.
- Stable dev signing: unchanged from dev17+
- Full Android Gradle build: requires GitHub Actions / Android SDK environment.
