buildscript {
    dependencies {
        // AGP 9 uses built-in Kotlin; this upgrades the embedded KGP to the
        // version used by the Compose compiler plugin below.
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.3.21")
    }
}
plugins {
    id("com.android.application") version "9.3.1" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.3.21" apply false
}
