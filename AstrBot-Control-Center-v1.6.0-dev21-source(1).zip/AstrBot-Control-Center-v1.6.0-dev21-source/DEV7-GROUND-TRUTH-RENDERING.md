# v1.6.0-dev7 — 状态真值、扫码渲染与控制台空白恢复

## 这版解决什么

1. **下一步必须是真实状态。** 处理中/启动中不再显示“现在无需操作”；被动状态胶囊直接展示 `SituationData.next`。
2. **SnowLuma 黑屏不再只看 VNC 是否连通。** 核心会把 QQ 登录窗口居中、映射、raise/focus；App 只在中心 ROI 像素验证通过后揭开远程桌面。
3. **修正 Openbox 启动。** 不再使用该 Ubuntu Openbox 不支持的 `--display`，统一通过 `DISPLAY=... openbox`。
4. **兼容恢复有上限。** QR probe 的 `unknown/notready/blank` 都进入有限重试；只允许一次兼容渲染恢复，第二次仍空则明确失败。
5. **AstrBot 空白页可被检测。** 标准控制台加载结束后做轻量 DOM probe；空白只自动 reload 一次，仍为空时把“服务在运行但页面未渲染”显示给用户。
6. **不为了 FPS 数字制造无意义重绘。** 静止界面允许 0 submitted frames；优化集中在交互期间的长帧，页面标题从逐字符动画降为整段过渡。

## SnowLuma 真值链路

`QQ process → X11 window exists → centered/mapped/raised → VNC framebuffer → center ROI pixel probe → QR visible`

任何前置条件没有通过，都不能把页面标成“可扫码”。

## 控制台恢复链路

`HTTP/WebView load → onPageFinished → DOM probe → ok / one reload → explicit render error`

这里区分“后台服务可用”和“WebView 页面真正完成渲染”，避免白板看起来像正常状态。
