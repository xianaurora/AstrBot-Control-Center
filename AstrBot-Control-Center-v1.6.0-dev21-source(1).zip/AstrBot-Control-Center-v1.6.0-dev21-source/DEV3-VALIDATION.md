# dev3 validation

## 已完成的静态验证

- `ControlCenterModels.kt` + `ControlStatusParser.kt` 使用本机 Kotlin 编译器独立编译通过。
- 使用模拟 `STATUS|key|value` 数据运行解析测试，确认核心组件版本、QQ 在线、运行链路、就绪状态与 `HEALTHY` 健康状态均可正确解析。
- 当前 14 个 Kotlin 源文件执行括号 / 字符串 / 注释平衡扫描，无未闭合结构。
- 对当前 `engine-dev2.zip` 的 `astrctl` 逐项确认 dev3 使用的命令存在：
  - `web-status`
  - `web-status-live`
  - `console-ping`
  - `logs-list`
  - `log`
  - `web-url`
  - `queue`
  - `snowluma-login-request`
- 没有修改内置 `engine.zip`，其版本与 hotfix5 保持一致。

## dev3 额外防护

- `astrctl queue` 返回 `QUEUED|busy|...` 时，不再误报“新操作已提交”，而是提示已有操作正在执行。
- 打开 QQ 登录页或 Web 控制台时捕获 URI 打开异常，避免设备没有可用浏览器时直接崩溃。
- 工作状态的呼吸动画只在 `WORKING` 时运行；稳定状态不会保留无意义的无限动画任务。
- 中文界面进一步收敛技术英文：控制中心标题、运行状态标签、服务守护与系统信息使用中文表达。

## 仍需 GitHub Actions / Android Studio 验证

当前执行环境没有 Android SDK 与 Compose classpath，因此无法在本地完成 Android APK 编译。项目已保留 GitHub Actions 构建流程，最终应至少完成：

1. `:app:assembleDebug`
2. 竖屏首次进入控制中心
3. 横屏首次进入控制中心
4. 总览 ↔ 服务 ↔ 日志 ↔ 更多连续切换 30 次
5. 启动 / 停止 / 重启快速连点测试
6. 日志跟随与暂停跟随测试
7. NapCat 需要登录时“打开 QQ 登录”
8. 横竖屏切换后日志和当前 Tab 状态
9. App 前后台切换，确认后台不持续 Root 轮询
10. 165 Hz / 120 Hz / 60 Hz 真机观察动画帧感
