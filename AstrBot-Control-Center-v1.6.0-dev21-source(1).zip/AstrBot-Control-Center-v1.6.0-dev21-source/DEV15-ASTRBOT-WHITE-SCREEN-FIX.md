# dev15 — AstrBot 白屏二次修复

## 诊断依据

2026-08-11 22:58:53 的诊断包确认：

- AstrBot 4.26.8 进程正常，6185 WebUI 已 ready。
- AstrBot 日志明确显示当前使用 4.26.8 包内自带的 Dashboard `dist`，因此 dev14 猜测的“服务端旧 dist / hashed bundle 混用”不是完整根因。
- dev14 的 DOM 探针没有把纯白页面判为失败，说明原探针把“存在 DOM 节点”误当成了“用户实际看到了界面”。
- 目标设备为 Lenovo TB321FU，Android 16 / SDK 36。

## dev15 改动

1. AstrBot 在 Android 16 上单独使用 WebView 软件兼容渲染层；QQ/SnowLuma 不受影响。
2. AstrBot 不再启用 `offscreenPreRaster`，避免大 SPA 在 Compose + WebView 场景中提前栅格化后出现空白合成面。
3. 空白检测不再按“节点数量”判断，而是检查：可见文本、真实可见元素、可见交互/图形元素、非白色绘制区域、根节点尺寸与 document.readyState。
4. 第一次确认空白：只清理 AstrBot 的非认证 LocalStorage 与 SessionStorage，保留 `token/user` 等登录字段，然后重新加载。
5. 第二次仍空白：只删除 AstrBot `http://127.0.0.1:6185` 这个 origin 的 WebStorage，并强制软件渲染后再次加载。此步骤可能要求重新登录 AstrBot，但不会清 QQ/SnowLuma 的站点数据，也不会清全局 Cookie。
6. 第三次仍没有可见内容：停止自动恢复，显示 JS console、资源错误、挂载摘要、WebView provider/version 与当前渲染层，并保留“浏览器打开”。
7. 所有自动恢复都有上限，不会形成无限 reload。

## 服务器侧结论

本次诊断中 AstrBot 本身不是“未启动”：日志显示 `AstrBot v4.26.8 WebUI is ready`，并且模型请求正常。因此 dev15 的重点放在 Android WebView 持久化站点状态和 Android 16 渲染兼容层，而不是重复重启 AstrBot。
