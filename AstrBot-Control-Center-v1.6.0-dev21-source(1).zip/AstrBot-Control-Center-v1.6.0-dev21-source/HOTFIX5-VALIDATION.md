# hotfix5 validation

本轮未修改内置核心组件二进制内容；`app/src/main/assets/engine.zip` 与 hotfix4、外发 `engine-dev2.zip` 的 SHA-256 保持一致。

已执行：

- Kotlin 源码括号/字符串/注释边界静态检查：通过；
- `kotlinc` 解析级检查：未发现 syntax / expecting / unclosed 类语法错误；由于当前环境没有 Android/Compose classpath，完整编译会在 AndroidX import 处停止；
- 用户界面文案扫描：不再把 “Engine” / “Root Engine” 作为用户术语；界面统一使用“核心组件”。Root 管理器名称（KernelSU / Magisk / APatch）按实际技术名称保留；历史兼容输出仍通过 `uiCopy()` 映射。
- 教程页滚动结构复查：紧凑窗口为列表→详情单滚动容器，宽窗口为受约束 list-detail，两种方向均不再嵌套同方向无限滚动；
- 主要交互按钮统一经过 `MotionButton` / `MotionOutlinedButton`；
- 内置核心组件 ZIP 哈希未变化。

当前环境仍缺少完整 Android SDK / Gradle wrapper JAR，因此没有在本机产出 APK。应使用项目内 GitHub Actions 或 Android Studio 完成最终 Android 编译与真机回归。
