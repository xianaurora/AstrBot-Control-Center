# dev10 buildfix1

GitHub Actions failed at `:app:compileDebugKotlin` because `SituationAction` invoked Compose UI (`Surface`, `Text`, and `MotionButton`) without being marked `@Composable`.

Fix:

- Restore `@Composable` on `SituationAction`.
- Extend `scripts/verify-source.sh` so the three overview situation composables (`SituationText`, `NextStepBeacon`, `SituationAction`) must retain `@Composable`.
- No runtime/core behavior or embedded engine version changed. App remains `1.6.0-dev10 / 160800`; embedded core remains `1.6.0-dev7 / 16007`.
