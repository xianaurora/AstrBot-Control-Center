# v1.6.0-dev4 — 维护中心 / 内嵌控制台 / 脱敏日志

## 这版解决什么

dev3 的主要问题是“功能已经存在，但入口太平”：日志源一次铺得太多，维护藏在低优先级页面，WebUI 仍然要跳浏览器。dev4 重新整理一级信息架构，而不是继续往原页面塞按钮。

一级导航固定为：

- 总览：只回答 AstrBot / QQ / OneBot 是否可用。
- 维护：所有会改变运行状态的操作集中在这里。
- 日志：观察、筛选、脱敏和导出。
- 控制台：把 AstrBot WebUI 与当前 QQ WebUI 直接嵌进 App。

## 维护中心

维护成为一级入口，并在运行状态需要处理时显示状态点。首屏只放最常用动作：

- 启动 / 重启全部服务
- QQ 扫码登录
- QQ 运行方式切换（NapCat / SnowLuma）

其余操作按“诊断与修复 / 日志与诊断 / 设备与帮助”分组。切换 QQ 运行方式和重启设备都有明确确认，不使用含糊的单个“重启”入口。

## QQ 运行方式

调用现有核心组件协议：

- `astrctl queue engine-napcat app`
- `astrctl queue engine-snowluma app`

核心组件负责停止旧 QQ 方案、修改选择、启动新方案、失败回滚和重新采集状态；App 只负责提交、展示进行态和完成后的验证，不复制底层切换逻辑。

## 内嵌 WebUI

新增 Compose + Android WebView 控制台：

- AstrBot 控制台
- 当前 QQ 控制台（NapCat 或 SnowLuma）
- QQ 扫码入口直接在 App 内打开
- 后退 / 前进 / 刷新
- Cookie 与登录态保持
- JavaScript / DOM Storage / WebSocket 所需的普通 WebView 能力
- 文件选择器
- 下载交给 Android DownloadManager
- 横竖屏切换保留 Activity / WebView 实例

安全边界：

- 核心组件返回的控制台 URL 只接受 `localhost / 127.0.0.1 / ::1`。
- WebView 内仅允许本机 HTTP(S) 页面继续在 App 内导航；外部链接交给系统浏览器。
- Network Security Config 默认禁止全局明文，仅为 localhost / 127.0.0.1 开放本机 HTTP。
- 禁止 WebView 直接读取 `file://` 文件。

## 日志层级

原先十多个日志源不再同时出现在一级列表。现在一级只显示：

- 概览
- AstrBot
- QQ
- 系统

具体日志源只在进入对应分类后出现，减少长期占屏的按钮和列表项。

## 脱敏日志

日志默认使用“已脱敏”显示，可临时切回原始日志。UI 侧脱敏覆盖：

- QQ / UIN / account 字段
- Token / Secret / Password / API key / Session
- Authorization / Bearer
- Cookie / Set-Cookie
- URL 认证参数
- Android / 设备标识字段
- 非 localhost IP
- 典型 Android 用户私有路径

同一敏感值使用 SHA-256 派生的短匿名标识，例如 `<QQ:15E2B0>`，从而保留“两个日志位置是否属于同一账号/地址”的排障关系。

UI 脱敏在 `Dispatchers.Default` 完成，不在 Compose 主线程执行多轮正则替换。导出的脱敏日志包仍调用核心组件原有的 `export-start redacted`，因此导出侧继续使用核心组件已有的隐私审计与脱敏流程。

## 动画与 120 Hz 流畅性

dev4 不删除动画，调整为更统一的物理运动：

- 一级页面切换：短距离位移 + 淡入淡出，位移使用 spring。
- 导航选中：颜色与缩放连续过渡。
- 维护主操作：按钮按压使用 `graphicsLayer` 缩放，进行态原位置变为进度反馈。
- QQ 运行方式：选中容器与比例连续变化。
- 控制台：WebUI 加载进度覆盖在容器顶部，不让整个页面重排。
- 日志：只有新尾部真正变化时才触发跟随；距离太远时直接定位，避免每次轮询对长列表执行大距离动画。
- 日志脱敏移出 UI 线程；WebView progress 只在 loading 布尔值真正变化时写状态。

用户真机截图显示 120 Hz 设备上 MAX 119.2 / AVG 107.1 / MIN 44.9 FPS。dev4 的目标不是追平均值，而是减少偶发长帧造成的可感知卡顿。

## 核心组件兼容性

dev4 没有修改内置核心组件 ZIP。继续使用 v1.6.0-dev2 / protocol v1，因为本版需要的命令已经存在：

- `web-url`
- `snowluma-login-request`
- `queue engine-napcat|engine-snowluma`
- `logs-list / log`
- `export-start redacted|raw`
- `export-status / export-cancel`

因此从 dev3 升级 dev4 不需要为了这些 UI 功能重新刷核心组件。

## dev4 收尾优化

- 状态轮询不再因为 `STATUS_TIME` 每次变化就触发整个控制中心重新发射 UI 状态；只有可见运行状态变化时才更新，降低固定轮询与页面动画撞帧的概率。
- 日志列表使用“行内容 + 同内容出现序号”的稳定 key，尾部窗口滚动时尽量复用已有行，而不是用当前位置作为 key 导致整屏条目失效。
- 日志源快速切换时丢弃前一个来源晚到的 Root 读取结果，避免新标签页短暂闪出旧日志。
- WebUI 文件选择器只把 `content://` 结果交给 WebView；`file://` 等结果直接拒绝。WebView 同时关闭直接文件访问及 file URL 跨域访问。
- 本机明文网络例外仅覆盖 localhost / IPv4 loopback / IPv6 loopback，其他目标仍继承全局禁止明文策略。
