# dev20 — QQ 原生触摸与完整桌面

本轮针对 dev18 真机截图中的四个回归：

1. 完整桌面 noVNC 黑屏。
2. QQ 登录窗口能看到“登录”等按钮，但触摸没有落到真实 QQ 窗口。
3. AstrBot 返回栏被 Android 16 状态栏覆盖。
4. 工具页重复显示“当前情况 / QQ 等待登录”。

## 修复

- QQ 登录触摸不再从不存在的 Android 配置路径猜 X11 DISPLAY；直接读取 `snowluma-instance-list` 的 main 实例 DISPLAY，再用 `xdotool` 点击真实 QQ 窗口相对坐标。
- “完整桌面”不再创建 noVNC WebView。Android 直接从 SnowLuma Xvfb 用 FFmpeg 抓取整张桌面 JPEG，并把用户点击按实际显示比例映射回 X11 桌面坐标。
- 普通 QQ 登录窗口和完整桌面都只在用户真实触摸时发送一次点击，不做自动点击循环。
- AstrBot classic Activity 保留已验证的 WebView 渲染路径，只加强系统栏安全区：首帧使用系统资源高度兜底，随后从 decor WindowInsets 精确更新 toolbar/WebView/progress/诊断卡位置；WebView renderer 重建也沿用当前 inset。
- 工具页删除重复 SituationCard；“当前情况”只保留在总览。

## 不变

- 内嵌 core 仍为 `v1.6.0-dev11 / 16011`，engine.zip 不修改。
- 固定开发签名继续沿用 dev17 的证书。
- 桌面名称仍为 `AstrBot CC`。
