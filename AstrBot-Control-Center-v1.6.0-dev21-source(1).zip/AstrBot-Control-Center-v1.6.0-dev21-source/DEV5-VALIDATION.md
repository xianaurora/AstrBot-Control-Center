# v1.6.0-dev5 验证记录

## 版本

- Android App: `1.6.0-dev5` / `versionCode 160300`
- 内置核心组件: `1.6.0-dev3` / `versionCode 16003`

## 已在当前构建环境实际执行

### 源码 / 资源门禁

执行：

```bash
./scripts/verify-source.sh
```

检查项：

- `engine.zip` SHA-256 与 `engine.sha256` 一致。
- ZIP 可完整解压。
- `manifest/module-files.sha256` 全部校验通过。
- 78 个 shell / astrctl 类脚本通过 `bash -n`。
- Android XML 全部可以被 XML parser 解析。
- 核心组件版本、自定义扫码页、QQ 窗口 readiness gate 存在。
- dev4 触发隐式 receiver 编译错误的 `AnimatedVisibility` 模式没有重新出现。
- 旧四入口导航标识没有重新出现。

### 纯 Kotlin 行为测试

在本地使用 `kotlinc` 对 `ControlStatusParser`、`ControlCenterModels`、`LogRedactor` 做过脱离 Android Framework 的编译/运行检查：

- SnowLuma 模式下旧核心组件返回 `ONEBOT_REASON=NapCat 未运行` 时，解析结果不会再把 NapCat 文案交给 UI。
- `activeQqUp / activeQqReady` 跟随 `QQ_ENGINE`。
- 日志脱敏对 QQ / token / IP 使用稳定匿名标识，并保留 loopback 地址。

同样的行为已加入 `app/src/test/...` JUnit 测试，并由 GitHub Actions 的 `:app:testDebugUnitTest` 强制执行。

### 核心组件行为

- `onebot_reason()` 在 SnowLuma mock 状态下返回 SnowLuma 原因，不再返回 NapCat。
- `snowluma_instance_login_url()` 指向 `astrbot_qr.html`。
- `guest/run-snowluma.sh` 只有在 `wait_and_raise_qq_window()` 找到并拉起 QQ 窗口后才宣布扫码桌面 ready。
- `xdotool` 已加入 SnowLuma QR 依赖检查/安装路径。

## Android / Compose 完整编译状态

当前容器没有完整 Android SDK / Gradle 分发包，并且当前运行环境不能联网下载这些构建依赖，因此**这里没有宣称本地 `assembleDebug` 已完成**。

为了避免再次出现 dev4 那种“源码包发出后才由 GitHub 发现 Compose 编译错误”的问题，dev5 的 GitHub Actions 已改成硬门禁：

```text
Static source gate
→ :app:testDebugUnitTest
→ :app:assembleDebug
→ 只有全部成功才上传 APK artifact
```

也就是说，GitHub Actions 产出的 dev5 APK 才代表真实 Android/Compose 编译已经通过；任何 Kotlin/Compose 编译错误都会在上传 APK 前直接使 workflow 失败。

## 仍需真机验证

无法在容器内替代的项目包括：

- SnowLuma 实际 X11/QQ 窗口标题是否被 `xdotool` 在该设备上稳定识别。
- noVNC 自定义页面在 WebView 中的触摸、缩放和横竖屏体验。
- 点击日志闪退在用户设备上的最终回归测试（原诊断包没有 Android logcat 的旧崩溃堆栈，因此本版采用结构性加固而不是声称精确复现旧堆栈）。
- 120 Hz 下真实 jank / frame timing。
