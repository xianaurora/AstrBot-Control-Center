# dev13 implementation notes

Release targets:

- Android app: `1.6.0-dev13 / 161100`
- Embedded core: `1.6.0-dev11 / 16011`

## Build regression fixed

`RootShell` no longer calls the newer Java `Process.pid()` API. Root commands start in a dedicated session, write their shell PID to a temporary root-owned file, and timeout cleanup walks `/proc/<pid>/task/<pid>/children` before terminating the process tree. Output capture remains bounded.

## Guided user flow

- The old breathing “next step” indicator is replaced by a four-stage task track: environment → robot service → QQ → message connection.
- Normal pages use user-facing wording; protocol and implementation terminology stays in logs/advanced tools.
- A “检查机器人” entry provides a user-readable diagnosis and context-sensitive next action.
- Console context (`AstrBot / SnowLuma / login state`) is displayed on the right as non-clickable status rather than mixed into navigation.

## Environment page

- Environment readiness and safe repair/reinstall are separate from troubleshooting tools.
- Reinstall requires a verified local Ubuntu base archive and preserves persistent AstrBot configuration, plugins, QQ state, and user configuration.
- User-facing switches cover boot auto-online, crash recovery, rescue recovery, and NapCat message keepalive.
- “关闭全部自动功能” disables only those user-facing automation behaviors; launch supervision remains internal infrastructure.

## Mainland dependency sources

Available profiles: auto, Aliyun, USTC, TUNA, BFSU, Huawei Cloud, official.

The profile applies to Ubuntu Ports packages and Python package installation. Auto mode probes current `noble/InRelease` endpoints and uses the fastest reachable profile. Security updates remain on the official Ubuntu Ports archive by default. The custom Ubuntu base archive itself is not assigned an invented mirror URL; it still requires a verified release resource/local import.

## QR and console

- The normal SnowLuma login remains native PNG capture; the QR square is cropped and enlarged with nearest/no filtering for sharper display.
- QR refresh stays explicitly user-triggered and cooldown-protected.
- AstrBot HTTP/static-resource probing is diagnostic only. It cannot prevent the real WebView from loading.
