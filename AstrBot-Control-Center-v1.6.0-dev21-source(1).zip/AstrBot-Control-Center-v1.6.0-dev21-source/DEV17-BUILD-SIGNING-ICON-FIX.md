# dev17 — build/signing/icon fix

## 1. Kotlin compile failure fixed

`WebResourceError.description` is a nullable `CharSequence`, not a nullable `String`.
The dev16 call `error?.description.orEmpty()` therefore failed Kotlin compilation.
dev17 converts it explicitly with `error?.description?.toString() ?: ""`.

## 2. Stable development update signing

GitHub-hosted runners are disposable. Relying on Android Gradle Plugin's automatically
created debug keystore can produce APKs with a different signing identity on later runs,
which Android refuses to install as an update over an app signed by a different key.

dev17 adds a repository-local DEVELOPMENT update keystore and explicitly assigns it to
both `debug` and `release`. GitHub Actions also runs `apksigner verify --print-certs` and
uploads `signing-info.txt` next to the APK.

The checked-in key is intentionally a development convenience key and is not appropriate
for a public production/Play Store release. The Gradle file supports these environment
overrides for a private production key:

- `ASTRBOT_KEYSTORE_PATH`
- `ASTRBOT_KEYSTORE_PASSWORD`
- `ASTRBOT_KEY_ALIAS`
- `ASTRBOT_KEY_PASSWORD`

### Important migration note

An APK already installed with an older, lost/different signing key cannot be upgraded by
an APK signed with this new dev17 key. Uninstall the old Control Center once before the
first dev17 install. From dev17 onward, builds using the included stable development key
can update each other in place as long as the application ID stays unchanged.

## 3. Launcher icon

The supplied blue/white character artwork is now wired as the launcher icon:

- legacy density-specific `mipmap-*` PNGs
- API 26+ adaptive icon XML
- `android:icon` and `android:roundIcon` in the manifest

Only the black JPEG area connected to the four outer corners is made transparent for
legacy launcher compatibility; the actual illustration is preserved.
