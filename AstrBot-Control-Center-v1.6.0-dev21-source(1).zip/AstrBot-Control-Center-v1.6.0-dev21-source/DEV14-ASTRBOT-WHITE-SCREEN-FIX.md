# dev14 — AstrBot 白屏修复

## 本次根因方向

此前核心 `web-probe astrbot` 使用 no-cache 请求确认 6185 首页与 JS/CSS 正常，但 Android WebView 的 AstrBot 页面仍使用 `LOAD_DEFAULT`。AstrBot 原地升级前端后，WebView 可能继续命中旧 index / 旧 hashed bundle 缓存，表现为“服务 ready、资源探测正常、内嵌页面纯白”。同时 dev13 对子资源错误只记录诊断，不会把核心 JS/CSS 失败直接显示给用户。

## dev14 改动

- AstrBot URL 一拿到就立即发布给 Compose，HTTP/静态资源 probe 只做旁路诊断，不再延迟 WebView 创建。
- 仅 AstrBot 使用 `WebSettings.LOAD_NO_CACHE`，首次请求附带 `Cache-Control: no-cache, no-store` 与 `Pragma: no-cache`；SnowLuma/NapCat 保持原缓存策略，避免影响其性能。
- AstrBot 的本机 `.js/.mjs/.css` 网络错误和 HTTP 4xx/5xx 直接进入原生错误页，不再沉默成白屏。
- `onPageFinished` 后采用双阶段宽限检查，只判断 SPA 是否真正挂载出可见 UI；若持续空白，只执行一次带时间戳 query 的 cache-busted 重载。
- 第二次仍空白时停止自动恢复，显示 JS console、静态资源问题、DOM 挂载摘要和当前 Android WebView provider/version。
- AstrBot 错误页同时提供“重新连接”和“浏览器打开”，不再把用户留在无法解释的白板上。
- 保留 dev12 的 SPA-safe URL 策略：绝不把 WebView 的 history/hash 变化当作需要回到 `/` 的理由。

## 安全/行为边界

- 不清 Cookie、LocalStorage 或 AstrBot 登录态。
- 不调用 `clearCache()`，避免把其它控制台的缓存一起清掉。
- 不恢复 127.0.0.1/localhost 循环切换。
- 白屏恢复严格最多一次，不存在无限 reload。
