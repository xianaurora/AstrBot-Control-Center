# dev11 诊断结论

针对 2026-08-11 13:30:43 诊断包：

- AstrBot 进程和 WebUI 服务端正常：`ASTRBOT_UP=1`、`ASTRBOT_WEB_READY=1`、端口 6185。此前白板更像 Android WebView 包装层/恢复逻辑问题，而不是 AstrBot 服务端没有启动。
- SnowLuma 正常模式已恢复：诊断记录 `render=normal`，用户反馈 SnowLuma WebUI 已不再明显卡顿。
- QQ 登录窗口真实存在并可定位：诊断记录窗口 `320x460`、标题 `QQ`，说明默认扫码不需要依赖远程桌面协议才能取得二维码画面。
- noVNC 链路仍反复产生短连接和 HTTP 404；因此 dev11 将它从“默认扫码通路”降级为显式的“完整桌面”高级入口。

## dev11 架构

默认 SnowLuma 扫码：

`QQ@Xvfb -> xdotool 定位窗口 -> FFmpeg x11grab 单帧 PNG -> astrctl/base64 -> Android -> Compose Image`

高级完整桌面：

`QQ@Xvfb -> x11vnc -> websockify -> noVNC -> WebView`

AstrBot：

`6185 ready -> 普通 Android WebView -> 页面生命周期/HTTP/网络/console 回调`

不再使用 DOM/canvas “是否空白”的猜测来自动重载页面。

## 额外发现

原生 PNG 初稿的临时文件名曾为 `frame.png.tmp.<pid>`。FFmpeg 会根据文件末尾扩展名选择输出 muxer，因此该写法会导致 `Unable to choose an output format`，让截图必然失败。最终代码已改成 `frame.tmp.<pid>.png`，并显式指定 PNG 编码，同时统一 X11 输入为 `:<display>.0+<x>,<y>`。
