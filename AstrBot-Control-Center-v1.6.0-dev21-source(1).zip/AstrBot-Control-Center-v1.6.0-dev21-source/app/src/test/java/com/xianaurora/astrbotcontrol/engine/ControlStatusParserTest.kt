package com.xianaurora.astrbotcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ControlStatusParserTest {
    @Test
    fun snowlumaStatusDoesNotLeakLegacyNapCatReason() {
        val status = ControlStatusParser.parse(
            """
            STATUS|QQ_ENGINE|snowluma
            STATUS|ASTRBOT_UP|1
            STATUS|SNOWLUMA_UP|1
            STATUS|SNOWLUMA_READY|1
            STATUS|SNOWLUMA_WEB_READY|1
            STATUS|NAPCAT_UP|0
            STATUS|ONEBOT_CONNECTED|0
            STATUS|ONEBOT_REASON|NapCat 未运行
            STATUS|MAIN_QQ_STATE|starting
            STATUS|MAIN_QQ_REASON|SnowLuma/QQ 正在启动或等待登录
            """.trimIndent()
        )

        assertEquals("snowluma", status.qqEngine)
        assertTrue(status.activeQqUp)
        assertTrue(status.activeQqReady)
        assertFalse(status.oneBotReason.contains("NapCat", ignoreCase = true))
        assertTrue(status.oneBotReason.contains("SnowLuma"))
    }
}
