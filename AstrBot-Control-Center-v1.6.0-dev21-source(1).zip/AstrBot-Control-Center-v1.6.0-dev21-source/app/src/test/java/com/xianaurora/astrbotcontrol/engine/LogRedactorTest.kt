package com.xianaurora.astrbotcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LogRedactorTest {
    @Test
    fun sensitiveValuesArePseudonymizedAndLoopbackIsPreserved() {
        val raw = "uin=123456789 token=abcdef1234567890 Authorization: Bearer secret-token peer=8.8.8.8 local=127.0.0.1"
        val first = LogRedactor.redact(raw)
        val second = LogRedactor.redact(raw)

        assertEquals(first, second)
        assertFalse(first.contains("123456789"))
        assertFalse(first.contains("abcdef1234567890"))
        assertFalse(first.contains("secret-token"))
        assertFalse(first.contains("8.8.8.8"))
        assertTrue(first.contains("127.0.0.1"))
        assertTrue(first.contains("<QQ:"))
        assertTrue(first.contains("<TOKEN:"))
        assertTrue(first.contains("<IP:"))
    }
}
