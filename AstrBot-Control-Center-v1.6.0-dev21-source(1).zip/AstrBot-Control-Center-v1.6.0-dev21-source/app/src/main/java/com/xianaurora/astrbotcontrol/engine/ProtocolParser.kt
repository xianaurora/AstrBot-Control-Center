package com.xianaurora.astrbotcontrol.engine

import com.xianaurora.astrbotcontrol.model.EngineStatus
import com.xianaurora.astrbotcontrol.model.InstallEvent
import com.xianaurora.astrbotcontrol.model.InstallPlanItem
import com.xianaurora.astrbotcontrol.model.ResourceStatus

object ProtocolParser {
    fun keyValues(text: String): Map<String, String> = buildMap {
        text.lineSequence().forEach { line ->
            val i = line.indexOf('=')
            if (i > 0 && !line.startsWith("INSTALL_EVENT|")) put(line.substring(0, i), line.substring(i + 1))
        }
    }

    fun status(text: String): EngineStatus {
        val m = keyValues(text)
        return EngineStatus(
            protocol = m["protocol"]?.toIntOrNull() ?: m["engine_protocol"]?.toIntOrNull() ?: 0,
            engineVersion = m["engine_version"].orEmpty(),
            stage = m["stage"] ?: "idle",
            step = m["step"] ?: "none",
            state = m["state"] ?: "idle",
            title = m["title"] ?: "尚未开始",
            detail = m["detail"].orEmpty(),
            current = m["current"]?.toLongOrNull(),
            total = m["total"]?.toLongOrNull(),
            unit = m["unit"].orEmpty(),
            errorCode = m["error_code"].orEmpty(),
            solutionId = m["solution_id"].orEmpty(),
            rootfsReady = m["rootfs"] == "ready",
            astrbotReady = m["astrbot"] == "ready",
            napcatReady = m["napcat"] == "ready",
            onebotReady = m["onebot"] == "ready",
            fastBootReady = m["fast_boot"] == "ready",
            workerRunning = m["worker"] == "running",
            rebootRequired = m["reboot_required"] == "1",
            engineVerifiedEpoch = m["engine_verified"]?.toLongOrNull() ?: 0
        )
    }

    private fun pipeFields(line: String): Map<String, String> = buildMap {
        line.split('|').drop(1).forEach { part ->
            val i = part.indexOf('=')
            if (i > 0) put(part.substring(0, i), part.substring(i + 1))
        }
    }

    fun events(text: String): List<InstallEvent> = text.lineSequence()
        .filter { it.startsWith("INSTALL_EVENT|") }
        .map { pipeFields(it) }
        .map { m ->
            InstallEvent(
                epoch = m["epoch"]?.toLongOrNull() ?: 0,
                stage = m["stage"].orEmpty(),
                step = m["step"].orEmpty(),
                state = m["state"].orEmpty(),
                title = m["title"].orEmpty(),
                detail = m["detail"].orEmpty(),
                current = m["current"]?.toLongOrNull(),
                total = m["total"]?.toLongOrNull(),
                unit = m["unit"].orEmpty(),
                errorCode = m["error_code"].orEmpty(),
                solutionId = m["solution_id"].orEmpty()
            )
        }.toList()

    fun plan(text: String): List<InstallPlanItem> = text.lineSequence()
        .filter { it.startsWith("PLAN|") }
        .map { pipeFields(it) }
        .map { m -> InstallPlanItem(m["id"].orEmpty(), m["title"].orEmpty(), m["network"] == "1", m["state"].orEmpty(), m["detail"].orEmpty()) }
        .toList()

    fun resource(text: String): ResourceStatus {
        val line = text.lineSequence().firstOrNull { it.startsWith("RESOURCE|") } ?: return ResourceStatus()
        val m = pipeFields(line)
        return ResourceStatus(
            id = m["id"] ?: "rootfs",
            state = m["state"] ?: "missing",
            filename = m["filename"] ?: ResourceStatus().filename,
            size = m["size"]?.toLongOrNull() ?: 0,
            expectedSize = m["expected_size"]?.toLongOrNull() ?: ResourceStatus().expectedSize,
            sha256 = m["sha256"].orEmpty(),
            expectedSha256 = m["expected_sha256"] ?: ResourceStatus().expectedSha256,
            delivery = m["delivery"] ?: "catalog_or_import"
        )
    }
}
