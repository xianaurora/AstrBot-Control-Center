package com.xianaurora.astrbotcontrol.help

data class HelpSection(val title: String, val body: String)
data class HelpTopic(val id: String, val title: String, val summary: String, val sections: List<HelpSection>)

object HelpContent {
    val topics = listOf(
        HelpTopic("overview", "从零开始安装", "安装 APK → 离线检查 → 核心组件 → 重启 → 运行资源 → QQ 登录。", listOf(
            HelpSection("安装分成哪几段？", "第一段只安装控制中心和核心组件，不联网。核心组件在重启后验证成功，用户确认“开始准备环境”之后，才允许 Ubuntu/AstrBot/Linux QQ/NapCat 等运行资源联网。"),
            HelpSection("安装时可以退出吗？", "每个大阶段都保存检查点。重新打开后会读取核心组件的状态，不会故意把已完成组件从头安装。下载器会保留可恢复的 .part 文件。"),
            HelpSection("QQ 扫码算安装吗？", "不算。OneBot 配置完成后安装即完成。QQ 登录属于首次使用流程，因此二维码过期或暂时不登录都不会让下一次开机重新安装。")
        )),
        HelpTopic("preflight", "设备检查与 Root", "检查 ARM64、4 KB 内存页、Root 和可用空间。", listOf(
            HelpSection("为什么必须 ARM64 / 4 KB？", "当前核心组件和已验证的 Ubuntu 运行环境按 ARM64 + 4 KB 内存页构建和测试。不满足条件时会直接停止，避免安装到一半再失败。"),
            HelpSection("为什么这时才申请 Root？", "第一次打开软件不会自动弹 Root。只有用户点击开始安装后才申请，用于安装核心组件、读取核心组件状态和执行明确的控制操作。"),
            HelpSection("没有 Root 怎么办？", "控制中心不会自动修改 boot 镜像。请先按设备对应的 Magisk、KernelSU 或 APatch 官方流程完成 Root，再返回重新检查。")
        )),
        HelpTopic("engine_backup", "升级前快照与核心组件回退", "升级前只备份模块文件；验证失败时可恢复旧核心组件，不回滚 AstrBot/QQ 业务数据。", listOf(
            HelpSection("快照包含什么？", "只包含 /data/adb/modules/astrbot_standalone 当前核心组件文件。Ubuntu、AstrBot、插件、NapCat、QQ 登录态和配置仍留在持久数据目录，不会复制进这个快照。"),
            HelpSection("什么时候创建？", "检测到现有核心组件且你明确点击升级时，控制中心会先创建快照。快照失败会直接停止升级。即使绕过控制中心、直接在 Root 管理器里手动安装 dev2，模块安装脚本也会在迁移前再尝试创建一次回退点。"),
            HelpSection("什么时候建议回退？", "如果重启后找不到新核心组件、协议不匹配或版本没有完整切换，错误页会出现“恢复原核心组件”。恢复完成后需要再重启一次。"),
            HelpSection("回退会不会丢插件？", "不会。核心组件回退只恢复 Root 模块本体；AstrBot 数据、插件目录、QQ 登录数据和当前运行环境不会回退或删除。")
        )),
        HelpTopic("engine_install", "安装核心组件", "核心组件是 Root 层后台服务与恢复入口。", listOf(
            HelpSection("这个步骤联网吗？", "不联网。核心组件安装包已内置在 APK 中，控制中心先校验 SHA-256，再交给 Root 管理器安装。"),
            HelpSection("会覆盖 AstrBot 数据吗？", "不会把业务数据打包进模块目录。现有 Ubuntu、AstrBot 数据、NapCat 配置和 QQ 登录状态继续位于 /data/adb/astrbot_standalone。"),
            HelpSection("APatch 安装失败怎么办？", "不同 APatch 版本的命令行行为可能不同。控制中心会显示 Root 管理器的原始返回信息；如果命令行安装不可用，可在 APatch 管理器中手动导入同一核心组件安装包，不要直接复制模块目录。")
        )),
        HelpTopic("reboot_engine", "为什么必须重启一次", "确认核心组件已在重启后真正加载。", listOf(
            HelpSection("为什么不能跳过？", "写入模块并不等于核心组件已经运行。重启后 service.sh 进入 Root 的 late_start 阶段才会写入验证标记，控制中心只在此后继续。"),
            HelpSection("重启后会偷偷下载吗？", "不会。新装或未完整环境会把 auto_setup_first_boot 设为 0；核心组件只等待控制中心下一步确认。")
        )),
        HelpTopic("rootfs_resource", "Ubuntu 基础资源", "当前核心组件使用一份经过设备验证的 Ubuntu 基础环境。", listOf(
            HelpSection("为什么需要它？", "AstrBot、Python 工具和 Linux QQ 的独立运行环境都依赖这份 Ubuntu 基础层。导入前会校验文件大小和 SHA-256。"),
            HelpSection("为什么现在显示本地导入？", "当前开发版只有这份兼容资源的校验值，没有可信的正式下载地址，因此不会换成未经验证的 Ubuntu 包。正式下载源接入后可在同一页面自动下载；本地导入入口仍会保留。"),
            HelpSection("选错文件会怎样？", "文件大小或 SHA-256 不匹配时立即拒绝，不解压、不覆盖现有 rootfs。")
        )),
        HelpTopic("network_download", "下载中断与恢复", "网络失败不应该等于整个安装失败。", listOf(
            HelpSection("断网后会从零开始吗？", "uv、Linux QQ 和 NapCat 的下载器会保存 .part，并在服务器支持 HTTP Range 时续传。已通过校验的完整缓存不会重复下载。"),
            HelpSection("一直连接失败怎么办？", "先确认网络和 DNS，再展开“技术详情”查看具体域名与返回。部分资源有官方/备用源自动回退；资源仍可通过本地文件导入到指定缓存。")
        )),
        HelpTopic("no_space", "存储空间不足", "释放空间后只重试当前阶段。", listOf(
            HelpSection("会删旧数据腾空间吗？", "不会。控制中心和核心组件不会为了完成安装自动删除现有 AstrBot/QQ 数据。"),
            HelpSection("释放多少合适？", "基础检查建议至少保留约 2 GiB；完整环境和插件可能需要更多。Ubuntu 展开前还会再检查一次可用空间。")
        )),
        HelpTopic("resource_integrity", "资源校验失败", "校验失败的文件绝不安装。", listOf(
            HelpSection("这代表什么？", "文件可能下载不完整、版本不匹配或被修改。校验失败时会保留当前运行环境并停止切换。"),
            HelpSection("怎么解决？", "删除损坏的临时文件或重新获取正确版本，再重试该组件。技术详情会显示预期与实际 SHA-256/大小。")
        )),
        HelpTopic("astrbot_install", "AstrBot 安装失败", "Ubuntu 已完成时只需要重试 AstrBot 阶段。", listOf(
            HelpSection("会重装 Ubuntu 吗？", "不会。setup 每次先检查 rootfs_ready/app_ready/napcat_installed/stage4_ready，只处理缺失阶段。"),
            HelpSection("常见原因", "PyPI 网络异常、Python 环境问题、剩余空间不足。展开 action.log 和 stage2-install.log 可以看到具体源和命令返回。")
        )),
        HelpTopic("napcat_install", "Linux QQ / NapCat 安装失败", "下载缓存和 AstrBot 环境会保留。", listOf(
            HelpSection("Linux QQ 如何验证？", "当前版本通过 Debian 元数据检查 Package、Architecture 和 Version；NapCat ZIP 另外固定 SHA-256。"),
            HelpSection("重试会丢配置吗？", "安装运行环境前会备份已有 NapCat config，重新组装后再恢复。仍建议重要账号配置另外保留备份。")
        )),
        HelpTopic("onebot_config", "OneBot 配置失败", "这是本地配置步骤，不需要重装下载资源。", listOf(
            HelpSection("怎么恢复？", "直接重新生成 Token 与反向 WebSocket 配置即可。QQ 是否已经扫码不影响安装完成。")
        )),
        HelpTopic("first_start", "安装完成但首次启动失败", "把“安装”和“启动”分开处理。", listOf(
            HelpSection("需要重新安装吗？", "不需要。FIRST_START_FAILED 表示组件已经落盘，只是服务启动/连接阶段没完成。应查看启动日志并重新启动服务。")
        )),
        HelpTopic("protocol", "版本或协议不兼容", "控制中心不会在未知协议上盲目执行 Root 操作。", listOf(
            HelpSection("怎么解决？", "安装与当前 APK 配套的核心组件。App 与核心组件的版本号可以不同，但 app-protocol 必须兼容。")
        )),
        HelpTopic("generic", "其他安装问题", "先保留现场，再看当前步骤和日志。", listOf(
            HelpSection("推荐顺序", "先看失败卡片的‘发生了什么 / 数据是否安全 / 下一步’，再展开技术日志。不要第一时间清数据或完整重装。"),
            HelpSection("需要反馈时", "导出脱敏诊断、错误代码、当前 stage/step 和最近 action.log。不要公开 OneBot Token、QQ 登录态或控制台密码。")
        ))
    )

    fun byId(id: String?): HelpTopic = topics.firstOrNull { it.id == id } ?: topics.first()
}
