package com.xianaurora.astrbotcontrol.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.xianaurora.astrbotcontrol.engine.ControlCenterViewModel
import com.xianaurora.astrbotcontrol.model.ConsoleTarget
import com.xianaurora.astrbotcontrol.model.ControlCenterUiState
import com.xianaurora.astrbotcontrol.model.ControlDestination
import com.xianaurora.astrbotcontrol.model.LogCategory
import com.xianaurora.astrbotcontrol.model.LogSource
import com.xianaurora.astrbotcontrol.model.OperationsSection
import com.xianaurora.astrbotcontrol.model.RuntimeHealth
import com.xianaurora.astrbotcontrol.model.RuntimeStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first

private object MotionSpec {
    val strongEaseOut = CubicBezierEasing(0.23f, 1f, 0.32f, 1f)
    val strongEaseInOut = CubicBezierEasing(0.77f, 0f, 0.175f, 1f)
    const val quick = 160
    const val page = 240
    const val fade = 120
    val spatialSpring = spring<Float>(dampingRatio = 0.84f, stiffness = 470f)
    val pressSpring = spring<Float>(dampingRatio = 0.82f, stiffness = 760f)
    val settleSpring = spring<Dp>(dampingRatio = 0.82f, stiffness = 520f)
}

private data class UiLogLine(val text: String, val occurrence: Int)
private data class SituationData(
    val label: String,
    val title: String,
    val detail: String,
    val next: String,
    val actionLabel: String = "",
    val action: String = ""
)

private fun destinationRank(destination: ControlDestination) = when (destination) {
    ControlDestination.OVERVIEW -> 0
    ControlDestination.CONSOLE -> 1
    ControlDestination.ENVIRONMENT -> 2
    ControlDestination.OPERATIONS -> 3
}

@Composable
fun ControlCenterApp(
    vm: ControlCenterViewModel,
    onOpenHelp: () -> Unit
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    var confirmExitWithChanges by rememberSaveable { mutableStateOf(false) }

    BackHandler(enabled = ui.settingsDraft.dirty) { confirmExitWithChanges = true }
    BackHandler(enabled = !ui.settingsDraft.dirty && ui.destination == ControlDestination.CONSOLE && !ui.workbenchHome) {
        vm.returnToWorkbenchHome()
    }
    if (confirmExitWithChanges) {
        AlertDialog(
            onDismissRequest = { confirmExitWithChanges = false },
            title = { Text("还有未保存的更改") },
            text = { Text("当前选择还没有应用。可以继续编辑，或放弃这些更改并退出控制中心。") },
            confirmButton = {
                TextButton(onClick = {
                    confirmExitWithChanges = false
                    vm.cancelSettingsDraft()
                    (context as? Activity)?.finish()
                }) { Text("放弃并退出") }
            },
            dismissButton = { TextButton(onClick = { confirmExitWithChanges = false }) { Text("继续编辑") } }
        )
    }

    if (ui.pendingDestination != null) {
        val pendingLabel = ui.pendingConsoleTarget?.label ?: ui.pendingDestination?.title.orEmpty()
        AlertDialog(
            onDismissRequest = vm::keepEditingSettings,
            title = { Text("还有未保存的更改") },
            text = { Text("先保存或取消当前更改，再离开这个页面。也可以直接放弃更改继续前往 $pendingLabel。") },
            confirmButton = { TextButton(onClick = vm::discardSettingsAndContinue) { Text("放弃并继续") } },
            dismissButton = { TextButton(onClick = vm::keepEditingSettings) { Text("继续编辑") } }
        )
    }

    DisposableEffect(lifecycleOwner, vm) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> vm.start()
                Lifecycle.Event.ON_STOP -> vm.stop()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) vm.start()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            vm.stop()
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 760.dp
        if (wide) {
            Box(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxSize()) {
                    ControlRail(
                        destination = ui.destination,
                        attention = ui.status.health == RuntimeHealth.ATTENTION,
                        onDestination = vm::setDestination,
                        modifier = Modifier.width(108.dp).fillMaxHeight()
                    )
                    ControlContent(ui, vm, onOpenHelp, Modifier.weight(1f).fillMaxHeight(), true)
                }
                if (ui.settingsDraft.dirty) {
                    SettingsSaveBar(
                        ui = ui,
                        vm = vm,
                        compact = false,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(start = 132.dp, end = 24.dp, bottom = 18.dp).widthIn(max = 760.dp)
                    )
                }
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    ControlContent(ui, vm, onOpenHelp, Modifier.fillMaxSize(), false)
                    if (ui.settingsDraft.dirty) {
                        SettingsSaveBar(
                            ui = ui,
                            vm = vm,
                            compact = true,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 10.dp)
                        )
                    }
                }
                ControlBottomBar(
                    destination = ui.destination,
                    attention = ui.status.health == RuntimeHealth.ATTENTION,
                    onDestination = vm::setDestination,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ControlContent(
    ui: ControlCenterUiState,
    vm: ControlCenterViewModel,
    onOpenHelp: () -> Unit,
    modifier: Modifier,
    wide: Boolean
) {
    Box(modifier.background(MaterialTheme.colorScheme.background)) {
        if (ui.loading) {
            ControlCenterLoading()
        } else {
            AnimatedContent(
                targetState = ui.destination,
                transitionSpec = {
                    val forward = destinationRank(targetState) >= destinationRank(initialState)
                    val enter = if (forward) 28 else -28
                    val exit = if (forward) -14 else 14
                    (fadeIn(tween(MotionSpec.page, easing = MotionSpec.strongEaseOut)) +
                        slideInHorizontally(tween(MotionSpec.page, easing = MotionSpec.strongEaseOut)) { enter }) togetherWith
                        (fadeOut(tween(MotionSpec.fade)) +
                            slideOutHorizontally(tween(MotionSpec.quick, easing = MotionSpec.strongEaseInOut)) { exit })
                },
                label = "control-destination"
            ) { destination ->
                when (destination) {
                    ControlDestination.OVERVIEW -> OverviewScreen(ui, vm, wide)
                    ControlDestination.CONSOLE -> ConsoleScreen(ui, vm, wide)
                    ControlDestination.ENVIRONMENT -> EnvironmentScreen(ui, vm, wide)
                    ControlDestination.OPERATIONS -> OperationsScreen(ui, vm, onOpenHelp, wide)
                }
            }
        }

        ControlMessageOverlay(
            error = ui.errorMessage,
            message = ui.transientMessage,
            onDismiss = vm::clearMessages,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun ControlCenterLoading() {
    val infinite = rememberInfiniteTransition(label = "control-loading")
    val pulse by infinite.animateFloat(
        initialValue = .96f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(760, easing = MotionSpec.strongEaseInOut), repeatMode = RepeatMode.Reverse),
        label = "control-loading-pulse"
    )
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(70.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("A", fontSize = 29.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Text("正在恢复控制中心", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("读取当前状态与下一步操作", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OverviewScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val padding = if (wide) 30.dp else 18.dp
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = padding, end = padding, top = 22.dp, bottom = if (ui.settingsDraft.dirty) 142.dp else 30.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)
    ) {
        item {
            ScreenHeader(
                eyebrow = "控制中心",
                title = greetingTitle(ui.status),
                subtitle = "先看当前情况；需要操作时，界面会直接告诉你下一步。",
                refreshing = ui.refreshing,
                onRefresh = vm::refresh
            )
        }
        item { SituationCard(ui, vm, emphasize = true) }
        item {
            if (wide) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    KeyStatusCard(Modifier.weight(1f), "A", "机器人服务", astrbotState(ui.status), ui.status.astrbotUp && ui.status.astrbotWebReady, ui.status.astrbotUp && !ui.status.astrbotWebReady, astrbotDetail(ui.status))
                    KeyStatusCard(Modifier.weight(1f), "QQ", "QQ", qqStateLabel(ui.status), ui.status.qqOnline, ui.status.qqStartingCount > 0, qqEngineLabel(ui.status))
                    KeyStatusCard(Modifier.weight(1f), "↔", "消息连接", oneBotState(ui.status), ui.status.oneBotConnected > 0, ui.status.stackStarting, oneBotDetail(ui.status))
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    KeyStatusCard(Modifier.fillMaxWidth(), "A", "机器人服务", astrbotState(ui.status), ui.status.astrbotUp && ui.status.astrbotWebReady, ui.status.astrbotUp && !ui.status.astrbotWebReady, astrbotDetail(ui.status))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        KeyStatusCard(Modifier.weight(1f), "QQ", "QQ", qqStateLabel(ui.status), ui.status.qqOnline, ui.status.qqStartingCount > 0, qqEngineLabel(ui.status))
                        KeyStatusCard(Modifier.weight(1f), "↔", "消息连接", oneBotState(ui.status), ui.status.oneBotConnected > 0, ui.status.stackStarting, oneBotDetail(ui.status))
                    }
                }
            }
        }
        item { ActivityCard(ui.status) }
    }
}

@Composable
private fun SituationCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, emphasize: Boolean) {
    val situation = situationFor(ui)
    val health = ui.status.health
    val container by animateColorAsState(
        targetValue = when (health) {
            RuntimeHealth.HEALTHY -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = if (emphasize) .62f else .42f)
            RuntimeHealth.WORKING -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .58f)
            RuntimeHealth.ATTENTION -> MaterialTheme.colorScheme.errorContainer.copy(alpha = .68f)
            else -> MaterialTheme.colorScheme.surfaceContainerHigh
        },
        animationSpec = tween(220, easing = MotionSpec.strongEaseOut),
        label = "situation-container"
    )
    Surface(
        modifier = Modifier.fillMaxWidth().animateContentSize(animationSpec = spring(dampingRatio = .9f, stiffness = 430f)),
        color = container,
        shape = RoundedCornerShape(if (emphasize) 34.dp else 28.dp)
    ) {
        BoxWithConstraints(Modifier.padding(if (emphasize) 22.dp else 18.dp)) {
            val compact = maxWidth < 520.dp
            if (compact) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    SituationText(situation, ui.status, ui.actionBusy || ui.status.actionRunning || ui.status.stackStarting)
                    if (situation.actionLabel.isNotBlank()) SituationAction(situation, ui, vm, Modifier.fillMaxWidth())
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Box(Modifier.weight(1f)) { SituationText(situation, ui.status, ui.actionBusy || ui.status.actionRunning || ui.status.stackStarting) }
                    if (situation.actionLabel.isNotBlank()) SituationAction(situation, ui, vm, Modifier.widthIn(min = 190.dp, max = 250.dp))
                }
            }
        }
    }
}

@Composable
private fun SituationText(situation: SituationData, status: RuntimeStatus, working: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("当前情况", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        KineticText(
            text = situation.title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            label = "situation-title"
        )
        Text(situation.detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
        GuidedTaskProgress(status = status, next = situation.next, working = working)
    }
}

@Composable
private fun GuidedTaskProgress(status: RuntimeStatus, next: String, working: Boolean, modifier: Modifier = Modifier) {
    val environmentDone = status.coreReady
    val botDone = status.astrbotUp
    val qqDone = status.qqOnline
    val connectionDone = status.oneBotConnected > 0
    val done = listOf(environmentDone, botDone, qqDone, connectionDone)
    val labels = listOf("环境", "机器人", "QQ", "连接")
    val current = done.indexOfFirst { !it }.let { if (it < 0) done.lastIndex else it }
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = .48f)
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                labels.forEachIndexed { index, label ->
                    Text(
                        text = if (done[index]) "✓ $label" else label,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (index == current && !done[index]) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (done[index] || index == current) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .65f),
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                done.forEachIndexed { index, complete ->
                    when {
                        complete -> LinearProgressIndicator(
                            progress = { 1f },
                            modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape),
                        )
                        index == current && working -> LinearProgressIndicator(
                            modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape)
                        )
                        else -> LinearProgressIndicator(
                            progress = { 0f },
                            modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape),
                        )
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("下一步", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                KineticText(
                    text = next,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Medium,
                    label = "guided-next"
                )
            }
        }
    }
}

@Composable
private fun SituationAction(situation: SituationData, ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    if (situation.actionLabel.isBlank()) return
    val enabled = !ui.actionBusy && !ui.status.actionRunning
    MotionButton(situation.actionLabel, enabled, true, modifier) {
        when (situation.action) {
            "login" -> vm.openQqLogin()
            "start" -> vm.runAction("start")
            "bridge" -> vm.runAction("bridge-repair")
            "operations" -> vm.setDestination(ControlDestination.OPERATIONS)
            else -> vm.setDestination(ControlDestination.OPERATIONS)
        }
    }
}

@Composable
private fun KeyStatusCard(modifier: Modifier, glyph: String, title: String, state: String, good: Boolean, working: Boolean, detail: String) {
    val surface by animateColorAsState(
        targetValue = if (good) MaterialTheme.colorScheme.surfaceContainer else if (working) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = .35f) else MaterialTheme.colorScheme.surfaceContainer,
        animationSpec = tween(180, easing = MotionSpec.strongEaseOut),
        label = "status-card"
    )
    Surface(modifier = modifier.heightIn(min = 130.dp), color = surface, shape = RoundedCornerShape(28.dp)) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceContainerHighest, modifier = Modifier.size(39.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text(glyph, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                }
                Spacer(Modifier.weight(1f))
                StatePill(state, good)
            }
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ActivityCard(status: RuntimeStatus) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("最近状态", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            ActivityLine("收到消息", status.lastInbound)
            ActivityLine("发出消息", status.lastOutbound)
            ActivityLine("模型响应", status.lastModelOk)
            if (status.lastEvent.isNotBlank()) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
                Text(status.lastEvent, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun ActivityLine(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        KineticText(
            text = value.ifBlank { "暂无" },
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            label = "activity-value-$label"
        )
    }
}

@Composable
private fun EnvironmentScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    var confirmReinstall by rememberSaveable { mutableStateOf(false) }
    if (confirmReinstall) {
        AlertDialog(
            onDismissRequest = { confirmReinstall = false },
            title = { Text("重新安装运行环境？") },
            text = {
                Text("会暂时停止机器人并重新安装 Ubuntu 与运行组件。AstrBot 配置、插件、QQ 登录数据和用户配置保存在独立目录，不会因为这一步被删除。需要本机已有通过校验的基础环境资源。")
            },
            confirmButton = {
                TextButton(onClick = { confirmReinstall = false; vm.runAction("environment-reinstall") }) { Text("开始重新安装") }
            },
            dismissButton = { TextButton(onClick = { confirmReinstall = false }) { Text("取消") } }
        )
    }

    val padding = if (wide) 30.dp else 18.dp
    Column(Modifier.fillMaxSize().padding(start = padding, end = padding, top = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader(
            eyebrow = "运行环境",
            title = if (ui.status.coreReady) "环境已经准备好" else "环境需要处理",
            subtitle = "管理运行环境、自动运行和软件依赖来源。普通使用不需要了解里面的技术细节。",
            refreshing = ui.refreshing,
            onRefresh = vm::refresh
        )
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(bottom = if (ui.settingsDraft.dirty) 142.dp else 30.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { EnvironmentHealthCard(ui, vm, onReinstall = { confirmReinstall = true }) }
            item { AutomationSettingsCard(ui, vm) }
            item { DownloadSourceCard(ui, vm) }
            item { EnvironmentWhyCard() }
        }
    }
}

@Composable
private fun EnvironmentHealthCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, onReinstall: () -> Unit) {
    val status = ui.status
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(if (status.coreReady) "运行环境正常" else "运行环境不完整", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (status.coreReady) "机器人需要的基础环境已经就绪。" else "可以先检查并修复；必要时再重新安装运行环境。",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StatePill(if (status.coreReady) "正常" else "需处理", status.coreReady)
            }
            HorizontalDivider()
            InfoRow("基础环境", if (status.rootfsReady) "已就绪" else "未就绪")
            InfoRow("机器人环境", if (status.astrbotReady) "已就绪" else "未就绪")
            InfoRow("QQ 环境", if (status.activeQqReady) "已就绪" else "未就绪")
            InfoRow("消息连接配置", if (status.bridgeReady) "已就绪" else "未就绪")
            if (status.lastBootSeconds > 0) InfoRow("上次开机准备", "${status.lastBootSeconds} 秒")
            if (ui.actionBusy || status.actionRunning) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(ui.actionLabel.ifBlank { "正在处理运行环境" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                if (maxWidth < 480.dp) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MotionButton("检查并修复", !ui.actionBusy && !status.actionRunning, true, Modifier.fillMaxWidth()) { vm.runAction("repair") }
                        MotionButton("重新安装运行环境", !ui.actionBusy && !status.actionRunning, false, Modifier.fillMaxWidth(), onReinstall)
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MotionButton("检查并修复", !ui.actionBusy && !status.actionRunning, true, Modifier.weight(1f)) { vm.runAction("repair") }
                        MotionButton("重新安装运行环境", !ui.actionBusy && !status.actionRunning, false, Modifier.weight(1f), onReinstall)
                    }
                }
            }
        }
    }
}

@Composable
private fun AutomationSettingsCard(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val status = ui.status
    val draft = ui.settingsDraft
    val autostart = if (draft.initialized) draft.stackAutostart else status.stackAutostart
    val watchdog = if (draft.initialized) draft.watchdogEnabled else status.watchdogEnabled
    val rescue = if (draft.initialized) draft.rescueEnabled else status.rescueEnabled
    val guard = if (draft.initialized) draft.messageGuardEnabled else status.messageGuardEnabled
    val enabled = !ui.actionBusy && !status.actionRunning
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("自动运行", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("先调整需要的选项，最后统一保存。关闭后不会删除任何配置。", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (draft.dirtyFields.any { it in setOf("autostart", "watchdog", "rescue", "message_guard") }) PendingPill()
            }
            Spacer(Modifier.height(5.dp))
            FeatureToggleRow(
                title = "开机后自动上线",
                detail = "设备重启后自动启动机器人；关闭后需要手动启动。",
                checked = autostart,
                enabled = enabled,
                onChanged = { vm.updateAutomationDraft("autostart", it) }
            )
            FeatureToggleRow(
                title = "服务异常时自动恢复",
                detail = if (!autostart && !watchdog) "开启它会同时选中“开机后自动上线”，保存时一起应用。" else "AstrBot 或 QQ 意外退出时尝试恢复服务。",
                checked = watchdog,
                enabled = enabled,
                onChanged = { vm.updateAutomationDraft("watchdog", it) }
            )
            FeatureToggleRow(
                title = "严重异常时自动救援",
                detail = "普通恢复无效时，由核心组件执行更完整的安全恢复。",
                checked = rescue,
                enabled = enabled,
                onChanged = { vm.updateAutomationDraft("rescue", it) }
            )
            if ((if (draft.initialized) draft.qqEngine else status.qqEngine) == "napcat") {
                FeatureToggleRow(
                    title = "消息链保活",
                    detail = "长时间运行时检查消息连接，避免休眠后失去响应。",
                    checked = guard,
                    enabled = enabled,
                    onChanged = { vm.updateAutomationDraft("message_guard", it) }
                )
            }
            if (autostart || watchdog || rescue || guard) {
                Spacer(Modifier.height(6.dp))
                MotionButton(
                    text = "关闭全部自动功能",
                    enabled = enabled,
                    primary = false,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = vm::stageDisableAllAutomation
                )
                Text(
                    "这里只修改待保存状态；点击下方“保存更改”后才会真正应用。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun FeatureToggleRow(title: String, detail: String, checked: Boolean, enabled: Boolean, onChanged: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChanged, enabled = enabled)
    }
}

@Composable
private fun DownloadSourceCard(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val sources = listOf(
        "auto" to "自动选择（推荐）",
        "aliyun" to "阿里云",
        "ustc" to "中科大",
        "tuna" to "清华 TUNA",
        "bfsu" to "北外 BFSU",
        "huawei" to "华为云",
        "official" to "官方"
    )
    val selectedSource = if (ui.settingsDraft.initialized) ui.settingsDraft.downloadSource else ui.status.downloadSource
    val sourceDirty = "download_source" in ui.settingsDraft.dirtyFields
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("软件依赖来源", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("用于 Ubuntu 软件包和 Python 依赖。先选择，保存后才切换。安全更新始终保留官方 Ubuntu 源。", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (sourceDirty) PendingPill()
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(sources, key = { it.first }) { source ->
                    DownloadSourceChoice(
                        text = source.second,
                        selected = selectedSource == source.first,
                        enabled = !ui.actionBusy && !ui.status.actionRunning,
                        onClick = { vm.updateDownloadSourceDraft(source.first) }
                    )
                }
            }
            val currentLabel = sources.firstOrNull { it.first == ui.status.downloadSource }?.second ?: "自动选择"
            val pendingLabel = sources.firstOrNull { it.first == selectedSource }?.second ?: selectedSource
            val effectiveLabel = sources.firstOrNull { it.first == ui.status.downloadSourceEffective }?.second
            Text(
                when {
                    sourceDirty -> "当前：$currentLabel · 待保存：$pendingLabel"
                    ui.status.downloadSource == "auto" && !effectiveLabel.isNullOrBlank() -> "当前：$currentLabel · 已选 $effectiveLabel"
                    else -> "当前：$currentLabel"
                },
                style = MaterialTheme.typography.labelMedium,
                color = if (sourceDirty) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DownloadSourceChoice(text: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Surface(
        shape = CircleShape,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.clip(CircleShape).clickable(enabled = enabled, onClick = onClick)
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun EnvironmentWhyCard() {
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("为什么需要运行环境？", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("AstrBot 和 Linux QQ 原本运行在 Linux 中。控制中心会替你准备并维护这个环境；日常使用只需要关注机器人是否上线、QQ 是否登录和消息是否连接。", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OperationsScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, onOpenHelp: () -> Unit, wide: Boolean) {
    var confirmReboot by remember { mutableStateOf(false) }
    var advancedOpen by rememberSaveable { mutableStateOf(false) }
    if (confirmReboot) {
        AlertDialog(
            onDismissRequest = { confirmReboot = false },
            title = { Text("重启设备？") },
            text = { Text("这是整台 Android 设备重启，不是重启机器人服务。正在进行的任务会被中断。") },
            confirmButton = { TextButton(onClick = { confirmReboot = false; vm.rebootDevice() }) { Text("重启设备") } },
            dismissButton = { TextButton(onClick = { confirmReboot = false }) { Text("取消") } }
        )
    }

    val padding = if (wide) 26.dp else 18.dp
    Column(Modifier.fillMaxSize().padding(start = padding, end = padding, top = 20.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        ScreenHeader("工具", "遇到问题，先检查", "先告诉你哪里有问题和该做什么；日志和高级工具需要时再展开。", ui.refreshing, vm::refresh)
        if (wide) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                LazyColumn(
                    modifier = Modifier.weight(.88f).fillMaxHeight(),
                    contentPadding = PaddingValues(bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { HealthCheckCard(ui, vm) }
                    item { ServiceActionsCard(ui, vm) }
                    item { DiagnosticCard(ui, vm, Modifier.fillMaxWidth()) }
                    item { AdvancedToolsDisclosure(advancedOpen, { advancedOpen = !advancedOpen }) }
                    if (advancedOpen) {
                        item { QqModeCard(ui, vm) }
                        item { RepairCard(ui, vm, Modifier.fillMaxWidth()) }
                        item { DeviceHelpCard(onOpenHelp, onReboot = { confirmReboot = true }) }
                    }
                }
                LogPanel(ui, vm, Modifier.weight(1.12f).fillMaxHeight(), compact = false)
            }
        } else {
            OperationsSectionSelector(ui.operationsSection, vm::setOperationsSection)
            AnimatedContent(
                targetState = ui.operationsSection,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                transitionSpec = {
                    (fadeIn(tween(180, easing = MotionSpec.strongEaseOut)) + slideInHorizontally(tween(210, easing = MotionSpec.strongEaseOut)) { it / 10 }) togetherWith fadeOut(tween(100))
                },
                label = "operations-section"
            ) { section ->
                when (section) {
                    OperationsSection.ACTIONS -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 22.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item { HealthCheckCard(ui, vm) }
                        item { ServiceActionsCard(ui, vm) }
                        item { AdvancedToolsDisclosure(advancedOpen, { advancedOpen = !advancedOpen }) }
                        if (advancedOpen) {
                            item { QqModeCard(ui, vm) }
                            item { RepairCard(ui, vm, Modifier.fillMaxWidth()) }
                            item { DeviceHelpCard(onOpenHelp, onReboot = { confirmReboot = true }) }
                        }
                    }
                    OperationsSection.LOGS -> LogPanel(ui, vm, Modifier.fillMaxSize(), compact = true)
                    OperationsSection.DIAGNOSTICS -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 22.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item { DiagnosticCard(ui, vm, Modifier.fillMaxWidth()) }
                    }
                }
            }
        }
    }
}

@Composable
private fun HealthCheckCard(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(42.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text("?", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("不知道哪里出了问题？", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("检查机器人、QQ、消息连接和运行环境，然后按结果给出下一步。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (ui.healthCheckBusy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (ui.healthCheckMessage.isNotBlank()) {
                Text(ui.healthCheckMessage, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            MotionButton(
                text = if (ui.healthCheckBusy) "正在检查…" else "检查机器人",
                enabled = !ui.healthCheckBusy && !ui.actionBusy,
                primary = true,
                modifier = Modifier.fillMaxWidth(),
                onClick = vm::runHealthCheck
            )
            if (!ui.healthCheckBusy && ui.healthCheckMessage.isNotBlank()) {
                when {
                    !ui.status.coreReady -> MotionButton("打开环境", !ui.actionBusy, false, Modifier.fillMaxWidth()) { vm.setDestination(ControlDestination.ENVIRONMENT) }
                    !ui.status.astrbotUp && ui.status.coreReady -> MotionButton("启动机器人", !ui.actionBusy, false, Modifier.fillMaxWidth()) { vm.runAction("start") }
                    ui.status.qqNeedsLogin -> MotionButton("QQ 登录", !ui.actionBusy, false, Modifier.fillMaxWidth(), vm::openQqLogin)
                    ui.status.oneBotAuthFailed -> MotionButton("帮我修复消息连接", !ui.actionBusy, false, Modifier.fillMaxWidth()) { vm.runAction("bridge-repair") }
                    ui.status.qqOnline && ui.status.oneBotConnected <= 0 -> MotionButton("帮我修复", !ui.actionBusy, false, Modifier.fillMaxWidth()) { vm.runAction("bridge-repair") }
                }
            }
        }
    }
}

@Composable
private fun AdvancedToolsDisclosure(open: Boolean, onToggle: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).clickable(onClick = onToggle)
    ) {
        Row(Modifier.padding(horizontal = 17.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("高级工具", fontWeight = FontWeight.SemiBold)
                Text("运行方式、专项修复和设备级操作", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(if (open) "⌃" else "⌄", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OperationsSectionSelector(selected: OperationsSection, onSelect: (OperationsSection) -> Unit) {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(5.dp)) {
            val count = OperationsSection.entries.size
            val slot = maxWidth / count
            val index = OperationsSection.entries.indexOf(selected).coerceAtLeast(0)
            val x by animateDpAsState(slot * index, MotionSpec.settleSpring, label = "ops-tab-x")
            Surface(
                shape = RoundedCornerShape(17.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.width(slot).height(42.dp).offset(x = x)
            ) {}
            Row(Modifier.fillMaxWidth()) {
                OperationsSection.entries.forEach { section ->
                    Box(
                        Modifier.width(slot).height(42.dp).clip(RoundedCornerShape(17.dp)).clickable { onSelect(section) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(section.label, fontWeight = if (section == selected) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}

@Composable
private fun ServiceActionsCard(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val busy = ui.actionBusy || ui.status.actionRunning || ui.status.stackStarting
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth().animateContentSize()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("常用操作", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            if (ui.actionBusy) {
                Text(ui.actionLabel, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("正在执行并验证结果，现在不需要重复点击。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            BoxWithConstraints(Modifier.fillMaxWidth()) {
                val compact = maxWidth < 500.dp
                if (compact) {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        MotionButton(if (ui.status.stackRunning) "重启全部服务" else "启动全部服务", !busy, true, Modifier.fillMaxWidth()) { vm.runAction(if (ui.status.stackRunning) "restart" else "start") }
                        if (ui.status.stackRunning) MotionButton("停止全部服务", !busy, false, Modifier.fillMaxWidth()) { vm.runAction("stop") }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        MotionButton(if (ui.status.stackRunning) "重启全部服务" else "启动全部服务", !busy, true, Modifier.weight(1f)) { vm.runAction(if (ui.status.stackRunning) "restart" else "start") }
                        if (ui.status.stackRunning) MotionButton("停止全部服务", !busy, false, Modifier.weight(1f)) { vm.runAction("stop") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PendingPill() {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.tertiaryContainer) {
        Text("未保存", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onTertiaryContainer)
    }
}

@Composable
private fun SettingsSaveBar(
    ui: ControlCenterUiState,
    vm: ControlCenterViewModel,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val count = ui.settingsDraft.dirtyFields.size
    Surface(
        shape = RoundedCornerShape(if (compact) 20.dp else 24.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHighest,
        shadowElevation = 12.dp,
        modifier = modifier.fillMaxWidth().animateContentSize()
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(if (compact) 12.dp else 16.dp)) {
            val vertical = maxWidth < 430.dp
            if (vertical) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("$count 项更改等待处理", fontWeight = FontWeight.Bold)
                        Text("尚未生效。保存或取消后这条操作栏才会消失。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { vm.cancelSettingsDraft() }, enabled = !ui.actionBusy, modifier = Modifier.weight(1f)) { Text("取消") }
                        Button(onClick = vm::saveSettingsDraft, enabled = !ui.actionBusy && count > 0, modifier = Modifier.weight(1f)) { Text(if (ui.actionBusy) "保存中…" else "保存更改") }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                        Text("未保存", modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("$count 项更改等待处理", fontWeight = FontWeight.Bold)
                        Text("尚未生效；请在这里保存或取消。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedButton(onClick = { vm.cancelSettingsDraft() }, enabled = !ui.actionBusy) { Text("取消") }
                    Button(onClick = vm::saveSettingsDraft, enabled = !ui.actionBusy && count > 0) { Text(if (ui.actionBusy) "保存中…" else "保存更改") }
                }
            }
        }
    }
}

@Composable
private fun QqModeCard(ui: ControlCenterUiState, vm: ControlCenterViewModel) {
    val current = ui.status.qqEngine
    val selected = if (ui.settingsDraft.initialized) ui.settingsDraft.qqEngine else current
    val dirty = "qq_engine" in ui.settingsDraft.dirtyFields
    val busy = ui.actionBusy || ui.status.actionRunning
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("QQ 运行方式", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("先选择运行方式，确认无误后保存。日志、工作台和 QQ 登录都会跟随已保存的运行方式。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (dirty) PendingPill() else StatePill(if (current == "snowluma") "SnowLuma" else "NapCat", good = true)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeChoice("NapCat", selected == "napcat", enabled = !busy, Modifier.weight(1f)) { vm.updateQqEngineDraft("napcat") }
                ModeChoice("SnowLuma", selected == "snowluma", enabled = !busy && ui.status.snowlumaReady, Modifier.weight(1f)) { vm.updateQqEngineDraft("snowluma") }
            }
            if (dirty) {
                Text("当前：${if (current == "snowluma") "SnowLuma" else "NapCat"} · 待保存：${if (selected == "snowluma") "SnowLuma" else "NapCat"}。保存操作固定显示在屏幕底部。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            } else if (!ui.status.snowlumaReady) {
                Text("SnowLuma 尚未安装时不会允许选择。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ModeChoice(text: String, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
        animationSpec = tween(170, easing = MotionSpec.strongEaseOut),
        label = "mode-bg"
    )
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .97f else 1f, MotionSpec.pressSpring, label = "mode-press")
    Surface(
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(RoundedCornerShape(18.dp)).clickable(interactionSource = interaction, indication = null, enabled = enabled && !selected, onClick = onClick),
        color = bg,
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AnimatedContent(
                targetState = selected,
                transitionSpec = {
                    (fadeIn(tween(150, easing = MotionSpec.strongEaseOut)) + scaleIn(initialScale = .72f, animationSpec = MotionSpec.spatialSpring)) togetherWith fadeOut(tween(80))
                },
                label = "mode-glyph"
            ) { active ->
                Text(if (active) "●" else "○", color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            KineticText(text = text, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, label = "mode-label-$text")
        }
    }
}

@Composable
private fun RepairCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    val busy = ui.actionBusy || ui.status.actionRunning
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = modifier) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("诊断与修复", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("只在出现异常时使用。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(5.dp))
            MaintenanceRow("自动恢复", "只重启真正退出的组件。", enabled = !busy) { vm.runAction("heal") }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
            MaintenanceRow("修复 OneBot", "检查鉴权与反向连接。", enabled = !busy) { vm.runAction("bridge-repair") }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
            MaintenanceRow("修复插件依赖", "扫描并修复 AstrBot 插件依赖。", enabled = !busy) { vm.runAction("plugin-deps") }
        }
    }
}

@Composable
private fun DiagnosticCard(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier) {
    var showRawConfirm by remember { mutableStateOf(false) }
    if (showRawConfirm) {
        AlertDialog(
            onDismissRequest = { showRawConfirm = false },
            title = { Text("导出完整日志包？") },
            text = { Text("完整日志包可能包含 QQ 号、Token、网络地址和账号配置。只有在你明确需要完整原始数据时再导出。") },
            confirmButton = { TextButton(onClick = { showRawConfirm = false; vm.startExport("raw") }) { Text("继续导出") } },
            dismissButton = { TextButton(onClick = { showRawConfirm = false }) { Text("取消") } }
        )
    }
    val export = ui.exportState
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = modifier.animateContentSize()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("日志与诊断", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("默认导出脱敏日志包，并附带必要的非敏感诊断信息。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (export.running) {
                LinearProgressIndicator(progress = { export.percent / 100f }, modifier = Modifier.fillMaxWidth())
                Text(export.detail.ifBlank { "正在采集" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = vm::cancelExport) { Text("取消导出") }
            } else {
                MotionButton("导出脱敏日志包", true, true, Modifier.fillMaxWidth()) { vm.startExport("redacted") }
                TextButton(onClick = { showRawConfirm = true }) { Text("需要完整原始日志包") }
            }
            if (!export.running && export.path.isNotBlank()) {
                Text(export.path, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun DeviceHelpCard(onOpenHelp: () -> Unit, onReboot: () -> Unit) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("设备与帮助", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            MaintenanceRow("安装与使用教程", "安装、恢复与常见问题。", onClick = onOpenHelp)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f))
            MaintenanceRow("重启设备", "重启整台 Android 设备。", critical = true, onClick = onReboot)
        }
    }
}

@Composable
private fun EnvironmentCard(ui: ControlCenterUiState) {
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("环境信息", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            InfoRow("核心组件", ui.status.moduleVersion.ifBlank { "未知" })
            InfoRow("设备", ui.status.device.ifBlank { "未知" })
            InfoRow("Android", ui.status.android.ifBlank { "未知" })
            InfoRow("内核", ui.status.kernel.ifBlank { "未知" })
        }
    }
}

@Composable
private fun MaintenanceRow(
    title: String,
    detail: String,
    enabled: Boolean = true,
    critical: Boolean = false,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .985f else 1f, MotionSpec.pressSpring, label = "maintenance-row")
    Row(
        Modifier.fillMaxWidth().graphicsLayer { alpha = if (enabled) 1f else .45f; scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(16.dp)).clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, color = if (critical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.headlineSmall, color = if (critical) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LogPanel(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier, compact: Boolean) {
    val displayText = if (ui.redactLogs) ui.redactedLogText else ui.logText
    val lines = remember(displayText) {
        val seen = HashMap<String, Int>()
        displayText.lineSequence().map { text ->
            val occurrence = seen[text] ?: 0
            seen[text] = occurrence + 1
            UiLogLine(text, occurrence)
        }.toList()
    }
    val listState = rememberLazyListState()
    var followTail by rememberSaveable { mutableStateOf(true) }
    val tailToken = lines.lastOrNull()?.let { 31 * it.text.hashCode() + it.occurrence } ?: 0

    LaunchedEffect(tailToken, followTail, ui.selectedLogId) {
        if (!followTail || lines.isEmpty()) return@LaunchedEffect
        val target = lines.lastIndex
        // Wait until LazyColumn has actually composed this source. Calling animateScrollToItem
        // during a source switch before the new item provider is measured can throw on some
        // Compose versions/devices. Cancellation from a newer log update is expected.
        snapshotFlow { listState.layoutInfo.totalItemsCount }.first { it > target }
        try {
            if (target - listState.firstVisibleItemIndex > 70) listState.scrollToItem(target)
            else listState.animateScrollToItem(target)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: IndexOutOfBoundsException) {
            // A newer log snapshot replaced this one between measurement and scrolling.
            // The next LaunchedEffect invocation will follow the new tail safely.
        }
    }

    Surface(modifier = modifier, shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.fillMaxSize()) {
            LogToolbar(ui, vm, followTail, { followTail = !followTail }, displayText, compact)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .52f))
            if (lines.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        if (ui.logLoading) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.4.dp)
                        Text(if (ui.logLoading) "正在读取日志…" else "暂无日志", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                // Do not wrap LazyColumn in SelectionContainer. Compose has known crashes when
                // selected lazy-list items are disposed while scrolling. Copy is provided in the
                // toolbar instead, keeping the live log list stable.
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(1.dp)
                ) {
                    items(lines, key = { "${it.occurrence}:${it.text}" }) { item ->
                        val line = item.text
                        Text(
                            line.ifEmpty { " " },
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.5.sp,
                            lineHeight = 17.sp,
                            color = if (line.contains("error", true) || line.contains("失败") || line.contains("fatal", true)) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LogToolbar(
    ui: ControlCenterUiState,
    vm: ControlCenterViewModel,
    followTail: Boolean,
    onToggleFollow: () -> Unit,
    displayText: String,
    compact: Boolean
) {
    val context = LocalContext.current
    val categorySources = remember(ui.logSources, ui.logCategory) { ui.logSources.filter { it.category == ui.logCategory } }
    Column(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (compact) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(LogCategory.entries, key = { it.name }) { category ->
                    LogCategoryChip(category.label, category == ui.logCategory) { vm.selectLogCategory(category) }
                }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                LogCategory.entries.forEach { category ->
                    LogCategoryChip(category.label, category == ui.logCategory) { vm.selectLogCategory(category) }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(categorySources.firstOrNull { it.id == ui.selectedLogId }?.label ?: ui.logCategory.label, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (ui.logLoading) CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp)
            PrivacyToggle(ui.redactLogs) { vm.setLogRedaction(it) }
            TextButton(onClick = { copyText(context, displayText); }, enabled = displayText.isNotBlank()) { Text("复制") }
            TextButton(onClick = onToggleFollow) {
                KineticText(text = if (followTail) "暂停" else "跟随", style = MaterialTheme.typography.labelLarge, label = "log-follow")
            }
        }
        if (categorySources.size > 1) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(categorySources, key = { it.id }) { source ->
                    LogSourceChip(source, source.id == ui.selectedLogId) { vm.selectLog(source.id) }
                }
            }
        }
    }
}

@Composable
private fun PrivacyToggle(redacted: Boolean, onChanged: (Boolean) -> Unit) {
    val bg by animateColorAsState(
        if (redacted) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer,
        tween(160, easing = MotionSpec.strongEaseOut),
        label = "privacy-bg"
    )
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable { onChanged(!redacted) }) {
        KineticCharacters(
            text = if (redacted) "已脱敏" else "原始",
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (redacted) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer,
            fontWeight = FontWeight.SemiBold,
            label = "privacy-state"
        )
    }
}

@Composable
private fun LogCategoryChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh, tween(150, easing = MotionSpec.strongEaseOut), label = "log-category-chip")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable(onClick = onClick)) {
        Text(text, modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp), style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun LogSourceChip(source: LogSource, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.surfaceContainerHighest else Color.Transparent, tween(150, easing = MotionSpec.strongEaseOut), label = "log-source")
    Surface(shape = CircleShape, color = bg, modifier = Modifier.clip(CircleShape).clickable(onClick = onClick)) {
        Text(source.label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun ConsoleScreen(ui: ControlCenterUiState, vm: ControlCenterViewModel, wide: Boolean) {
    val controller = rememberConsoleWebController()
    val padding = if (wide) 24.dp else 12.dp
    Column(
        Modifier.fillMaxSize().padding(start = padding, end = padding, top = 14.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (ui.workbenchHome) {
            ScreenHeader(
                eyebrow = "工作台",
                title = "选择要进入的工作区",
                subtitle = "AstrBot、当前 QQ 引擎和 QQ 登录都从这里进入。入口的样式与动作保持一致。",
                refreshing = ui.refreshing,
                onRefresh = vm::refresh
            )
            WorkbenchHome(ui, vm, Modifier.weight(1f).fillMaxWidth(), wide)
        } else {
            WorkbenchFocusedBar(ui, vm, controller)
            WorkbenchContent(ui, vm, controller, Modifier.weight(1f).fillMaxWidth(), wide)
        }
    }
}

@Composable
private fun WorkbenchHome(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier, wide: Boolean) {
    val cards = listOf(
        Triple(
            "AstrBot",
            when {
                ui.status.astrbotWebReady -> "后台已就绪"
                ui.status.astrbotUp -> "正在启动"
                else -> "已停止"
            },
            "管理机器人、模型、插件与配置。"
        ),
        Triple(
            qqEngineLabel(ui.status),
            qqStateLabel(ui.status),
            "管理当前正在使用的 QQ 引擎。"
        ),
        Triple(
            "QQ 登录",
            when {
                ui.status.qqOnline -> "已经登录"
                ui.status.qqNeedsLogin -> "等待登录"
                else -> "账号登录"
            },
            "扫码、自动登录与完整桌面都集中在这里。"
        )
    )
    if (wide) {
        Row(modifier, horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            WorkspaceLaunchCard(
                title = cards[0].first,
                status = cards[0].second,
                detail = cards[0].third,
                glyph = "A",
                good = ui.status.astrbotWebReady,
                modifier = Modifier.weight(1f),
                onEnter = vm::reopenAstrBotNativeConsole
            )
            WorkspaceLaunchCard(
                title = cards[1].first,
                status = cards[1].second,
                detail = cards[1].third,
                glyph = "Q",
                good = ui.status.qqOnline,
                modifier = Modifier.weight(1f),
                onEnter = { vm.openConsole(ConsoleTarget.QQ) }
            )
            WorkspaceLaunchCard(
                title = cards[2].first,
                status = cards[2].second,
                detail = cards[2].third,
                glyph = "↗",
                good = ui.status.qqOnline,
                modifier = Modifier.weight(1f),
                onEnter = vm::openQqLogin
            )
        }
    } else {
        LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                WorkspaceLaunchCard(cards[0].first, cards[0].second, cards[0].third, "A", ui.status.astrbotWebReady, Modifier.fillMaxWidth(), vm::reopenAstrBotNativeConsole)
            }
            item {
                WorkspaceLaunchCard(cards[1].first, cards[1].second, cards[1].third, "Q", ui.status.qqOnline, Modifier.fillMaxWidth()) { vm.openConsole(ConsoleTarget.QQ) }
            }
            item {
                WorkspaceLaunchCard(cards[2].first, cards[2].second, cards[2].third, "↗", ui.status.qqOnline, Modifier.fillMaxWidth(), vm::openQqLogin)
            }
        }
    }
}

@Composable
private fun WorkspaceLaunchCard(
    title: String,
    status: String,
    detail: String,
    glyph: String,
    good: Boolean,
    modifier: Modifier = Modifier,
    onEnter: () -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        shadowElevation = 1.dp
    ) {
        Column(
            Modifier.fillMaxWidth().padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surfaceContainerHighest, modifier = Modifier.size(52.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text(glyph, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(if (good) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .35f)))
                        KineticText(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, label = "workspace-home-$title")
                    }
                }
            }
            Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Button(onClick = onEnter, modifier = Modifier.fillMaxWidth()) { Text("进入") }
        }
    }
}

@Composable
private fun WorkbenchFocusedBar(ui: ControlCenterUiState, vm: ControlCenterViewModel, controller: ConsoleWebController) {
    val title = when (ui.console.target) {
        ConsoleTarget.ASTRBOT -> "AstrBot"
        ConsoleTarget.QQ -> qqEngineLabel(ui.status)
        ConsoleTarget.QQ_LOGIN -> "QQ 登录"
    }
    val state = when (ui.console.target) {
        ConsoleTarget.ASTRBOT -> if (ui.status.astrbotWebReady) "后台已就绪" else "正在准备"
        ConsoleTarget.QQ -> qqStateLabel(ui.status)
        ConsoleTarget.QQ_LOGIN -> when {
            ui.status.qqOnline || ui.console.phase == "complete" -> "已登录"
            ui.console.qrExpired -> "二维码已过期"
            ui.console.loading -> "正在准备"
            else -> qqEngineLabel(ui.status)
        }
    }
    val showWebNav = ui.console.target == ConsoleTarget.QQ ||
        (ui.console.target == ConsoleTarget.QQ_LOGIN && ui.status.qqEngine != "snowluma")
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = vm::returnToWorkbenchHome) { Text("‹ 工作台") }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                KineticText(state, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, label = "focused-workspace-state")
            }
            if (ui.console.target == ConsoleTarget.QQ_LOGIN && ui.status.qqEngine == "snowluma") {
                if (ui.console.qrDesktopMode) {
                    TextButton(onClick = vm::openQqLogin) { Text("登录窗口") }
                } else if (ui.console.qrImageBytes.isNotEmpty()) {
                    TextButton(onClick = vm::openQqDesktop) { Text("完整桌面") }
                }
            }
            if (showWebNav) ConsoleNavControls(controller)
        }
    }
}

@Composable
private fun WorkbenchContent(
    ui: ControlCenterUiState,
    vm: ControlCenterViewModel,
    controller: ConsoleWebController,
    modifier: Modifier,
    wide: Boolean
) {
    when (ui.console.target) {
        ConsoleTarget.QQ_LOGIN -> QqLoginWorkspace(ui, vm, controller, modifier, wide)
        else -> StandardConsoleWorkspace(ui, vm, controller, modifier, wide)
    }
}

@Composable
private fun StandardConsoleWorkspace(ui: ControlCenterUiState, vm: ControlCenterViewModel, controller: ConsoleWebController, modifier: Modifier, wide: Boolean) {
    Surface(modifier, shape = RoundedCornerShape(if (wide) 28.dp else 22.dp), color = MaterialTheme.colorScheme.surfaceContainer, shadowElevation = 1.dp) {
        Box(Modifier.fillMaxSize()) {
            when {
                ui.console.target == ConsoleTarget.ASTRBOT -> AstrBotNativeConsoleWorkspace(
                    ready = ui.status.astrbotWebReady || ui.console.url.isNotBlank(),
                    detail = ui.console.detail,
                    canOpenBrowser = ui.console.url.isNotBlank(),
                    onOpen = vm::reopenAstrBotNativeConsole,
                    onOpenBrowser = vm::openCurrentConsoleExternally,
                    modifier = Modifier.fillMaxSize()
                )
                ui.console.error.isNotBlank() -> ConsoleError(
                    message = ui.console.error,
                    onRetry = vm::retryConsole,
                    modifier = Modifier.align(Alignment.Center)
                )
                ui.console.url.isBlank() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator()
                        Text("正在连接 ${qqEngineLabel(ui.status)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                else -> EmbeddedConsoleWebView(
                    url = ui.console.url,
                    controller = controller,
                    modifier = Modifier.fillMaxSize(),
                    presentation = ConsoleWebPresentation.STANDARD,
                    onLoadingChanged = vm::setConsoleLoading,
                    onError = vm::setConsoleError
                )
            }
            if (ui.console.loading && ui.console.url.isNotBlank()) {
                LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            }
        }
    }
}

@Composable
private fun AstrBotNativeConsoleWorkspace(
    ready: Boolean,
    detail: String,
    canOpenBrowser: Boolean,
    onOpen: () -> Unit,
    onOpenBrowser: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.padding(22.dp).widthIn(max = 620.dp).fillMaxWidth()
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(54.dp)) {
                        Box(contentAlignment = Alignment.Center) { Text("A", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("AstrBot 管理", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text("独立管理页 · 返回键直接回到工作台", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(
                    detail.ifBlank { "AstrBot 后台已经准备好。为了保持稳定渲染，管理页会在独立窗口中打开。" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(onClick = onOpen, enabled = ready, modifier = Modifier.fillMaxWidth()) { Text(if (ready) "打开 AstrBot" else "AstrBot 正在启动") }
                TextButton(onClick = onOpenBrowser, enabled = canOpenBrowser, modifier = Modifier.fillMaxWidth()) { Text("用系统浏览器打开") }
                Text(
                    "页面内的网页后退、刷新、兼容渲染和诊断都在右上角 ⋮ 中；系统返回和左上角返回始终退出管理页。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun QqLoginWorkspace(ui: ControlCenterUiState, vm: ControlCenterViewModel, controller: ConsoleWebController, modifier: Modifier, wide: Boolean) {
    val snowluma = ui.status.qqEngine == "snowluma"
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(if (wide) 30.dp else 24.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            shadowElevation = 1.dp
        ) {
            val visualState = when {
                ui.console.error.isNotBlank() -> "error"
                ui.console.phase == "complete" -> "complete"
                snowluma && ui.console.qrDesktopMode -> "desktop"
                snowluma && ui.console.qrImageBytes.isNotEmpty() -> "native"
                !snowluma && ui.console.url.isNotBlank() -> "web"
                else -> "preparing"
            }
            AnimatedContent(
                targetState = visualState,
                modifier = Modifier.fillMaxSize().padding(8.dp),
                transitionSpec = {
                    (fadeIn(tween(210, easing = MotionSpec.strongEaseOut)) +
                        scaleIn(initialScale = .985f, animationSpec = tween(240, easing = MotionSpec.strongEaseOut))) togetherWith
                        fadeOut(tween(105))
                },
                label = "qq-login-workspace"
            ) { state ->
                when (state) {
                    "error" -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        ConsoleError(ui.console.error, vm::retryConsole)
                    }
                    "complete" -> QqLoginComplete(Modifier.fillMaxSize())
                    "desktop" -> NativeQqDesktopFrame(ui, vm, Modifier.fillMaxSize(), wide)
                    "native" -> NativeQqLoginFrame(ui, vm, Modifier.fillMaxSize(), wide)
                    "web" -> EmbeddedConsoleWebView(
                        url = ui.console.url,
                        controller = controller,
                        modifier = Modifier.fillMaxSize(),
                        presentation = ConsoleWebPresentation.STANDARD,
                        onLoadingChanged = vm::setConsoleLoading,
                        onError = vm::setConsoleError
                    )
                    else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        QqLoginPreparing(ui)
                    }
                }
            }
        }
    }
}


@Composable
private fun NativeQqDesktopFrame(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier, wide: Boolean) {
    val image = remember(ui.console.qrDesktopImageBytes) {
        val bytes = ui.console.qrDesktopImageBytes
        if (bytes.isEmpty()) null else runCatching {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        }.getOrNull()
    }
    val width = ui.console.qrDesktopImageWidth.coerceAtLeast(1)
    val height = ui.console.qrDesktopImageHeight.coerceAtLeast(1)
    Surface(modifier = modifier, shape = RoundedCornerShape(if (wide) 28.dp else 22.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.fillMaxSize().padding(if (wide) 18.dp else 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("完整 QQ 桌面", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("原生画面 · 可直接触摸 · 不再使用 noVNC", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(if (ui.console.qrDesktopInteractionBusy) "操作中" else if (image != null) "可触摸" else "载入中", good = image != null && !ui.console.qrDesktopInteractionBusy)
                TextButton(onClick = vm::openQqLogin) { Text("返回登录") }
            }
            Surface(
                modifier = Modifier.fillMaxWidth().weight(1f),
                shape = RoundedCornerShape(22.dp),
                color = Color(0xFF121518)
            ) {
                val touchModifier = if (image != null && !ui.console.qrDesktopInteractionBusy) {
                    Modifier.pointerInput(width, height) {
                        detectTapGestures { offset ->
                            val boxW = size.width.coerceAtLeast(1).toFloat()
                            val boxH = size.height.coerceAtLeast(1).toFloat()
                            val imageAspect = width.toFloat() / height.toFloat()
                            val boxAspect = boxW / boxH
                            val drawnW: Float
                            val drawnH: Float
                            val left: Float
                            val top: Float
                            if (boxAspect > imageAspect) {
                                drawnH = boxH
                                drawnW = drawnH * imageAspect
                                left = (boxW - drawnW) / 2f
                                top = 0f
                            } else {
                                drawnW = boxW
                                drawnH = drawnW / imageAspect
                                left = 0f
                                top = (boxH - drawnH) / 2f
                            }
                            if (offset.x < left || offset.x > left + drawnW || offset.y < top || offset.y > top + drawnH) return@detectTapGestures
                            val x = (((offset.x - left) / drawnW) * width).toInt().coerceIn(0, width - 1)
                            val y = (((offset.y - top) / drawnH) * height).toInt().coerceIn(0, height - 1)
                            vm.tapQqDesktopFrame(x, y)
                        }
                    }
                } else Modifier
                Box(Modifier.fillMaxSize().then(touchModifier), contentAlignment = Alignment.Center) {
                    if (image != null) {
                        Image(
                            bitmap = image,
                            contentDescription = "完整 QQ 桌面实时画面",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit,
                            filterQuality = FilterQuality.Low
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            CircularProgressIndicator()
                            Text("正在读取完整桌面", color = MaterialTheme.colorScheme.inverseOnSurface)
                        }
                    }
                    if (ui.console.qrDesktopInteractionBusy) {
                        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.inverseSurface.copy(alpha = .88f)) {
                            Text("正在操作…", modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), color = MaterialTheme.colorScheme.inverseOnSurface)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NativeQqLoginFrame(ui: ControlCenterUiState, vm: ControlCenterViewModel, modifier: Modifier, wide: Boolean) {
    var refreshNow by remember(ui.console.qrRefreshAvailableAtMs) { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(ui.console.qrRefreshAvailableAtMs, ui.console.qrExpired) {
        while (ui.console.qrExpired && System.currentTimeMillis() < ui.console.qrRefreshAvailableAtMs) {
            refreshNow = System.currentTimeMillis()
            delay(1000)
        }
        refreshNow = System.currentTimeMillis()
    }
    val cooldownSeconds = ((ui.console.qrRefreshAvailableAtMs - refreshNow + 999L) / 1000L).coerceAtLeast(0L)
    val loginImage = remember(ui.console.qrImageBytes) {
        val bytes = ui.console.qrImageBytes
        if (bytes.isEmpty()) null else runCatching {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        }.getOrNull()
    }

    Surface(modifier = modifier, shape = RoundedCornerShape(if (wide) 28.dp else 22.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        if (wide) {
            Row(Modifier.fillMaxSize().padding(22.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                QrVisualCard(
                    qrImage = loginImage,
                    frameWidth = ui.console.qrImageWidth,
                    frameHeight = ui.console.qrImageHeight,
                    expired = ui.console.qrExpired,
                    interactionBusy = ui.console.qrInteractionBusy,
                    onTap = vm::tapQqLoginFrame,
                    modifier = Modifier.weight(1.18f).widthIn(max = 560.dp)
                )
                QqLoginInfoPanel(ui, vm, cooldownSeconds, Modifier.weight(.82f))
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                item {
                    QrVisualCard(
                        qrImage = loginImage,
                        frameWidth = ui.console.qrImageWidth,
                        frameHeight = ui.console.qrImageHeight,
                        expired = ui.console.qrExpired,
                        interactionBusy = ui.console.qrInteractionBusy,
                        onTap = vm::tapQqLoginFrame,
                        modifier = Modifier.fillMaxWidth().widthIn(max = 560.dp)
                    )
                }
                item { QqLoginInfoPanel(ui, vm, cooldownSeconds, Modifier.fillMaxWidth()) }
            }
        }
    }
}

@Composable
private fun QrVisualCard(
    qrImage: androidx.compose.ui.graphics.ImageBitmap?,
    frameWidth: Int,
    frameHeight: Int,
    expired: Boolean,
    interactionBusy: Boolean,
    onTap: (Int, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val width = frameWidth.takeIf { it > 0 } ?: qrImage?.width ?: 1
    val height = frameHeight.takeIf { it > 0 } ?: qrImage?.height ?: 1
    val frameAspect = (width.toFloat() / height.toFloat()).coerceIn(.5f, 2.5f)
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = modifier) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("QQ 登录窗口", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("这是实时画面，可以直接点里面的按钮。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(
                    when {
                        interactionBusy -> "操作中"
                        expired -> "需刷新"
                        else -> "可触摸"
                    },
                    good = !expired && !interactionBusy
                )
            }
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color.White,
                modifier = Modifier.fillMaxWidth().aspectRatio(frameAspect)
            ) {
                val touchModifier = if (qrImage != null && !interactionBusy) {
                    Modifier.pointerInput(width, height) {
                        detectTapGestures { offset ->
                            val boxW = size.width.coerceAtLeast(1).toFloat()
                            val boxH = size.height.coerceAtLeast(1).toFloat()
                            val imageAspect = width.toFloat() / height.toFloat()
                            val boxAspect = boxW / boxH
                            val drawnW: Float
                            val drawnH: Float
                            val left: Float
                            val top: Float
                            if (boxAspect > imageAspect) {
                                drawnH = boxH
                                drawnW = drawnH * imageAspect
                                left = (boxW - drawnW) / 2f
                                top = 0f
                            } else {
                                drawnW = boxW
                                drawnH = drawnW / imageAspect
                                left = 0f
                                top = (boxH - drawnH) / 2f
                            }
                            if (offset.x < left || offset.x > left + drawnW || offset.y < top || offset.y > top + drawnH) return@detectTapGestures
                            val x = (((offset.x - left) / drawnW) * width).toInt().coerceIn(0, width - 1)
                            val y = (((offset.y - top) / drawnH) * height).toInt().coerceIn(0, height - 1)
                            onTap(x, y)
                        }
                    }
                } else Modifier
                Box(Modifier.fillMaxSize().then(touchModifier), contentAlignment = Alignment.Center) {
                    if (qrImage != null) {
                        Image(
                            bitmap = qrImage,
                            contentDescription = "QQ 登录窗口实时画面",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit,
                            filterQuality = FilterQuality.None
                        )
                    } else {
                        CircularProgressIndicator()
                    }
                    if (interactionBusy) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.inverseSurface.copy(alpha = .82f)) {
                            Text("正在操作…", modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.inverseOnSurface, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
            Text("如果当前显示的是账号登录、二维码切换或确认按钮，直接在上面的画面里点击即可。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun QqLoginInfoPanel(ui: ControlCenterUiState, vm: ControlCenterViewModel, cooldownSeconds: Long, modifier: Modifier = Modifier) {
    val expired = ui.console.qrExpired
    val ready = ui.console.qrImageBytes.isNotEmpty() && !expired && ui.console.error.isBlank()
    Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = modifier) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("登录状态", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                Surface(shape = CircleShape, color = if (ready) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.tertiaryContainer, modifier = Modifier.size(42.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text(if (ready) "✓" else if (expired) "↻" else "…", fontWeight = FontWeight.Bold) }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    KineticText(if (expired) "需要刷新二维码" else if (ready) "等待你完成登录" else "正在准备登录", fontWeight = FontWeight.SemiBold, label = "login-panel-title")
                    Text(if (ready) "可以扫码，也可以直接操作左侧 QQ 登录窗口。" else ui.console.detail.ifBlank { "正在唤醒 QQ 登录窗口。" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f))
            Text("登录窗口现在是可触摸的：账号选择、切换扫码、登录按钮都可以直接点。完成后控制中心会自动识别登录状态。", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("登录数据会保存在独立运行目录中；正常情况下下次启动会复用现有登录态，失效后才需要重新扫码。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (expired) {
                MotionButton(
                    text = when {
                        ui.console.qrRefreshBusy -> "正在刷新…"
                        cooldownSeconds > 0L -> "${cooldownSeconds}s 后可刷新"
                        else -> "刷新二维码"
                    },
                    enabled = !ui.console.qrRefreshBusy && cooldownSeconds <= 0L,
                    primary = true,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = vm::refreshQqLoginCode
                )
            }
        }
    }
}

@Composable
private fun QqLoginComplete(modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(28.dp)) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(72.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("✓", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
            Text("QQ 已登录", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
            Text("登录已经完成。机器人会继续建立消息连接，不需要再操作。", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun QqLoginPreparing(ui: ControlCenterUiState, modifier: Modifier = Modifier) {
    Column(modifier.padding(24.dp).widthIn(max = 480.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        val infinite = rememberInfiniteTransition(label = "qr-preparing")
        val scale by infinite.animateFloat(1f, 1.05f, infiniteRepeatable(tween(720, easing = MotionSpec.strongEaseInOut), RepeatMode.Reverse), label = "qr-preparing-scale")
        Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(78.dp).graphicsLayer { scaleX = scale; scaleY = scale }) {
            Box(contentAlignment = Alignment.Center) { Text("QQ", fontWeight = FontWeight.Bold, fontSize = 22.sp) }
        }
        KineticCharacters(
            text = loginPhaseTitle(ui.console.phase),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            label = "qr-preparing-title"
        )
        KineticText(
            text = ui.console.detail.ifBlank { "正在准备 QQ 登录画面" },
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            label = "qr-preparing-detail"
        )
        Text(
            if (ui.status.qqEngine == "snowluma") "登录窗口准备好后，二维码会自动显示在这里。"
            else "登录页面准备完成后会在此显示。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ConsoleNavControls(controller: ConsoleWebController) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        CompactTool("‹", controller.canGoBack, controller::back)
        CompactTool("›", controller.canGoForward, controller::forward)
        CompactTool("↻", true, controller::refresh)
    }
}

@Composable
private fun CompactTool(text: String, enabled: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 5.dp)) {
        Text(text, fontSize = 19.sp)
    }
}

@Composable
private fun ConsoleError(
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
    onOpenBrowser: (() -> Unit)? = null
) {
    Column(modifier.padding(24.dp).widthIn(max = 440.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("页面暂不可用", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onRetry, shape = RoundedCornerShape(16.dp)) { Text("重新连接") }
            if (onOpenBrowser != null) {
                OutlinedButton(onClick = onOpenBrowser, shape = RoundedCornerShape(16.dp)) { Text("浏览器打开") }
            }
        }
    }
}

@Composable
private fun MotionButton(text: String, enabled: Boolean, primary: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .97f else 1f, MotionSpec.pressSpring, label = "motion-button")
    val alpha by animateFloatAsState(if (enabled) 1f else .62f, tween(120), label = "motion-button-alpha")
    if (primary) {
        Button(
            onClick = onClick,
            enabled = enabled,
            interactionSource = interaction,
            modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale; this.alpha = alpha },
            shape = RoundedCornerShape(17.dp)
        ) { KineticText(text = text, style = MaterialTheme.typography.labelLarge, label = "motion-button-label") }
    } else {
        OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            interactionSource = interaction,
            modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale; this.alpha = alpha },
            shape = RoundedCornerShape(17.dp)
        ) { KineticText(text = text, style = MaterialTheme.typography.labelLarge, label = "motion-button-label") }
    }
}

@Composable
private fun ScreenHeader(eyebrow: String, title: String, subtitle: String, refreshing: Boolean, onRefresh: () -> Unit) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(eyebrow, style = MaterialTheme.typography.labelSmall, letterSpacing = 1.2.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            KineticText(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
                label = "screen-header-title"
            )
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        PressableCircleButton(refreshing, onRefresh)
    }
}

@Composable
private fun PressableCircleButton(refreshing: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .92f else 1f, MotionSpec.pressSpring, label = "refresh-scale")
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.size(46.dp).graphicsLayer { scaleX = scale; scaleY = scale }.clip(CircleShape).clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (refreshing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("↻", fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun ControlBottomBar(destination: ControlDestination, attention: Boolean, onDestination: (ControlDestination) -> Unit, modifier: Modifier) {
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .96f)) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 7.dp)) {
            val items = ControlDestination.entries
            val slot = maxWidth / items.size
            val index = items.indexOf(destination).coerceAtLeast(0)
            val x by animateDpAsState(slot * index + 4.dp, MotionSpec.settleSpring, label = "bottom-indicator-x")
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.width(slot - 8.dp).height(44.dp).offset(x = x)
            ) {}
            Row(Modifier.fillMaxWidth()) {
                items.forEach { item ->
                    BottomNavigationSlot(item, item == destination, attention && item == ControlDestination.OPERATIONS, { onDestination(item) }, Modifier.width(slot))
                }
            }
        }
    }
}

@Composable
private fun BottomNavigationSlot(item: ControlDestination, selected: Boolean, attention: Boolean, onClick: () -> Unit, modifier: Modifier) {
    Box(modifier.height(44.dp).clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(item.shortLabel, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, color = if (selected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
            if (attention) Box(Modifier.size(6.dp).background(MaterialTheme.colorScheme.error, CircleShape))
        }
    }
}

@Composable
private fun ControlRail(destination: ControlDestination, attention: Boolean, onDestination: (ControlDestination) -> Unit, modifier: Modifier) {
    val slotHeight = 76.dp
    Surface(modifier = modifier, color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .92f)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(52.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("A", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
            Spacer(Modifier.height(24.dp))
            val items = ControlDestination.entries
            Box(Modifier.fillMaxWidth().height(slotHeight * items.size)) {
                val index = items.indexOf(destination).coerceAtLeast(0)
                val y by animateDpAsState(slotHeight * index + 4.dp, MotionSpec.settleSpring, label = "rail-indicator-y")
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth().height(slotHeight - 8.dp).offset(y = y)
                ) {}
                Column(Modifier.fillMaxSize()) {
                    items.forEach { item ->
                        RailNavigationSlot(item, item == destination, attention && item == ControlDestination.OPERATIONS, { onDestination(item) }, Modifier.fillMaxWidth().height(slotHeight))
                    }
                }
            }
        }
    }
}

@Composable
private fun RailNavigationSlot(item: ControlDestination, selected: Boolean, attention: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .96f else 1f, MotionSpec.pressSpring, label = "rail-press")
    Column(
        modifier.graphicsLayer { scaleX = scale; scaleY = scale }.clip(RoundedCornerShape(20.dp)).clickable(interactionSource = interaction, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box {
            AnimatedContent(
                targetState = selected,
                transitionSpec = {
                    (fadeIn(tween(150, easing = MotionSpec.strongEaseOut)) + scaleIn(initialScale = .72f, animationSpec = MotionSpec.spatialSpring)) togetherWith fadeOut(tween(70))
                },
                label = "rail-glyph"
            ) { active ->
                Text(navGlyph(item, active), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            if (attention) Box(Modifier.align(Alignment.TopEnd).size(6.dp).background(MaterialTheme.colorScheme.error, CircleShape))
        }
        Spacer(Modifier.height(4.dp))
        Text(item.shortLabel, style = MaterialTheme.typography.labelSmall, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun StatePill(text: String, good: Boolean) {
    Surface(shape = CircleShape, color = if (good) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHighest) {
        KineticCharacters(
            text = text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (good) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
            label = "state-pill"
        )
    }
}

@Composable
private fun KineticText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
    textAlign: TextAlign? = null,
    label: String
) {
    AnimatedContent(
        targetState = text,
        modifier = modifier,
        transitionSpec = {
            (fadeIn(tween(170, easing = MotionSpec.strongEaseOut)) +
                slideInVertically(tween(190, easing = MotionSpec.strongEaseOut)) { it.coerceAtLeast(1) / 4 }) togetherWith
                (fadeOut(tween(85)) + slideOutVertically(tween(115, easing = MotionSpec.strongEaseInOut)) { -it.coerceAtLeast(1) / 5 })
        },
        label = label
    ) { value ->
        Text(
            text = value,
            style = style,
            color = color,
            fontWeight = fontWeight,
            maxLines = maxLines,
            overflow = overflow,
            textAlign = textAlign
        )
    }
}

@Composable
private fun KineticCharacters(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    label: String
) {
    var settled by remember(text) { mutableStateOf(false) }
    LaunchedEffect(text) {
        settled = false
        delay(12)
        settled = true
    }
    Row(modifier, horizontalArrangement = Arrangement.Center) {
        text.forEachIndexed { index, char ->
            val stagger = (index * 13).coerceAtMost(84)
            val alpha by animateFloatAsState(
                targetValue = if (settled) 1f else .32f,
                animationSpec = tween(150, delayMillis = stagger, easing = MotionSpec.strongEaseOut),
                label = "$label-alpha-$index"
            )
            val y by animateDpAsState(
                targetValue = if (settled) 0.dp else 5.dp,
                animationSpec = spring(dampingRatio = .68f, stiffness = 620f),
                label = "$label-y-$index"
            )
            Text(
                text = char.toString(),
                modifier = Modifier.offset(y = y).graphicsLayer { this.alpha = alpha },
                style = style,
                color = color,
                fontWeight = fontWeight,
                textAlign = textAlign
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 460.dp))
    }
}

@Composable
private fun ControlMessageOverlay(error: String, message: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    val text = error.ifBlank { message }
    val critical = error.isNotBlank()
    LaunchedEffect(text) {
        if (text.isNotBlank() && !text.startsWith("状态读取失败") && !text.contains("已保存：")) {
            delay(4600)
            onDismiss()
        }
    }
    AnimatedContent(
        targetState = text,
        modifier = modifier.padding(horizontal = 18.dp, vertical = 16.dp),
        transitionSpec = {
            (fadeIn(tween(180, easing = MotionSpec.strongEaseOut)) + scaleIn(initialScale = .97f, animationSpec = tween(180, easing = MotionSpec.strongEaseOut))) togetherWith fadeOut(tween(100))
        },
        label = "message-overlay"
    ) { current ->
        if (current.isNotBlank()) {
            Surface(shape = RoundedCornerShape(20.dp), color = if (critical) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.inverseSurface, shadowElevation = 5.dp) {
                Row(Modifier.padding(horizontal = 15.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(current, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = if (critical) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.inverseOnSurface, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    TextButton(onClick = onDismiss) { Text("知道了") }
                }
            }
        } else {
            Spacer(Modifier.size(1.dp))
        }
    }
}

private fun copyText(context: Context, text: String) {
    if (text.isBlank()) return
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("AstrBot log", text))
}

private fun situationFor(ui: ControlCenterUiState): SituationData {
    val s = ui.status
    if (ui.actionBusy || s.actionRunning || s.stackStarting) {
        return SituationData(
            label = "处理中",
            title = ui.actionLabel.ifBlank { "服务正在变化" },
            detail = "控制中心正在等待核心组件完成操作并重新检查状态。",
            next = when {
                s.qqEngine == "snowluma" && (s.mainQqState == "starting" || s.qqNeedsLogin) -> "等待 QQ 登录窗口准备完成"
                s.stackStarting -> "等待服务启动完成"
                else -> "等待当前操作完成"
            }
        )
    }
    return when {
        s.qqNeedsLogin -> SituationData(
            label = "需操作",
            title = "QQ 等待登录",
            detail = "${qqEngineLabel(s)} 已经准备好，但 QQ 还没有完成登录。",
            next = "打开 QQ 登录工作区并完成登录",
            actionLabel = "QQ 登录",
            action = "login"
        )
        s.oneBotAuthFailed -> SituationData(
            label = "需修复",
            title = "消息连接需要修复",
            detail = "QQ 和机器人服务都在运行，但它们之间的消息连接配置不一致。",
            next = "修复消息连接",
            actionLabel = "帮我修复",
            action = "bridge"
        )
        s.qqStalledCount > 0 || s.snowlumaQqExited -> SituationData(
            label = "需检查",
            title = "QQ 运行状态异常",
            detail = s.qqAlertReason.ifBlank { s.mainQqReason.ifBlank { "QQ 进程没有处于预期状态。" } },
            next = "打开工具检查原因并处理",
            actionLabel = "帮我检查",
            action = "operations"
        )
        s.qqEngine == "snowluma" && s.stackRunning && s.oneBotConnected == 0 &&
            (s.mainQqState == "starting" || s.mainQqReason.contains("登录") || normalizedOneBotReason(s).contains("登录")) -> SituationData(
            label = "待确认",
            title = "QQ 等待登录",
            detail = "机器人服务已经准备好，现在只需要完成 QQ 登录。",
            next = "打开 QQ 登录工作区并完成登录",
            actionLabel = "QQ 登录",
            action = "login"
        )
        !s.stackRunning && s.coreReady -> SituationData(
            label = "待启动",
            title = "运行环境已就绪",
            detail = "核心组件和运行资源已经准备完成，目前服务处于停止状态。",
            next = "启动全部服务",
            actionLabel = "启动全部服务",
            action = "start"
        )
        s.stackRunning && s.oneBotConnected > 0 -> SituationData(
            label = "正常",
            title = "机器人已经上线",
            detail = "QQ 已登录，消息连接已经建立，可以正常收发消息。",
            next = "现在无需操作"
        )
        s.stackRunning -> SituationData(
            label = "等待连接",
            title = "服务已启动",
            detail = normalizedOneBotReason(s),
            next = "等待消息连接自动完成"
        )
        else -> SituationData(
            label = "检查中",
            title = "正在检查运行环境",
            detail = "控制中心正在确认运行环境、机器人服务、QQ 和消息连接。",
            next = "等待状态刷新"
        )
    }
}

private fun greetingTitle(status: RuntimeStatus): String = when (status.health) {
    RuntimeHealth.HEALTHY -> "运行正常"
    RuntimeHealth.WORKING -> "正在准备服务"
    RuntimeHealth.ATTENTION -> if (status.qqNeedsLogin) "等待 QQ 登录" else "有一项需要处理"
    RuntimeHealth.STOPPED -> "服务已停止"
    RuntimeHealth.UNKNOWN -> "正在读取状态"
}

private fun normalizedOneBotReason(status: RuntimeStatus): String = when {
    status.oneBotConnected > 0 -> "消息连接已建立"
    status.oneBotAuthFailed -> "消息连接配置不一致，需要修复"
    status.qqNeedsLogin -> "等待 QQ 登录后建立消息连接"
    status.activeQqUp -> "QQ 已启动，正在建立消息连接"
    else -> "等待 QQ 启动后建立消息连接"
}

private fun astrbotState(status: RuntimeStatus): String = when {
    status.astrbotUp && status.astrbotWebReady -> "正常"
    status.astrbotUp -> "启动中"
    status.astrbotReady -> "已停止"
    else -> "未就绪"
}

private fun astrbotDetail(status: RuntimeStatus): String = if (status.astrbotUp) "负责处理消息与机器人逻辑" else "启动后负责处理消息与机器人逻辑"
private fun oneBotState(status: RuntimeStatus): String = when {
    status.oneBotConnected > 0 -> "已连接"
    status.oneBotAuthFailed -> "鉴权异常"
    status.oneBotListen -> "等待连接"
    else -> "未连接"
}
private fun oneBotDetail(status: RuntimeStatus): String = normalizedOneBotReason(status)
private fun qqEngineLabel(status: RuntimeStatus): String = if (status.qqEngine == "snowluma") "SnowLuma" else "NapCat"
private fun qqStateLabel(status: RuntimeStatus): String = when {
    status.qqOnline -> "在线"
    status.qqNeedsLogin -> "需要登录"
    status.qqEngine == "snowluma" && status.oneBotConnected == 0 &&
        (status.mainQqReason.contains("登录") || normalizedOneBotReason(status).contains("登录")) -> "待登录"
    status.qqStartingCount > 0 -> "启动中"
    status.qqStalledCount > 0 || status.snowlumaQqExited -> "异常"
    status.mainQqState == "stopped" -> "已停止"
    else -> status.mainQqState.replace('_', ' ').ifBlank { "未知" }
}

private fun navGlyph(destination: ControlDestination, selected: Boolean): String = when (destination) {
    ControlDestination.OVERVIEW -> if (selected) "◉" else "◎"
    ControlDestination.CONSOLE -> if (selected) "▣" else "▢"
    ControlDestination.ENVIRONMENT -> if (selected) "◆" else "◇"
    ControlDestination.OPERATIONS -> if (selected) "≈" else "⌁"
}

private fun loginPhaseTitle(phase: String): String = when (phase) {
    "installing" -> "正在准备原生截图组件"
    "starting" -> "正在唤醒 QQ 登录窗口"
    "capturing" -> "正在读取 QQ 登录画面"
    "ready" -> "QQ 登录画面已就绪"
    "desktop-starting" -> "正在启动完整 QQ 桌面"
    "desktop-capturing" -> "正在读取完整 QQ 桌面"
    "desktop" -> "完整 QQ 桌面已就绪"
    "rendering" -> "正在启动完整 QQ 桌面"
    "complete" -> "QQ 登录已完成"
    "failed" -> "QQ 登录画面准备失败"
    else -> "正在准备 QQ 登录画面"
}

private fun loginNextStep(phase: String): String = when (phase) {
    "installing" -> "等待原生截图组件安装完成"
    "starting" -> "等待 QQ 登录窗口出现"
    "capturing" -> "等待第一张 QQ 登录画面"
    "desktop-starting" -> "等待完整 QQ 桌面启动"
    "desktop-capturing" -> "等待第一张完整桌面画面"
    "rendering" -> "等待完整 QQ 桌面启动"
    "complete" -> "QQ 登录已完成"
    "failed" -> "查看原因后重新连接"
    else -> "等待 QQ 登录画面准备完成"
}
