package com.xianaurora.astrbotcontrol.engine

import java.security.MessageDigest

/**
 * UI-side privacy filter for logs shown/copied in the native control center.
 * The Engine's redacted diagnostic bundle remains the authoritative export path;
 * this filter makes on-screen logs safe by default as well.
 *
 * Replacements are deterministic: the same sensitive value maps to the same short
 * pseudonym, which preserves debugging relationships without exposing the raw value.
 */
object LogRedactor {
    private val secretKv = Regex(
        """(?i)((?<!<)\b(?:access[_-]?token|token|secret|password|passwd|api[_-]?key|apikey|session|webui[_-]?token|onebot[_-]?token)\b\s*[:=]\s*)([^\s,;\]}"]+)"""
    )
    private val authorizationHeader = Regex("(?i)(\\bAuthorization\\b\\s*[:=]\\s*)((?:Bearer|Basic)\\s+)?([^\\s,;]+)")
    private val cookieHeader = Regex("(?i)(\\b(?:Cookie|Set-Cookie)\\b\\s*[:=]\\s*)([^\\r\\n]+)")
    private val bearer = Regex("(?i)\\bBearer\\s+([A-Za-z0-9._~+\\-/=]{8,})")
    private val qqKv = Regex("(?i)(\\b(?:qq|uin|account|qq_number|qqid|user_id|self_id|bot_id)\\b\\s*[:=]\\s*)([1-9][0-9]{4,14})")
    private val urlSecret = Regex("(?i)([?&](?:token|access_token|key|secret|auth|password|ticket|code|sign|qrsig|ptqrtoken)=)([^&#\\s]+)")
    private val qqLoginUrl = Regex("(?i)https?://[^\\s\"<>]*(?:txz\\.qq\\.com|qrsig|ptqrtoken|qrcode|qrlogin)[^\\s\"<>]*")
    private val ipv4 = Regex("(?<![0-9])((?:[0-9]{1,3}\\.){3}[0-9]{1,3})(?![0-9])")
    private val ipv6 = Regex("(?i)(?<![0-9a-f:])(?:[0-9a-f]{1,4}:){2,7}[0-9a-f]{0,4}(?![0-9a-f:])")
    private val androidId = Regex("(?i)(\\b(?:android_id|device_id|serial|imei)\\b\\s*[:=]\\s*)([A-Za-z0-9._:-]{6,})")
    private val homePath = Regex("/(?:data/user/\\d+/[^/\\s]+|storage/emulated/\\d+/[^/\\s]+|sdcard/Android/data/[^/\\s]+)")

    fun redact(text: String): String {
        if (text.isBlank()) return text
        var out = text
        out = authorizationHeader.replace(out) { m -> m.groupValues[1] + m.groupValues[2] + tag("TOKEN", m.groupValues[3].trim()) }
        out = cookieHeader.replace(out) { m -> m.groupValues[1] + tag("COOKIE", m.groupValues[2].trim()) }
        out = bearer.replace(out) { m -> "Bearer " + tag("TOKEN", m.groupValues[1]) }
        out = secretKv.replace(out) { m -> m.groupValues[1] + tag("TOKEN", m.groupValues[2]) }
        out = qqKv.replace(out) { m -> m.groupValues[1] + tag("QQ", m.groupValues[2]) }
        out = qqLoginUrl.replace(out) { m -> tag("LOGIN_URL", m.value) }
        out = urlSecret.replace(out) { m -> m.groupValues[1] + tag("TOKEN", m.groupValues[2]) }
        out = androidId.replace(out) { m -> m.groupValues[1] + tag("DEVICE", m.groupValues[2]) }
        out = ipv4.replace(out) { m ->
            val value = m.groupValues[1]
            if (value == "127.0.0.1" || value.startsWith("0.") || value.startsWith("255.")) value else tag("IP", value)
        }
        out = ipv6.replace(out) { m ->
            val value = m.value
            if (value == "::1" || value == "::") value else tag("IP", value)
        }
        out = homePath.replace(out) { m -> tag("PATH", m.value) }
        return out
    }

    private fun tag(kind: String, value: String): String {
        if (value.matches(Regex("<[A-Z]+:[0-9A-F]{6}>"))) return value
        val digest = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        val id = digest.take(3).joinToString("") { "%02X".format(it) }
        return "<$kind:$id>"
    }
}
