package com.xianaurora.astrbotcontrol.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

data class ShellResult(
    val code: Int,
    val stdout: String,
    val stderr: String,
    val timedOut: Boolean = false
) {
    val ok: Boolean get() = code == 0 && !timedOut
}

class RootShell {
    suspend fun root(command: String, timeoutSeconds: Long = 30): ShellResult = withContext(Dispatchers.IO) {
        // A shell inside its own session writes its PID to a short-lived file.  This
        // avoids the newer Java Process PID API, which is not available in every Android
        // bootclasspath used by our CI even when the JVM target itself is 17.
        val pidFile = "/data/local/tmp/astr-control-shell-${System.nanoTime()}.pid"
        val worker = "echo ${'$'}${'$'} > ${q(pidFile)}; exec /system/bin/sh -c ${q(command)}"
        val wrapped = "exec /system/bin/toybox setsid /system/bin/sh -c ${q(worker)}"
        try {
            runProcess(listOf("su", "-c", wrapped), timeoutSeconds, rootPidFile = pidFile)
        } finally {
            runCatching { File(pidFile).delete() }
            // The app UID normally cannot remove a root-owned pid file, so also ask
            // root to clean it.  This is best effort and deliberately has no user data.
            runCatching {
                val cleaner = ProcessBuilder(listOf("su", "-c", "rm -f ${q(pidFile)}"))
                    .redirectErrorStream(true)
                    .start()
                cleaner.waitFor(600, TimeUnit.MILLISECONDS)
                if (cleaner.isAlive) cleaner.destroyForcibly()
            }
        }
    }

    suspend fun normal(command: String, timeoutSeconds: Long = 15): ShellResult = withContext(Dispatchers.IO) {
        runProcess(listOf("sh", "-c", command), timeoutSeconds, rootPidFile = null)
    }

    private fun runProcess(args: List<String>, timeoutSeconds: Long, rootPidFile: String?): ShellResult {
        return try {
            val process = ProcessBuilder(args).redirectErrorStream(false).start()
            val outReader = BufferedReader(InputStreamReader(process.inputStream))
            val errReader = BufferedReader(InputStreamReader(process.errorStream))
            val out = StringBuilder()
            val err = StringBuilder()
            val outThread = Thread { readBounded(outReader, out) }.apply { name = "astr-shell-stdout" }
            val errThread = Thread { readBounded(errReader, err) }.apply { name = "astr-shell-stderr" }
            outThread.start()
            errThread.start()

            val done = process.waitFor(timeoutSeconds.coerceAtLeast(1), TimeUnit.SECONDS)
            if (!done) {
                val rootPid = rootPidFile?.let(::readRootPid)
                if (rootPid != null) terminateRootTree(rootPid, force = false)
                process.destroy()
                if (!process.waitFor(450, TimeUnit.MILLISECONDS)) {
                    if (rootPid != null) terminateRootTree(rootPid, force = true)
                    process.destroyForcibly()
                    process.waitFor(800, TimeUnit.MILLISECONDS)
                }
                runCatching { process.inputStream.close() }
                runCatching { process.errorStream.close() }
            }
            outThread.join(1600)
            errThread.join(1600)
            ShellResult(
                code = if (done) process.exitValue() else -1,
                stdout = out.toString().trimEnd(),
                stderr = err.toString().trimEnd(),
                timedOut = !done
            )
        } catch (t: Throwable) {
            ShellResult(-1, "", t.message ?: t::class.java.simpleName)
        }
    }

    private fun readRootPid(pidFile: String): Long? {
        val command = "cat ${q(pidFile)} 2>/dev/null"
        return runCatching {
            val reader = ProcessBuilder(listOf("su", "-c", command)).redirectErrorStream(true).start()
            val text = reader.inputStream.bufferedReader().use { it.readText().trim() }
            reader.waitFor(500, TimeUnit.MILLISECONDS)
            if (reader.isAlive) reader.destroyForcibly()
            text.toLongOrNull()?.takeIf { it > 1L }
        }.getOrNull()
    }

    private fun readBounded(reader: BufferedReader, target: StringBuilder) {
        reader.use {
            while (true) {
                val line = runCatching { it.readLine() }.getOrNull() ?: break
                if (target.length < MAX_CAPTURE_CHARS) {
                    val remaining = MAX_CAPTURE_CHARS - target.length
                    if (remaining > 0) target.append(line.take(remaining))
                    if (target.length < MAX_CAPTURE_CHARS) target.append('\n')
                }
            }
        }
        if (target.length >= MAX_CAPTURE_CHARS && !target.endsWith(TRUNCATED_MARKER)) {
            val keep = (MAX_CAPTURE_CHARS - TRUNCATED_MARKER.length).coerceAtLeast(0)
            if (target.length > keep) target.setLength(keep)
            target.append(TRUNCATED_MARKER)
        }
    }

    /** Best-effort recursive cleanup for a timed-out root command. */
    private fun terminateRootTree(rootPid: Long, force: Boolean) {
        if (rootPid <= 1L) return
        val signal = if (force) "KILL" else "TERM"
        val script = """
            ROOT_PID=$rootPid
            SIGNAL=$signal
            kill_tree() {
              P="${'$'}1"
              F="/proc/${'$'}P/task/${'$'}P/children"
              if [ -r "${'$'}F" ]; then
                for C in ${'$'}(cat "${'$'}F" 2>/dev/null); do
                  kill_tree "${'$'}C"
                done
              fi
              kill -"${'$'}SIGNAL" "${'$'}P" 2>/dev/null || true
            }
            kill_tree "${'$'}ROOT_PID"
        """.trimIndent()
        runCatching {
            val killer = ProcessBuilder(listOf("su", "-c", script)).redirectErrorStream(true).start()
            killer.waitFor(900, TimeUnit.MILLISECONDS)
            if (killer.isAlive) killer.destroyForcibly()
        }
    }

    companion object {
        private const val MAX_CAPTURE_CHARS = 512 * 1024
        private const val TRUNCATED_MARKER = "\n… output truncated by Control Center …"

        fun q(value: String): String = "'" + value.replace("'", "'\\''") + "'"
    }
}
