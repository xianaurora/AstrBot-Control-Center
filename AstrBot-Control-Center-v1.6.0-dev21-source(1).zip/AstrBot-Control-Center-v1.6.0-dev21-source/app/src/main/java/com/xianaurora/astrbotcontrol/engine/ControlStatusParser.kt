package com.xianaurora.astrbotcontrol.engine

import com.xianaurora.astrbotcontrol.model.RuntimeStatus

object ControlStatusParser {
    fun parse(text: String): RuntimeStatus {
        val m = linkedMapOf<String, String>()
        text.lineSequence().forEach { line ->
            if (!line.startsWith("STATUS|")) return@forEach
            val p = line.split('|', limit = 3)
            if (p.size >= 3) m[p[1]] = p[2]
        }
        fun s(key: String) = m[key].orEmpty()
        fun b(key: String) = s(key) == "1"
        fun i(key: String) = s(key).toIntOrNull() ?: 0
        fun l(key: String) = s(key).toLongOrNull() ?: 0L

        val qqEngine = s("QQ_ENGINE").ifBlank { "napcat" }
        val rawOneBotReason = s("ONEBOT_REASON")
        val oneBotReason = when {
            qqEngine == "snowluma" && rawOneBotReason.contains("NapCat", ignoreCase = true) ->
                s("MAIN_QQ_REASON").ifBlank { "SnowLuma 正在等待 OneBot 连接" }
            qqEngine == "napcat" && rawOneBotReason.contains("SnowLuma", ignoreCase = true) ->
                s("MAIN_QQ_REASON").ifBlank { "NapCat 正在等待 OneBot 连接" }
            else -> rawOneBotReason
        }

        return RuntimeStatus(
            moduleVersion = s("MODULE_VERSION"),
            qqEngine = qqEngine,
            astrbotUp = b("ASTRBOT_UP"),
            astrbotWebReady = b("ASTRBOT_WEB_READY"),
            astrbotPid = s("ASTRBOT_PID"),
            astrbotPort = i("ASTRBOT_PORT"),
            napcatUp = b("NAPCAT_UP"),
            napcatWebReady = b("NAPCAT_WEB_READY"),
            napcatPid = s("NAPCAT_PID"),
            snowlumaUp = b("SNOWLUMA_UP"),
            snowlumaWebReady = b("SNOWLUMA_WEB_READY"),
            snowlumaPid = s("SNOWLUMA_PID"),
            snowlumaPort = i("SNOWLUMA_PORT"),
            snowlumaQqExited = b("SNOWLUMA_QQ_EXITED"),
            oneBotListen = b("ONEBOT_LISTEN"),
            oneBotConnected = i("ONEBOT_CONNECTED"),
            oneBotAuthFailed = b("ONEBOT_AUTH_FAILED"),
            oneBotReason = oneBotReason,
            qqOnlineCount = i("QQ_ONLINE_COUNT"),
            qqLoginRequiredCount = i("QQ_LOGIN_REQUIRED_COUNT"),
            qqStartingCount = i("QQ_STARTING_COUNT"),
            qqStalledCount = i("QQ_STALLED_COUNT"),
            qqAlertInstance = s("QQ_ALERT_INSTANCE"),
            qqAlertReason = s("QQ_ALERT_REASON"),
            mainQqState = s("MAIN_QQ_STATE").ifBlank { "unknown" },
            mainQqReason = s("MAIN_QQ_REASON"),
            rootfsReady = b("ROOTFS_READY"),
            astrbotReady = b("ASTRBOT_READY"),
            napcatReady = b("NAPCAT_READY"),
            snowlumaReady = b("SNOWLUMA_READY"),
            bridgeReady = b("BRIDGE_READY"),
            fastBootReady = b("FAST_BOOT_READY"),
            installReady = b("INSTALL_READY"),
            actionRunning = b("ACTION_RUNNING"),
            stackStarting = b("STACK_STARTING"),
            stackAutostart = b("STACK_AUTOSTART"),
            watchdogEnabled = b("WATCHDOG_ENABLED"),
            watchdogRunning = b("WATCHDOG_RUNNING"),
            rescueEnabled = b("RESCUE_SUPERVISOR_ENABLED"),
            rescueRunning = b("RESCUE_SUPERVISOR_RUNNING"),
            messageGuardEnabled = b("MESSAGE_GUARD_ENABLED"),
            messageGuardRunning = b("MESSAGE_GUARD_RUNNING"),
            downloadSource = s("DOWNLOAD_SOURCE").ifBlank { "auto" },
            downloadSourceEffective = s("DOWNLOAD_SOURCE_EFFECTIVE"),
            instanceTotal = i("INSTANCE_TOTAL"),
            instanceEnabled = i("INSTANCE_ENABLED"),
            instanceRunning = i("INSTANCE_RUNNING"),
            lastBootResult = s("LAST_BOOT_RESULT").ifBlank { "unknown" },
            lastBootSeconds = i("LAST_BOOT_SECONDS"),
            lastStackResult = s("LAST_STACK_RESULT").ifBlank { "unknown" },
            lastStackSeconds = i("LAST_STACK_SECONDS"),
            device = s("DEVICE"),
            android = s("ANDROID"),
            kernel = s("KERNEL"),
            apiWarning = b("API_WARN"),
            apiWarningReason = s("API_WARN_REASON"),
            toolWarning = b("TOOL_WARN"),
            pluginBlock = b("PLUGIN_BLOCK"),
            eventLoopWarning = b("EVENT_LOOP_WARN"),
            lastInbound = s("LAST_INBOUND").ifBlank { "暂无" },
            lastOutbound = s("LAST_OUTBOUND").ifBlank { "暂无" },
            lastModelOk = s("LAST_MODEL_OK").ifBlank { "暂无" },
            lastEvent = s("LAST_EVENT"),
            statusEpoch = l("STATUS_TIME")
        )
    }
}
