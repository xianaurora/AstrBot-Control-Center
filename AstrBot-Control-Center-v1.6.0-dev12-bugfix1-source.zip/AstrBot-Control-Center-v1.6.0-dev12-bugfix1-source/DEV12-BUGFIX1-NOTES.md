# dev12 bugfix1

This patch intentionally contains stability fixes only.

- Removed stale dev3 installer target metadata and made the installer read the target Core release from `EngineRepository`.
- Made rootfs import/download validation use the active resource catalog size/SHA consistently, including resumable `.part` handling.
- Serialized Core `settings.conf` writes with a lock and per-process temporary file.
- Unified missing `stack_autostart` defaults to enabled across boot/watchdog/CLI paths.
- Reworked RootShell timeouts to drain bounded output and terminate the spawned process tree instead of only the top `su` process.
- Native QQ frame polling no longer expires after ~5 minutes, resumes after app foreground return, and pauses while a manual QR refresh is in progress.
- Operations log polling now runs only while the Logs section is actually visible.
- Removed the 4.5-second WebView visible-DOM heuristic that could falsely mark a slow AstrBot SPA as failed.
- Synchronized app/core/catalog/CI release metadata.
