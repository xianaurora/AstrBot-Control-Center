# Build status — v1.6.0-dev12-bugfix1

- Android App: `1.6.0-dev12-bugfix1` / `161001`
- 内置核心组件: `1.6.0-dev10` / `16010`
- Scope: bug fixes only; no new user-facing feature or layout work in this patch.
- Validation: `scripts/verify-source.sh` plus engine shell/manifest checks.
- Final Android compile remains delegated to the repository GitHub Actions workflow.
