package com.xianaurora.astrbotcontrol.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.util.concurrent.TimeUnit

data class ShellResult(
    val code: Int,
    val stdout: String,
    val stderr: String,
    val timedOut: Boolean = false
) {
    val ok: Boolean get() = code == 0 && !timedOut
}

class RootShell {
    suspend fun root(command: String, timeoutSeconds: Long = 30): ShellResult = withContext(Dispatchers.IO) {
        runProcess(listOf("su", "-c", command), timeoutSeconds, rootProcess = true)
    }

    suspend fun normal(command: String, timeoutSeconds: Long = 15): ShellResult = withContext(Dispatchers.IO) {
        runProcess(listOf("sh", "-c", command), timeoutSeconds, rootProcess = false)
    }

    private fun runProcess(args: List<String>, timeoutSeconds: Long, rootProcess: Boolean): ShellResult {
        return try {
            val process = ProcessBuilder(args).redirectErrorStream(false).start()
            val out = StringBuilder()
            val err = StringBuilder()
            val outThread = Thread { drainLimited(process.inputStream, out) }.apply { isDaemon = true }
            val errThread = Thread { drainLimited(process.errorStream, err) }.apply { isDaemon = true }
            outThread.start()
            errThread.start()
            val done = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)
            if (!done) {
                terminateProcessTree(process.pid(), rootProcess)
                process.destroyForcibly()
                process.waitFor(1200, TimeUnit.MILLISECONDS)
            }
            outThread.join(1500)
            errThread.join(1500)
            runCatching { process.inputStream.close() }
            runCatching { process.errorStream.close() }
            runCatching { process.outputStream.close() }
            ShellResult(
                if (done) process.exitValue() else -1,
                out.toString().trimEnd(),
                err.toString().trimEnd(),
                !done
            )
        } catch (t: Throwable) {
            ShellResult(-1, "", t.message ?: t::class.java.simpleName)
        }
    }

    private fun drainLimited(input: InputStream, output: StringBuilder) {
        input.bufferedReader().use { reader ->
            val buffer = CharArray(8192)
            var kept = 0
            var truncated = false
            while (true) {
                val count = reader.read(buffer)
                if (count <= 0) break
                if (kept < MAX_OUTPUT_CHARS) {
                    val take = minOf(count, MAX_OUTPUT_CHARS - kept)
                    output.append(buffer, 0, take)
                    kept += take
                    if (take < count) truncated = true
                } else {
                    truncated = true
                }
            }
            if (truncated) output.append("\n[output truncated]")
        }
    }

    private fun terminateProcessTree(pid: Long, rootProcess: Boolean) {
        if (pid <= 1) return
        val script = """
            kill_tree() {
              p=${'$'}1
              [ -r /proc/${'$'}p/task/${'$'}p/children ] || { kill -TERM ${'$'}p 2>/dev/null || true; return; }
              for c in ${'$'}(cat /proc/${'$'}p/task/${'$'}p/children 2>/dev/null); do kill_tree ${'$'}c; done
              kill -TERM ${'$'}p 2>/dev/null || true
            }
            kill_tree $pid
            sleep 0.15
            kill_tree_kill() {
              p=${'$'}1
              [ -r /proc/${'$'}p/task/${'$'}p/children ] && for c in ${'$'}(cat /proc/${'$'}p/task/${'$'}p/children 2>/dev/null); do kill_tree_kill ${'$'}c; done
              kill -KILL ${'$'}p 2>/dev/null || true
            }
            kill_tree_kill $pid
        """.trimIndent()
        runCatching {
            val killerArgs = if (rootProcess) listOf("su", "-c", script) else listOf("sh", "-c", script)
            val killer = ProcessBuilder(killerArgs).redirectErrorStream(true).start()
            killer.waitFor(3, TimeUnit.SECONDS)
            if (killer.isAlive) killer.destroyForcibly()
        }
    }

    companion object {
        private const val MAX_OUTPUT_CHARS = 512 * 1024
        fun q(value: String): String = "'" + value.replace("'", "'\\''") + "'"
    }
}
