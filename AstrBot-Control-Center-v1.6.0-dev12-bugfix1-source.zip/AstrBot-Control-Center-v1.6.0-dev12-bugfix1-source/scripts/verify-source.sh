#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

expected="$(awk 'NR==1{print $1}' "$ASSETS/engine.sha256")"
actual="$(sha256sum "$ASSETS/engine.zip" | awk '{print $1}')"
[[ "$expected" == "$actual" ]] || { echo "engine.zip SHA mismatch" >&2; exit 20; }
unzip -t "$ASSETS/engine.zip" >/dev/null
unzip -q "$ASSETS/engine.zip" -d "$TMP/engine"
(
  cd "$TMP/engine"
  sha256sum -c manifest/module-files.sha256 >/dev/null
)

grep -qx 'version=1.6.0-dev10' "$TMP/engine/module.prop" || { echo "unexpected embedded core version" >&2; exit 21; }
grep -qx 'versionCode=16010' "$TMP/engine/module.prop" || { echo "unexpected embedded core versionCode" >&2; exit 22; }
grep -q '^VERSION=v1.6.0-dev10$' "$TMP/engine/astrctl" || { echo "astrctl release mismatch" >&2; exit 23; }

count=0
while IFS= read -r file; do
  case "$file" in
    *.sh|*/astrctl|*/service.sh|*/post-fs-data.sh|*/action.sh)
      if head -n 1 "$file" | grep -q 'bash'; then bash -n "$file"; else sh -n "$file"; fi
      count=$((count+1))
      ;;
  esac
done < <(find "$TMP/engine" -type f -print | sort)

python3 - "$ROOT" <<'PY'
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
root = Path(sys.argv[1])
for f in root.rglob('*.xml'):
    ET.parse(f)
for f in root.rglob('*.kt'):
    lines = f.read_text(errors='replace').splitlines()
    imports = [x for x in lines if x.startswith('import ')]
    if len(imports) != len(set(imports)):
        raise SystemExit(f"duplicate Kotlin import: {f}")
PY

CONTROL="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/ui/ControlCenterApp.kt"
WEBVIEW="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/ui/EmbeddedConsoleWebView.kt"
MODELS="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/model/ControlCenterModels.kt"
REPO="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlCenterRepository.kt"
VM="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlCenterViewModel.kt"
ENGINE_REPO="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/EngineRepository.kt"
INSTALLER_MODELS="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/model/InstallerModels.kt"
INSTALLER_VM="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/InstallerViewModel.kt"
ROOT_SHELL="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/RootShell.kt"
WORKFLOW="$ROOT/.github/workflows/build-apk.yml"

# General app invariants from earlier crash/build fixes.
if grep -q 'AnimatedVisibility' "$CONTROL"; then
  echo "ControlCenterApp.kt unexpectedly reintroduced AnimatedVisibility" >&2; exit 24
fi
if grep -Eq 'SelectionContainer[[:space:]]*[{(]' "$CONTROL"; then
  echo "live logs must not be wrapped in SelectionContainer" >&2; exit 25
fi
grep -q 'versionName = "1.6.0-dev12-bugfix1"' "$ROOT/app/build.gradle.kts" || { echo "app version mismatch" >&2; exit 26; }
grep -q 'versionCode = 161001' "$ROOT/app/build.gradle.kts" || { echo "app versionCode mismatch" >&2; exit 27; }
grep -q 'TARGET_ENGINE_VERSION = "1.6.0-dev10"' "$ENGINE_REPO" || { echo "core target mismatch" >&2; exit 28; }
grep -q 'TARGET_ENGINE_VERSION_CODE = 16010' "$ENGINE_REPO" || { echo "core target code mismatch" >&2; exit 29; }

python3 - "$CONTROL" <<'PY'
import re, sys
from pathlib import Path
text = Path(sys.argv[1]).read_text()
for name in ("SituationText", "NextStepBeacon", "SituationAction", "QqLoginWorkspace", "NativeQqLoginFrame", "QqLoginComplete", "QqLoginStatusStrip"):
    if not re.search(r"@Composable\s+(?:private\s+)?fun\s+" + re.escape(name) + r"\s*\(", text):
        raise SystemExit(f"Compose annotation missing on {name}")
PY

grep -q 'NextStepBeacon' "$CONTROL" || { echo "animated next-step beacon missing" >&2; exit 30; }

# dev11 native QR contract: default scan path is PNG -> Compose, not noVNC/WebView.
grep -q 'capture_qq_login_frame()' "$TMP/engine/guest/run-snowluma.sh" || { echo "native QQ frame capture missing" >&2; exit 31; }
grep -q -- '-f x11grab' "$TMP/engine/guest/run-snowluma.sh" || { echo "FFmpeg x11grab capture missing" >&2; exit 32; }
grep -q 'SNOWLUMA_NATIVE_QR_FRAME_READY' "$TMP/engine/guest/run-snowluma.sh" || { echo "native frame diagnostic marker missing" >&2; exit 33; }
grep -q 'snowluma-login-frame ID' "$TMP/engine/astrctl" || { echo "native frame command missing" >&2; exit 34; }
grep -q 'cmd_snowluma_login_frame()' "$TMP/engine/astrctl" || { echo "native frame implementation missing" >&2; exit 35; }
grep -q 'snowluma-login-desktop)' "$TMP/engine/astrctl" || { echo "advanced full-desktop fallback missing" >&2; exit 36; }
LOGIN_BLOCK="$(sed -n '/^[[:space:]]*login)$/,/^[[:space:]]*frame)/p' "$TMP/engine/guest/run-snowluma.sh")"
if grep -F 'start_novnc' <<<"$LOGIN_BLOCK" >/dev/null; then
  echo "normal SnowLuma login still starts noVNC" >&2; exit 37
fi
grep -F 'capture_qq_login_frame' <<<"$LOGIN_BLOCK" >/dev/null || { echo "normal SnowLuma login does not capture native frame" >&2; exit 38; }
MONITOR_BLOCK="$(sed -n '/^monitor_login_sessions()/,/^monitor_desktops()/p' "$TMP/engine/guest/run-snowluma.sh")"
grep -F 'QQ_PIDS' <<<"$MONITOR_BLOCK" >/dev/null || { echo "login completion is not tied to QQ process" >&2; exit 39; }
if grep -F 'NOVNC_PIDS' <<<"$MONITOR_BLOCK" >/dev/null; then
  echo "login completion still depends on noVNC" >&2; exit 40
fi

# Android side must decode the frame and render it natively.
grep -q 'suspend fun qqLoginFrame' "$REPO" || { echo "Android native frame repository missing" >&2; exit 41; }
grep -q 'snowluma-login-frame main' "$REPO" || { echo "Android native frame command wiring missing" >&2; exit 42; }
grep -q 'startNativeQqFramePolling' "$VM" || { echo "native frame polling missing" >&2; exit 43; }
grep -q 'qrImageBytes = frame.png' "$VM" || { echo "native PNG is not stored in UI state" >&2; exit 44; }
grep -q 'BitmapFactory.decodeByteArray' "$CONTROL" || { echo "native PNG decode missing" >&2; exit 45; }
grep -q 'private fun NativeQqLoginFrame' "$CONTROL" || { echo "native QR composable missing" >&2; exit 46; }
grep -q '二维码过期时由你手动触发一次刷新' "$CONTROL" || { echo "manual QR refresh UX label missing" >&2; exit 47; }
grep -q 'openQqDesktop' "$VM" || { echo "advanced desktop action missing" >&2; exit 48; }

# dev12 manual QR refresh: only exposed after the native frame detects QQ's expired state.
grep -q 'snowluma-login-refresh-code ID' "$TMP/engine/astrctl" || { echo "manual QR refresh command missing" >&2; exit 60; }
grep -q 'refresh_qq_qr_code()' "$TMP/engine/guest/run-snowluma.sh" || { echo "manual QR refresh implementation missing" >&2; exit 61; }
grep -q 'policy=user_triggered_once' "$TMP/engine/guest/run-snowluma.sh" || { echo "manual QR refresh is not explicitly user-triggered-once" >&2; exit 62; }
grep -q 'SLRC_AGE=.*SLRC_NOW-SLRC_LAST' "$TMP/engine/astrctl" || { echo "manual QR refresh Core cooldown missing" >&2; exit 73; }
grep -q 'SLRC_AGE.*-lt 30' "$TMP/engine/astrctl" || { echo "manual QR refresh 30-second cooldown missing" >&2; exit 74; }
grep -q 'looksLikeExpiredQqQr' "$REPO" || { echo "expired QR detector missing" >&2; exit 63; }
grep -q 'qrExpired = frame.expired' "$VM" || { echo "expired QR state wiring missing" >&2; exit 64; }
grep -q 'fun refreshQqLoginCode' "$VM" || { echo "manual QR refresh action missing" >&2; exit 65; }
grep -q 'qrRefreshAvailableAtMs' "$MODELS" || { echo "manual QR refresh cooldown state missing" >&2; exit 66; }
[[ "$(grep -R -o 'refreshQqLoginCode' "$ROOT/app/src/main/java" | wc -l | tr -d ' ')" == 2 ]] || { echo "manual QR refresh has unexpected automatic call sites" >&2; exit 75; }
[[ "$(grep -o 'repository.qqLoginRefreshCode()' "$VM" | wc -l | tr -d ' ')" == 1 ]] || { echo "manual QR refresh repository call count is not one" >&2; exit 76; }
REFRESH_BLOCK="$(sed -n '/^refresh_qq_qr_code()/,/^start_qq_for()/p' "$TMP/engine/guest/run-snowluma.sh")"
[[ "$(grep -o 'click 1' <<<"$REFRESH_BLOCK" | wc -l | tr -d ' ')" == 1 ]] || { echo "Core QR refresh must send exactly one click" >&2; exit 77; }
if grep -Eq '^[[:space:]]*(while|for)[[:space:]]' <<<"$REFRESH_BLOCK"; then
  echo "Core QR refresh unexpectedly contains an automatic loop" >&2; exit 78
fi
if grep -R -q 'qrRefreshCoolingDown\|refreshQqQrCode' "$ROOT/app/src/main/java"; then
  echo "stale QR refresh implementation remains" >&2; exit 67
fi

# AstrBot WebUI: verify root/assets/MIME in the core, and never fight SPA navigation from Compose.
grep -q 'cmd_web_probe()' "$TMP/engine/astrctl" || { echo "AstrBot WebUI probe command missing" >&2; exit 68; }
grep -q "emit('ok', '200'" "$TMP/engine/guest/probe-astrbot-web.py" || { echo "AstrBot WebUI probe implementation missing" >&2; exit 69; }
grep -q 'suspend fun astrbotWebProbe' "$REPO" || { echo "Android AstrBot WebUI probe wiring missing" >&2; exit 70; }
grep -q 'lastRequestedUrl' "$WEBVIEW" || { echo "WebView requested-URL tracking missing" >&2; exit 71; }
if grep -F 'view.url != url' "$WEBVIEW" >/dev/null; then
  echo "SPA-breaking exact-current-URL reload loop remains" >&2; exit 72
fi

# WebView recovery stays non-destructive: no old canvas/blank recovery loop, cache clear, host swap, or automatic reload.
for forbidden in STANDARD_PAGE_PROBE_JS QR_FRAME_PROBE_JS qrDesktopFallbackUrl alternateLoopbackUrl 'clearCache('; do
  if grep -F "$forbidden" "$WEBVIEW" >/dev/null; then
    echo "obsolete WebView recovery heuristic remains: $forbidden" >&2; exit 49
  fi
done
grep -q 'onPageStarted' "$WEBVIEW" || { echo "WebView page-start callback missing" >&2; exit 50; }
grep -q 'onPageFinished' "$WEBVIEW" || { echo "WebView page-finished callback missing" >&2; exit 51; }
grep -q 'onReceivedError' "$WEBVIEW" || { echo "WebView network error callback missing" >&2; exit 52; }
grep -q 'onReceivedHttpError' "$WEBVIEW" || { echo "WebView HTTP error callback missing" >&2; exit 53; }
grep -q 'onConsoleMessage' "$WEBVIEW" || { echo "WebView console diagnostics missing" >&2; exit 54; }
grep -q 'onRenderProcessGone' "$WEBVIEW" || { echo "WebView renderer recovery missing" >&2; exit 55; }
if grep -q 'LAYER_TYPE_SOFTWARE' "$WEBVIEW"; then
  echo "forced software WebView compositor reintroduced" >&2; exit 56
fi
grep -q 'RENDERER_PRIORITY_IMPORTANT' "$WEBVIEW" || { echo "WebView renderer priority missing" >&2; exit 57; }

# Legacy advanced desktop performance tuning remains isolated to explicit noVNC use.
grep -q -- '-nowf -wait 10 -defer 10 -nowait_bog -nonap' "$TMP/engine/guest/run-snowluma.sh" || { echo "advanced noVNC responsiveness tuning missing" >&2; exit 58; }

# dev12 bugfix1 stability gates: no feature expansion, only correctness/lifecycle fixes.
if grep -Eq '1\.6\.0-dev3|16003' "$INSTALLER_MODELS"; then
  echo "stale installer target release remains" >&2; exit 79
fi
grep -q 'targetEngineVersion = EngineRepository.TARGET_ENGINE_VERSION' "$INSTALLER_VM" || { echo "installer target is not sourced from EngineRepository" >&2; exit 80; }
grep -q 'targetEngineVersionCode = EngineRepository.TARGET_ENGINE_VERSION_CODE' "$INSTALLER_VM" || { echo "installer target code is not sourced from EngineRepository" >&2; exit 81; }
cmp -s "$ROOT/app/src/main/assets/resource-catalog.json" "$TMP/engine/manifest/resource-catalog.json" || { echo "app/core resource catalogs diverged" >&2; exit 82; }
grep -q '"release": "v1.6.0-dev10"' "$ROOT/app/src/main/assets/resource-catalog.json" || { echo "resource catalog release mismatch" >&2; exit 83; }
grep -q 'importVerifiedRootfsFile(file: File, catalog: RootfsCatalog)' "$ENGINE_REPO" || { echo "rootfs import still ignores catalog metadata" >&2; exit 84; }
grep -q 'copied.toDouble() / catalog.size.toDouble()' "$ENGINE_REPO" || { echo "local rootfs import progress still uses hardcoded size" >&2; exit 85; }
if grep -q 'astrbot-core-v1.6.0-dev6.zip' "$ENGINE_REPO"; then echo "stale core cache filename remains" >&2; exit 86; fi
grep -q 'MAX_OUTPUT_CHARS' "$ROOT_SHELL" || { echo "RootShell output is still unbounded" >&2; exit 87; }
grep -q 'terminateProcessTree' "$ROOT_SHELL" || { echo "RootShell timeout does not clean process tree" >&2; exit 88; }
grep -q 'settings\.\$\$\.new' "$TMP/engine/lib/common.sh" || { echo "settings writes do not use per-process temp files" >&2; exit 89; }
grep -q 'settings.lock' "$TMP/engine/lib/common.sh" || { echo "settings writes are not serialized" >&2; exit 90; }
if grep -R -q 'config_get stack_autostart 0' "$TMP/engine/watchdog.sh" "$TMP/engine/astrctl"; then echo "stack_autostart default mismatch remains" >&2; exit 91; fi
if grep -q 'repeat(360)' "$VM"; then echo "native QR polling still has a fixed five-minute lifetime" >&2; exit 92; fi
grep -q 'resumeQqLoginPollingIfNeeded' "$VM" || { echo "native QR polling does not resume after foreground return" >&2; exit 93; }
grep -q 'snapshot.console.qrRefreshBusy' "$VM" || { echo "native QR polling can race manual QR refresh" >&2; exit 94; }
grep -q '_ui.value.operationsSection != OperationsSection.LOGS' "$VM" || { echo "log polling is not scoped to the visible Logs section" >&2; exit 95; }
if grep -q 'STANDARD_MOUNT_PROBE_JS\|4500L' "$WEBVIEW"; then echo "false-positive SPA mount timeout remains" >&2; exit 96; fi
grep -q 'Build dev12 bugfix1 APK' "$WORKFLOW" || { echo "workflow release name is stale" >&2; exit 97; }
grep -q 'AstrBot-Control-Center-v1.6.0-dev12-bugfix1-debug' "$WORKFLOW" || { echo "workflow artifact name is stale" >&2; exit 98; }

sh "$TMP/engine/tests/test-control-center-v1604-qr-rendering.sh" "$TMP/engine" >/dev/null

echo "SOURCE_GATE_OK engine_sha=$actual shell_files=$count native_qr=1 manual_qr_refresh=1 astrbot_probe=1 bugfix1=1"
