# Build status — dev23

- Android App: `1.6.0-dev23` / `162300`
- Embedded core: `1.6.0-dev14` / `16014`
- Workspace change: focused workspaces hide global navigation and share fullscreen/top-bar behavior.
- Engine change: planned SnowLuma stop avoids self-restart delay; successful engine switch explicitly returns success.
- UI change: broader rounded/soft geometry pass across Control Center and installer.
- Stable dev signing: unchanged from dev17+
- Full Android Gradle build: requires GitHub Actions / Android SDK environment.
