# dev23

- Focused workspace mode now hides the global rail/bottom navigation after entering SnowLuma, NapCat or QQ Login, matching AstrBot's focused shell.
- Compose workspaces gain reversible fullscreen and a compact overflow-menu toolbar.
- SnowLuma intentional shutdown is marked as planned so its internal supervisor does not restart it during a QQ-engine switch.
- Successful NapCat/SnowLuma switches explicitly return success instead of leaking a trailing shell-condition `rc=1`.
- Broad soft-geometry pass across Control Center, workbench, installer and settings save bar.
- AstrBot keeps the proven classic WebView path while receiving a rounded container and matching workbench chrome.

# dev22

- Compact tablet workbench with runtime strip, launchers, service chain and next action.
- Same-frame SnowLuma QQ login touch mapping.
- Embedded core v1.6.0-dev13 atomic mkdir settings lock for NapCat/SnowLuma switching.
- AstrBot classic WebView gets unified workbench chrome and fullscreen mode.
- Launcher artwork replaced with the new user-provided icon, preserving `AstrBot CC` label and stable signing.

# dev21 真机交互修复

针对 dev20 真机反馈：

- 环境设置的“保存更改 / 取消”固定在屏幕底部，未保存时始终可见。
- 工作台不再同时展示三套不同操作模型；先从统一入口卡片进入，再显示单一工作区。
- QQ 登录实时画面的点击坐标改为根坐标映射，修复“看到的位置”和“实际点击的位置”不一致。
- NapCat / SnowLuma 切换修复 BusyBox `flock -w` 不兼容导致的 `rc=87`。
- 如果 QQ 引擎设置提交失败，会尝试恢复切换前正在运行的引擎。
- AstrBot 已验证可用的经典 WebView 路径、固定签名、`AstrBot CC` 桌面名和安全区图标保持不变。
