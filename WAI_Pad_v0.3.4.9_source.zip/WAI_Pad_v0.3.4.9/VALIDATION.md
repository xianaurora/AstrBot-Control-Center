# WAI Pad v0.3.4.9 Validation

Current release validation is documented in `VALIDATION_v0349.md`.

Important: hand-written Kotlin stubs are only supplemental language checks. The authoritative Android SDK/API check is the GitHub Actions Gradle build (`gradle :app:assembleDebug`). v0.3.4.9 specifically fixes the real SDK compile failure reported for v0.3.4.8.
