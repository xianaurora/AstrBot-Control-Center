#!/usr/bin/env bash
set -Eeuo pipefail
BASE=/root/WAI_Pad
RUNTIME="$BASE/runtime"
mkdir -p "$RUNTIME"
log(){ echo "[$(date '+%F %T')] $*"; }
health(){ curl -fsS --max-time 4 "$1" >/dev/null 2>&1; }
active_job(){
  if curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health 2>/dev/null | grep -Eq '"current"[[:space:]]*:[[:space:]]*"[^" ]+'; then return 0; fi
  # If companion itself crashed, its durable state still owns the Comfy prompt. Protect core
  # restart until the restarted companion gets a chance to reattach/resolve that prompt.
  [ -f "$RUNTIME/jobs_state.json" ] && grep -Eq '"status"[[:space:]]*:[[:space:]]*"(claimed|submitting|running|repairing)"' "$RUNTIME/jobs_state.json" 2>/dev/null
}
PY="/root/venv/bin/python"; [ -x "$PY" ] || PY="$(command -v python3 || command -v python)"

# All service mutations share one process-wide lock with guard/maintenance/Android updater.
if [ "${WAI_PAD_LOCK_HELD:-0}" != "1" ]; then
  exec 9>"$RUNTIME/service.lock"
  flock -w 35 9 || { log '[WARN] 服务器维护锁繁忙，本次初始化延后'; exit 75; }
fi

log '=== WAI Pad v0.3.4.9 自动初始化 ==='
if ! command -v wai >/dev/null 2>&1; then
  log '[ERROR] 找不到 wai 命令；不会改动你的现有环境。'; exit 2
fi

panel_ok=0; comfy_ok=0
health http://127.0.0.1:6017/api/health && panel_ok=1
health http://127.0.0.1:6006/system_stats && comfy_ok=1
if [ "$panel_ok" -eq 0 ] || [ "$comfy_ok" -eq 0 ]; then
  if active_job; then
    # A tablet reconnect / panel outage must never interrupt an in-flight prompt.
    log "[启动] 检测到活动任务；当前 panel=$panel_ok comfy=$comfy_ok，延后任何可能重启 ComfyUI 的 wai start/restart。"
  else
    log '[启动] 核心服务未完全就绪，执行非破坏性 wai start'
    wai start >/dev/null 2>&1 || true
    sleep 7
    panel_ok=0; comfy_ok=0
    health http://127.0.0.1:6017/api/health && panel_ok=1
    health http://127.0.0.1:6006/system_stats && comfy_ok=1
    if [ "$panel_ok" -eq 0 ] || [ "$comfy_ok" -eq 0 ]; then
      log '[启动] wai start 未完全恢复且当前无活动任务，执行一次 wai restart'
      wai restart >/dev/null 2>&1 || true
      sleep 8
    fi
  fi
fi

"$PY" -m py_compile "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py"
bash -n "$BASE/bootstrap.sh" "$BASE/guard.sh"
CODE_HASH="$(cat "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py" "$BASE/guard.sh" "$BASE/bootstrap.sh" | sha256sum | awk '{print $1}')"
OLD_HASH="$(cat "$RUNTIME/code.sha256" 2>/dev/null || true)"
API_UP=0; health http://127.0.0.1:6027/v1/health && API_UP=1

if [ "$API_UP" -eq 1 ] && [ "$CODE_HASH" = "$OLD_HASH" ]; then
  log '[任务服务] 已运行且代码未变化，保留当前任务/队列。'
elif [ "$API_UP" -eq 1 ] && active_job; then
  log '[任务服务] 仍有活动任务；即使磁盘代码变化也延后 companion 重启。'
else
  if pgrep -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1; then
    log '[任务服务] 安全重启 companion（不会重启 ComfyUI）'
    pkill -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' || true
    sleep 1
  fi
  nohup "$PY" "$BASE/job_api.py" >>"$RUNTIME/job_api.nohup.log" 2>&1 </dev/null &
  for _ in $(seq 1 16); do health http://127.0.0.1:6027/v1/health && break; sleep 1; done
  if ! health http://127.0.0.1:6027/v1/health; then
    log '[ERROR] WAI Pad 异步任务服务未启动，旧 WAI 仍保持原样。'
    tail -50 "$RUNTIME/job_api.nohup.log" 2>/dev/null || true; exit 3
  fi
  printf '%s' "$CODE_HASH" > "$RUNTIME/code.sha256"
fi

# A running shell never reloads a replaced guard.sh. Restart only the guard process when
# its script hash changed; this is harmless to ComfyUI and makes updates actually take effect.
GUARD_HASH="$(sha256sum "$BASE/guard.sh" | awk '{print $1}')"
OLD_GUARD_HASH="$(cat "$RUNTIME/guard.sha256" 2>/dev/null || true)"
if pgrep -f '^bash /root/WAI_Pad/guard.sh daemon$' >/dev/null 2>&1 && [ "$GUARD_HASH" != "$OLD_GUARD_HASH" ]; then
  log '[守护] guard 脚本已更新，仅重启 guard 进程'
  pkill -f '^bash /root/WAI_Pad/guard.sh daemon$' || true
  sleep 1
fi
if ! pgrep -f '^bash /root/WAI_Pad/guard.sh daemon$' >/dev/null 2>&1; then
  log '[守护] 启动自动检测与修复'
  nohup bash "$BASE/guard.sh" daemon >>"$BASE/guard.nohup.log" 2>&1 </dev/null &
fi
printf '%s' "$GUARD_HASH" > "$RUNTIME/guard.sha256"

printf '[状态] Panel: '; health http://127.0.0.1:6017/api/health && echo OK || echo DEGRADED
printf '[状态] ComfyUI: '; health http://127.0.0.1:6006/system_stats && echo OK || echo DEGRADED
printf '[状态] Qwen: '; health http://127.0.0.1:8011/v1/models && echo OK || echo '休眠/离线（生成时可回退轻量模式）'
printf '[状态] WAI Pad API: '; curl -fsS --max-time 4 http://127.0.0.1:6027/v1/health || true; echo
log '[隐私] 参考图由任务所有权管理；成图仅在本机确认后清理远端，清理失败会持续重试。'
log '[完成] companion 通道已可用；核心服务若显示 DEGRADED，将由 guard 在安全条件下恢复。'
