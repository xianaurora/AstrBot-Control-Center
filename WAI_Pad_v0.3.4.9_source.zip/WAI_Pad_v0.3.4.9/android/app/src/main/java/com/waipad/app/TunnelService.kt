package com.waipad.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.jcraft.jsch.Session
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

class TunnelService : Service() {
    companion object {
        const val CHANNEL_ID = "wai_pad_tunnel"
        @Volatile var connected = false
        @Volatile var bridgeReady = false
        @Volatile var stackReady = false
        @Volatile var phase = "idle"
        @Volatile var message = "未连接"
        @Volatile var lastBootstrapOutput = ""
        @Volatile var lastConnectedAt = 0L
        @Volatile var jupyterForwarded = false
        @Volatile var jupyterRemotePort = 0
        @Volatile private var activeSession: Session? = null
        private val sessionGuard = Any()

        fun forceReconnect(reason: String = "请求重建连接") {
            bridgeReady = false; stackReady = false
            phase = "reconnecting"; message = reason
            val s = synchronized(sessionGuard) { activeSession }
            try { s?.disconnect() } catch (_: Exception) {}
        }

        fun start(context: Context) {
            val i = Intent(context, TunnelService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
        fun stop(context: Context) = context.stopService(Intent(context, TunnelService::class.java))
    }

    private val running = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var ownedSession: Session? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "WAI Pad 服务器连接", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        startForeground(17, notification("准备连接 AutoDL…"))
    }

    private fun notification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("WAI Pad").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).build()
    }

    private fun notifyStatus(text: String) {
        try { getSystemService(NotificationManager::class.java).notify(17, notification(text)) } catch (_: Exception) {}
    }

    private data class Health(val api: Boolean, val stack: Boolean, val detail: String = "")

    private fun localHealth(): Health {
        return try {
            val c = URL("http://127.0.0.1:16027/v1/health").openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 2200; c.readTimeout = 2200; c.setRequestProperty("Connection", "close")
                val code = c.responseCode
                if (code !in 200..299) {
                    Health(false, false, "HTTP $code")
                } else {
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    val o = JSONObject(text)
                    Health(true, o.optBoolean("ready", false), o.optString("detail", ""))
                }
            } finally { c.disconnect() }
        } catch (e: Exception) { Health(false, false, e.message ?: "") }
    }

    private fun remoteApiReady(session: Session): Boolean = try {
        val r = SshClient.exec(session, "curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health >/dev/null 2>&1", 8_000)
        r.first == 0
    } catch (_: Exception) { false }

    private fun waitLocalApi(ms: Long = 15_000): Health {
        val until = System.currentTimeMillis() + ms
        var last = Health(false, false)
        while (running.get() && System.currentTimeMillis() < until) {
            last = localHealth()
            if (last.api) return last
            Thread.sleep(700)
        }
        return last
    }

    private fun detectJupyter(session: Session): Int {
        val cmd = "for p in 8888 8889 8890 8891 8080; do if curl -fsS --max-time 1 http://127.0.0.1:\$p/ >/dev/null 2>&1 || curl -fsS --max-time 1 http://127.0.0.1:\$p/lab >/dev/null 2>&1; then echo \$p; exit 0; fi; done; exit 1"
        val r = SshClient.exec(session, cmd, 12_000)
        return r.second.trim().lineSequence().firstOrNull()?.toIntOrNull() ?: 0
    }

    private fun publishSession(s: Session) {
        ownedSession = s
        synchronized(sessionGuard) { activeSession = s }
    }

    private fun disconnectOwned() {
        val s = ownedSession
        ownedSession = null
        synchronized(sessionGuard) { if (activeSession === s) activeSession = null }
        try { s?.disconnect() } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running.compareAndSet(false, true)) exec.submit { loop() }
        return START_STICKY
    }

    private fun loop() {
        var reconnectFailures = 0
        while (running.get()) {
            val p = SecurePrefs(this)
            if (!p.hasServer()) {
                connected = false; bridgeReady = false; stackReady = false; phase = "setup"
                message = "首次使用：请在设置里填写一次 SSH 密码"
                notifyStatus("等待首次连接设置")
                Thread.sleep(3000); continue
            }
            try {
                phase = "connecting"; message = "正在连接 AutoDL…"; connected = false; bridgeReady = false; stackReady = false
                notifyStatus(message)
                disconnectOwned()
                val s = SshClient.connect(p)
                publishSession(s)
                // Only publish a connection after all required local forwards succeeded.
                s.setPortForwardingL(16017, "127.0.0.1", 6017)
                s.setPortForwardingL(16006, "127.0.0.1", 6006)
                s.setPortForwardingL(16027, "127.0.0.1", 6027)
                connected = true; lastConnectedAt = System.currentTimeMillis(); reconnectFailures = 0
                phase = "bootstrap"; message = "隧道已连接，正在检查服务…"; notifyStatus(message)

                lastBootstrapOutput = RemoteBootstrap.installAndStart(this, s).takeLast(16_000)
                var updateDeferred = lastBootstrapOutput.contains("WAI_PAD_UPDATE_DEFERRED_ACTIVE_JOB=1")
                var lastDeferredRetry = System.currentTimeMillis()
                val initial = waitLocalApi(18_000)
                if (!initial.api) {
                    if (remoteApiReady(s)) throw IOException("SSH 本地 16027 转发已失效，正在重建隧道")
                    throw IllegalStateException("WAI Pad API 尚未就绪")
                }
                bridgeReady = true; stackReady = initial.stack

                // Jupyter is optional and probed only after the core companion is usable, so it
                // cannot delay normal startup.
                val jp = try { detectJupyter(s) } catch (_: Exception) { 0 }
                jupyterRemotePort = jp; jupyterForwarded = false
                if (jp > 0) {
                    try { s.setPortForwardingL(18888, "127.0.0.1", jp); jupyterForwarded = true } catch (_: Exception) {}
                }

                if (stackReady) {
                    phase = "ready"
                    message = if (jupyterForwarded) "已连接 · WAI/Comfy/Jupyter 正常" else "已连接 · WAI/Comfy 正常"
                    notifyStatus(message)
                } else {
                    phase = "degraded"; message = "已连接 · companion 正常，核心服务恢复中"
                    notifyStatus(message)
                }

                var localFailures = 0
                while (running.get() && s.isConnected) {
                    val h = localHealth()
                    if (!h.api) {
                        localFailures++; bridgeReady = false; stackReady = false
                        if (remoteApiReady(s)) throw IOException("16027 本地转发失效，自动重建 SSH 隧道")
                        phase = "repairing"; message = "远端任务服务异常，正在安全恢复…"; notifyStatus(message)
                        try {
                            lastBootstrapOutput = RemoteBootstrap.installAndStart(this, s).takeLast(16_000)
                            val repaired = waitLocalApi(15_000)
                            bridgeReady = repaired.api; stackReady = repaired.stack
                            if (!repaired.api && localFailures >= 2) throw IOException("服务恢复后仍不可用，重建连接")
                        } catch (e: Exception) {
                            lastBootstrapOutput = (lastBootstrapOutput + "\n" + (e.message ?: "恢复失败")).takeLast(16_000)
                            if (!s.isConnected || e is IOException || localFailures >= 2) throw e
                        }
                    } else {
                        localFailures = 0; bridgeReady = true; stackReady = h.stack
                        if (h.stack) { phase = "ready"; message = "已连接" }
                        else { phase = "degraded"; message = "已连接 · 核心服务恢复中" }
                        // An APK upgrade may arrive while an old companion owns an active prompt.
                        // Defer hot replacement, then retry automatically once that prompt finishes.
                        if (updateDeferred && System.currentTimeMillis() - lastDeferredRetry >= 30_000L) {
                            lastDeferredRetry = System.currentTimeMillis()
                            try {
                                val out = RemoteBootstrap.installAndStart(this, s)
                                lastBootstrapOutput = out.takeLast(16_000)
                                updateDeferred = out.contains("WAI_PAD_UPDATE_DEFERRED_ACTIVE_JOB=1")
                            } catch (e: Exception) {
                                lastBootstrapOutput = (lastBootstrapOutput + "\n延期更新重试：" + (e.message ?: "失败")).takeLast(16_000)
                            }
                        }
                    }
                    Thread.sleep(5000)
                }
            } catch (e: Exception) {
                disconnectOwned()
                connected = false; bridgeReady = false; stackReady = false; jupyterForwarded = false; phase = "reconnecting"
                message = "连接中断，正在自动重连：${e.message ?: "未知错误"}"
                notifyStatus("连接中断 · 自动重连中")
                reconnectFailures++
                val delay = min(30_000L, 2_500L * (1L shl min(3, reconnectFailures - 1)))
                Thread.sleep(delay)
            }
        }
    }

    override fun onDestroy() {
        running.set(false)
        disconnectOwned()
        connected = false; bridgeReady = false; stackReady = false; jupyterForwarded = false; phase = "stopped"; message = "已停止"
        exec.shutdownNow(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
