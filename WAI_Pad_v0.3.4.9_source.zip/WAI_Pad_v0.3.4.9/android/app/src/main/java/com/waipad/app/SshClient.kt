package com.waipad.app

import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.HostKey
import com.jcraft.jsch.HostKeyRepository
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.UserInfo
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.Base64
import java.util.Properties

object SshClient {
    private fun fingerprint(rawKey: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(rawKey)
        return "SHA256:" + Base64.getEncoder().withoutPadding().encodeToString(digest)
    }

    private class PinnedHostKeyRepository(private val expected: String) : HostKeyRepository {
        override fun check(host: String?, key: ByteArray?): Int {
            if (key == null) return HostKeyRepository.CHANGED
            return if (fingerprint(key) == expected) HostKeyRepository.OK else HostKeyRepository.CHANGED
        }
        override fun add(hostkey: HostKey?, ui: UserInfo?) = Unit
        override fun remove(host: String?, type: String?) = Unit
        override fun remove(host: String?, type: String?, key: ByteArray?) = Unit
        override fun getKnownHostsRepositoryID(): String = "WAI Pad pinned fingerprint"
        override fun getHostKey(): Array<HostKey> = emptyArray()
        override fun getHostKey(host: String?, type: String?): Array<HostKey> = emptyArray()
    }

    fun connect(host: String, port: Int, user: String, password: String, pinnedFingerprint: String = ""): Session {
        require(host.isNotBlank()) { "SSH 主机为空" }
        require(port in 1..65535) { "SSH 端口无效" }
        require(user.isNotBlank()) { "SSH 用户为空" }
        require(password.isNotEmpty()) { "SSH 密码为空" }

        val jsch = JSch()
        if (pinnedFingerprint.isNotBlank()) {
            // IMPORTANT: enforce the saved host key during key exchange, before password auth.
            jsch.setHostKeyRepository(PinnedHostKeyRepository(pinnedFingerprint))
        }
        val s = jsch.getSession(user, host, port)
        s.setPassword(password)
        val cfg = Properties()
        cfg["StrictHostKeyChecking"] = if (pinnedFingerprint.isBlank()) "no" else "yes"
        cfg["PreferredAuthentications"] = "password,keyboard-interactive,publickey"
        s.setConfig(cfg)
        s.serverAliveInterval = 20_000
        s.serverAliveCountMax = 3
        s.connect(18_000)
        return s
    }

    fun connect(prefs: SecurePrefs): Session {
        val host = prefs.get("host", "connect.nmb2.seetacloud.com")
        val portText = prefs.get("port", "28823")
        val port = portText.toIntOrNull() ?: throw IllegalArgumentException("SSH 端口不是有效数字: $portText")
        val user = prefs.get("user", "root")
        val password = prefs.get("password")
        val saved = prefs.get("sshFingerprint")
        val s = connect(host, port, user, password, saved)
        if (saved.isBlank()) {
            // TOFU only on the very first successful connection. Later connections are pinned
            // before authentication by PinnedHostKeyRepository above.
            prefs.put("sshFingerprint", fingerprint(s))
        }
        return s
    }

    fun fingerprint(session: Session): String {
        val raw = try { Base64.getDecoder().decode(session.hostKey.key) } catch (_: Exception) { session.hostKey.key.toByteArray() }
        return fingerprint(raw)
    }

    fun exec(session: Session, command: String, timeoutMs: Long = 90_000): Pair<Int, String> {
        val ch = session.openChannel("exec") as ChannelExec
        val out = ByteArrayOutputStream(); val err = ByteArrayOutputStream()
        try {
            ch.setCommand(command); ch.setInputStream(null)
            ch.setOutputStream(out); ch.setErrStream(err); ch.connect(10_000)
            val start = System.currentTimeMillis()
            while (!ch.isClosed && System.currentTimeMillis() - start < timeoutMs) {
                if (Thread.currentThread().isInterrupted) throw InterruptedException("SSH 操作已取消")
                Thread.sleep(80)
            }
            val timedOut = !ch.isClosed
            val code = if (timedOut) 124 else ch.exitStatus
            val text = out.toString(Charsets.UTF_8.name()) + err.toString(Charsets.UTF_8.name())
            return code to text
        } finally {
            try { if (ch.isConnected) ch.disconnect() } catch (_: Exception) {}
        }
    }

    fun putBytes(session: Session, remotePath: String, data: ByteArray) {
        val ch = session.openChannel("sftp") as ChannelSftp
        ch.connect(10_000)
        try {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("SFTP 操作已取消")
            ch.put(ByteArrayInputStream(data), remotePath)
        } finally { ch.disconnect() }
    }

    fun putBytesAtomic(session: Session, remotePath: String, data: ByteArray) {
        val ch = session.openChannel("sftp") as ChannelSftp
        ch.connect(10_000)
        val tmp = "$remotePath.wai-upload-${System.nanoTime()}"
        try {
            if (Thread.currentThread().isInterrupted) throw InterruptedException("SFTP 操作已取消")
            ch.put(ByteArrayInputStream(data), tmp)
            try { ch.rm(remotePath) } catch (_: Exception) {}
            ch.rename(tmp, remotePath)
        } catch (e: Exception) {
            try { ch.rm(tmp) } catch (_: Exception) {}
            throw e
        } finally {
            ch.disconnect()
        }
    }
}
