# WAI Pad v0.3.4.19 Validation

- Android metadata: versionName 0.3.4.19, versionCode 25.
- Main and embedded engine_v34.py/job_api.py must be byte-identical.
- Python compile check required for both server copies.
- Explicit nude/body-exposure prompt must activate body stabilizer; clothed prompt must not.
- Body stabilizer must not add clothing, age-coded terms, chibi/short-leg positive terms, or overwrite the user's original prompt.
- Ordinary txt workflow keeps Style LoRA at 0.90 model / 0.90 CLIP.
- Explicit body-exposure txt workflow uses the split strength pair derived from 0.90: model 0.954, CLIP 0.828.
