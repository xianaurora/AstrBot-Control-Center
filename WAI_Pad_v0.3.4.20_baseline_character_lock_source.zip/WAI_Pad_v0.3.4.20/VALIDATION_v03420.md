# v0.3.4.20 Validation

- Python server files compile successfully.
- Server and Android embedded copies are byte-identical for engine/job_api after synchronization.
- Android versionCode/versionName bumped to 26 / 0.3.4.20.
- baseline_lock defaults to true for legacy and Android clients.
- Outfit override uses lower whole-image A conditioning than same-outfit generation.
- Person+pose baseline mode keeps OpenPose strong and reduces Depth to a light perspective hint.
