# WAI Pad v0.3.4.18

版本：0.3.4.18 / versionCode 24

- 从原始 v0.3.4.15 干净源码重新修复，不继承 0.3.4.16/17 的人工 Q 版风格锚点。
- txt/img/ref/person+pose 的固定画风 LoRA 强度统一到原 txt2img 基准。
- ref/person+pose 默认采样回到原 txt2img 的 28 steps / CFG 4.8；动作严格开关只改变姿势约束，不再改变采样风格。
- 删除 person+pose 自动追加的 natural anatomy。
- 换装/新增配件/露肤要求出现时，不再追加 preserve key outfit details，并降低人物参考图的整体服装条件。
- white thighhighs / white pantyhose / cat paw gloves 仅在用户明确请求时增加文本权重；删除/不要指令不会反向触发。
- 人物+动作优先采用 UI 选择的输出尺寸；修复极端长图 fallback 被强制拉宽的问题。
- 修复 split prompt 字段为空时回退旧 merged prompt 的兼容逻辑；编辑输入后旧的最终提示词预览立即失效。
- 修复 Android WebP 上传仍使用 .png 文件名的问题。
- 未添加任何年龄描述，也未重新定义用户 LoRA 的画风。
