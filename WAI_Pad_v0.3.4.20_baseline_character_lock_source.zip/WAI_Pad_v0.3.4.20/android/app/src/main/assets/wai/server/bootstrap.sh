#!/usr/bin/env bash
set -Eeuo pipefail
BASE=/root/WAI_Pad
RUNTIME="$BASE/runtime"
COMPANION_LOCK="$RUNTIME/companion.lock"
LEGACY_LOCK="$RUNTIME/service.lock"
mkdir -p "$RUNTIME"
log(){ echo "[$(date '+%F %T')] $*"; }
health(){ curl -fsS --max-time 3 "$1" >/dev/null 2>&1; }
PY="/root/venv/bin/python"; [ -x "$PY" ] || PY="$(command -v python3 || command -v python)"

log '=== WAI Pad v0.3.4.20 快速初始化（分层锁） ==='
if ! command -v wai >/dev/null 2>&1; then
  log '[WARN] 找不到 wai 命令；companion 仍会尝试启动，核心恢复交给用户环境。'
fi

"$PY" -m py_compile "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py"
bash -n "$BASE/bootstrap.sh" "$BASE/guard.sh"
CODE_HASH="$(cat "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py" "$BASE/guard.sh" "$BASE/bootstrap.sh" | sha256sum | awk '{print $1}')"
OLD_HASH="$(cat "$RUNTIME/code.sha256" 2>/dev/null || true)"

# Companion start/restart has its own tiny lock. It NEVER waits for legacy service.lock or core.lock.
exec 8>"$COMPANION_LOCK"
if flock -w 8 8; then
  API_UP=0; health http://127.0.0.1:6027/v1/health && API_UP=1
  live_current=0
  if [ "$API_UP" -eq 1 ] && curl -fsS --max-time 2 http://127.0.0.1:6027/v1/health 2>/dev/null | grep -Eq '"current"[[:space:]]*:[[:space:]]*"[^" ]+'; then live_current=1; fi

  if [ "$API_UP" -eq 1 ] && [ "$CODE_HASH" = "$OLD_HASH" ]; then
    log '[任务服务] 已运行且代码未变化，保留当前任务/队列。'
  elif [ "$API_UP" -eq 1 ] && [ "$live_current" -eq 1 ]; then
    log '[任务服务] 当前正在生成；新代码已落盘，但延后 companion 进程重启。'
  else
    if pgrep -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1; then
      log '[任务服务] 安全重启 companion（只重启控制面，不触碰 ComfyUI）'
      pkill -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' || true
      sleep 1
    fi
    nohup "$PY" "$BASE/job_api.py" 8>&- 9>&- >>"$RUNTIME/job_api.nohup.log" 2>&1 </dev/null &
    for _ in $(seq 1 14); do health http://127.0.0.1:6027/v1/health && break; sleep 1; done
    if ! health http://127.0.0.1:6027/v1/health; then
      log '[ERROR] WAI Pad companion 未启动；不会重启 ComfyUI。'
      tail -60 "$RUNTIME/job_api.nohup.log" 2>/dev/null || true
      flock -u 8 2>/dev/null || true; exec 8>&-
      exit 3
    fi
  fi
  printf '%s' "$CODE_HASH" > "$RUNTIME/code.sha256"
  flock -u 8 2>/dev/null || true
else
  log '[WARN] companion 启动锁繁忙；已有另一条控制面恢复正在执行。'
fi
exec 8>&-

GUARD_HASH="$(sha256sum "$BASE/guard.sh" | awk '{print $1}')"
OLD_GUARD_HASH="$(cat "$RUNTIME/guard.sha256" 2>/dev/null || true)"
GUARD_RUNNING=0; pgrep -f '^bash /root/WAI_Pad/guard.sh daemon$' >/dev/null 2>&1 && GUARD_RUNNING=1

start_new_guard(){
  if ! pgrep -f '^bash /root/WAI_Pad/guard.sh daemon$' >/dev/null 2>&1; then
    log '[守护] 启动自动检测与修复'
    nohup bash "$BASE/guard.sh" daemon 8>&- 9>&- >>"$BASE/guard.nohup.log" 2>&1 </dev/null &
  fi
  printf '%s' "$GUARD_HASH" > "$RUNTIME/guard.sha256"
}

if [ "$GUARD_RUNNING" -eq 1 ] && [ "$GUARD_HASH" != "$OLD_GUARD_HASH" ]; then
  # v0.3.4.14 and older guards may be inside wai repair while holding legacy service.lock. Killing
  # only the parent guard can orphan that repair. Let it finish, while companion is already usable,
  # then replace the daemon. The legacy lock no longer blocks any v0.3.4.20 control-plane action.
  if flock -n "$LEGACY_LOCK" -c true 2>/dev/null; then
    log '[守护] 旧 guard 当前空闲；立即切换到新版 guard'
    pkill -f '^bash /root/WAI_Pad/guard.sh daemon$' || true
    sleep 1
    start_new_guard
  else
    log '[守护] 旧 guard 仍在核心修复；companion 已独立恢复，guard 将在旧 repair 释放锁后热迁移。'
    WATCHER="$RUNTIME/guard_migrate.sh"
    cat > "$WATCHER" <<'EOS'
#!/usr/bin/env bash
BASE=/root/WAI_Pad
RUNTIME="$BASE/runtime"
LEGACY="$RUNTIME/service.lock"
for _ in $(seq 1 240); do
  if flock -n "$LEGACY" -c true 2>/dev/null; then
    pkill -f '^bash /root/WAI_Pad/guard.sh daemon$' 2>/dev/null || true
    sleep 1
    if ! pgrep -f '^bash /root/WAI_Pad/guard.sh daemon$' >/dev/null 2>&1; then
      nohup bash "$BASE/guard.sh" daemon >>"$BASE/guard.nohup.log" 2>&1 </dev/null &
    fi
    sha256sum "$BASE/guard.sh" | awk '{print $1}' > "$RUNTIME/guard.sha256"
    exit 0
  fi
  sleep 2
done
exit 0
EOS
    chmod 700 "$WATCHER"
    if ! pgrep -f '^bash /root/WAI_Pad/runtime/guard_migrate.sh$' >/dev/null 2>&1; then
      nohup bash "$WATCHER" >>"$RUNTIME/guard_migrate.log" 2>&1 </dev/null &
    fi
  fi
elif [ "$GUARD_RUNNING" -eq 0 ]; then
  start_new_guard
else
  printf '%s' "$GUARD_HASH" > "$RUNTIME/guard.sha256"
fi

panel_ok=0; comfy_ok=0
health http://127.0.0.1:6017/api/health && panel_ok=1
health http://127.0.0.1:6006/system_stats && comfy_ok=1
if [ "$panel_ok" -eq 0 ] || [ "$comfy_ok" -eq 0 ]; then
  log "[核心] Panel=$panel_ok Comfy=$comfy_ok；guard 使用独立 core.lock 后台恢复，不阻塞 companion。"
fi

printf '[状态] Panel: '; [ "$panel_ok" -eq 1 ] && echo OK || echo DEGRADED
printf '[状态] ComfyUI: '; [ "$comfy_ok" -eq 1 ] && echo OK || echo DEGRADED
printf '[状态] Qwen: '; health http://127.0.0.1:8011/v1/models && echo OK || echo '休眠/离线（生成时可回退轻量模式）'
printf '[状态] WAI Pad API: '; curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health || true; echo
log '[完成] companion 与核心修复已彻底解耦；旧 service.lock 不再能卡住 6027。'
