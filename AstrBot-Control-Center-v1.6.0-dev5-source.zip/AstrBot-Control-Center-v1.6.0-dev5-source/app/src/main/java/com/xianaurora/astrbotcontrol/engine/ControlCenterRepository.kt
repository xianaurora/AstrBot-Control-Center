package com.xianaurora.astrbotcontrol.engine

import com.xianaurora.astrbotcontrol.model.DiagnosticExportState
import com.xianaurora.astrbotcontrol.model.LogSource
import com.xianaurora.astrbotcontrol.model.QqLoginSession
import com.xianaurora.astrbotcontrol.model.RuntimeStatus

class ControlCenterRepository(
    private val shell: RootShell = RootShell()
) {
    companion object {
        private const val ASTRCTL = EngineRepository.ASTRCTL
    }

    suspend fun available(): Boolean = shell.root("test -x ${RootShell.q(ASTRCTL)}", 8).ok

    suspend fun keepConsoleActive(): ShellResult = shell.root(
        "${RootShell.q(ASTRCTL)} console-ping",
        10
    )

    suspend fun status(forceLive: Boolean = false): Result<RuntimeStatus> {
        val cmd = if (forceLive) "web-status-live" else "web-status"
        val result = shell.root("${RootShell.q(ASTRCTL)} $cmd", if (forceLive) 20 else 12)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "无法读取控制中心状态" } }))
        }
        return Result.success(ControlStatusParser.parse(result.stdout))
    }

    suspend fun queue(action: String): ShellResult {
        val safeAction = when (action) {
            "start", "stop", "restart", "heal", "repair", "plugin-deps", "bridge-repair",
            "engine-snowluma", "engine-napcat", "napcat-reset-login" -> action
            else -> return ShellResult(2, "", "不支持的操作：$action")
        }
        return shell.root("${RootShell.q(ASTRCTL)} queue $safeAction app", 15)
    }

    suspend fun rebootDevice(): ShellResult = shell.root("sync; reboot", 8)

    suspend fun logSources(): Result<List<LogSource>> {
        val result = shell.root("${RootShell.q(ASTRCTL)} logs-list", 15)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "无法读取日志列表" } }))
        }
        val items = result.stdout.lineSequence().mapNotNull { line ->
            if (!line.startsWith("LOG|")) return@mapNotNull null
            val p = line.split('|', limit = 3)
            if (p.size < 3 || p[1].isBlank()) null else LogSource(p[1], p[2].ifBlank { p[1] })
        }.toList()
        return Result.success(items)
    }

    suspend fun log(key: String, lines: Int = 360): Result<String> {
        val safeKey = key.takeIf { it.matches(Regex("[A-Za-z0-9._-]+")) } ?: "health"
        val safeLines = lines.coerceIn(20, 1200)
        val result = shell.root("${RootShell.q(ASTRCTL)} log ${RootShell.q(safeKey)} $safeLines", 18)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "日志读取失败" } }))
        }
        return Result.success(result.stdout)
    }

    suspend fun exportStart(mode: String): Result<DiagnosticExportState> {
        val safeMode = if (mode == "raw") "raw" else "redacted"
        val result = shell.root("${RootShell.q(ASTRCTL)} export-start $safeMode", 15)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "诊断导出没有启动" } }))
        }
        return exportStatus()
    }

    suspend fun exportStatus(): Result<DiagnosticExportState> {
        val result = shell.root("${RootShell.q(ASTRCTL)} export-status", 10)
        if (!result.ok) {
            return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout.ifBlank { "无法读取导出状态" } }))
        }
        val values = linkedMapOf<String, String>()
        result.stdout.lineSequence().forEach { line ->
            if (!line.startsWith("EXPORT|")) return@forEach
            val p = line.split('|', limit = 3)
            if (p.size == 3) values[p[1]] = p[2]
        }
        return Result.success(
            DiagnosticExportState(
                state = values["state"].orEmpty().ifBlank { "idle" },
                phase = values["phase"].orEmpty().ifBlank { "idle" },
                percent = values["percent"]?.toIntOrNull()?.coerceIn(0, 100) ?: 0,
                detail = values["detail"].orEmpty(),
                path = values["path"].orEmpty().ifBlank { values["output"].orEmpty() },
                mode = values["mode"].orEmpty().ifBlank { "redacted" },
                running = values["running"] == "1"
            )
        )
    }

    suspend fun exportCancel(): ShellResult = shell.root("${RootShell.q(ASTRCTL)} export-cancel", 12)

    suspend fun qqLoginSession(engine: String): Result<QqLoginSession> {
        if (engine != "snowluma") {
            return webUrl("napcat", "login").map { url ->
                QqLoginSession(state = "ready", url = url, detail = "NapCat 登录页面已就绪")
            }
        }
        val result = shell.root("${RootShell.q(ASTRCTL)} snowluma-login-request main", 15)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout }))
        val line = result.stdout.lineSequence().firstOrNull { it.startsWith("LOGIN|") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回扫码状态"))
        val parts = line.split('|', limit = 4)
        val state = parts.getOrNull(1).orEmpty().ifBlank { "idle" }
        val url = parts.getOrNull(2).orEmpty()
        val detail = parts.getOrNull(3).orEmpty()
        if (url.isNotBlank() && !isLocalConsoleUrl(url)) {
            return Result.failure(IllegalStateException("扫码桌面返回了非本机地址，已拒绝打开"))
        }
        return Result.success(QqLoginSession(state = state, url = url, detail = detail))
    }

    suspend fun webUrl(kind: String, mode: String = "admin"): Result<String> {
        val safeKind = when (kind) {
            "astrbot", "napcat", "snowluma" -> kind
            else -> return Result.failure(IllegalArgumentException("未知控制台：$kind"))
        }
        val safeMode = when (mode) {
            "admin", "login", "qr" -> mode
            else -> "admin"
        }
        val result = shell.root("${RootShell.q(ASTRCTL)} web-url $safeKind $safeMode", 10)
        if (!result.ok) return Result.failure(IllegalStateException(result.stderr.ifBlank { result.stdout }))
        val url = result.stdout.lineSequence().map { it.trim() }.firstOrNull { it.startsWith("http://") || it.startsWith("https://") }
            ?: return Result.failure(IllegalStateException("核心组件没有返回可打开的地址"))
        if (!isLocalConsoleUrl(url)) return Result.failure(IllegalStateException("控制台返回了非本机地址，已拒绝打开"))
        return Result.success(url)
    }

    private fun isLocalConsoleUrl(url: String): Boolean {
        return runCatching {
            val uri = java.net.URI(url)
            (uri.scheme == "http" || uri.scheme == "https") &&
                (uri.host == "127.0.0.1" || uri.host == "localhost" || uri.host == "::1")
        }.getOrDefault(false)
    }
}
