#!/usr/bin/env bash
set -u
BASE=/root/WAI_Pad
RUNTIME="$BASE/runtime"
COMPANION_LOCK="$RUNTIME/companion.lock"
CORE_LOCK="$RUNTIME/core.lock"
LEGACY_LOCK="$RUNTIME/service.lock"
LOG="$BASE/guard.log"
mkdir -p "$RUNTIME"
PY="/root/venv/bin/python"; [ -x "$PY" ] || PY="$(command -v python3 || command -v python)"

bounded_run(){
  local limit="$1"; shift
  if command -v timeout >/dev/null 2>&1; then
    timeout -k 8s "${limit}s" "$@"
    return $?
  fi
  "$@" & local pid=$!
  ( sleep "$limit"; kill -TERM "$pid" 2>/dev/null || true; sleep 5; kill -KILL "$pid" 2>/dev/null || true ) & local killer=$!
  wait "$pid"; local rc=$?
  kill "$killer" 2>/dev/null || true; wait "$killer" 2>/dev/null || true
  return "$rc"
}
log(){
  [ -f "$LOG" ] && [ "$(stat -c%s "$LOG" 2>/dev/null || echo 0)" -gt 5242880 ] && mv -f "$LOG" "$LOG.1" 2>/dev/null || true
  echo "[$(date '+%F %T')] $*" >> "$LOG"
}
health(){ curl -fsS --max-time 4 "$1" >/dev/null 2>&1; }

# The companion is the control plane.  It gets its own lock and MUST remain restartable even while
# a minutes-long wai start/restart/repair is holding CORE_LOCK.
lock_companion(){
  exec 8>"$COMPANION_LOCK"
  if ! flock -w 2 8; then exec 8>&-; return 1; fi
}
unlock_companion(){ flock -u 8 2>/dev/null || true; exec 8>&-; }
lock_core(){
  exec 9>"$CORE_LOCK"
  if ! flock -w 2 9; then exec 9>&-; return 1; fi
}
unlock_core(){ flock -u 9 2>/dev/null || true; exec 9>&-; }

start_api_locked(){
  health http://127.0.0.1:6027/v1/health && return 0

  if pgrep -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1; then
    # Allow a busy Python process two short grace probes, then recycle ONLY the companion process.
    sleep 2; health http://127.0.0.1:6027/v1/health && return 0
    sleep 2; health http://127.0.0.1:6027/v1/health && return 0
  fi

  # Restarting job_api is safe for an active Comfy prompt: durable job state/client_id are designed
  # to reattach after process death.  Never let stale jobs_state prevent the control plane itself.
  log 'WAI Pad API 持续离线，单独恢复 companion（不触碰 ComfyUI）'
  if ! "$PY" -m py_compile "$BASE/job_api.py" "$BASE/engine_v34.py" "$BASE/maintenance.py" >/dev/null 2>&1; then
    log 'companion 文件语法校验失败；等待 Android 原子更新修复，核心服务不做改动'
    return 1
  fi
  pkill -f '[p]ython.*\/root\/WAI_Pad\/job_api.py' >/dev/null 2>&1 || true
  nohup "$PY" "$BASE/job_api.py" 8>&- 9>&- >>"$RUNTIME/job_api.nohup.log" 2>&1 </dev/null &
  for _ in $(seq 1 10); do health http://127.0.0.1:6027/v1/health && return 0; sleep 1; done
  log 'companion 恢复后仍未通过健康检查'
  return 1
}
start_api(){
  lock_companion || { log 'companion 启动锁繁忙，本轮检查跳过'; return 0; }
  start_api_locked || true
  unlock_companion
}

active_job(){
  # Prefer the live companion. Durable state is only a fallback when the control plane cannot be
  # restored; stale jobs_state must never stop us from restoring the companion itself.
  if health http://127.0.0.1:6027/v1/health; then
    curl -fsS --max-time 3 'http://127.0.0.1:6027/v1/jobs?limit=120' 2>/dev/null |       grep -Eq '"status"[[:space:]]*:[[:space:]]*"(claimed|submitting|running|repairing)"'
    return $?
  fi
  [ -f "$RUNTIME/jobs_state.json" ] && grep -Eq '"status"[[:space:]]*:[[:space:]]*"(claimed|submitting|running|repairing)"' "$RUNTIME/jobs_state.json" 2>/dev/null
}

repair_core(){
  # Control plane first, with a separate lock.  This call never waits on CORE_LOCK.
  start_api
  lock_core || { log '已有核心 wai 修复正在运行，本轮核心修复跳过；companion 不受影响'; return 0; }

  local panel=1 comfy=1
  health http://127.0.0.1:6017/api/health || panel=0
  health http://127.0.0.1:6006/system_stats || comfy=0

  if active_job; then
    if [ "$comfy" -eq 1 ]; then
      log "检测到活动任务且 ComfyUI 正常（panel=$panel）；延后任何全量 wai restart。"
      unlock_core; return 0
    fi
    log '活动任务存在但 ComfyUI 不可达；连续复核，避免瞬时抖动误杀任务。'
    local still_down=1
    for _ in $(seq 1 12); do sleep 5; health http://127.0.0.1:6006/system_stats && still_down=0 && break; done
    if [ "$still_down" -eq 0 ]; then
      log 'ComfyUI 已自行恢复，不执行重启。'; unlock_core; return 0
    fi
    log 'ComfyUI 在活动任务保护窗口内持续约 60 秒不可达；允许受控恢复核心服务。'
  fi

  log "核心服务持续异常 panel=$panel comfy=$comfy，先执行有时限的 wai start"
  bounded_run 60 wai start 8>&- 9>&- >>"$LOG" 2>&1 || true
  sleep 7
  if ! health http://127.0.0.1:6017/api/health || ! health http://127.0.0.1:6006/system_stats; then
    log 'wai start 未完全恢复，执行一次有时限的 wai restart'
    bounded_run 90 wai restart 8>&- 9>&- >>"$LOG" 2>&1 || true
    sleep 8
  fi
  if ! health http://127.0.0.1:6017/api/health || ! health http://127.0.0.1:6006/system_stats; then
    local ctl=''
    for c in /root/WAI_v31/WAI_ctl.sh /root/WAI_v3/WAI_ctl.sh /root/WAI_v34_fullfix/WAI_ctl.sh; do
      [ -x "$c" ] && ctl="$c" && break
    done
    if [ -n "$ctl" ]; then
      log "常规启动/重启未恢复，执行一次有时限的受控 repair: $ctl"
      bounded_run 120 "$ctl" repair 8>&- 9>&- >>"$LOG" 2>&1 || true
      sleep 10
    fi
  fi
  unlock_core

  # Recheck/restart control plane AFTER releasing CORE_LOCK.  Even if a vendor wai command killed
  # unrelated Python processes, companion recovery can now happen immediately and independently.
  start_api
}

case "${1:-daemon}" in
  once)
    start_api
    if ! health http://127.0.0.1:6017/api/health || ! health http://127.0.0.1:6006/system_stats; then repair_core; fi
    ;;
  daemon)
    log 'WAI Pad v0.3.4.16 守护开始（companion/core 分层锁）'
    fail=0
    while true; do
      start_api
      panel=1; comfy=1
      health http://127.0.0.1:6017/api/health || panel=0
      health http://127.0.0.1:6006/system_stats || comfy=0
      if [ "$panel" -eq 1 ] && [ "$comfy" -eq 1 ]; then
        fail=0
      else
        fail=$((fail+1)); log "核心健康检查失败 #$fail panel=$panel comfy=$comfy"
        if [ "$fail" -ge 2 ]; then repair_core; fail=0; fi
      fi
      sleep 20
    done
    ;;
esac
