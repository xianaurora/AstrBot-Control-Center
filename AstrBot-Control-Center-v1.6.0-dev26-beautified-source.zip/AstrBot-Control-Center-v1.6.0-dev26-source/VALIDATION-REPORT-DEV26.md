# Validation report · dev26

- App version: `1.6.0-dev26 / 162600`
- Embedded core: `1.6.0-dev15 / 16015` (unchanged)
- Source gate: PASS
- Pure Kotlin models/parser compile: PASS
- Installer model compile: PASS
- Kotlin/KTS lexical structure scan: PASS
- Background task key/dedup guards: present
- Save + direct engine switch share target dedup key: present
- Busy queue does not auto-create failed duplicate task: present
- Compact 46dp task indicator + 25dp × 2dp progress line: present
- AstrBot native compact task indicator: present
- Product assets: AstrBot / NapCat / SnowLuma / QQ / OneBot present
- Stable signing: retained
- Full Android Compose compile: requires GitHub Actions Android SDK environment
