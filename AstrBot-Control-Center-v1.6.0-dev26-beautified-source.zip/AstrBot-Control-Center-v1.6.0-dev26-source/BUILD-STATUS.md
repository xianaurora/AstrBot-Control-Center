# Build status · v1.6.0-dev26

- App: `1.6.0-dev26` (`162600`)
- Embedded core: `1.6.0-dev15` (`16015`)
- Source gate: PASS
- Pure Kotlin model/parser compile: PASS
- Installer model compile: PASS
- Task dedup / repeated-save guard: PASS (static gate)
- Compact top task indicator: PASS (static gate)
- Product icon resources: PASS
- Stable development signing: retained
- GitHub Actions: full unit tests + Compose APK build + stable certificate verification
- 16 KB APK zip-alignment check: retained
