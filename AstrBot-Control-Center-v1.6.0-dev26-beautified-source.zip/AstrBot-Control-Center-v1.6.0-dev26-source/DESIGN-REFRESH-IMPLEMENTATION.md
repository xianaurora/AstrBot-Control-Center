# AstrBot CC · UI / Motion redesign pass

This source tree contains a visual-system and motion refresh on top of v1.6.0-dev26 while preserving the existing runtime, workbench, staged-settings, task-center and classic AstrBot WebView architecture.

## Visual system

- AstrBot now owns a stable cool-neutral Material 3 palette instead of inheriting Android wallpaper dynamic color.
- Rebuilt typography hierarchy for dashboard readability on phones and tablets.
- Reduced the previous all-large-radius look and introduced a tighter 8/12/18/24/32 dp shape scale.
- Added subtle static brand atmosphere to the app background; expensive continuous background animation is intentionally avoided.
- Redesigned rail and bottom navigation with real vector icons, a proper AstrBot mark, selected-state gradient layers and press feedback.
- Refined overview hero, status cards, activity panel, workbench status strip, workspace cards and floating save/apply surface.
- Updated the installer shell and welcome surface to use the same visual language.

## Motion

- Unified motion timing/easing into one set of quick / standard / page transitions.
- Press feedback uses graphics-layer scaling so it does not require relayout.
- Removed the old per-character Dp-offset animation path. Dynamic text now transitions as one unit, eliminating one layout animation per glyph.
- Kept continuous animation only where it communicates an active process (loading, active task, QR preparation), with restrained amplitudes.

## QQ product identity

- Removed the hand-drawn `ic_qq_penguin.xml` from UI usage.
- Added `drawable-nodpi/product_qq.png`, using the official full-color QQ penguin artwork treatment with a clean app-icon tile.
- All QQ overview/workbench/login product surfaces now use `R.drawable.product_qq`.

## Validation

- `bash scripts/verify-source.sh` passes after updating design-system assertions.
- Kotlin source bracket-balance scan passes for `ControlCenterApp.kt`, `InstallerApp.kt`, and `Theme.kt`.
- This environment does not include Android Gradle / SDK, so a real Compose compile / APK build still needs Android Studio or the repository CI workflow.

## Design references used

- Android Developers: Material 3 / adaptive Compose guidance.
- Android Developers: Compose animation performance guidance.
- Tencent ISUX: QQ brand symbol guidance (penguin is a protected core brand element and should not be redrawn or altered).
- Apple App Store / Tencent QQ listing: current QQ product identity reference.
