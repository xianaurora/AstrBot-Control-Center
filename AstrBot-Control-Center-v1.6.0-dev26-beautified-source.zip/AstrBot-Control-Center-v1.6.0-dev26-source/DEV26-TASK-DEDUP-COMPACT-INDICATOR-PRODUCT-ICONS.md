# dev26 · 紧凑任务指示器 / 重复保存去重 / 产品图标

## 本轮修复

- 顶部任务入口固定为 46dp 圆形图标，不再显示“任务 1 / 失败 2”大胶囊，也不会被进度条撑满标题区域。
- 运行中的任务只在任务图标底部显示 25dp × 2dp 细进度条；多任务才显示小数字角标，历史失败只显示一个小红点。只有点击任务图标后才展开任务详情与步骤。
- AstrBot classic Activity 使用同一任务图标，并在图标底部显示当前任务进度。
- BackgroundTask 使用稳定 `key` 去重；设置页保存和工具页直接切换 QQ 引擎共用 `engine-switch:<target>`，同一个目标不会重复排队。
- 连续点击“保存”时，已提交字段立即从 dirty 状态移到 applying 状态；相同目标正在应用时不会再次产生待保存或再次提交。
- Core 返回 `QUEUED|busy|...` 时不再制造一条假的失败任务；如果是其它后台任务占用，只恢复尚未真正提交的字段，不把“忙”当失败。
- 引擎切换轮询不会因为 worker 启动前的短暂空窗提前判失败；成功确认目标引擎后自动清理 `qq_engine` 的 dirty/applying 状态。
- 总览、工作台、QQ 运行方式、工作区状态等产品身份改为图形资源：AstrBot、NapCat、SnowLuma、QQ 企鹅和 OneBot 链路图标。

## 不变项

- AstrBot 继续使用已经验证不白屏的 classic Activity WebView。
- 内嵌 core 仍为 `1.6.0-dev15 / 16015`。
- 固定开发签名保持不变。
- dev25 的 Compact / Medium / Expanded / Large 自适应与 16KB 检查继续保留。
