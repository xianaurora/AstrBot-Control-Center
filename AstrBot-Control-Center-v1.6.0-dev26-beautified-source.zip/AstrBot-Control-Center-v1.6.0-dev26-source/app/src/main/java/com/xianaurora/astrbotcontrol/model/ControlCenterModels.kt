package com.xianaurora.astrbotcontrol.model

enum class ControlDestination(val title: String, val shortLabel: String) {
    OVERVIEW("总览", "总览"),
    CONSOLE("工作台", "工作台"),
    ENVIRONMENT("环境", "环境"),
    OPERATIONS("工具", "工具")
}

enum class OperationsSection(val label: String) {
    ACTIONS("常用"),
    LOGS("日志"),
    DIAGNOSTICS("诊断")
}

enum class RuntimeHealth {
    HEALTHY,
    WORKING,
    ATTENTION,
    STOPPED,
    UNKNOWN
}

enum class LogCategory(val label: String) {
    OVERVIEW("概览"),
    ASTRBOT("AstrBot"),
    QQ("QQ"),
    SYSTEM("系统")
}

enum class ConsoleTarget(val label: String) {
    ASTRBOT("AstrBot"),
    QQ("QQ"),
    QQ_LOGIN("QQ 登录")
}

data class RuntimeStatus(
    val moduleVersion: String = "",
    val qqEngine: String = "napcat",
    val astrbotUp: Boolean = false,
    val astrbotWebReady: Boolean = false,
    val astrbotPid: String = "",
    val astrbotPort: Int = 0,
    val napcatUp: Boolean = false,
    val napcatWebReady: Boolean = false,
    val napcatPid: String = "",
    val snowlumaUp: Boolean = false,
    val snowlumaWebReady: Boolean = false,
    val snowlumaPid: String = "",
    val snowlumaPort: Int = 0,
    val snowlumaQqExited: Boolean = false,
    val oneBotListen: Boolean = false,
    val oneBotConnected: Int = 0,
    val oneBotAuthFailed: Boolean = false,
    val oneBotReason: String = "",
    val qqOnlineCount: Int = 0,
    val qqLoginRequiredCount: Int = 0,
    val qqStartingCount: Int = 0,
    val qqStalledCount: Int = 0,
    val qqAlertInstance: String = "",
    val qqAlertReason: String = "",
    val mainQqState: String = "unknown",
    val mainQqReason: String = "",
    val rootfsReady: Boolean = false,
    val astrbotReady: Boolean = false,
    val napcatReady: Boolean = false,
    val snowlumaReady: Boolean = false,
    val bridgeReady: Boolean = false,
    val fastBootReady: Boolean = false,
    val installReady: Boolean = false,
    val actionRunning: Boolean = false,
    val stackStarting: Boolean = false,
    val stackAutostart: Boolean = true,
    val watchdogEnabled: Boolean = false,
    val watchdogRunning: Boolean = false,
    val rescueEnabled: Boolean = true,
    val rescueRunning: Boolean = false,
    val messageGuardEnabled: Boolean = false,
    val messageGuardRunning: Boolean = false,
    val downloadSource: String = "auto",
    val downloadSourceEffective: String = "",
    val instanceTotal: Int = 0,
    val instanceEnabled: Int = 0,
    val instanceRunning: Int = 0,
    val lastBootResult: String = "unknown",
    val lastBootSeconds: Int = 0,
    val lastStackResult: String = "unknown",
    val lastStackSeconds: Int = 0,
    val device: String = "",
    val android: String = "",
    val kernel: String = "",
    val apiWarning: Boolean = false,
    val apiWarningReason: String = "",
    val toolWarning: Boolean = false,
    val pluginBlock: Boolean = false,
    val eventLoopWarning: Boolean = false,
    val lastInbound: String = "暂无",
    val lastOutbound: String = "暂无",
    val lastModelOk: String = "暂无",
    val lastEvent: String = "",
    val statusEpoch: Long = 0L
) {
    val qqOnline: Boolean get() = qqOnlineCount > 0 || mainQqState == "online" || oneBotConnected > 0
    val qqNeedsLogin: Boolean get() = qqLoginRequiredCount > 0 || mainQqState == "login_required"
    val activeQqUp: Boolean get() = if (qqEngine == "snowluma") snowlumaUp else napcatUp
    val activeQqReady: Boolean get() = if (qqEngine == "snowluma") snowlumaReady else napcatReady
    val activeQqWebReady: Boolean get() = if (qqEngine == "snowluma") snowlumaWebReady else napcatWebReady
    val stackRunning: Boolean get() = astrbotUp && activeQqUp
    val coreReady: Boolean get() = rootfsReady && astrbotReady && bridgeReady && activeQqReady
    val health: RuntimeHealth get() = when {
        actionRunning || stackStarting || qqStartingCount > 0 -> RuntimeHealth.WORKING
        oneBotAuthFailed || qqStalledCount > 0 || apiWarning || toolWarning || pluginBlock || eventLoopWarning -> RuntimeHealth.ATTENTION
        stackRunning && oneBotConnected > 0 -> RuntimeHealth.HEALTHY
        stackRunning && qqNeedsLogin -> RuntimeHealth.ATTENTION
        stackRunning -> RuntimeHealth.WORKING
        coreReady -> RuntimeHealth.STOPPED
        else -> RuntimeHealth.UNKNOWN
    }
}

data class LogSource(
    val id: String,
    val label: String,
    val category: LogCategory = LogCategory.SYSTEM
)

data class DiagnosticExportState(
    val state: String = "idle",
    val phase: String = "idle",
    val percent: Int = 0,
    val detail: String = "",
    val path: String = "",
    val mode: String = "redacted",
    val running: Boolean = false
) {
    val finished: Boolean get() = state in setOf("done", "success", "completed") && !running
}

data class QqLoginSession(
    val state: String = "idle",
    val url: String = "",
    val detail: String = ""
) {
    val ready: Boolean get() = state == "ready"
    val complete: Boolean get() = state == "complete"
    val failed: Boolean get() = state == "failed"
}

data class QqLoginFrame(
    val state: String = "idle",
    val width: Int = 0,
    val height: Int = 0,
    val detail: String = "",
    val png: ByteArray = ByteArray(0),
    val expired: Boolean = false,
    val frameToken: String = "",
    val display: Int = 0,
    val windowX: Int = 0,
    val windowY: Int = 0,
    val windowWidth: Int = 0,
    val windowHeight: Int = 0
) {
    val ready: Boolean get() = state == "ready" && png.isNotEmpty()
    val complete: Boolean get() = state == "complete"
    val failed: Boolean get() = state == "failed"
}

data class ConsoleState(
    val target: ConsoleTarget = ConsoleTarget.ASTRBOT,
    val url: String = "",
    val title: String = "AstrBot 控制台",
    val loading: Boolean = false,
    val error: String = "",
    val phase: String = "idle",
    val detail: String = "",
    val requestId: Long = 0L,
    val qrCompatAttempted: Boolean = false,
    val qrFrameVerified: Boolean = false,
    val qrImageBytes: ByteArray = ByteArray(0),
    val qrImageWidth: Int = 0,
    val qrImageHeight: Int = 0,
    val qrFrameToken: String = "",
    val qrFrameDisplay: Int = 0,
    val qrFrameWindowX: Int = 0,
    val qrFrameWindowY: Int = 0,
    val qrFrameWindowWidth: Int = 0,
    val qrFrameWindowHeight: Int = 0,
    val qrDesktopMode: Boolean = false,
    val qrDesktopImageBytes: ByteArray = ByteArray(0),
    val qrDesktopImageWidth: Int = 0,
    val qrDesktopImageHeight: Int = 0,
    val qrDesktopInteractionBusy: Boolean = false,
    val qrExpired: Boolean = false,
    val qrRefreshBusy: Boolean = false,
    val qrInteractionBusy: Boolean = false,
    val qrRefreshAvailableAtMs: Long = 0L
)




enum class BackgroundTaskState {
    QUEUED,
    RUNNING,
    SUCCEEDED,
    FAILED
}

enum class TaskStepState {
    WAITING,
    RUNNING,
    DONE,
    FAILED
}

data class BackgroundTaskStep(
    val label: String,
    val state: TaskStepState = TaskStepState.WAITING,
    val detail: String = ""
)

data class BackgroundTask(
    val id: String,
    val key: String = id,
    val title: String,
    val subtitle: String = "",
    val state: BackgroundTaskState = BackgroundTaskState.QUEUED,
    val progress: Int = 0,
    val detail: String = "等待后台处理",
    val steps: List<BackgroundTaskStep> = emptyList(),
    val createdAtMs: Long = System.currentTimeMillis(),
    val finishedAtMs: Long = 0L
) {
    val active: Boolean get() = state == BackgroundTaskState.QUEUED || state == BackgroundTaskState.RUNNING
}

enum class StatusConnectionState {
    CONNECTING,
    CACHED,
    READY,
    STALE,
    UNAVAILABLE
}

data class SettingsDraft(
    val initialized: Boolean = false,
    val stackAutostart: Boolean = false,
    val watchdogEnabled: Boolean = false,
    val rescueEnabled: Boolean = true,
    val messageGuardEnabled: Boolean = false,
    val downloadSource: String = "auto",
    val qqEngine: String = "napcat",
    val dirtyFields: Set<String> = emptySet()
) {
    val dirty: Boolean get() = dirtyFields.isNotEmpty()
}

data class ControlCenterUiState(
    val loading: Boolean = true,
    val refreshing: Boolean = false,
    val destination: ControlDestination = ControlDestination.OVERVIEW,
    val workbenchHome: Boolean = true,
    val operationsSection: OperationsSection = OperationsSection.ACTIONS,
    val status: RuntimeStatus = RuntimeStatus(),
    val logSources: List<LogSource> = emptyList(),
    val logCategory: LogCategory = LogCategory.OVERVIEW,
    val selectedLogId: String = "health",
    val logText: String = "",
    val redactedLogText: String = "",
    val logLoading: Boolean = false,
    val redactLogs: Boolean = true,
    val actionBusy: Boolean = false,
    val actionLabel: String = "",
    val healthCheckBusy: Boolean = false,
    val healthCheckMessage: String = "",
    val exportState: DiagnosticExportState = DiagnosticExportState(),
    val console: ConsoleState = ConsoleState(),
    val settingsDraft: SettingsDraft = SettingsDraft(),
    val settingsApplyingFields: Set<String> = emptySet(),
    val tasks: List<BackgroundTask> = emptyList(),
    val statusConnection: StatusConnectionState = StatusConnectionState.CONNECTING,
    val pendingDestination: ControlDestination? = null,
    val pendingConsoleTarget: ConsoleTarget? = null,
    val transientMessage: String = "",
    val errorMessage: String = "",
    val lastRefreshEpoch: Long = 0L
)
