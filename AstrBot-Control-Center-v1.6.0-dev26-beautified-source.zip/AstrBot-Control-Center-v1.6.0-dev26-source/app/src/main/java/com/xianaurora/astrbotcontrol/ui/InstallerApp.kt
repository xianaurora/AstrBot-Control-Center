package com.xianaurora.astrbotcontrol.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.xianaurora.astrbotcontrol.R
import com.xianaurora.astrbotcontrol.engine.ControlCenterViewModel
import com.xianaurora.astrbotcontrol.engine.InstallerViewModel
import com.xianaurora.astrbotcontrol.help.HelpContent
import com.xianaurora.astrbotcontrol.help.HelpTopic
import com.xianaurora.astrbotcontrol.model.CheckItem
import com.xianaurora.astrbotcontrol.model.EngineStatus
import com.xianaurora.astrbotcontrol.model.InstallEvent
import com.xianaurora.astrbotcontrol.model.InstallPlanItem
import com.xianaurora.astrbotcontrol.model.InstallScreen
import com.xianaurora.astrbotcontrol.model.InstallerUiState
import kotlin.math.roundToInt

private val MotionSpring = spring<Float>(
    dampingRatio = 0.88f,
    stiffness = 470f
)
private val MotionEasing = CubicBezierEasing(0.16f, 1f, 0.3f, 1f)
private const val MotionFastMs = 120
private const val MotionStandardMs = 240

private fun screenRank(screen: InstallScreen): Int = when (screen) {
    InstallScreen.RESTORING -> 0
    InstallScreen.WELCOME -> 1
    InstallScreen.PREFLIGHT -> 2
    InstallScreen.ENGINE_INSTALL -> 3
    InstallScreen.REBOOT_REQUIRED, InstallScreen.ENGINE_VERIFY -> 4
    InstallScreen.ROLLBACK_REBOOT_REQUIRED, InstallScreen.ROLLBACK_COMPLETE -> 4
    InstallScreen.RUNTIME_PLAN -> 5
    InstallScreen.RUNTIME_INSTALL -> 6
    InstallScreen.READY -> 7
    InstallScreen.HELP -> 8
    InstallScreen.ERROR -> 9
}

@Composable
fun AstrBotControlApp(vm: InstallerViewModel, controlVm: ControlCenterViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importRootfs(uri)
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.background,
                        MaterialTheme.colorScheme.surfaceContainerLowest,
                        MaterialTheme.colorScheme.background
                    )
                )
            )
            .safeDrawingPadding()
    ) {
        AnimatedContent(
            targetState = ui.screen,
            transitionSpec = {
                val forward = screenRank(targetState) >= screenRank(initialState)
                val enterOffset: (Int) -> Int = { width -> if (forward) width / 18 else -width / 18 }
                val exitOffset: (Int) -> Int = { width -> if (forward) -width / 28 else width / 28 }
                (
                    fadeIn(tween(MotionStandardMs, easing = MotionEasing)) +
                        slideInHorizontally(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessLow
                            ),
                            initialOffsetX = enterOffset
                        )
                ) togetherWith (
                    fadeOut(tween(MotionFastMs)) +
                        slideOutHorizontally(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            ),
                            targetOffsetX = exitOffset
                        )
                )
            },
            label = "screen"
        ) { screen ->
            when (screen) {
                InstallScreen.RESTORING -> CenteredWorking("正在恢复状态", ui.message.ifBlank { "正在读取重启后的核心组件与安装进度，请稍候" })
                InstallScreen.WELCOME -> WelcomeScreen(onStart = vm::begin, onHelp = { vm.openHelp("overview") })
                InstallScreen.PREFLIGHT -> InstallerShell(ui, onHelp = { vm.openHelp("preflight") }) {
                    PreflightScreen(ui, onRefresh = vm::runPreflight, onContinue = vm::goToEngineInstall)
                }
                InstallScreen.ENGINE_INSTALL -> InstallerShell(ui, onHelp = { vm.openHelp("engine_install") }) {
                    EngineInstallScreen(ui, onConfirmChanged = vm::setEngineUpgradeConfirmed, onInstall = vm::installEngine)
                }
                InstallScreen.REBOOT_REQUIRED -> InstallerShell(ui, onHelp = { vm.openHelp("reboot_engine") }) {
                    RebootScreen(ui, onReboot = vm::requestReboot, onVerify = vm::verifyEngine)
                }
                InstallScreen.ENGINE_VERIFY -> InstallerShell(ui, onHelp = { vm.openHelp("reboot_engine") }) {
                    CenteredWorking("验证核心组件", ui.message.ifBlank { "正在读取重启后的核心组件协议与状态" })
                }
                InstallScreen.ROLLBACK_REBOOT_REQUIRED -> InstallerShell(ui, onHelp = { vm.openHelp("engine_backup") }) {
                    RollbackRebootScreen(ui, onReboot = vm::requestReboot)
                }
                InstallScreen.ROLLBACK_COMPLETE -> InstallerShell(ui, onHelp = { vm.openHelp("engine_backup") }) {
                    RollbackCompleteScreen(ui, onDone = vm::finishRollback)
                }
                InstallScreen.RUNTIME_PLAN -> InstallerShell(ui, onHelp = { vm.openHelp(if (!ui.resourceStatus.ready && !ui.engineStatus.rootfsReady) "rootfs_resource" else "overview") }) {
                    RuntimePlanScreen(
                        ui = ui,
                        onImport = { importLauncher.launch(arrayOf("application/x-xz", "application/octet-stream", "*/*")) },
                        onDownload = vm::downloadRootfs,
                        onRefresh = vm::refreshPlan,
                        onStart = vm::startRuntimeInstall,
                        onDetails = vm::showTechnicalLog,
                        onHelp = vm::openHelp
                    )
                }
                InstallScreen.RUNTIME_INSTALL -> InstallerShell(ui, onHelp = { vm.openHelp(ui.engineStatus.solutionId.ifBlank { "overview" }) }) {
                    RuntimeInstallScreen(ui, onRefreshDetails = vm::showTechnicalLog, onHelp = vm::openHelp)
                }
                InstallScreen.READY -> ControlCenterApp(controlVm, onOpenHelp = { vm.openHelp("overview") })
                InstallScreen.HELP -> HelpCenter(selected = ui.helpTopic, onBack = vm::closeHelp)
                InstallScreen.ERROR -> ErrorScreen(ui, onRetry = vm::retryCurrent, onRollback = vm::rollbackEngine, onHelp = { vm.openHelp(ui.error?.solutionId) }, onDetails = vm::showTechnicalLog)
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onStart: () -> Unit, onHelp: () -> Unit) {
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered = true }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 26.dp),
        contentAlignment = Alignment.Center
    ) {
        val compact = maxWidth < 460.dp
        Column(
            modifier = Modifier.fillMaxWidth().widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(tween(MotionStandardMs, easing = MotionEasing)) +
                    slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessLow
                        )
                    ) { it / 5 }
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Image(
                                painter = painterResource(R.drawable.product_astrbot),
                                contentDescription = "AstrBot",
                                modifier = Modifier.size(44.dp),
                                contentScale = ContentScale.Fit
                            )
                        }
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "安装 AstrBot",
                            style = MaterialTheme.typography.displaySmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "开始前确认设备满足以下条件",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(tween(MotionStandardMs, delayMillis = 60, easing = MotionEasing)) +
                    slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessLow
                        )
                    ) { it / 6 }
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RequirementChip("ARM64")
                    RequirementChip("4 KB")
                    RequirementChip("Root")
                }
            }

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(tween(MotionStandardMs, delayMillis = 110, easing = MotionEasing)) +
                    slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessLow
                        )
                    ) { it / 7 }
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = .82f)
                ) {
                    Text(
                        "安装核心组件后需重启 1 次 · 到运行环境阶段才联网",
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            AnimatedVisibility(
                visible = entered,
                enter = fadeIn(tween(MotionStandardMs, delayMillis = 160, easing = MotionEasing)) +
                    slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessLow
                        )
                    ) { it / 8 }
            ) {
                if (compact) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        MotionButton(
                            onClick = onStart,
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(22.dp)
                        ) { Text("开始安装", fontWeight = FontWeight.SemiBold) }
                        MotionOutlinedButton(
                            onClick = onHelp,
                            modifier = Modifier.fillMaxWidth().height(50.dp),
                            shape = RoundedCornerShape(22.dp)
                        ) { Text("安装教程") }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        MotionButton(
                            onClick = onStart,
                            modifier = Modifier.height(52.dp),
                            shape = RoundedCornerShape(22.dp)
                        ) { Text("开始安装", fontWeight = FontWeight.SemiBold) }
                        MotionOutlinedButton(
                            onClick = onHelp,
                            modifier = Modifier.height(52.dp),
                            shape = RoundedCornerShape(22.dp)
                        ) { Text("安装教程") }
                    }
                }
            }
        }
    }
}

@Composable
private fun RequirementChip(text: String) {
    Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = .72f)
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun MotionButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: RoundedCornerShape = RoundedCornerShape(22.dp),
    content: @Composable RowScope.() -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) .982f else 1f,
        animationSpec = MotionSpring,
        label = "primary-press"
    )
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale },
        shape = shape,
        interactionSource = interaction,
        content = content
    )
}

@Composable
private fun MotionOutlinedButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: RoundedCornerShape = RoundedCornerShape(22.dp),
    content: @Composable RowScope.() -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) .982f else 1f,
        animationSpec = MotionSpring,
        label = "secondary-press"
    )
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.graphicsLayer { scaleX = scale; scaleY = scale },
        shape = shape,
        interactionSource = interaction,
        content = content
    )
}

@Composable
private fun InstallerShell(ui: InstallerUiState, onHelp: () -> Unit, content: @Composable () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 840.dp
        if (wide) {
            Row(Modifier.fillMaxSize().padding(22.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                StepRail(ui, Modifier.width(250.dp).fillMaxHeight(), onHelp)
                Surface(
                    modifier = Modifier.weight(1f).fillMaxHeight(),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.82f),
                    tonalElevation = 1.dp
                ) {
                    Box(Modifier.fillMaxSize().padding(28.dp)) { content() }
                }
            }
        } else {
            Column(Modifier.fillMaxSize()) {
                CompactHeader(ui, onHelp)
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)) { content() }
            }
        }
    }
}

private data class Step(val name: String, val screens: Set<InstallScreen>)
private val steps = listOf(
    Step("设备检查", setOf(InstallScreen.PREFLIGHT)),
    Step("安装核心组件", setOf(InstallScreen.ENGINE_INSTALL)),
    Step("重启验证", setOf(InstallScreen.REBOOT_REQUIRED, InstallScreen.ENGINE_VERIFY, InstallScreen.ROLLBACK_REBOOT_REQUIRED)),
    Step("运行资源", setOf(InstallScreen.RUNTIME_PLAN)),
    Step("环境安装", setOf(InstallScreen.RUNTIME_INSTALL)),
    Step("完成", setOf(InstallScreen.READY))
)

@Composable
private fun StepRail(ui: InstallerUiState, modifier: Modifier, onHelp: () -> Unit) {
    val current = steps.indexOfFirst { ui.screen in it.screens }.let { if (it < 0) 0 else it }
    Surface(modifier, shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.88f)) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("安装 AstrBot", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("控制中心", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(14.dp))
            steps.forEachIndexed { i, step ->
                val active = i == current
                val done = i < current || (ui.screen == InstallScreen.READY && i <= current)
                val itemScale by animateFloatAsState(
                    targetValue = if (active) 1f else .985f,
                    animationSpec = MotionSpring,
                    label = "step-scale-$i"
                )
                val itemColor by animateColorAsState(
                    targetValue = if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                    animationSpec = tween(MotionFastMs, easing = MotionEasing),
                    label = "step-color-$i"
                )
                Surface(
                    modifier = Modifier.graphicsLayer { scaleX = itemScale; scaleY = itemScale },
                    shape = RoundedCornerShape(22.dp),
                    color = itemColor
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StepDot(done, active, i + 1)
                        Text(
                            step.name,
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium,
                            color = if (active) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
            TextButton(onClick = onHelp, modifier = Modifier.fillMaxWidth()) { Text("?  当前步骤教程") }
            Text("需要时可打开当前步骤教程。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StepDot(done: Boolean, active: Boolean, number: Int) {
    val color = when {
        done || active -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.outlineVariant
    }
    val scale by animateFloatAsState(
        targetValue = if (active) 1.08f else 1f,
        animationSpec = MotionSpring,
        label = "step-dot-$number"
    )
    Surface(
        shape = CircleShape,
        color = color,
        modifier = Modifier.size(28.dp).graphicsLayer { scaleX = scale; scaleY = scale }
    ) {
        Box(contentAlignment = Alignment.Center) {
            AnimatedContent(
                targetState = done,
                transitionSpec = {
                    (fadeIn(tween(MotionFastMs)) + slideInVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMedium
                        )
                    ) { it / 3 }) togetherWith
                        (fadeOut(tween(MotionFastMs)) + slideOutVertically(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMedium
                            )
                        ) { -it / 3 })
                },
                label = "step-dot-content-$number"
            ) { completed ->
                Text(
                    if (completed) "✓" else number.toString(),
                    color = if (completed || active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun CompactHeader(ui: InstallerUiState, onHelp: () -> Unit) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(18.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("AstrBot", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        TextButton(onClick = onHelp) { Text("帮助") }
    }
}

@Composable
private fun PreflightScreen(ui: InstallerUiState, onRefresh: () -> Unit, onContinue: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            PageTitle("设备检查", "所有检查都在本机完成。通过之前不会联网，也不会修改运行环境。")
            Spacer(Modifier.height(10.dp))
        }
        items(ui.checks, key = { it.id }) { CheckRow(it) }
        if (ui.existingEngine.present) {
            item {
                Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .45f)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("检测到现有核心组件", fontWeight = FontWeight.SemiBold)
                        Text("${ui.existingEngine.version.ifBlank { "未知版本" }}  →  ${ui.targetEngineVersion}", style = MaterialTheme.typography.titleMedium)
                        Text("只升级现有核心组件，不会并行安装第二份。升级前会先创建仅包含核心组件本体的回退快照。", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (ui.existingEngine.persistentDataPresent) {
                            Text("现有运行环境：${ui.existingEngine.runtimeSummary} · 持久数据约 ${formatBytes(ui.existingEngine.persistentDataBytes)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            if (ui.busy) WorkingStrip(ui.message)
            else MessageStrip(ui.message, good = ui.checks.isNotEmpty() && ui.checks.all { it.ok })
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MotionOutlinedButton(onClick = onRefresh, enabled = !ui.busy, shape = RoundedCornerShape(20.dp)) { Text("重新检查") }
                MotionButton(onClick = onContinue, enabled = !ui.busy && ui.checks.isNotEmpty() && ui.checks.all { it.ok }, shape = RoundedCornerShape(20.dp)) { Text(if (ui.existingEngine.present) "查看升级内容" else "继续") }
            }
        }
    }
}

@Composable
private fun CheckRow(item: CheckItem) {
    Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = .5.dp) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            StatusDot(item.ok)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title.uiCopy(), fontWeight = FontWeight.SemiBold)
                Text(item.detail.uiCopy(), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
            Text(if (item.ok) "通过" else "需处理", color = if (item.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun StatusDot(ok: Boolean) {
    Surface(shape = CircleShape, color = if (ok) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer, modifier = Modifier.size(34.dp)) {
        Box(contentAlignment = Alignment.Center) { Text(if (ok) "✓" else "!", fontWeight = FontWeight.Bold, color = if (ok) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onErrorContainer) }
    }
}

@Composable
private fun EngineInstallScreen(
    ui: InstallerUiState,
    onConfirmChanged: (Boolean) -> Unit,
    onInstall: () -> Unit
) {
    val upgrading = ui.existingEngine.present
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        PageTitle(if (upgrading) "升级核心组件" else "安装核心组件", "这一阶段只使用 APK 内置的核心组件安装包，不会下载 Ubuntu、AstrBot、QQ 或 NapCat。")
        GlassCard {
            DetailLine("Root 管理器", ui.rootBackend.label + ui.rootBackendVersion.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty())
            if (upgrading) DetailLine("当前核心组件", ui.existingEngine.version.ifBlank { "未知版本" })
            DetailLine("目标版本", ui.targetEngineVersion)
            DetailLine("安装包 SHA-256", ui.engineAssetSha256.ifBlank { "准备中" })
            DetailLine("网络访问", "不需要")
            DetailLine("现有运行环境", if (ui.existingEngine.persistentDataPresent) ui.existingEngine.runtimeSummary else "未检测到持久业务环境")
            DetailLine("现有业务数据", "保留，不参与核心组件回退")
            DetailLine("升级保护", if (upgrading) "写入前创建旧核心组件回退快照" else "首次安装无需回退快照")
            DetailLine("完成后", "需要重启 1 次")
        }
        ExpandableInfo("安装时会做什么？") {
            Text(
                if (upgrading) {
                    """1. 校验 APK 内置核心组件。
2. 对当前 Root 模块本体创建 SHA-256 可验证回退快照。
3. 调用当前 Root 管理器原地升级同一个 astrbot_standalone 模块。
4. 重启后验证协议、目标版本和 late_start 标记。

Ubuntu、AstrBot、插件、NapCat、QQ 登录态和配置不进入核心组件快照，也不会在这一步联网。""".trimIndent()
                } else {
                    "控制中心把内置 ZIP 复制到 Root 临时目录，调用当前 Root 管理器的模块安装命令。模块脚本只做架构、页大小、完整性与迁移检查，不在刷入阶段启动运行资源下载。"
                },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 24.sp
            )
        }
        if (ui.existingEngine.rollbackAvailable && upgrading) {
            MessageStrip("已有可用回退点：${ui.existingEngine.rollbackVersion.ifBlank { ui.existingEngine.version }}。本次升级会刷新为最新的升级前快照。", good = true)
        }
        if (upgrading) {
            Surface(
                modifier = Modifier.fillMaxWidth().clickable(enabled = !ui.busy) { onConfirmChanged(!ui.engineUpgradeConfirmed) },
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = ui.engineUpgradeConfirmed,
                        onCheckedChange = if (ui.busy) null else onConfirmChanged
                    )
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text("确认原地升级 ${ui.existingEngine.version.ifBlank { "当前版本" }} → ${ui.targetEngineVersion}", fontWeight = FontWeight.SemiBold)
                        Text("升级前只备份核心组件本体；Ubuntu、AstrBot、插件、QQ 登录态和配置保持原样。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        if (ui.message.isNotBlank() && !ui.busy) MessageStrip(ui.message, good = true)
        if (ui.busy) WorkingStrip(ui.message)
        MotionButton(
            onClick = onInstall,
            enabled = !ui.busy && (!upgrading || ui.engineUpgradeConfirmed),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(22.dp)
        ) {
            if (ui.busy) { CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)) }
            Text(if (ui.busy) (if (upgrading) "正在升级核心组件" else "正在安装核心组件") else (if (upgrading) "确认并升级核心组件" else "安装核心组件"))
        }
    }
}

@Composable
private fun RebootScreen(ui: InstallerUiState, onReboot: () -> Unit, onVerify: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        PageTitle("需要重启一次", "重启后 Root 才会加载新的核心组件；本次重启不会自动联网。")
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .75f)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("核心组件已写入", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(ui.message.ifBlank { "重启后重新打开控制中心，会自动继续验证核心组件。" }, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .82f))
                Text("✓ 不会重复安装模块\n✓ 不会下载运行资源\n✓ 已有 AstrBot / QQ 数据继续保留", lineHeight = 25.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MotionButton(onClick = onReboot, enabled = !ui.busy, shape = RoundedCornerShape(20.dp)) { Text("立即重启") }
            MotionOutlinedButton(onClick = onVerify, enabled = !ui.busy, shape = RoundedCornerShape(20.dp)) { Text("我已经重启，重新验证") }
        }
    }
}

@Composable
private fun RollbackRebootScreen(ui: InstallerUiState, onReboot: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        PageTitle("已恢复升级前核心组件", "模块文件已经恢复；Root 模块需要再重启一次，才会重新按旧版本加载。")
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .72f)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("回退快照已恢复", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text(ui.message, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("✓ 只回退核心组件文件\n✓ Ubuntu / AstrBot / 插件 / QQ 登录态不回退\n✓ 重启后可继续使用原 Web 控制台", lineHeight = 25.sp)
            }
        }
        MotionButton(onClick = onReboot, enabled = !ui.busy, shape = RoundedCornerShape(20.dp)) { Text("重启并完成回退") }
    }
}

@Composable
private fun RollbackCompleteScreen(ui: InstallerUiState, onDone: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        PageTitle("核心组件回退完成", "设备已经重新启动，升级前的核心组件已重新加载。")
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .72f)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("当前核心组件：${ui.existingEngine.version.ifBlank { "升级前版本" }}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text(ui.message, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("✓ Root 模块本体已回退\n✓ Ubuntu / AstrBot / 插件 / QQ 数据保持当前状态\n✓ 原 Web 控制台仍可继续使用", lineHeight = 25.sp)
            }
        }
        MotionButton(onClick = onDone, shape = RoundedCornerShape(20.dp)) { Text("完成") }
    }
}

@Composable
private fun RuntimePlanScreen(
    ui: InstallerUiState,
    onImport: () -> Unit,
    onDownload: () -> Unit,
    onRefresh: () -> Unit,
    onStart: () -> Unit,
    onDetails: () -> Unit,
    onHelp: (String?) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            PageTitle("准备运行环境", "从这里开始才可能联网。先确认所需资源和当前缓存，再继续。")
            Spacer(Modifier.height(4.dp))
            MessageStrip(ui.message, good = ui.resourceStatus.ready || ui.engineStatus.rootfsReady)
        }
        items(ui.plan, key = { it.id }) { PlanRow(it) }
        if (!ui.engineStatus.rootfsReady) {
            item {
                ResourceCard(ui, onImport, onDownload, onHelp)
            }
        }
        item {
            ExpandableInfo("查看将执行的详细操作") {
                Text("Ubuntu：校验 → 解压到 staging → 验证 → 原子切换\nAstrBot：uv → Python 工具环境 → AstrBot → 初始化\nLinux QQ / NapCat：apt 依赖 → 可恢复下载 → 校验 → 保配置组装\nOneBot：本地 Token / 反向 WebSocket → 快速启动标记", lineHeight = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onClick = onDetails) { Text("刷新技术日志") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                MotionButton(onClick = onStart, enabled = !ui.busy && (ui.engineStatus.rootfsReady || ui.resourceStatus.ready), shape = RoundedCornerShape(20.dp)) { Text("开始准备环境") }
                MotionOutlinedButton(onClick = onRefresh, enabled = !ui.busy, shape = RoundedCornerShape(20.dp)) { Text("重新检查") }
            }
            Text("点击“开始准备环境”即代表允许核心组件从此刻开始访问网络。", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
private fun ResourceCard(ui: InstallerUiState, onImport: () -> Unit, onDownload: () -> Unit, onHelp: (String?) -> Unit) {
    val r = ui.resourceStatus
    Surface(shape = RoundedCornerShape(22.dp), color = if (r.ready) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .5f) else MaterialTheme.colorScheme.surfaceContainerHigh) {
        Column(Modifier.padding(19.dp).animateContentSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(r.ready)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Ubuntu 24.04 兼容基础资源", fontWeight = FontWeight.SemiBold)
                    Text(if (r.ready) "已验证 · ${formatBytes(r.expectedSize)}" else "尚未准备 · ${formatBytes(r.expectedSize)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (ui.importProgress != null) {
                val p by animateFloatAsState(ui.importProgress, MotionSpring, label = "import")
                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().clip(CircleShape))
                Text("本地读取与 SHA-256 校验 ${(p * 100).roundToInt()}%", style = MaterialTheme.typography.bodySmall)
            }
            if (ui.resourceDownloadProgress != null) {
                val p by animateFloatAsState(ui.resourceDownloadProgress, MotionSpring, label = "download-rootfs")
                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().clip(CircleShape))
                Text(ui.resourceDownloadDetail.ifBlank { "正在下载并准备断点续传" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!r.ready) {
                Text(if (ui.resourceAutoDownloadAvailable) "可以自动获取当前核心组件清单指定的兼容资源。下载结束后会在 App 与核心组件两侧再次校验 SHA-256。" else "当前开发版还没有配置这份定制兼容 rootfs 的正式公开下载地址，因此不会用未经设备验证的通用包替代。可先从本地导入；发布源配置后会直接提供自动获取。", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (ui.resourceAutoDownloadAvailable) {
                        MotionButton(onClick = onDownload, enabled = !ui.busy, shape = RoundedCornerShape(18.dp)) { Text("自动获取") }
                    }
                    MotionOutlinedButton(onClick = onImport, enabled = !ui.busy, shape = RoundedCornerShape(18.dp)) { Text("从本地导入") }
                    TextButton(onClick = { onHelp("rootfs_resource") }) { Text("为什么？") }
                }
            }
        }
    }
}

@Composable
private fun PlanRow(item: InstallPlanItem) {
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            StatusDot(item.state == "ready")
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title.uiCopy(), fontWeight = FontWeight.SemiBold)
                Text(item.detail.uiCopy(), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Surface(shape = CircleShape, color = if (item.network && item.state != "ready") MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceContainer) {
                Text(if (item.network && item.state != "ready") "需要网络" else if (item.state == "ready") "已完成" else "本地", Modifier.padding(10.dp, 6.dp), style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun RuntimeInstallScreen(ui: InstallerUiState, onRefreshDetails: () -> Unit, onHelp: (String?) -> Unit) {
    var details by rememberSaveable { mutableStateOf(false) }
    var logOpen by rememberSaveable { mutableStateOf(false) }
    val s = ui.engineStatus
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            PageTitle("正在准备运行环境", "安装会按检查点继续，已完成的步骤不会重复执行。")
            CurrentOperationCard(s)
        }
        item {
            ExpandableCard("正在执行的操作", details, { details = !details }) {
                EventTimeline(ui.events, onHelp)
            }
        }
        item {
            ExpandableCard("技术日志", logOpen, { logOpen = !logOpen }) {
                Row { TextButton(onClick = onRefreshDetails) { Text("刷新") } }
                SelectionContainer {
                    Text(ui.technicalLog.ifBlank { "暂时没有日志输出" }, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun CurrentOperationCard(s: EngineStatus) {
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .60f)) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(s.title.ifBlank { "等待核心组件状态" }.uiCopy(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
            if (s.detail.isNotBlank()) Text(s.detail.uiCopy(), color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .82f))
            if (s.hasProgress) {
                val p by animateFloatAsState(s.progress, MotionSpring, label = "runtime-progress")
                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape))
                Row(Modifier.fillMaxWidth()) {
                    Text("${(p * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.weight(1f))
                    Text("${formatAmount(s.current, s.unit)} / ${formatAmount(s.total, s.unit)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .75f))
                }
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape))
                Text("当前操作没有可靠的总量，因此使用动态进度，不伪造百分比。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .75f))
            }
        }
    }
}

@Composable
private fun EventTimeline(events: List<InstallEvent>, onHelp: (String?) -> Unit) {
    if (events.isEmpty()) {
        Text("任务刚开始，等待第一条核心组件事件。", color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        events.takeLast(18).forEach { e ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                Surface(shape = CircleShape, color = when (e.state) {
                    "success" -> MaterialTheme.colorScheme.primary
                    "failed" -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.secondary
                }, modifier = Modifier.size(9.dp).padding(top = 4.dp)) {}
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.title.ifBlank { "${e.stage} / ${e.step}" }.uiCopy(), fontWeight = FontWeight.Medium)
                    if (e.detail.isNotBlank()) Text(e.detail.uiCopy(), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                if (e.state == "failed") TextButton(onClick = { onHelp(e.solutionId.ifBlank { "generic" }) }) { Text("解决") }
            }
        }
    }
}

@Composable
private fun ReadyScreen(ui: InstallerUiState, onHelp: () -> Unit) {
    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }
    val badgeScale by animateFloatAsState(
        targetValue = if (appeared) 1f else .72f,
        animationSpec = spring(dampingRatio = .72f, stiffness = 360f),
        label = "ready-badge-scale"
    )
    val badgeAlpha by animateFloatAsState(
        targetValue = if (appeared) 1f else 0f,
        animationSpec = tween(MotionStandardMs, easing = MotionEasing),
        label = "ready-badge-alpha"
    )

    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 820.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(72.dp).graphicsLayer {
                    scaleX = badgeScale
                    scaleY = badgeScale
                    alpha = badgeAlpha
                }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("✓", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            PageTitle("安装完成", "核心组件与运行环境已经准备完成。QQ 登录属于使用流程，不会影响安装完成标记。")
            GlassCard {
                DetailLine("核心组件", ui.engineStatus.engineVersion.ifBlank { "已验证" })
                DetailLine("Ubuntu", if (ui.engineStatus.rootfsReady) "正常" else "待检查")
                DetailLine("AstrBot", if (ui.engineStatus.astrbotReady) "正常" else "待检查")
                DetailLine("Linux QQ / NapCat", if (ui.engineStatus.napcatReady) "正常" else "待检查")
                DetailLine("OneBot", if (ui.engineStatus.onebotReady) "已配置" else "待检查")
            }
            MessageStrip("原 Web 控制台仍可继续使用。", good = true)
            MotionOutlinedButton(onClick = onHelp, shape = RoundedCornerShape(20.dp)) { Text("查看教程") }
        }
    }
}

@Composable
private fun ErrorScreen(ui: InstallerUiState, onRetry: () -> Unit, onRollback: () -> Unit, onHelp: () -> Unit, onDetails: () -> Unit) {
    val e = ui.error
    var detailOpen by rememberSaveable { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 820.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.size(58.dp)) {
                Box(contentAlignment = Alignment.Center) { Text("!", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer) }
            }
            Text((e?.title ?: "操作没有完成").uiCopy(), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
            Text(e?.message.orEmpty().uiCopy(), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("你的数据怎么样？", fontWeight = FontWeight.SemiBold)
                    Text(e?.dataSafeMessage.orEmpty().uiCopy(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (!e?.code.isNullOrBlank()) Text("错误代码 · ${e?.code}", fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MotionButton(onClick = onRetry, shape = RoundedCornerShape(20.dp)) { Text("重试当前步骤") }
                if (e?.rollbackRecommended == true) {
                    MotionOutlinedButton(onClick = onRollback, shape = RoundedCornerShape(20.dp)) { Text("恢复原核心组件") }
                }
                MotionOutlinedButton(onClick = onHelp, shape = RoundedCornerShape(20.dp)) { Text("查看解决方案") }
            }
            ExpandableCard("技术详情", detailOpen, { detailOpen = !detailOpen }) {
                TextButton(onClick = onDetails) { Text("刷新日志") }
                SelectionContainer { Text(ui.technicalLog.ifBlank { e?.message.orEmpty() }, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 18.sp) }
            }
        }
    }
}

@Composable
private fun HelpCenter(selected: String?, onBack: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var selectedId by rememberSaveable(selected) { mutableStateOf(selected ?: "overview") }
    var compactDetail by rememberSaveable(selected) { mutableStateOf(selected != null) }
    val topics = remember(query) {
        if (query.isBlank()) HelpContent.topics
        else HelpContent.topics.filter {
            it.title.contains(query, true) ||
                it.summary.contains(query, true) ||
                it.sections.any { section -> section.title.contains(query, true) || section.body.contains(query, true) }
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize().padding(20.dp)) {
        val wide = maxWidth >= 840.dp
        if (wide) {
            BackHandler { onBack() }
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Surface(
                    Modifier.width(300.dp).fillMaxHeight(),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Column(Modifier.padding(18.dp)) {
                        TextButton(onClick = onBack) { Text("← 返回") }
                        Text("帮助与教程", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        SearchLikeField(query) { query = it }
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            items(topics, key = { it.id }) { topic ->
                                HelpTopicListItem(
                                    topic = topic,
                                    selected = selectedId == topic.id,
                                    onClick = { selectedId = topic.id }
                                )
                            }
                        }
                    }
                }
                Surface(
                    Modifier.weight(1f).fillMaxHeight(),
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .80f)
                ) {
                    AnimatedContent(
                        targetState = selectedId,
                        modifier = Modifier.fillMaxSize(),
                        transitionSpec = {
                            (fadeIn(tween(MotionStandardMs, easing = MotionEasing)) +
                                slideInHorizontally(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessLow
                                    )
                                ) { it / 20 }) togetherWith
                                (fadeOut(tween(MotionFastMs)) +
                                    slideOutHorizontally(
                                        animationSpec = spring(
                                            dampingRatio = Spring.DampingRatioNoBouncy,
                                            stiffness = Spring.StiffnessMediumLow
                                        )
                                    ) { -it / 28 })
                        },
                        label = "help-wide-topic"
                    ) { id ->
                        HelpTopicPage(
                            HelpContent.byId(id),
                            Modifier.fillMaxSize().padding(26.dp).verticalScroll(rememberScrollState())
                        )
                    }
                }
            }
        } else {
            BackHandler(enabled = compactDetail) { compactDetail = false }
            BackHandler(enabled = !compactDetail) { onBack() }
            AnimatedContent(
                targetState = compactDetail,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = {
                    if (targetState) {
                        (fadeIn(tween(MotionStandardMs, easing = MotionEasing)) +
                            slideInHorizontally(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                    stiffness = Spring.StiffnessLow
                                )
                            ) { it / 8 }) togetherWith
                            (fadeOut(tween(MotionFastMs)) +
                                slideOutHorizontally(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                ) { -it / 12 })
                    } else {
                        (fadeIn(tween(MotionStandardMs, easing = MotionEasing)) +
                            slideInHorizontally(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                    stiffness = Spring.StiffnessLow
                                )
                            ) { -it / 8 }) togetherWith
                            (fadeOut(tween(MotionFastMs)) +
                                slideOutHorizontally(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                ) { it / 12 })
                    }
                },
                label = "help-compact-navigation"
            ) { detail ->
                if (detail) {
                    Column(Modifier.fillMaxSize()) {
                        TextButton(onClick = { compactDetail = false }) { Text("← 全部教程") }
                        Surface(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            shape = RoundedCornerShape(22.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer.copy(alpha = .82f)
                        ) {
                            HelpTopicPage(
                                HelpContent.byId(selectedId),
                                Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())
                            )
                        }
                    }
                } else {
                    Column(Modifier.fillMaxSize()) {
                        TextButton(onClick = onBack) { Text("← 返回") }
                        Text("帮助与教程", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        SearchLikeField(query) { query = it }
                        Spacer(Modifier.height(12.dp))
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(topics, key = { it.id }) { topic ->
                                HelpTopicListItem(
                                    topic = topic,
                                    selected = selectedId == topic.id,
                                    onClick = {
                                        selectedId = topic.id
                                        compactDetail = true
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HelpTopicListItem(topic: HelpTopic, selected: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .986f else 1f,
        animationSpec = MotionSpring,
        label = "help-topic-press-${topic.id}"
    )
    val containerColor by animateColorAsState(
        targetValue = when {
            selected && pressed -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = .86f)
            selected -> MaterialTheme.colorScheme.primaryContainer
            pressed -> MaterialTheme.colorScheme.surfaceContainerHighest
            else -> Color.Transparent
        },
        animationSpec = tween(MotionFastMs, easing = MotionEasing),
        label = "help-topic-color-${topic.id}"
    )
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clickable(interactionSource = interaction, indication = LocalIndication.current, onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        color = containerColor
    ) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                topic.title,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
            )
            Text(
                topic.summary,
                style = MaterialTheme.typography.bodySmall,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .72f) else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SearchLikeField(value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = CircleShape,
        placeholder = { Text("搜索问题、步骤或错误代码") },
        label = { Text("搜索教程") }
    )
}

@Composable
private fun HelpTopicPage(topic: HelpTopic, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(topic.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        Text(topic.summary, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        topic.sections.forEach { section ->
            var open by rememberSaveable(topic.id, section.title) { mutableStateOf(false) }
            ExpandableCard(section.title, open, { open = !open }) {
                Text(section.body, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 24.sp)
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun ExpandableInfo(title: String, content: @Composable () -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(false) }
    ExpandableCard(title, open, { open = !open }, content)
}

@Composable
private fun ExpandableCard(title: String, open: Boolean, onToggle: () -> Unit, content: @Composable () -> Unit) {
    val caretRotation by animateFloatAsState(
        targetValue = if (open) 180f else 0f,
        animationSpec = MotionSpring,
        label = "expand-caret-$title"
    )
    Surface(
        Modifier.fillMaxWidth().animateContentSize(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioNoBouncy,
                stiffness = Spring.StiffnessMediumLow
            )
        ),
        shape = RoundedCornerShape(26.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(17.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Text(
                    "⌄",
                    modifier = Modifier.graphicsLayer { rotationZ = caretRotation },
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            AnimatedVisibility(
                open,
                enter = fadeIn(tween(MotionStandardMs, easing = MotionEasing)) +
                    expandVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMediumLow
                        ),
                        expandFrom = Alignment.Top
                    ),
                exit = fadeOut(tween(MotionFastMs)) +
                    shrinkVertically(
                        animationSpec = spring(
                            dampingRatio = Spring.DampingRatioNoBouncy,
                            stiffness = Spring.StiffnessMedium
                        ),
                        shrinkTowards = Alignment.Top
                    )
            ) {
                Column(
                    Modifier.padding(start = 17.dp, end = 17.dp, bottom = 17.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) { content() }
            }
        }
    }
}

@Composable
private fun GlassCard(content: @Composable () -> Unit) {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = .80f), tonalElevation = 1.dp) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) { content() }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.width(130.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Text(value, Modifier.weight(1f), fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 24.sp)
    }
}

@Composable
private fun MessageStrip(text: String, good: Boolean) {
    if (text.isBlank()) return
    Surface(shape = RoundedCornerShape(22.dp), color = if (good) MaterialTheme.colorScheme.primaryContainer.copy(alpha = .48f) else MaterialTheme.colorScheme.surfaceContainerHighest) {
        Text(text.uiCopy(), Modifier.fillMaxWidth().padding(14.dp), color = if (good) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun WorkingStrip(text: String) {
    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surfaceContainerHighest) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
            Text(text.ifBlank { "正在处理" }.uiCopy(), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CenteredWorking(title: String, detail: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            CircularProgressIndicator()
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun String.uiCopy(): String =
    replace("Root Engine", "核心组件").replace("Engine", "核心组件")

private fun formatAmount(value: Long?, unit: String): String {
    if (value == null) return "—"
    return if (unit == "bytes") formatBytes(value) else "$value ${unit.ifBlank { "" }}".trim()
}

private fun formatBytes(value: Long): String = when {
    value >= 1024L * 1024 * 1024 -> "%.2f GiB".format(value / 1024.0 / 1024.0 / 1024.0)
    value >= 1024L * 1024 -> "%.1f MiB".format(value / 1024.0 / 1024.0)
    value >= 1024L -> "%.1f KiB".format(value / 1024.0)
    else -> "$value B"
}
