package com.xianaurora.astrbotcontrol.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * AstrBot CC owns its palette instead of inheriting wallpaper dynamic color.
 * That keeps the control center visually stable across launchers/tablets and
 * gives product imagery (AstrBot / NapCat / SnowLuma / QQ) a neutral stage.
 */
private val Light = lightColorScheme(
    primary = Color(0xFF006B93),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFC8E9FF),
    onPrimaryContainer = Color(0xFF002F43),
    secondary = Color(0xFF62558A),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE8DEFF),
    onSecondaryContainer = Color(0xFF332B52),
    tertiary = Color(0xFF006C5D),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF9BF2DA),
    onTertiaryContainer = Color(0xFF00382F),
    background = Color(0xFFF6F8FC),
    onBackground = Color(0xFF171C23),
    surface = Color(0xFFF6F8FC),
    onSurface = Color(0xFF171C23),
    surfaceVariant = Color(0xFFE1E7EF),
    onSurfaceVariant = Color(0xFF4B5664),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF1F4F9),
    surfaceContainer = Color(0xFFEBEFF5),
    surfaceContainerHigh = Color(0xFFE5EAF2),
    surfaceContainerHighest = Color(0xFFDDE4EE),
    outline = Color(0xFF72808F),
    outlineVariant = Color(0xFFC6D0DC),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF79D2FF),
    onPrimary = Color(0xFF003548),
    primaryContainer = Color(0xFF153B50),
    onPrimaryContainer = Color(0xFFC7E9FF),
    secondary = Color(0xFFC9B9FF),
    onSecondary = Color(0xFF33265C),
    secondaryContainer = Color(0xFF403362),
    onSecondaryContainer = Color(0xFFE8DEFF),
    tertiary = Color(0xFF6FE1C1),
    onTertiary = Color(0xFF00382F),
    tertiaryContainer = Color(0xFF16443B),
    onTertiaryContainer = Color(0xFF9EF2DA),
    background = Color(0xFF090D13),
    onBackground = Color(0xFFE7EDF5),
    surface = Color(0xFF090D13),
    onSurface = Color(0xFFE7EDF5),
    surfaceVariant = Color(0xFF303B48),
    onSurfaceVariant = Color(0xFFB8C4D2),
    surfaceContainerLowest = Color(0xFF070A0F),
    surfaceContainerLow = Color(0xFF0E131B),
    surfaceContainer = Color(0xFF131A23),
    surfaceContainerHigh = Color(0xFF19222D),
    surfaceContainerHighest = Color(0xFF222D3A),
    outline = Color(0xFF8291A2),
    outlineVariant = Color(0xFF2C3948),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF5F171A),
    onErrorContainer = Color(0xFFFFDAD6)
)

private val AstrBotTypography = Typography(
    displaySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 36.sp,
        lineHeight = 42.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 32.sp,
        lineHeight = 38.sp,
        letterSpacing = (-0.35).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 28.sp,
        lineHeight = 34.sp,
        letterSpacing = (-0.25).sp
    ),
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 23.sp,
        lineHeight = 29.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        letterSpacing = 0.05.sp
    ),
    titleSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 21.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        lineHeight = 18.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        letterSpacing = 0.1.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 17.sp,
        letterSpacing = 0.15.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 16.sp,
        letterSpacing = 0.2.sp
    )
)

@Composable
fun AstrBotTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography = AstrBotTypography,
        shapes = Shapes(
            extraSmall = RoundedCornerShape(8.dp),
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(18.dp),
            large = RoundedCornerShape(24.dp),
            extraLarge = RoundedCornerShape(32.dp)
        ),
        content = content
    )
}
