# WAI Pad v0.3.4

## 本轮重点

### 1. 人物参考画风锁定加强
- 人物参考模式现在也默认启用“固定画风锁定”。
- Style LoRA 权重提高：ref 1.15、person+pose 1.10。
- 人物参考整体 IPAdapter 在锁定模式下降到 0.09，并只在前 22% 采样阶段参与。
- Face IPAdapter 在锁定模式下降到 0.52，并在 48% 后退出。
- 锁定模式改用 `K+mean(V) w/ C penalty`，减少参考图自身渲染/配色泄漏。
- 仍保留关闭画风锁定的兼容模式。

### 2. 固定 APK 签名
- v0.3.4 起 Debug/Release 都使用工程内固定 Beta 更新签名。
- 同一 v0.3.4+ 系列以后可以直接覆盖安装，不再因为 GitHub Runner 每次生成不同 debug.keystore 而提示签名不一致。
- 注意：从旧随机签名版本升级到 v0.3.4 仍需要最后一次卸载重装；之后不再需要。
- 该 Beta key 只适合个人自用测试，不用于公开商店发布。

### 3. 本机保险库，卸载不丢图
- 每张成图现在双写：
  1. WAI Pad App 私有图库
  2. 平板本机 `Pictures/WAI Pad/` 保险库
- 保险库是本机存储，不上传任何云端。
- 卸载 WAI Pad 会清掉 App 私有数据，但 `Pictures/WAI Pad/` 中的保险副本保留。
- 重装后，授权读取本机图片并刷新图库，会自动把保险库图片重新导入 WAI Pad。
- 在 App 中删除图库项默认只删私有副本，不误删保险库。

## 兼容性
- Android 10+：MediaStore 本地保险库。
- Android 8/9：公共 Pictures/WAI Pad 目录，需要旧版存储权限。

## v0.3.4
- 修复参考图模式批量生成卡在“提交 N 个任务 / 等待 GPU”：参考图现在只经 SSH 上传一次，任务队列只传轻量 token；服务器为每个任务创建短期本地副本，不再重复传输巨大 base64。
- 新增 `/v1/images` 临时上传接口；上传 token 创建完全部任务后立即释放，任务临时参考图完成后自动清理，遗留文件有 TTL 清理。
- 固定 APK 开发签名：源码内置专用的 WAI Pad DEV 更新签名。从 v0.3.4 开始，同一源码包构建出的 APK 可以直接覆盖更新，不再每次因 GitHub Runner 临时 debug key 不同而要求卸载。
- 本地图库升级为“本机保险库”：Android 10+ 图片写入设备本地 `Pictures/WAI Pad`，元数据写入 `Documents/WAI Pad/Metadata`，均不上传云端，并在卸载 App 后保留；重装后会自动重新扫描显示。
- Android 8/9 保留旧应用私有存储回退模式，并明确提示卸载会删除。
