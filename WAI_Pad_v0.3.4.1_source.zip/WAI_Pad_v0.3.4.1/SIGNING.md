# WAI Pad 签名说明

v0.3.4 开始不再依赖 GitHub Runner 临时 debug key。

固定开发签名 SHA-256 指纹：
`89:3B:B5:F8:BA:F7:F8:6C:DC:43:A5:93:F1:8D:9A:7D:1E:AE:DC:08:73:66:53:F8:E8:CD:E4:B1:FE:D3:14:B6`

这能保证后续版本可直接覆盖升级。

重要：本签名仅用于当前个人开发阶段。因为 APK 拥有 AutoDL/SSH 控制能力，如果未来公开源码或正式分发，应把签名私钥迁移到 GitHub Actions Secrets/离线正式密钥，不应公开开发私钥。
