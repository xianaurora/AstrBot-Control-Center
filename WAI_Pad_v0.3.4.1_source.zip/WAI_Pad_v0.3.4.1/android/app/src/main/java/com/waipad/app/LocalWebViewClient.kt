package com.waipad.app

import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.FileInputStream

class LocalWebViewClient(private val store: LocalImageStore) : WebViewClient() {
    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
        val u = request?.url ?: return null
        if (u.host == "app.local" && u.path?.startsWith("/local-images/") == true) {
            val name = u.lastPathSegment ?: return null
            val file = store.resolve(name)
                ?: return WebResourceResponse(
                    "text/plain",
                    "utf-8",
                    404,
                    "Not Found",
                    emptyMap(),
                    "missing".byteInputStream()
                )

            val ext = file.extension.lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: when (ext) {
                    "jpg", "jpeg" -> "image/jpeg"
                    "webp" -> "image/webp"
                    else -> "image/png"
                }

            return WebResourceResponse(mime, null, FileInputStream(file))
        }
        return super.shouldInterceptRequest(view, request)
    }
}
