# WAI Pad v0.3.4 验证结果

已完成静态检查：
- Python `py_compile`：通过
- Shell `bash -n`：通过
- 前端 JavaScript `node --check`：通过
- APK 内置 companion 与 server 镜像一致：通过
- 固定签名 keystore 可被 keytool 正常读取：通过

待真机验证：
- v0.3.4 首次安装后再构建 v0.3.4+ 是否可直接覆盖安装
- Android 13+ READ_MEDIA_IMAGES 授权后的卸载恢复流程
- 人物参考模式同一参考图的画风锁定效果
