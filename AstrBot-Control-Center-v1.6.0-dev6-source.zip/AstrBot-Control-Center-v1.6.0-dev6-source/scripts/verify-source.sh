#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ASSETS="$ROOT/app/src/main/assets"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

expected="$(awk 'NR==1{print $1}' "$ASSETS/engine.sha256")"
actual="$(sha256sum "$ASSETS/engine.zip" | awk '{print $1}')"
[[ "$expected" == "$actual" ]] || { echo "engine.zip SHA mismatch" >&2; exit 20; }
unzip -t "$ASSETS/engine.zip" >/dev/null
unzip -q "$ASSETS/engine.zip" -d "$TMP/engine"

# The installer verifies the same file manifest on-device. Catch a stale manifest
# before Gradle spends time compiling the APK.
(
  cd "$TMP/engine"
  sha256sum -c manifest/module-files.sha256 >/dev/null
)

grep -qx 'version=1.6.0-dev4' "$TMP/engine/module.prop" || { echo "unexpected embedded core version" >&2; exit 24; }
grep -qx 'versionCode=16004' "$TMP/engine/module.prop" || { echo "unexpected embedded core versionCode" >&2; exit 25; }
grep -q 'wait_and_raise_qq_window' "$TMP/engine/guest/run-snowluma.sh" || { echo "QQ-window readiness gate missing" >&2; exit 26; }
grep -q 'astrbot_qr.html' "$TMP/engine/guest/run-snowluma.sh" || { echo "custom QR desktop missing" >&2; exit 27; }
grep -q 'QQ_ENGINE' "$TMP/engine/astrctl" || { echo "active QQ engine status missing" >&2; exit 28; }

count=0
while IFS= read -r file; do
  case "$file" in
    *.sh|*/astrctl|*/service.sh|*/post-fs-data.sh|*/action.sh)
      if head -n 1 "$file" | grep -q 'bash'; then bash -n "$file"; else sh -n "$file"; fi
      count=$((count+1))
      ;;
  esac
done < <(find "$TMP/engine" -type f -print | sort)

python3 - "$ROOT" <<'PY'
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
root = Path(sys.argv[1])
for f in root.rglob('*.xml'):
    ET.parse(f)
PY

CONTROL="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/ui/ControlCenterApp.kt"
MODELS="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/model/ControlCenterModels.kt"
PARSER="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/ControlStatusParser.kt"

# The dev4 build failure came from an implicit ColumnScope.AnimatedVisibility call
# inside a Box. The rewritten control center deliberately avoids that overload.
if grep -q 'AnimatedVisibility' "$CONTROL"; then
  echo "ControlCenterApp.kt unexpectedly reintroduced AnimatedVisibility; review DSL receiver scope" >&2
  exit 21
fi

# A SelectionContainer around a lazy log list has caused real-world Compose crashes.
# Logs use a stable LazyColumn plus an explicit Copy action instead.
if grep -Eq 'SelectionContainer[[:space:]]*[{(]' "$CONTROL"; then
  echo "ControlCenterApp.kt must not wrap live logs in SelectionContainer" >&2
  exit 29
fi

# Old four-destination identifiers must not leak into the new three-destination shell.
if grep -R -E 'ControlDestination\.(SERVICES|LOGS|MORE|MAINTENANCE)' "$ROOT/app/src/main/java"; then
  echo "legacy control-center destination found" >&2
  exit 22
fi

grep -q 'OPERATIONS("运维"' "$MODELS" || { echo "operations destination missing" >&2; exit 30; }
grep -q 'CONSOLE("控制台"' "$MODELS" || { echo "console destination missing" >&2; exit 31; }
grep -q 'qqEngine == "snowluma"' "$PARSER" || { echo "active-engine parser fallback missing" >&2; exit 32; }

# Guard against accidentally shipping the old app target after changing the embedded core.
grep -q 'versionName = "1.6.0-dev6"' "$ROOT/app/build.gradle.kts" || { echo "app version mismatch" >&2; exit 33; }
grep -q 'TARGET_ENGINE_VERSION = "1.6.0-dev4"' "$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/engine/EngineRepository.kt" || { echo "core target mismatch" >&2; exit 34; }

# dev6 QR/rendering contract: keep software rendering available and allow one-shot
# compatibility recovery when the embedded canvas is detected as uniformly black.
if grep -q -- '--disable-software-rasterizer' "$TMP/engine/guest/run-snowluma.sh"; then
  echo "SnowLuma runtime must not disable the software rasterizer" >&2
  exit 35
fi
grep -q '1024x640x24' "$TMP/engine/guest/run-snowluma.sh" || { echo "SnowLuma Xvfb must use 24-bit color" >&2; exit 36; }
grep -q 'snowluma-login-compat' "$TMP/engine/astrctl" || { echo "SnowLuma compatibility login recovery missing" >&2; exit 37; }
sh "$TMP/engine/tests/test-control-center-v1604-qr-rendering.sh" "$TMP/engine" >/dev/null

WEBVIEW="$ROOT/app/src/main/java/com/xianaurora/astrbotcontrol/ui/EmbeddedConsoleWebView.kt"
# QR login is contextual under QQ, not a third console destination chip.
if grep -q 'ConsoleTargetChoice("扫码登录"' "$CONTROL"; then
  echo "duplicate scan-login console chip reintroduced" >&2
  exit 38
fi
# File export has a single home in diagnostics, not a duplicate live-log toolbar action.
if grep -q 'Text("导出")' "$CONTROL"; then
  echo "duplicate bare log export action reintroduced" >&2
  exit 39
fi
grep -q 'QR_FRAME_PROBE_JS' "$WEBVIEW" || { echo "QR black-frame probe missing" >&2; exit 40; }
grep -q 'onQrBlankDetected = vm::recoverBlankQqLogin' "$CONTROL" || { echo "QR compatibility recovery is not wired" >&2; exit 41; }
grep -q 'KineticCharacters' "$CONTROL" || { echo "dev6 kinetic microinteraction layer missing" >&2; exit 42; }

echo "SOURCE_GATE_OK engine_sha=$actual shell_files=$count"
