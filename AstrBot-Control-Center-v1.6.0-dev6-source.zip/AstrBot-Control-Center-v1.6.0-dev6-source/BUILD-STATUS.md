# Build status — v1.6.0-dev6

## 当前版本

- Android App: `1.6.0-dev6` / `160400`
- 内置核心组件: `1.6.0-dev4` / `16004`

## 本版重点

- 控制台一级目标收敛为 AstrBot / QQ；扫码作为 QQ 上下文动作，不再重复占位。
- 日志文件导出统一到运维页“日志与诊断”，实时日志工具栏只负责观察、复制、跟随与脱敏。
- SnowLuma 扫码加入真实 framebuffer 验证和一次性兼容渲染恢复；黑屏不再直接暴露给用户。
- 核心组件使用 24-bit Xvfb，并保留 Electron 软件渲染能力。
- 新增短状态字符错峰、状态文字替换、图标形变等微交互；日志正文保持稳定。
- dev5 的三入口架构、当前情况/下一步、SnowLuma/NapCat 状态分流、日志闪退加固继续保留。

## 构建门禁

GitHub Actions 在上传 APK 前依次执行：

1. `scripts/verify-source.sh`
2. `:app:testDebugUnitTest`
3. `:app:assembleDebug`

当前容器没有完整 Android SDK / Compose classpath，因此本地不把解析级检查冒充完整 APK 编译；最终产物仍以 Actions 实际通过为准。
