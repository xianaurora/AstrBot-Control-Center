# Build status — v1.6.0-dev20

- Android App: `1.6.0-dev20` / `161800`
- Embedded core: `1.6.0-dev11` / `16011`（未修改）
- Core SHA-256: `3a70879783559d6988c7f1bb82f4ede30b9b8ec617ca2da38392433c0fd97f8f`
- Signing: 沿用 dev17 固定开发更新证书
- Launcher label: `AstrBot CC`

## dev20 真机回归修复

- SnowLuma QQ 登录窗口可直接触摸，按钮/账号选择/扫码切换都映射回真实 QQ 窗口。
- 修正 DISPLAY 发现逻辑，不再读取不存在的 Android 配置路径。
- “完整桌面”从 noVNC 黑画布改为原生 X11 截图 + 触摸映射。
- AstrBot 独立 Activity 顶栏首帧即避让状态栏，真实 WindowInsets 到达后再精确修正；底部诊断卡避让导航栏。
- 工具页移除重复“当前情况 / QQ 等待登录”卡，只在总览保留。

源码门禁可通过 `scripts/verify-source.sh` 执行。完整 Android/Compose 编译仍以 GitHub Actions 为最终验证。
