# 构建 AstrBot CC v1.6.0-dev20

## GitHub Actions

仓库自带 `.github/workflows/build-apk.yml`。手动运行 **Build dev20 APK** 后会：

1. 检查源码门禁和内嵌 core SHA。
2. 准备 JDK / Android SDK / Gradle 环境。
3. 编译 Kotlin / Compose 源码。
4. 构建 Debug APK。
5. 使用项目固定开发更新证书签名。
6. 用 `apksigner` 核验证书 SHA-256。
7. 上传 `AstrBot-Control-Center-v1.6.0-dev20-stable-signed` artifact。

## 固定签名

固定开发证书 SHA-256：

`3D:EC:D0:53:61:E0:D6:A2:6A:92:66:88:20:4A:71:F9:3A:C3:AC:E2:3A:75:9D:0D:5C:58:D4:85:32:77:BB:2B`

从 dev17 开始，Debug/Release 构建都明确使用这一开发更新密钥，避免 GitHub runner 临时 debug keystore 导致每次构建无法覆盖升级。

## dev20 首测顺序

优先检查：QQ 登录窗口能否完整显示并直接点击底部“登录”；AstrBot 顶栏是否完全位于系统状态栏下方；工具页是否已没有重复的“当前情况”卡。
