# v1.6.0-dev20 静态验证报告

当前生成环境已验证：

- `engine.zip` SHA-256 与 `engine.sha256` 一致；内嵌 core 仍为 `1.6.0-dev11 / 16011`；
- core Shell 文件语法和既有源码门禁继续通过；
- App / catalog / GitHub Actions 版本均为 dev20；
- dev17 固定开发 keystore 可读取，证书指纹未改变；
- SnowLuma QQ 登录不再裁成静态方形二维码，而是展示完整 QQ 登录窗口；
- 登录画面带 `pointerInput` / `detectTapGestures`，触摸按实际 `ContentScale.Fit` 绘制区域映射到 QQ 窗口坐标；
- Android 端通过现有 `astrctl shell` 调用 `xdotool` 发送用户单次点击，不修改 engine.zip；
- 该 guest shell 片段已用 `bash -n` 通过语法检查；
- `openQqDesktop` 现在进入原生 X11 桌面捕获/触摸分支，ViewModel 不再调用 noVNC desktop session；
- 工具页 `SituationCard` 已清除，总览只保留一份；
- AstrBot classic Activity 显式根据 system bar insets 移动 toolbar、WebView、进度条和底部诊断卡；
- `ControlCenterModels.kt + ControlStatusParser.kt` 已用本机 `kotlinc` 实际编译通过。

最终门禁应输出包含：

```text
SOURCE_GATE_OK ... interactive_login_frame=1 tools_dedup=1 statusbar_insets=1 astrbot_classic_webview=1 ... stable_signing=1
```

## 当前环境限制

当前容器没有完整 Android SDK/Gradle Android 编译链，因此不声称本地 `assembleDebug` 已成功。完整 Compose/Kotlin Android 编译、resource linking、APK 打包和 `apksigner` 校验仍由附带的 GitHub Actions 完成。
