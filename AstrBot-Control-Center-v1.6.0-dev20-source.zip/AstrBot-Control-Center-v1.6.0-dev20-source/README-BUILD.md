# AstrBot CC v1.6.0-dev20

这是 AstrBot Control Center 的 dev20 源码。Android App 版本为 `1.6.0-dev20 / 161800`；内嵌 core 继续固定为 `1.6.0-dev11 / 16011`，本轮不修改 engine.zip。

## dev20 重点

- SnowLuma QQ 登录改为“完整 QQ 登录窗口 + 直接触摸”，不再只展示不可点击的静态二维码裁剪。
- “完整桌面”保留，但改走原生 X11 截图 + 触摸映射，不再使用黑屏的 noVNC WebView。
- AstrBot 独立管理页的顶部返回栏显式避让系统状态栏；系统返回仍直接回 AstrBot CC。
- 工具页删除重复的“当前情况 / QQ 等待登录”卡，总览页保留唯一一份。
- dev18 的工作台三分区、设置“先修改后保存/取消”、QQ 登录入口去重继续保留。
- 桌面名称仍为 `AstrBot CC`，图标继续使用安全区版本。

## 构建

推荐直接运行仓库内 GitHub Actions：**Build dev20 APK**。CI 会先运行 `scripts/verify-source.sh`，再执行完整 Android/Kotlin 编译，构建 Debug APK，并核对固定开发证书指纹。

固定开发证书 SHA-256：

`3D:EC:D0:53:61:E0:D6:A2:6A:92:66:88:20:4A:71:F9:3A:C3:AC:E2:3A:75:9D:0D:5C:58:D4:85:32:77:BB:2B`

如果设备已经安装 dev17/dev18 的固定证书版本，dev20 可直接覆盖安装；更早的随机 debug 签名版本需要先卸载旧 App 才能切换到固定证书链。
