# WAI Pad v0.3 validation

The following checks are run in this packaging environment:

- Python syntax: `server/job_api.py`, `server/engine_v34.py`
- Shell syntax: `server/bootstrap.sh`, `server/guard.sh`
- Frontend JavaScript syntax: `app.js`
- Frontend-to-Native bridge method name consistency
- Companion server asset hashes match the top-level `server/` copies
- Required Android source/resource files exist

Android bytecode/APK compilation is **not** claimed here because this environment does not contain the Android SDK/Gradle dependency cache and has no direct Maven network access.
