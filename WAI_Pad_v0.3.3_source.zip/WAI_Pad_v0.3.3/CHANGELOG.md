# Changelog

## v0.3.0
- 新增完整诊断中心：服务、GPU、端口、相关进程、模型依赖、磁盘一次检查。
- 自动修复分为“安全修复 / 深度修复”；修复前自动建立恢复点，支持回到最近恢复点。
- 修复保护：生图任务正在执行时，不允许全量重启核心服务；Panel 单独异常也不会误杀正常 ComfyUI 任务。
- 修复 companion 热更新 bug：检测到正在生图时，自动延后服务端代码更新，避免重启 job API 导致任务中断。
- 新增任务状态持久化。companion 意外重启后，可重新接管已有 `prompt_id` 的 ComfyUI 任务；文生图排队任务可恢复。
- 参考图隐私加强：`image/person/pose` 原始 base64 永不写入任务状态文件；上传进 ComfyUI 后立即从任务内存释放。
- 修复本地存图可靠性：图片和元数据采用临时文件 + fsync + 原子重命名，写入成功后才 ACK 删除 AutoDL 临时结果。
- 新增本地图 job_id 去重：如果“本机已保存但 ACK 时网络断开”，重连恢复不会重复保存同一张图片。
- 本地图片元数据明确标记 `app_private` 和 `cloud_sync=false`。
- companion 更新清单补齐 `maintenance.py`，避免部署后 import 缺失。
- 修复安全修复忙碌判断：只有真实 ComfyUI `prompt_id` 运行时才阻止重启，准备阶段仍可自动修复离线服务。

## v0.2.0
- 新增独立 `job_api.py`，端口 6027，不覆盖旧 6017。
- 生图改成 job 队列，加入 ComfyUI WebSocket 实时采样进度。
- 新增任务列表、取消、失败建议、任务清理。
- Seed / Steps / CFG 可控；批量任务支持。
- 结果改为原生 Android 直接下载保存，base64 成图不再穿过前端 JS。
- 本机保存成功后发送 `ack-local`，服务端自动删除对应 AutoDL 输出。
- 参考图任务结束自动删除远端临时输入。
- 增加 6 小时远端结果兜底清理。
- 本地图库增加 sidecar 元数据与收藏。
- 新增服务状态、GPU、显存、模型依赖和日志页。
- SSH 终端升级为持久 shell。
- 自动发现常见 Jupyter 本机端口。
- SSH 密码继续使用 Android KeyStore，并增加 TOFU SHA-256 主机指纹固定。
- 前台 SSH 服务负责自动 bootstrap 和自动恢复，不再要求用户手动输入启动命令。


## v0.3.2 真机输入/错误恢复修复
- 修复 Android WebView 中“提示词全选 -> 删除后无法继续输入”的 IME/组合输入异常：拦截全选删除并恢复有效光标。
- Prompt 与负面词增加“清空”按钮，作为触屏稳定入口。
- 修复 `[object ProgressEvent]`：FileReader/Image 错误现在转换为可读中文原因。
- 图片尺寸解码失败时不再丢弃已读到的 Data URL；人物+动作尺寸回退由服务端安全默认处理。
- 区分“生成失败”和“生成成功但本机保存失败”；后者保留 AutoDL 临时成图并由任务恢复器自动续存。
- 本机保存失败时不要求重新跑 GPU 生成。


## v0.3.3 人物+动作画风锁定
- 修复动作参考图通过 Composition IPAdapter 污染固定画风。
- 默认启用固定画风锁定：B 只控制 OpenPose + Depth。
- 降低 A 整体视觉参考对画风的侵入，提高固定 Style LoRA 优先级。
- 增加可关闭的画风锁定开关，保留特殊构图兼容性。
