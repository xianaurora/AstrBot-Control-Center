plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.waipad.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.waipad.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "0.3.4.2"
    }

    // Personal/private build key bundled only to keep GitHub Actions builds update-compatible.
    // Replace this before any public distribution.
    signingConfigs {
        create("waipadStable") {
            storeFile = file("waipad-dev.jks")
            storePassword = "waipad-local-2026"
            keyAlias = "waipad"
            keyPassword = "waipad-local-2026"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("waipadStable")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("waipadStable")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.github.mwiede:jsch:0.2.21")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
