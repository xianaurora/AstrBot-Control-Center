(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const qsa = s => Array.from(document.querySelectorAll(s));
  const pending = new Map(), bootPending = new Map(), savePending = new Map();
  let mode = 'txt', bootstrapped = false, jobsAvailable = false, currentJobIds = [], localTasks = new Map(), lastBootstrapAttempt = 0;

  window.WAI_NATIVE = {
    onApi(id, ok, payload) {
      const p = pending.get(id); if (!p) return; pending.delete(id);
      let data = payload; try { data = JSON.parse(payload); } catch (_) {}
      ok ? p.resolve(data) : p.reject(data);
    },
    onBootstrap(id, ok, output) {
      const p = bootPending.get(id); if (!p) return; bootPending.delete(id);
      ok ? p.resolve(output) : p.reject(output);
    },
    onImageSaved(id, ok, payload) {
      const p = savePending.get(id); if (!p) return; savePending.delete(id);
      let data = payload; try { data = JSON.parse(payload); } catch (_) {}
      ok ? p.resolve(data) : p.reject(data);
    }
  };

  function errText(e) {
    if (!e) return '未知错误';
    if (typeof e === 'string') return e;
    if (e.error || e.message || e.summary || e.suggestion) return e.error || e.message || e.summary || e.suggestion;
    // Android WebView/FileReader/Image errors are often Event/ProgressEvent objects.
    // String(event) becomes useless "[object ProgressEvent]", so translate them here.
    if (typeof Event !== 'undefined' && e instanceof Event) {
      const t = e.type || 'error';
      if (t === 'error') return '本地图片读取/解码失败，请重新选择图片后重试';
      if (t === 'abort') return '本地图片读取被中断';
      return `本地文件处理异常（${t}）`;
    }
    const text = String(e);
    return /^\[object (Progress)?Event\]$/.test(text) ? '本地图片读取/解码失败，请重新选择图片后重试' : text;
  }
  function esc(v){ return String(v ?? '').replace(/[&<>'"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
  function log(s) {
    const el = $('log'); if (!el) return;
    el.textContent += `[${new Date().toLocaleTimeString()}] ${s}\n`;
    el.scrollTop = el.scrollHeight;
  }
  function api(method, path, body = {}) {
    return new Promise((resolve, reject) => {
      const id = 'r' + Math.random().toString(36).slice(2);
      pending.set(id, {resolve, reject});
      Native.apiRequest(id, method, path, JSON.stringify(body));
      setTimeout(() => { if (pending.has(id)) { pending.delete(id); reject({error:'请求超时'}); } }, path.includes('/jobs/') ? 200000 : 190000);
    });
  }
  function bootstrap() {
    return new Promise((resolve, reject) => {
      const id = 'b' + Math.random().toString(36).slice(2);
      bootPending.set(id, {resolve, reject}); Native.bootstrapServer(id);
      setTimeout(() => { if (bootPending.has(id)) { bootPending.delete(id); reject('服务器初始化超时'); } }, 260000);
    });
  }
  function restartFromDisk() {
    return new Promise((resolve, reject) => {
      const id = 'rb' + Math.random().toString(36).slice(2);
      bootPending.set(id, {resolve, reject}); Native.restartServerFromDisk(id);
      setTimeout(() => { if (bootPending.has(id)) { bootPending.delete(id); reject('恢复后重启超时'); } }, 260000);
    });
  }
  function saveJob(jobId, metadata) {
    return new Promise((resolve, reject) => {
      const id = 's' + Math.random().toString(36).slice(2);
      savePending.set(id, {resolve, reject}); Native.downloadJobImage(id, jobId, JSON.stringify(metadata || {}));
      setTimeout(() => { if (savePending.has(id)) { savePending.delete(id); reject({error:'保存到本机超时'}); } }, 200000);
    });
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function fmtBytes(n) { n = Number(n || 0); if (n < 1024*1024) return `${(n/1024).toFixed(1)} KB`; if (n < 1024*1024*1024) return `${(n/1024/1024).toFixed(1)} MB`; return `${(n/1024/1024/1024).toFixed(2)} GB`; }

  const titles = {create:'创作',tasks:'任务',gallery:'图库',console:'控制台',tools:'工具',embed:'内嵌',settings:'设置'};
  qsa('.nav button').forEach(b => b.addEventListener('click', () => {
    qsa('.nav button').forEach(x => x.classList.remove('active')); b.classList.add('active');
    qsa('.page').forEach(x => x.classList.remove('on')); $(b.dataset.page).classList.add('on');
    $('pageTitle').textContent = titles[b.dataset.page] || 'WAI Pad';
    if (b.dataset.page === 'gallery') refreshGallery();
    if (b.dataset.page === 'console') { refreshStatus(); refreshLogs(); refreshRepairHistory(); }
    if (b.dataset.page === 'tasks') refreshTasks();
  }));

  function fileControls() {
    const box = $('fileArea'); box.innerHTML = '';
    const mk = (id, label) => { const w=document.createElement('div'); w.innerHTML=`<div class="label">${label}</div><input id="${id}" type="file" accept="image/*">`; box.appendChild(w); };
    if (mode === 'img') mk('imageA','原图');
    if (mode === 'ref') mk('imageA','人物参考图 A');
    if (mode === 'pp') { mk('imageA','人物参考图 A'); mk('imageB','动作参考图 B'); }
    $('imgAdvanced').classList.toggle('hidden', mode !== 'img');
    $('strictWrap').classList.toggle('hidden', mode !== 'pp');
    $('posePreview').classList.toggle('hidden', mode !== 'pp');
    $('steps').value = mode === 'pp' ? ($('strict').checked ? '40':'34') : (mode === 'ref' ? '34':'28');
    $('cfg').value = mode === 'pp' ? '4.35' : (mode === 'ref' ? '4.6':'4.8');
  }
  fileControls();
  qsa('#modeTabs button').forEach(b => b.addEventListener('click', () => { qsa('#modeTabs button').forEach(x=>x.classList.remove('on')); b.classList.add('on'); mode=b.dataset.mode; fileControls(); }));
  $('strict').addEventListener('change',()=>{ if(mode==='pp') $('steps').value=$('strict').checked?'40':'34'; });
  $('denoise').addEventListener('input',()=> $('denoiseVal').textContent=Number($('denoise').value).toFixed(2));


  // Android WebView + some Chinese IMEs can leave a textarea in a broken composing state
  // after Select all -> Delete. Intercept a full-selection delete and perform the clear
  // ourselves, then keep the caret in a valid editable position.
  function installAndroidEditableRecovery(el) {
    if (!el) return;
    let composing = false;
    el.addEventListener('compositionstart', () => { composing = true; });
    el.addEventListener('compositionend', () => {
      composing = false;
      if (!el.disabled && !el.readOnly) {
        const n = el.value.length;
        try { el.setSelectionRange(n, n); } catch (_) {}
      }
    });
    el.addEventListener('beforeinput', ev => {
      const isDelete = String(ev.inputType || '').startsWith('delete');
      const allSelected = el.value.length > 0 && el.selectionStart === 0 && el.selectionEnd === el.value.length;
      if (isDelete && allSelected) {
        ev.preventDefault();
        composing = false;
        el.value = '';
        try { el.setSelectionRange(0, 0); } catch (_) {}
        el.dispatchEvent(new Event('input', {bubbles:true}));
        requestAnimationFrame(() => { if (document.activeElement !== el) el.focus(); try { el.setSelectionRange(0,0); } catch (_) {} });
      }
    });
    el.addEventListener('input', ev => {
      // Safety net for WebViews where beforeinput is not delivered by the IME.
      if (el.value === '' && !composing && String(ev.inputType || '').startsWith('delete')) {
        el.disabled = false; el.readOnly = false;
        requestAnimationFrame(() => { try { el.setSelectionRange(0,0); } catch (_) {} });
      }
    });
    el.addEventListener('focus', () => { el.disabled = false; el.readOnly = false; });
  }
  installAndroidEditableRecovery($('prompt'));
  installAndroidEditableRecovery($('negative'));

  function clearEditable(id) { const el=$(id); if(!el)return; el.value=''; el.disabled=false; el.readOnly=false; el.focus(); try{el.setSelectionRange(0,0)}catch(_){} el.dispatchEvent(new Event('input',{bubbles:true})); }
  $('clearPrompt').addEventListener('click',()=>clearEditable('prompt'));
  $('clearNegative').addEventListener('click',()=>clearEditable('negative'));

  function readFile(id) {
    return new Promise((resolve, reject) => {
      const el=$(id); if(!el || !el.files || !el.files[0]) return resolve(null);
      const f=el.files[0], r=new FileReader();
      r.onload=()=>{
        const data = r.result;
        if (!data || typeof data !== 'string') return reject({error:`读取图片 ${f.name || ''} 失败：没有取得文件内容`});
        const img=new Image();
        img.onload=()=>resolve({data,w:img.naturalWidth||0,h:img.naturalHeight||0,name:f.name||''});
        // The server has a safe default aspect ratio if WebView cannot decode dimensions.
        // Do not throw a raw ProgressEvent and do not discard an otherwise valid Data URL.
        img.onerror=()=>resolve({data,w:0,h:0,name:f.name||'',dimensionWarning:true});
        img.src=data;
      };
      r.onerror=()=>reject({error:`读取图片 ${f.name || ''} 失败，请重新选择文件`});
      r.onabort=()=>reject({error:`读取图片 ${f.name || ''} 被中断，请重新选择文件`});
      try { r.readAsDataURL(f); } catch (e) { reject({error:`无法读取图片 ${f.name || ''}：${errText(e)}`}); }
    });
  }

  async function buildRequest() {
    if (!$('prompt').value.trim()) throw {error:'请先输入提示词'};
    const [w,h]=$('size').value.split('x').map(Number);
    const d={mode,prompt_mode:$('promptMode').value,prompt:$('prompt').value.trim(),negative:$('negative').value.trim(),width:w,height:h,seed:Number($('seed').value||-1),steps:Number($('steps').value||28),cfg:Number($('cfg').value||4.8)};
    if (mode==='img') { const a=await readFile('imageA'); if(!a)throw{error:'请选择原图'}; d.image=a.data; d.denoise=Number($('denoise').value); }
    if (mode==='ref') { const a=await readFile('imageA'); if(!a)throw{error:'请选择人物参考图'}; d.image=a.data; }
    if (mode==='pp') { const a=await readFile('imageA'),b=await readFile('imageB'); if(!a||!b)throw{error:'人物图 A 和动作图 B 都要选择'}; d.person=a.data; d.pose=b.data; d.pose_width=b.w; d.pose_height=b.h; d.strict=$('strict').checked; }
    return d;
  }

  async function optimizePrompt() {
    if(!$('prompt').value.trim()) return $('genMsg').textContent='请先输入提示词';
    $('genMsg').textContent='正在整理提示词…';
    const body={mode,prompt:$('prompt').value,negative:$('negative').value,prompt_mode:$('promptMode').value};
    try {
      let j; try { j=await api('POST','/v1/prompts/optimize',body); } catch(_) { j=await api('POST','/api/optimize',{...body,mode:mode==='pp'?'person_pose':mode}); }
      $('prompt').value=j.positive||$('prompt').value; $('negative').value=j.negative||$('negative').value; $('genMsg').textContent=j.note||'整理完成';
    } catch(e) { $('genMsg').textContent='整理失败：'+errText(e); }
  }
  $('optimize').addEventListener('click', optimizePrompt);

  function setMainProgress(job) {
    const p=Math.max(0,Math.min(100,Number(job.progress||0))); $('bar').style.width=p+'%';
    const stage=job.detail||job.stage||job.status||''; $('taskStage').textContent=stage; $('genMsg').textContent=`${stage}${p?` · ${p}%`:''}`;
  }

  async function pollJob(jobId) {
    let last={id:jobId,status:'queued',progress:0,detail:'等待 GPU'};
    for (;;) {
      try { last=await api('GET',`/v1/jobs/${jobId}`); localTasks.set(jobId,last); renderTasks(); setMainProgress(last); }
      catch(e) { await sleep(1200); continue; }
      if (last.status==='completed') {
        const meta={job_id:jobId,mode:(last.request||{}).mode||mode,prompt:(last.request||{}).prompt||'',negative:last.negative||'',positive:last.positive||'',seed:last.seed,steps:last.steps,cfg:last.cfg,time:Date.now(),favorite:false};
        $('genMsg').textContent='图片已生成，正在保存到 WAI Pad 本机图库…';
        let saved;
        try {
          saved=await saveJob(jobId,meta);
        } catch (e) {
          // Generation succeeded. Keep the remote temporary output for recovery instead of
          // reporting the whole generation as failed. refreshTasks/recoverCompleted will retry.
          throw {error:`图片已经生成，但保存到本机失败：${errText(e)}`, generated:true, job_id:jobId, suggestion:'远端临时成图会保留，连接恢复后 WAI Pad 会自动续存，不需要重新生成。'};
        }
        $('result').src=saved.url; $('result').style.display='block'; $('placeholder').style.display='none'; $('genMsg').textContent='已保存到本机，AutoDL 临时成图已请求自动清理'; log(`任务 ${jobId} 已本地保存：${saved.name}`); refreshGallery(); return saved;
      }
      if (last.status==='failed') throw {error:last.error||'生成失败',suggestion:last.suggestion||''};
      if (last.status==='cancelled') throw {error:'任务已取消'};
      await sleep(900);
    }
  }

  async function asyncGenerate(d, count) {
    const ids=[];
    for(let i=0;i<count;i++) { const one={...d}; if(Number.isFinite(d.seed)&&d.seed>=0) one.seed=d.seed+i; const j=await api('POST','/v1/jobs',one); ids.push(j.id); localTasks.set(j.id,{id:j.id,status:'queued',progress:0,detail:`第 ${i+1}/${count} 张等待 GPU`,request:{mode:d.mode,prompt:d.prompt}}); }
    currentJobIds=ids; renderTasks();
    let completed=0;
    const settled=await Promise.allSettled(ids.map(async id=>{ const s=await pollJob(id); completed++; $('genMsg').textContent=`已完成 ${completed}/${count}，图片只保存在 WAI Pad 本机`; return s; }));
    const failures=settled.filter(x=>x.status==='rejected');
    if(failures.length) throw failures[0].reason;
  }

  async function legacyGenerate(d, count) {
    log('异步 companion 暂未就绪，使用旧 WAI 兼容模式。');
    for(let i=0;i<count;i++) {
      $('genMsg').textContent=`兼容模式生成 ${i+1}/${count}…`;
      const j=await api('POST','/api/generate',d);
      if(!j.image) throw {error:'旧后端没有返回图片'};
      const meta={mode:d.mode,prompt:d.prompt,negative:j.negative||d.negative,positive:j.positive||'',seed:d.seed,steps:d.steps,cfg:d.cfg,time:Date.now(),legacy:true};
      const saved=JSON.parse(Native.saveImage(j.image,'wai',JSON.stringify(meta))); $('result').src=saved.url; $('result').style.display='block'; $('placeholder').style.display='none'; refreshGallery();
    }
  }

  $('generate').addEventListener('click', async () => {
    $('generate').disabled=true; $('bar').style.width='3%'; $('taskStage').textContent='准备任务';
    try { const d=await buildRequest(), count=Math.max(1,Math.min(4,Number($('count').value||1))); if(!jobsAvailable){$('genMsg').textContent='正在等待 WAI Pad 自动启动/修复服务…';await waitForJobs(25000);} if(!jobsAvailable){$('genMsg').textContent='自动服务仍未就绪，执行一次重新初始化…';await doBootstrap();await waitForJobs(10000);} if(!jobsAvailable)throw{error:'WAI Pad 隐私任务服务未就绪。为保证参考图/成图不会长期留在 AutoDL，主界面不会降级到旧同步生图。'}; $('genMsg').textContent=`提交 ${count} 个任务…`; await asyncGenerate(d,count); $('bar').style.width='100%'; setTimeout(()=>$('bar').style.width='0',1600); }
    catch(e) {
      $('bar').style.width='0';
      const extra=e&&e.suggestion?`；${e.suggestion}`:'';
      const prefix=e&&e.generated?'本地保存待恢复：':'生成失败：';
      $('genMsg').textContent=prefix+errText(e)+extra;
      log(prefix+errText(e)+extra);
      if(e&&e.generated) { $('taskStage').textContent='成图已完成 · 等待本机续存'; setTimeout(refreshTasks,800); }
    }
    finally { $('generate').disabled=false; currentJobIds=[]; }
  });

  $('cancel').addEventListener('click', async()=>{
    try {
      if(jobsAvailable && currentJobIds.length) { await Promise.allSettled(currentJobIds.map(id=>api('DELETE',`/v1/jobs/${id}`,{}))); $('genMsg').textContent='已发送取消请求'; }
      else { const j=await api('POST','/api/cancel',{}); $('genMsg').textContent=j.message||'已取消'; }
    } catch(e){ $('genMsg').textContent='取消失败：'+errText(e); }
  });

  $('posePreview').addEventListener('click', async()=>{
    if(mode!=='pp')return; const b=await readFile('imageB'); if(!b)return $('genMsg').textContent='请先选择动作参考图 B';
    $('genMsg').textContent='正在检查动作骨架和 Depth…'; $('posePreview').disabled=true;
    try { const j=await api('POST',jobsAvailable?'/v1/pose/preview':'/api/preview_pose',{pose:b.data}); const box=$('posePreviewBox'); box.innerHTML=''; (j.items||[]).forEach(it=>{const f=document.createElement('figure');f.innerHTML=`<figcaption>${it.label}</figcaption><img src="${it.image}" alt="${it.label}">`;box.appendChild(f)}); $('genMsg').textContent=j.note||'动作预览完成'; }
    catch(e){$('genMsg').textContent='动作预览失败：'+errText(e);} finally {$('posePreview').disabled=false;}
  });

  function taskBadge(status){ const map={queued:'排队',running:'运行',repairing:'自动修复',completed:'完成',failed:'失败',cancelled:'取消'}; return map[status]||status||'未知'; }
  function renderTasks(items) {
    if(items) { localTasks.clear(); items.forEach(j=>localTasks.set(j.id,j)); }
    const box=$('taskList'), arr=Array.from(localTasks.values()).sort((a,b)=>(b.created_at||0)-(a.created_at||0)); box.innerHTML='';
    if(!arr.length){box.innerHTML='<div class="muted">还没有任务。</div>';return;}
    arr.forEach(j=>{const row=document.createElement('div');row.className='task-row'; const req=j.request||{}; row.innerHTML=`<div><b>${esc(j.id||'')}</b><div class="muted">${esc(req.mode||'')} ${esc(new Date((j.created_at||Date.now()/1000)*1000).toLocaleTimeString())}</div></div><div>${esc(taskBadge(j.status))}</div><div><div>${esc(j.detail||j.error||'')}</div><div class="mini-progress"><i style="width:${Math.max(0,Math.min(100,Number(j.progress)||0))}%"></i></div>${j.suggestion?`<div class="warn">${esc(j.suggestion)}</div>`:''}</div><div>${['queued','running','repairing'].includes(j.status)?`<button class="secondary danger" data-cancel-job="${esc(j.id)}">取消</button>`:''}</div>`; box.appendChild(row);});
    qsa('[data-cancel-job]').forEach(b=>b.addEventListener('click',async()=>{try{await api('DELETE',`/v1/jobs/${b.dataset.cancelJob}`,{});setTimeout(refreshTasks,500)}catch(e){log(errText(e))}}));
  }
  const savingJobs=new Set();
  async function recoverCompleted(items){
    for(const job of items||[]){
      if(job.status!=='completed'||job.acked_local||savingJobs.has(job.id)) continue;
      savingJobs.add(job.id);
      try{
        // If the image was already written locally but the ACK failed because the tunnel dropped,
        // only retry the remote cleanup ACK. Never download/save the same result twice.
        if (Native.hasLocalJob && Native.hasLocalJob(job.id)) {
          await api('POST',`/v1/jobs/${job.id}/ack-local`,{});
          log(`任务 ${job.id} 已在本机，补发远端清理确认，避免重复存图`);
          continue;
        }
        const req=job.request||{};
        const meta={job_id:job.id,mode:req.mode||'txt',prompt:req.prompt||'',negative:job.negative||req.negative||'',positive:job.positive||'',seed:job.seed,steps:job.steps,cfg:job.cfg,time:Date.now(),recovered:true};
        const saved=await saveJob(job.id,meta); log(`恢复未保存任务 ${job.id} → ${saved.name}`); refreshGallery();
      }catch(e){ log(`恢复任务 ${job.id} 失败：${errText(e)}`); } finally { savingJobs.delete(job.id); }
    }
  }
  async function refreshTasks(){ if(!jobsAvailable)return renderTasks(); try{const j=await api('GET','/v1/jobs?limit=60');const items=j.items||[];renderTasks(items);recoverCompleted(items);}catch(e){log('任务列表读取失败：'+errText(e));} }
  $('refreshTasks').addEventListener('click',refreshTasks);
  $('cleanTasks').addEventListener('click',async()=>{try{await api('POST','/v1/jobs/cleanup',{});refreshTasks()}catch(e){log(errText(e))}});

  function refreshGallery(){
    let list=[]; try{list=JSON.parse(Native.listImages()||'[]')}catch(_){} const g=$('galleryGrid');g.innerHTML='';
    let st={}; try{st=JSON.parse(Native.localStats()||'{}')}catch(_){} $('galleryStats').textContent=`${st.count||0} 张 · ${fmtBytes(st.used_bytes||st.bytes||0)}`;
    if(!list.length){g.innerHTML='<div class="muted">还没有本地图片。生成完成后会自动出现在这里。</div>';return;}
    list.forEach(it=>{const d=document.createElement('div');d.className='thumb';d.innerHTML=`<img src="${it.url}" alt="${it.name}" data-view="${it.name}"><div class="thumb-actions"><button data-fav="${it.name}">${it.favorite?'★':'☆'}</button><button data-del="${it.name}">删除</button></div>`;g.appendChild(d)});
    qsa('[data-del]').forEach(b=>b.addEventListener('click',()=>{if(confirm('只删除 WAI Pad 本机这张图片？')){Native.deleteImage(b.dataset.del);refreshGallery();}}));
    qsa('[data-fav]').forEach(b=>b.addEventListener('click',()=>{Native.toggleFavorite(b.dataset.fav);refreshGallery();}));
    qsa('[data-view]').forEach(img=>img.addEventListener('click',()=>{const it=list.find(x=>x.name===img.dataset.view);if(!it)return;$('viewerImg').src=it.url;$('viewerMeta').textContent=`${it.name}\n${it.mode||''}\nSeed: ${it.seed??'-'}\n${it.prompt||''}`;$('viewer').classList.remove('hidden');}));
  }
  $('viewerClose').addEventListener('click',()=> $('viewer').classList.add('hidden')); $('refreshGallery').addEventListener('click',refreshGallery);

  function statusCard(title,value,cls=''){return `<div class="status-card"><b>${title}</b><span class="${cls}">${value}</span></div>`}
  async function refreshStatus(){
    try {
      if(jobsAvailable){const j=await api('GET','/v1/system/status');const g=j.gpu||{},s=j.services||{},m=j.models||{},d=j.disk||{};$('systemStatus').innerHTML=[statusCard('GPU',g.ok?`${g.name||'GPU'} · ${g.utilization??'?'}% · ${g.memory_used_mb??'?'} / ${g.memory_total_mb??'?'} MB`:'不可用',g.ok?'good':'bad'),statusCard('核心服务',`Panel ${s.panel?'✓':'×'} · ComfyUI ${s.comfy?'✓':'×'} · Qwen ${s.qwen?'✓':'休眠'} · Jobs ${s.job_api?'✓':'×'}`,s.panel&&s.comfy?'good':'bad'),statusCard('固定画风',`${m.style_lora||'-'} · ${m.style_ready?'就绪':'缺失'}${m.style_v3?' · v3':''}`,m.style_ready?'good':'bad'),statusCard('人物 / 动作',`IPAdapter ${m.ipadapter?'✓':'×'} · Pose ${m.pose?'✓':'×'} · Depth ${m.depth?'✓':'×'} · Composition ${m.composition?'✓':'×'}`,(m.ipadapter&&m.pose&&m.depth&&m.composition)?'good':'warn'),statusCard('数据盘',`${d.free_gb??'?'} / ${d.total_gb??'?'} GB 可用`),statusCard('隐私清理','参考图任务后清理 · 成图本机确认后清理','good')].join('');}
      else {const j=await api('GET','/api/status');$('systemStatus').innerHTML=`<div class="status-card">${j.html||'状态已读取'}</div>`;}
    } catch(e){$('systemStatus').innerHTML=statusCard('状态','暂时无法读取：'+errText(e),'bad');}
  }
  async function refreshLogs(){if(!jobsAvailable)return;try{const j=await api('GET','/v1/logs?lines=160');$('log').textContent=(j.text||'暂无日志')+'\n';$('log').scrollTop=$('log').scrollHeight}catch(e){log('日志读取失败：'+errText(e))}}
  $('health').addEventListener('click',refreshStatus); $('toolStatus').addEventListener('click',refreshStatus); $('refreshLogs').addEventListener('click',refreshLogs);

  function formatDiagnosis(j){
    const lines=[];
    lines.push(`${j.ok?'✓':'!'} ${j.summary||'诊断完成'}`);
    for(const c of (j.checks||[])) lines.push(`${c.ok?'[OK]':'[!!]'} ${c.name}: ${c.detail||''}`);
    if((j.issues||[]).length){
      lines.push('', '需要处理：');
      for(const it of j.issues) lines.push(`- ${it.severity==='warning'?'提醒':'异常'} · ${it.name}: ${it.detail||''}${it.suggestion?`\n  建议：${it.suggestion}`:''}`);
    }
    return lines.join('\n');
  }
  async function refreshRepairHistory(){
    if(!jobsAvailable)return;
    try{const j=await api('GET','/v1/system/repairs?limit=8'); const box=$('repairHistory'); box.innerHTML='';
      for(const it of (j.items||[])){const row=document.createElement('div');row.className='repair-event';
        const when=new Date((it.time||0)*1000).toLocaleString();
        row.innerHTML=`<span>${esc(when)}</span><b class="${it.ok?'ok':'fail'}">${esc(it.kind||'repair')}</b><span>${esc(it.summary||'')}</span>`;box.appendChild(row);}
      if(!(j.items||[]).length)box.innerHTML='<div class="muted">还没有修复记录。</div>';
    }catch(e){log('修复记录读取失败：'+errText(e));}
  }
  async function diagnose(){
    if(!jobsAvailable){$('diagnosticReport').textContent='任务服务尚未就绪，WAI Pad 正在自动连接/初始化。';return;}
    $('diagnosticReport').textContent='正在检查服务、GPU、端口、进程、模型和磁盘…';
    try{const j=await api('GET','/v1/system/diagnose');$('diagnosticReport').textContent=formatDiagnosis(j);return j;}
    catch(e){$('diagnosticReport').textContent='诊断失败：'+errText(e);throw e;}
  }
  async function repair(level='safe'){
    if(!jobsAvailable)return log('修复中心等待 WAI Pad 服务就绪');
    if(level==='deep'&&!confirm('深度修复会在创建恢复点后调用现有 WAI 受控 repair，可能重启 ComfyUI。确认当前没有正在生成的重要任务，并继续？'))return;
    $('diagnosticReport').textContent=`正在执行${level==='deep'?'深度':'安全'}修复；修复前会自动创建恢复点…`;
    try{const j=await api('POST','/v1/system/repair',{level});
      const acts=(j.actions||[]).map(a=>`[${a.ok?'OK':'WARN'}] ${a.action}\n${a.output||''}`).join('\n\n');
      $('diagnosticReport').textContent=`${j.summary||'修复完成'}\n恢复点：${j.snapshot||'-'}\n\n${acts}\n\n${j.after?formatDiagnosis(j.after):''}`;
      log(j.summary||'修复完成'); await refreshStatus(); await refreshRepairHistory();
    }catch(e){$('diagnosticReport').textContent='修复没有完成：'+errText(e)+'\n\n为保护正在运行的任务，WAI Pad 可能主动拒绝了修复。';log('修复失败/延后：'+errText(e));await refreshStatus();}
  }
  async function rollback(){
    if(!confirm('恢复最近一次修复前的 WAI Pad companion/config 快照？不会删除模型、训练素材或本机图库。'))return;
    $('diagnosticReport').textContent='正在恢复最近恢复点…';
    try{const j=await api('POST','/v1/system/rollback',{});$('diagnosticReport').textContent=(j.summary||'恢复完成')+'\n正在从恢复后的服务器文件重启（不会重新上传当前版本覆盖恢复点）…';log(j.summary||'恢复完成');const out=await restartFromDisk();log(out);jobsAvailable=false;await waitForJobs(18000);await diagnose();await refreshRepairHistory();}
    catch(e){$('diagnosticReport').textContent='回滚失败：'+errText(e);}
  }
  $('repair').addEventListener('click',()=>repair('safe')); $('toolRepair').addEventListener('click',()=>repair('safe'));
  $('repairSafe').addEventListener('click',()=>repair('safe')); $('repairDeep').addEventListener('click',()=>repair('deep'));
  $('diagnose').addEventListener('click',diagnose); $('toolDiagnose').addEventListener('click',diagnose); $('rollback').addEventListener('click',rollback);

  async function doBootstrap(){
    $('bootstrap').disabled=true; log('正在自动更新 WAI Pad companion、任务服务和守护…');
    try { const out=await bootstrap(); log(out); bootstrapped=true; await sleep(1200); await detectJobs(); refreshStatus(); }
    catch(e){ log('自动初始化失败：'+errText(e)); bootstrapped=false; }
    finally{$('bootstrap').disabled=false;}
  }
  $('bootstrap').addEventListener('click',doBootstrap);
  $('terminal').addEventListener('click',()=>Native.openTerminal()); $('toolTerminal').addEventListener('click',()=>Native.openTerminal()); $('openWai').addEventListener('click',()=>Native.openEmbedded('wai')); qsa('[data-open]').forEach(b=>b.addEventListener('click',()=>Native.openEmbedded(b.dataset.open)));

  function loadConfig(){let c={};try{c=JSON.parse(Native.getConfig()||'{}')}catch(_){};$('host').value=c.host||'connect.nmb2.seetacloud.com';$('port').value=c.port||'28823';$('user').value=c.user||'root';$('autodlUrl').value=c.autodlUrl||'https://www.autodl.com/console/instance/list';$('jupyterUrl').value=c.jupyterUrl||'';$('password').placeholder=c.hasPassword?'已安全保存；不修改可留空':'输入 AutoDL SSH 密码（只保存在本机）';$('fingerprint').textContent=c.sshFingerprint||'首次成功连接后自动记录';if(!c.hasPassword){setTimeout(()=>{const b=document.querySelector('.nav button[data-page="settings"]');if(b)b.click();$('settingsMsg').textContent='首次使用只需要输入一次 AutoDL SSH 密码，之后全部自动运行。';},80);}}
  loadConfig();
  $('saveSettings').addEventListener('click',()=>{const c={host:$('host').value.trim(),port:$('port').value.trim(),user:$('user').value.trim(),password:$('password').value,autodlUrl:$('autodlUrl').value.trim(),jupyterUrl:$('jupyterUrl').value.trim()};if(!c.host||!c.port||!c.user)return $('settingsMsg').textContent='主机、端口、用户不能为空';Native.saveConfig(JSON.stringify(c));$('password').value='';$('settingsMsg').textContent='已保存。WAI Pad 正在自动连接，后续无需输入启动命令。';bootstrapped=false;lastBootstrapAttempt=0;});
  $('disconnect').addEventListener('click',()=>{Native.stopConnection();$('settingsMsg').textContent='已断开；下次可重新自动连接';});
  $('clearFingerprint').addEventListener('click',()=>{if(confirm('只有在 AutoDL 更换 SSH 主机或你确认指纹变化时才重置。继续？')){Native.clearFingerprint();$('fingerprint').textContent='已重置；下次连接会重新固定';$('settingsMsg').textContent='SSH 指纹已重置，下次连接将重新记录。';}});

  async function detectJobs(){try{const h=await api('GET','/v1/health');jobsAvailable=!!h.ok;log(`异步任务服务就绪 v${h.version||''}`);}catch(_){jobsAvailable=false;}}
  async function waitForJobs(ms=25000){const end=Date.now()+ms;while(Date.now()<end){await detectJobs();if(jobsAvailable)return true;await sleep(1200);}return false;}
  function connectionTick(){let s={};try{s=JSON.parse(Native.connectionStatus()||'{}')}catch(_){};$('connDot').classList.toggle('on',!!s.bridgeReady);$('connText').textContent=s.connected?(s.message||'AutoDL 已连接'):(s.message||'未连接');if(s.bridgeReady){if(!bootstrapped){bootstrapped=true;detectJobs().then(()=>{refreshStatus();refreshTasks();});}}else if(!s.connected){bootstrapped=false;jobsAvailable=false;}}

  connectionTick(); setInterval(connectionTick,3000); setInterval(()=>{if(jobsAvailable)refreshStatus();},20000); setTimeout(async()=>{await detectJobs();refreshStatus();refreshTasks();if(jobsAvailable)refreshRepairHistory();},2200); refreshGallery();
})();
