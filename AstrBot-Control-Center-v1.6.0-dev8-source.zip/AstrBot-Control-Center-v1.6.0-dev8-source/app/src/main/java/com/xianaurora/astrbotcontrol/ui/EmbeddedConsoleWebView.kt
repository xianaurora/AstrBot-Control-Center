package com.xianaurora.astrbotcontrol.ui

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.View
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.xianaurora.astrbotcontrol.BuildConfig

@Stable
enum class ConsoleWebPresentation {
    STANDARD,
    QR_DESKTOP
}

@Stable
class ConsoleWebController internal constructor() {
    internal var webView: WebView? = null
    var canGoBack by mutableStateOf(false)
        private set
    var canGoForward by mutableStateOf(false)
        private set

    internal fun sync() {
        canGoBack = webView?.canGoBack() == true
        canGoForward = webView?.canGoForward() == true
    }

    fun back() {
        webView?.takeIf { it.canGoBack() }?.goBack()
        sync()
    }

    fun forward() {
        webView?.takeIf { it.canGoForward() }?.goForward()
        sync()
    }

    fun refresh() {
        webView?.reload()
    }
}

@Composable
fun rememberConsoleWebController(): ConsoleWebController = remember { ConsoleWebController() }

@Composable
fun EmbeddedConsoleWebView(
    url: String,
    controller: ConsoleWebController,
    modifier: Modifier = Modifier,
    presentation: ConsoleWebPresentation = ConsoleWebPresentation.STANDARD,
    onLoadingChanged: (Boolean) -> Unit = {},
    onError: (String) -> Unit = {},
    onQrFrameReady: () -> Unit = {},
    onQrBlankDetected: () -> Unit = {}
) {
    val context = LocalContext.current
    val latestLoadingChanged by rememberUpdatedState(onLoadingChanged)
    val latestError by rememberUpdatedState(onError)
    val latestQrFrameReady by rememberUpdatedState(onQrFrameReady)
    val latestQrBlankDetected by rememberUpdatedState(onQrBlankDetected)
    var lastQrProbeUrl by remember { mutableStateOf("") }
    var lastStandardRecoveryUrl by remember { mutableStateOf("") }
    var lastStandardFailureUrl by remember { mutableStateOf("") }
    var uploadCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val callback = uploadCallback
        uploadCallback = null
        val parsed = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            ?.filter { uri -> uri.scheme == "content" }
            ?.toTypedArray()
            ?.takeIf { it.isNotEmpty() }
        callback?.onReceiveValue(parsed)
    }

    val webView = remember(context, presentation) {
        WebView(context).apply {
            // Some vendor WebView builds paint the page background but lose accelerated
            // child layers. That exactly matches the AstrBot white page + noVNC black
            // page seen on-device, so local consoles prefer the stable compositor.
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            setBackgroundColor(if (presentation == ConsoleWebPresentation.QR_DESKTOP) 0xFF1F2326.toInt() else android.graphics.Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = false
            settings.allowFileAccessFromFileURLs = false
            settings.allowUniversalAccessFromFileURLs = false
            settings.allowContentAccess = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.mediaPlaybackRequiresUserGesture = false
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = false
            if (Build.VERSION.SDK_INT >= 23) settings.offscreenPreRaster = true
            if (Build.VERSION.SDK_INT >= 26) settings.safeBrowsingEnabled = true
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true)
        }
    }

    DisposableEffect(webView, controller) {
        controller.webView = webView
        onDispose {
            if (controller.webView === webView) controller.webView = null
            uploadCallback?.onReceiveValue(null)
            uploadCallback = null
            webView.stopLoading()
            webView.webChromeClient = null
            webView.webViewClient = WebViewClient()
            webView.destroy()
        }
    }

    BackHandler(enabled = controller.canGoBack) { controller.back() }

    AndroidView(
        modifier = modifier,
        factory = {
            webView.apply {
                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView?, newProgress: Int) {
                        latestLoadingChanged(newProgress < 100)
                    }

                    override fun onShowFileChooser(
                        webView: WebView?,
                        filePathCallback: ValueCallback<Array<Uri>>?,
                        fileChooserParams: FileChooserParams?
                    ): Boolean {
                        uploadCallback?.onReceiveValue(null)
                        uploadCallback = filePathCallback
                        val intent = runCatching { fileChooserParams?.createIntent() }.getOrNull()
                            ?: Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "*/*"
                            }
                        return runCatching {
                            fileLauncher.launch(intent)
                            true
                        }.getOrElse {
                            uploadCallback?.onReceiveValue(null)
                            uploadCallback = null
                            latestError("无法打开文件选择器：${it.message ?: "未知错误"}")
                            false
                        }
                    }
                }
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val target = request?.url ?: return false
                        if (isLocalConsoleUri(target)) return false
                        return runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, target).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            true
                        }.getOrElse {
                            latestError("外部链接无法打开")
                            true
                        }
                    }

                    override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                        latestLoadingChanged(true)
                        if (presentation == ConsoleWebPresentation.QR_DESKTOP) lastQrProbeUrl = ""
                        controller.sync()
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (presentation == ConsoleWebPresentation.QR_DESKTOP) {
                            val targetView = view
                            if (targetView != null) {
                                targetView.evaluateJavascript(QR_DESKTOP_POLISH_JS, null)
                                val pageUrl = url.orEmpty()
                                if (pageUrl.isNotBlank() && lastQrProbeUrl != pageUrl) {
                                    lastQrProbeUrl = pageUrl
                                    fun probeFrame(attempt: Int) {
                                        val waitMs = if (attempt == 0) 3200L else 1450L
                                        targetView.postDelayed({
                                            if (targetView.url == pageUrl && lastQrProbeUrl == pageUrl) {
                                                targetView.evaluateJavascript(QR_FRAME_PROBE_JS) { raw ->
                                                    if (targetView.url == pageUrl && lastQrProbeUrl == pageUrl) {
                                                        when (raw.orEmpty().trim().trim('\"')) {
                                                            "ok" -> latestQrFrameReady()
                                                            "blank" -> latestQrBlankDetected()
                                                            "notready", "unknown" -> if (attempt < 2) probeFrame(attempt + 1) else latestQrBlankDetected()
                                                        }
                                                    }
                                                }
                                            }
                                        }, waitMs)
                                    }
                                    probeFrame(0)
                                }
                            }
                        }
                        if (presentation != ConsoleWebPresentation.QR_DESKTOP) {
                            val targetView = view
                            val pageUrl = url.orEmpty()
                            if (targetView != null && pageUrl.isNotBlank()) {
                                fun probeStandard(attempt: Int) {
                                    val waitMs = if (attempt == 0) 1200L else 1800L
                                    targetView.postDelayed({
                                        if (targetView.url == pageUrl) {
                                            targetView.evaluateJavascript(STANDARD_PAGE_PROBE_JS) { raw ->
                                                if (targetView.url == pageUrl) {
                                                    when (raw.orEmpty().trim().trim('"')) {
                                                        "ok" -> Unit
                                                        "notready", "blank", "unknown" -> {
                                                            if (attempt < 1) {
                                                                probeStandard(attempt + 1)
                                                            } else if (lastStandardRecoveryUrl != pageUrl) {
                                                                lastStandardRecoveryUrl = pageUrl
                                                                latestLoadingChanged(true)
                                                                targetView.reload()
                                                            } else if (lastStandardFailureUrl != pageUrl) {
                                                                lastStandardFailureUrl = pageUrl
                                                                latestError("控制台页面没有完成渲染。服务仍在运行，可重新加载或在浏览器打开。")
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }, waitMs)
                                }
                                probeStandard(0)
                            }
                        }
                        latestLoadingChanged(false)
                        controller.sync()
                    }

                    override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                        controller.sync()
                    }

                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true) {
                            latestLoadingChanged(false)
                            latestError("控制台连接失败：${error?.description ?: "无法访问本机服务"}")
                        }
                    }
                }
                setDownloadListener(localDownloadListener(context))
            }
        },
        update = { view ->
            if (url.isNotBlank() && view.url != url) view.loadUrl(url)
            if (presentation == ConsoleWebPresentation.QR_DESKTOP && view.url == url && url.isNotBlank()) {
                view.evaluateJavascript(QR_DESKTOP_POLISH_JS, null)
            }
            controller.sync()
        }
    )
}

private val QR_DESKTOP_POLISH_JS = """
(function() {
  try {
    var id = 'astrbot-qr-polish';
    var style = document.getElementById(id);
    if (!style) {
      style = document.createElement('style');
      style.id = id;
      style.textContent = `
        html, body { margin:0 !important; padding:0 !important; width:100% !important; height:100% !important; overflow:hidden !important; background:#1f2326 !important; }
        #top_bar, #status_bar, #sendCtrlAltDelButton, #noVNC_status_bar, #noVNC_control_bar_anchor,
        #noVNC_control_bar, #noVNC_mobile_buttons, .noVNC_status, .noVNC_logo { display:none !important; }
        canvas { max-width:100vw !important; max-height:100vh !important; visibility:visible !important; opacity:1 !important; }
      `;
      (document.head || document.documentElement).appendChild(style);
    }
  } catch (e) {}
})();
""".trimIndent()

private val STANDARD_PAGE_PROBE_JS = """
(function() {
  try {
    var d = document.documentElement, b = document.body;
    if (!d || !b) return 'notready';
    var text = (b.innerText || '').replace(/\s+/g, ' ').trim();
    if (text.length >= 4) return 'ok';
    var candidates = b.querySelectorAll('canvas,svg,img,iframe,video,input,button,select,textarea');
    for (var i = 0; i < candidates.length && i < 64; i++) {
      var node = candidates[i];
      var rect = node.getBoundingClientRect ? node.getBoundingClientRect() : null;
      if (!rect || rect.width < 24 || rect.height < 18) continue;
      var style = window.getComputedStyle ? window.getComputedStyle(node) : null;
      if (style && (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity || '1') < 0.05)) continue;
      if (rect.right <= 0 || rect.bottom <= 0 || rect.left >= innerWidth || rect.top >= innerHeight) continue;
      return 'ok';
    }
    return 'blank';
  } catch (e) {
    return 'unknown';
  }
})();
""".trimIndent()

private val QR_FRAME_PROBE_JS = """
(function() {
  try {
    var canvas = document.querySelector('#noVNC_canvas, #screen canvas, #noVNC_screen canvas, canvas');
    if (!canvas || !canvas.width || !canvas.height || canvas.width < 160 || canvas.height < 100) return 'notready';
    var rect = canvas.getBoundingClientRect ? canvas.getBoundingClientRect() : null;
    var style = window.getComputedStyle ? window.getComputedStyle(canvas) : null;
    if (!rect || rect.width < 120 || rect.height < 80) return 'blank';
    if (style && (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity || '1') < 0.05)) return 'blank';
    if (rect.right <= 0 || rect.bottom <= 0 || rect.left >= innerWidth || rect.top >= innerHeight) return 'blank';

    // The QQ login window is centered by the core. Probe the center ROI rather than
    // the entire desktop so a cursor or a tiny noVNC status glyph cannot make a
    // uniformly black framebuffer look healthy.
    var sx = Math.floor(canvas.width * 0.28), sy = Math.floor(canvas.height * 0.12);
    var sw = Math.max(1, Math.floor(canvas.width * 0.44)), sh = Math.max(1, Math.floor(canvas.height * 0.76));
    var probe = document.createElement('canvas');
    probe.width = 24; probe.height = 24;
    var ctx = probe.getContext('2d', {willReadFrequently:true});
    if (!ctx) return 'unknown';
    ctx.drawImage(canvas, sx, sy, sw, sh, 0, 0, probe.width, probe.height);
    var pixels = ctx.getImageData(0, 0, probe.width, probe.height).data;
    var count = 0, sum = 0, sumSq = 0, min = 255, max = 0, bright = 0, mid = 0;
    for (var i = 0; i < pixels.length; i += 4) {
      if (pixels[i + 3] < 24) continue;
      var y = 0.2126 * pixels[i] + 0.7152 * pixels[i + 1] + 0.0722 * pixels[i + 2];
      sum += y; sumSq += y * y; count++;
      if (y < min) min = y; if (y > max) max = y;
      if (y >= 88) bright++;
      if (y >= 42) mid++;
    }
    if (count < 240) return 'notready';
    var avg = sum / count;
    var variance = Math.max(0, sumSq / count - avg * avg);
    var spread = max - min;
    var brightRatio = bright / count;
    var midRatio = mid / count;
    if (avg < 34 && spread < 22 && variance < 90 && brightRatio < 0.01) return 'blank';
    if (avg < 44 && midRatio < 0.025 && brightRatio < 0.008) return 'blank';
    return 'ok';
  } catch (e) {
    return 'unknown';
  }
})();
""".trimIndent()

private fun isLocalConsoleUri(uri: Uri): Boolean {
    val host = uri.host?.lowercase().orEmpty()
    return uri.scheme in setOf("http", "https") && host in setOf("127.0.0.1", "localhost", "::1")
}

private fun localDownloadListener(context: Context) = DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
    if (url.isNullOrBlank()) return@DownloadListener
    val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return@DownloadListener
    if (!isLocalConsoleUri(uri)) return@DownloadListener
    runCatching {
        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        val request = DownloadManager.Request(uri)
            .setTitle(fileName)
            .setDescription("AstrBot Control Center")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
        if (!mimeType.isNullOrBlank()) request.setMimeType(mimeType)
        if (!userAgent.isNullOrBlank()) request.addRequestHeader("User-Agent", userAgent)
        CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }?.let { request.addRequestHeader("Cookie", it) }
        if (Build.VERSION.SDK_INT >= 29) {
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        } else {
            request.setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, fileName)
        }
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    }
}
