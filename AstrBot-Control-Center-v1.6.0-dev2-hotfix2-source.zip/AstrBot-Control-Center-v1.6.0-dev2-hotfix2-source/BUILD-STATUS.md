# Build status — v1.6.0-dev2

## 已完成

- 同一模块 ID 的 v1.5.6.5 → dev2 原地升级识别
- App 显式升级确认；App 自身更新不会静默刷 Engine
- Engine-only 升级前 SHA-256 可验证快照
- `customize.sh` 二次回退点保护
- Engine 验证失败时的回退入口与“回退后再重启”状态
- 阻止意外降级到更低 Engine `versionCode`
- APK/Engine 安装阶段完全离线
- 重启后才验证 Engine；未完整环境不会自动联网 setup
- 完整旧运行环境直接复用
- 结构化安装进度、技术日志、教程与失败解决方案
- Ubuntu 本地导入与双重 SHA-256 校验
- 运行资源阶段下载器基础设施（断点 `.part` / Range / 进度 / 校验）

## 当前没有伪装成“已完成”的部分

1. **这里仍不能生成真实 APK。** 本执行环境没有 Android SDK / `android.jar` / `aapt2`，因此无法完成 Android 编译、签名和真机安装。
2. **还没有在你的实际 Magisk / KernelSU / APatch 设备上端到端验证。** dev2 应先按 `TESTING-CHECKLIST.md` 小步测试。
3. **定制 Ubuntu rootfs 没有可信公开下载 URL。** 已完整的 v1.5.6.5 环境不受影响；全新安装暂时保留本地导入。
4. 原生 App 目前重点仍是安装/恢复链路；完整“总览/账号/日志/环境/诊断/QQ 登录”迁移是后续工作，旧 WebUI 继续作为兼容入口。
