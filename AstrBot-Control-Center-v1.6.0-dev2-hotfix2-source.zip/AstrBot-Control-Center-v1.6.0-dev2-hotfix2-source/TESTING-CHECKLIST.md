# v1.6.0-dev2 真机测试清单

> 这是开发版。你已经备份插件是好事；仍请另外保留原 v1.5.6.5 模块 ZIP，并确认重要 AstrBot 配置/数据库与 QQ/NapCat 配置有可恢复副本。

## 0. 建议再做一次“业务数据”备份

你已经备份插件很好；在刷 dev2 前，还建议用当前 v1.5.6.5 自带的私密备份把 AstrBot 数据、NapCat/QQ 登录态、多账号与关键配置一起保存：

```bash
adb shell su -c '/data/adb/modules/astrbot_standalone/astrctl backup-data --confirm'
```

成功后会在 Download 生成 `AstrBotStandalone-private-backup-*.tar.gz`。这个包含登录态和敏感配置，建议确认生成成功后复制到电脑/加密位置保存，不要上传到公开位置。

另外保留你当前能正常使用的 v1.5.6.5 模块 ZIP。

## A. 只装 APK，先不动 Engine

1. 编译 `app-debug.apk`。
2. 安装 App 后先**关闭 Wi-Fi 和移动数据**。
3. 首次打开应只看到欢迎页，不自动弹 Root、不联网、不刷模块。
4. 点击“开始安装”后才出现 Root 请求。
5. 设备检查页应显示现有 Engine `v1.5.6.5 → v1.6.0-dev2`，并明确说明模块 ID 仍为 `astrbot_standalone`、不会并行安装第二个 Engine。

## B. 升级 Engine（全程继续断网）

1. 进入 Engine 页，确认“现有业务数据保留”“升级前创建 Engine-only 回退快照”。
2. 勾选显式升级确认，再点击升级。
3. App 应先创建旧 Engine 回退点，失败就必须停止。
4. Root Manager 返回安装成功后，应停在“需要重启”，且此时没有任何运行资源下载。
5. 重启设备，保持断网。
6. 打开 App，验证 Engine 为 `v1.6.0-dev2`、协议为 1。
7. 如果旧 v1.5.6.5 运行环境本来完整，应直接复用并进入 Ready，不重装 Ubuntu/AstrBot/NapCat。

## C. 升级后数据检查

重点检查：

- AstrBot 控制台能否打开；
- 插件目录、插件配置是否都在；
- AstrBot 数据/数据库是否在；
- NapCat/QQ 登录态是否保留；
- OneBot 是否能重新连接；
- 原 Web 控制台是否仍可用；
- 开机守护、自启动设置是否保持用户原选择。

## D. 检查回退点（不必真的回退）

电脑连接 ADB 后可执行：

```bash
adb shell su -c 'cat /data/adb/astrbot_standalone/engine-backups/latest.conf'
adb shell su -c '/system/bin/sh /data/adb/modules/astrbot_standalone/engine-maintenance.sh status'
```

应看到旧 Engine 版本和 `available=1`。

## E. 只有验证失败时再回退

优先使用 App 错误页里的“恢复原 Engine”。如果 App 无法使用，才用高级命令：

```bash
adb shell su -c '/system/bin/sh /data/adb/modules/astrbot_standalone/engine-maintenance.sh rollback --confirm'
```

命令成功后**必须重启**。这个回退只切 Root 模块本体，不会回退 Ubuntu/AstrBot/插件/QQ 数据。

## F. 恢复网络后的测试

只有 Engine 和旧环境都确认正常后再开网络。如果现有运行环境完整，不应该出现重新下载。若某组件原本就缺失，App 才进入运行环境准备页，并在用户明确点击后开始网络阶段。

## 出现问题时先不要清数据

保留现场并记录：

- App 错误代码；
- 当前 Engine 版本；
- `/data/adb/astrbot_standalone/logs/action.log`；
- `/data/adb/astrbot_standalone/engine-backups/latest.conf`；
- Root Manager 的安装输出。

不要先执行“清数据/彻底卸载”，这样最容易把可诊断问题变成不可恢复问题。
