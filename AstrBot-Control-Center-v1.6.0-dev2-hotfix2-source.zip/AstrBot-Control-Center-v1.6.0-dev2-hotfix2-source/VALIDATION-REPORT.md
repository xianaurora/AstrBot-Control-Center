# v1.6.0-dev2 静态验证报告

本生成环境已执行：

- Engine 非测试 Shell 脚本按各自 shebang 做语法检查；
- Engine Python 脚本语法检查；
- 所有 JSON 清单解析检查；
- `manifest/binaries.sha256` 校验；
- `manifest/module-files.sha256` 全文件校验；
- `tests/test-control-center-v1600.sh`：通过；
- `tests/test-control-center-v1602-upgrade-guard.sh`：通过；
- Android 端与 Android SDK 无关的 model/help Kotlin 源码用本机 `kotlinc` 编译：通过；
- 最终 Engine ZIP `unzip -t`：通过；
- App 内嵌 `engine.zip` 与外发 Engine ZIP SHA-256 完全一致。

## 尚未在这里验证

- Android APK 的完整 Gradle 编译（当前执行环境没有 Android SDK / aapt2 / android.jar）；
- Magisk、KernelSU、APatch 三种真实设备上的模块安装命令兼容性；
- 真机重启后的完整 Engine 版本/协议/回退链；
- 120 Hz 真机 jank / frame pacing；
- 用户现有 v1.5.6.5 业务数据的实际迁移。

因此 dev2 仍属于开发测试版，第一次测试应严格按 `TESTING-CHECKLIST.md` 分阶段执行。
