package com.xianaurora.astrbotcontrol.help

data class HelpSection(val title: String, val body: String)
data class HelpTopic(val id: String, val title: String, val summary: String, val sections: List<HelpSection>)

object HelpContent {
    val topics = listOf(
        HelpTopic("overview", "从零开始安装", "安装 APK → 离线检查 → Engine → 重启 → 运行资源 → QQ 登录。", listOf(
            HelpSection("安装分成哪几段？", "第一段只安装控制中心和 Root Engine，不联网。Engine 在重启后验证成功，用户确认“开始准备环境”之后，才允许 Ubuntu/AstrBot/Linux QQ/NapCat 等运行资源联网。"),
            HelpSection("安装时可以退出吗？", "每个大阶段都保存检查点。重新打开后会读取 Engine 的状态，不会故意把已完成组件从头安装。下载器会保留可恢复的 .part 文件。"),
            HelpSection("QQ 扫码算安装吗？", "不算。OneBot 配置完成后安装即完成。QQ 登录属于首次使用流程，因此二维码过期或暂时不登录都不会让下一次开机重新安装。")
        )),
        HelpTopic("preflight", "设备检查与 Root", "为什么要检查 ARM64、4 KB、Root 和空间。", listOf(
            HelpSection("为什么必须 ARM64 / 4 KB？", "当前 Engine 的 PRoot/loader 与已验证 Ubuntu 兼容环境是针对 ARM64 + 4 KB page size 构建和测试的。不满足条件时直接停止，比安装一半再失败更安全。"),
            HelpSection("为什么这时才申请 Root？", "第一次打开软件不会自动弹 Root。只有用户点击开始安装后才申请，用于安装 Engine、读取 Engine 状态和执行明确的控制操作。"),
            HelpSection("没有 Root 怎么办？", "控制中心不会自动修改 boot 镜像。请先按设备对应的 Magisk、KernelSU 或 APatch 官方流程完成 Root，再返回重新检查。")
        )),
        HelpTopic("engine_backup", "升级前快照与 Engine 回退", "升级前只备份模块文件；验证失败时可恢复旧 Engine，不回滚 AstrBot/QQ 业务数据。", listOf(
            HelpSection("快照包含什么？", "只包含 /data/adb/modules/astrbot_standalone 当前 Engine 模块文件。Ubuntu、AstrBot、插件、NapCat、QQ 登录态和配置仍留在持久数据目录，不会复制进这个快照。"),
            HelpSection("什么时候创建？", "检测到现有 Engine 且你明确点击升级时，控制中心会先创建快照。快照失败会直接停止升级。即使用户绕过 App 在 Root Manager 手动刷 dev2，模块安装脚本也会在迁移前再尝试创建一次回退点。"),
            HelpSection("什么时候建议回退？", "如果重启后找不到新 Engine、协议不匹配或版本没有完整切换，错误页会出现“恢复原 Engine”。恢复完成后需要再重启一次。"),
            HelpSection("回退会不会丢插件？", "不会。Engine 回退只恢复 Root 模块本体；AstrBot 数据、插件目录、QQ 登录数据和当前运行环境不会回退或删除。")
        )),
        HelpTopic("engine_install", "安装 Engine", "Engine 是 Root 层后台服务与恢复入口。", listOf(
            HelpSection("这个步骤联网吗？", "不联网。Engine ZIP 已内置在 APK 中，控制中心先计算 SHA-256，再交给 Root 管理器安装。"),
            HelpSection("会覆盖 AstrBot 数据吗？", "不会把业务数据打包进模块目录。现有 Ubuntu、AstrBot 数据、NapCat 配置和 QQ 登录状态继续位于 /data/adb/astrbot_standalone。"),
            HelpSection("APatch 安装失败怎么办？", "不同 APatch 版本的 CLI 行为可能不同。控制中心会显示 Root 管理器原始返回信息；如果 CLI 不支持当前版本，应使用 APatch Manager 手动导入同一 Engine ZIP，而不是直接复制模块目录。")
        )),
        HelpTopic("reboot_engine", "为什么必须重启一次", "确认 Engine 真正进入 Root late_start 环境。", listOf(
            HelpSection("为什么不能跳过？", "写入模块并不等于模块已经运行。重启后 service.sh 真正进入 late_start 才写入 engine-verified。控制中心只认这个验证标记。"),
            HelpSection("重启后会偷偷下载吗？", "不会。新装或未完整环境会把 auto_setup_first_boot 设为 0；Engine 只等待控制中心下一步确认。")
        )),
        HelpTopic("rootfs_resource", "Ubuntu 基础资源", "当前 Engine 使用一份经过设备验证的兼容 rootfs。", listOf(
            HelpSection("为什么需要它？", "AstrBot、Python 工具和 Linux QQ 的独立运行环境都依赖该 Ubuntu 基础层。Engine 会验证固定文件大小和 SHA-256。"),
            HelpSection("为什么现在显示本地导入？", "当前输入模块里只有这份兼容资源的校验值，没有它的公开正式下载地址。开发版不会偷偷换成未经设备验证的 Ubuntu 包。正式发布源接入后同一页面可自动下载；本地导入始终保留。"),
            HelpSection("选错文件会怎样？", "文件大小或 SHA-256 不匹配时立即拒绝，不解压、不覆盖现有 rootfs。")
        )),
        HelpTopic("network_download", "下载中断与恢复", "网络失败不应该等于整个安装失败。", listOf(
            HelpSection("断网后会从零开始吗？", "uv、Linux QQ 和 NapCat 的 Engine 下载器保存 .part，并在服务器支持 HTTP Range 时续传。已通过校验的完整缓存不会重复下载。"),
            HelpSection("一直连接失败怎么办？", "先确认网络和 DNS，再展开“技术详情”查看具体域名与返回。部分资源有官方/备用源自动回退；资源仍可通过本地文件导入到指定缓存。")
        )),
        HelpTopic("no_space", "存储空间不足", "释放空间后只重试当前阶段。", listOf(
            HelpSection("会删旧数据腾空间吗？", "不会。控制中心和 Engine 不会为了完成安装自动删除现有 AstrBot/QQ 数据。"),
            HelpSection("释放多少合适？", "基础检查建议至少保留约 2 GiB；实际完整环境和插件可能需要更多。Ubuntu 展开前 Engine 还会再做一次底层空间检查。")
        )),
        HelpTopic("resource_integrity", "资源校验失败", "校验失败的文件绝不安装。", listOf(
            HelpSection("这代表什么？", "文件可能下载不完整、版本不匹配或被修改。Engine 会保留当前运行环境并拒绝切换。"),
            HelpSection("怎么解决？", "删除损坏的临时文件或重新获取正确版本，再重试该组件。技术详情会显示预期与实际 SHA-256/大小。")
        )),
        HelpTopic("astrbot_install", "AstrBot 安装失败", "Ubuntu 已完成时只需要重试 AstrBot 阶段。", listOf(
            HelpSection("会重装 Ubuntu 吗？", "不会。setup 每次先检查 rootfs_ready/app_ready/napcat_installed/stage4_ready，只处理缺失阶段。"),
            HelpSection("常见原因", "PyPI 网络异常、Python 环境问题、剩余空间不足。展开 action.log 和 stage2-install.log 可以看到具体源和命令返回。")
        )),
        HelpTopic("napcat_install", "Linux QQ / NapCat 安装失败", "下载缓存和 AstrBot 环境会保留。", listOf(
            HelpSection("Linux QQ 如何验证？", "当前版本通过 Debian 元数据检查 Package、Architecture 和 Version；NapCat ZIP 另外固定 SHA-256。"),
            HelpSection("重试会丢配置吗？", "安装运行环境前会备份已有 NapCat config，重新组装后再恢复。仍建议重要账号配置另外保留备份。")
        )),
        HelpTopic("onebot_config", "OneBot 配置失败", "这是本地配置步骤，不需要重装下载资源。", listOf(
            HelpSection("怎么恢复？", "直接重新生成 Token 与反向 WebSocket 配置即可。QQ 是否已经扫码不影响安装完成。")
        )),
        HelpTopic("first_start", "安装完成但首次启动失败", "把“安装”和“启动”分开处理。", listOf(
            HelpSection("需要重新安装吗？", "不需要。FIRST_START_FAILED 表示组件已经落盘，只是服务启动/连接阶段没完成。应查看启动日志并重新启动服务。")
        )),
        HelpTopic("protocol", "版本或协议不兼容", "控制中心不会在未知协议上盲目执行 Root 操作。", listOf(
            HelpSection("怎么解决？", "安装与当前 APK 配套的 Engine。App 与 Engine 版本号可以不同，但 app-protocol 必须兼容。")
        )),
        HelpTopic("generic", "其他安装问题", "先保留现场，再看当前步骤和日志。", listOf(
            HelpSection("推荐顺序", "先看失败卡片的‘发生了什么 / 数据是否安全 / 下一步’，再展开技术日志。不要第一时间清数据或完整重装。"),
            HelpSection("需要反馈时", "导出脱敏诊断、错误代码、当前 stage/step 和最近 action.log。不要公开 OneBot Token、QQ 登录态或控制台密码。")
        ))
    )

    fun byId(id: String?): HelpTopic = topics.firstOrNull { it.id == id } ?: topics.first()
}
