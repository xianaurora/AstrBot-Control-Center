package com.xianaurora.astrbotcontrol.model

enum class RootBackend(val label: String) {
    MAGISK("Magisk"),
    KERNEL_SU("KernelSU"),
    APATCH("APatch"),
    UNKNOWN("未知 Root 管理器"),
    NONE("未获得 Root")
}

enum class InstallScreen {
    WELCOME,
    PREFLIGHT,
    ENGINE_INSTALL,
    REBOOT_REQUIRED,
    ENGINE_VERIFY,
    ROLLBACK_REBOOT_REQUIRED,
    ROLLBACK_COMPLETE,
    RUNTIME_PLAN,
    RUNTIME_INSTALL,
    READY,
    HELP,
    ERROR
}

data class CheckItem(
    val id: String,
    val title: String,
    val detail: String,
    val ok: Boolean,
    val blocking: Boolean = !ok
)

data class EngineStatus(
    val protocol: Int = 0,
    val engineVersion: String = "",
    val stage: String = "idle",
    val step: String = "none",
    val state: String = "idle",
    val title: String = "尚未开始",
    val detail: String = "",
    val current: Long? = null,
    val total: Long? = null,
    val unit: String = "",
    val errorCode: String = "",
    val solutionId: String = "",
    val rootfsReady: Boolean = false,
    val astrbotReady: Boolean = false,
    val napcatReady: Boolean = false,
    val onebotReady: Boolean = false,
    val fastBootReady: Boolean = false,
    val workerRunning: Boolean = false,
    val rebootRequired: Boolean = false,
    val engineVerifiedEpoch: Long = 0
) {
    val allRuntimeReady: Boolean get() = rootfsReady && astrbotReady && napcatReady && onebotReady
    val hasProgress: Boolean get() = current != null && total != null && total > 0 && current >= 0
    val progress: Float get() = if (hasProgress) (current!!.toDouble() / total!!.toDouble()).coerceIn(0.0, 1.0).toFloat() else 0f
}

data class InstallEvent(
    val epoch: Long,
    val stage: String,
    val step: String,
    val state: String,
    val title: String,
    val detail: String,
    val current: Long? = null,
    val total: Long? = null,
    val unit: String = "",
    val errorCode: String = "",
    val solutionId: String = ""
)

data class InstallPlanItem(
    val id: String,
    val title: String,
    val network: Boolean,
    val state: String,
    val detail: String
)

data class ResourceStatus(
    val id: String = "rootfs",
    val state: String = "missing",
    val filename: String = "AstrBot-Standalone-Base-Ubuntu24.04-arm64-v1.0.0.tar.xz",
    val size: Long = 0,
    val expectedSize: Long = 65831076,
    val sha256: String = "",
    val expectedSha256: String = "4590dbac3ec23adbadbeba67a9d9c0098069d55ebee4731a9889616a82981441",
    val delivery: String = "catalog_or_import"
) {
    val ready: Boolean get() = state == "ready"
}


data class ExistingEngineInfo(
    val present: Boolean = false,
    val version: String = "",
    val versionCode: Int = 0,
    val moduleId: String = "astrbot_standalone",
    val enabled: Boolean = false,
    val persistentDataPresent: Boolean = false,
    val persistentDataBytes: Long = 0,
    val rootfsReady: Boolean = false,
    val astrbotReady: Boolean = false,
    val napcatReady: Boolean = false,
    val onebotReady: Boolean = false,
    val rollbackAvailable: Boolean = false,
    val rollbackVersion: String = ""
) {
    val installed: Boolean get() = present
    val runtimeSummary: String get() = buildList {
        if (rootfsReady) add("Ubuntu")
        if (astrbotReady) add("AstrBot")
        if (napcatReady) add("NapCat")
        if (onebotReady) add("OneBot")
    }.joinToString(" · ").ifBlank { if (persistentDataPresent) "检测到持久数据" else "未检测到已完成运行环境" }
}

data class InstallerError(
    val code: String,
    val title: String,
    val message: String,
    val dataSafeMessage: String,
    val solutionId: String,
    val retryable: Boolean = true,
    val rollbackRecommended: Boolean = false
)

data class InstallerUiState(
    val screen: InstallScreen = InstallScreen.WELCOME,
    val busy: Boolean = false,
    val rootBackend: RootBackend = RootBackend.NONE,
    val rootBackendVersion: String = "",
    val checks: List<CheckItem> = emptyList(),
    val engineAssetSha256: String = "",
    val engineAssetReady: Boolean = false,
    val targetEngineVersion: String = "1.6.0-dev2",
    val targetEngineVersionCode: Int = 16002,
    val existingEngine: ExistingEngineInfo = ExistingEngineInfo(),
    val engineUpgradeConfirmed: Boolean = false,
    val engineStatus: EngineStatus = EngineStatus(),
    val plan: List<InstallPlanItem> = emptyList(),
    val resourceStatus: ResourceStatus = ResourceStatus(),
    val events: List<InstallEvent> = emptyList(),
    val technicalLog: String = "",
    val error: InstallerError? = null,
    val helpTopic: String? = null,
    val helpReturnScreen: InstallScreen? = null,
    val message: String = "",
    val importProgress: Float? = null,
    val resourceDownloadProgress: Float? = null,
    val resourceDownloadDetail: String = "",
    val resourceAutoDownloadAvailable: Boolean = false,
    val installStartedByApp: Boolean = false,
    val rollbackPrepared: Boolean = false
)
