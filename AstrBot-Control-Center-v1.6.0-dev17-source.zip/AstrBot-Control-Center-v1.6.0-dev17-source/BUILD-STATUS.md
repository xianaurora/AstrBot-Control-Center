# Build status — v1.6.0-dev17

- Fixed the dev16 Kotlin compilation failure in `AstrBotWebActivity.kt` (`CharSequence?.orEmpty`).
- Added stable development APK signing for both debug and release builds.
- GitHub Actions now verifies the produced APK signature and uploads `signing-info.txt`.
- Added the user-supplied character artwork as legacy + adaptive launcher icons.
- Embedded engine remains v1.6.0-dev11 and its SHA-256 is unchanged.
- Local source gate must report `SOURCE_GATE_OK` before packaging.

This environment still does not include the complete Android SDK/Gradle build toolchain,
so the authoritative full Android compile remains the included GitHub Actions workflow.
