WAI Pad v0.3.4.12

本版重点：启动控制面与 Comfy/Panel 重修复彻底解耦；服务器再慢也不应把 SSH 控制面卡在“正在检查服务”。
旧签名 -> v0.3.4 可能需要最后一次卸载；v0.3.4 以后保持同一签名可直接覆盖升级。
新生成图片会额外保存在平板本机 Pictures/WAI Pad，卸载 App 也不会删除该保险库。

WAI Pad v0.3 开发版
=================

这是按当前 AutoDL + ComfyUI + Qwen + WAI v3.4 环境做的安卓平板一体化版本。
目标不是“网页套壳”，而是：打开 WAI Pad -> 自动连接服务器 -> 自动启动/检查/修复 -> 直接生图 -> 图片进入平板本机图库。

一、正常使用时不需要输入命令
----------------------------
第一次安装后，只需要在“设置”里输入一次 AutoDL SSH 密码并点“保存并自动连接”。
主机 connect.nmb2.seetacloud.com、端口 28823、用户 root 已预填。
以后：
1. App 前台服务自动建立 SSH 隧道并断线重连。
2. 自动上传/更新 WAI Pad companion，不覆盖旧 WAI 6017 面板。
3. 自动启动 WAI / ComfyUI / Qwen（需要时）。
4. 自动启动异步任务 API 6027 和 guard 守护。
5. Panel / ComfyUI 连续异常时 guard 自动 wai restart；仍不恢复才调用现有受控 repair。
6. 生成任务异常时只做一次有边界的自动修复，不进入无限修复循环。

二、保留高级命令入口
------------------
“控制台/工具 -> SSH 终端”是持久 shell，会保留 cd 等会话状态，并有 Ctrl+C。
它只作为高级维护入口；普通生图不依赖它。

三、图片只以 WAI Pad 本机图库为最终存储
-------------------------------------
- Android 图片目录：应用私有 files/wai_images（外部 App/云盘默认不可见）。
- 元数据：应用私有 files/wai_images_meta。
- 不做任何云盘同步。
- 参考图上传 AutoDL 后，任务结束自动删除 ComfyUI input 临时文件。
- 成图完成后先通过 SSH 隧道直接下载到 Android 私有存储；本机写入成功后，App 才发送 ack-local，AutoDL 的对应输出临时文件随后删除。
- 如果平板没来得及确认保存，远端结果最多保留 72 小时，由 janitor 清理，兼顾断线恢复与隐私。
- 卸载 WAI Pad 会删除 App 私有索引/副本，但 Pictures/WAI Pad 本机保险库保留；重装后可从保险库导回。默认不会自动把图传到任何云端。

四、软件功能
----------
创作：文生图 / 图生图 / 人物参考 / 人物+动作
任务：异步队列、真实 ComfyUI WebSocket 采样进度、取消、错误原因、自动恢复未落盘的已完成任务
图库：本地图片、收藏、删除、Seed/Prompt/Steps/CFG 元数据
控制台：GPU、显存、ComfyUI、Qwen、Style LoRA、IPAdapter、Pose、Depth、Composition、磁盘、日志
工具：一键体检、自动修复、SSH 终端、动作骨架/Depth 预览
内嵌：AutoDL / JupyterLab / ComfyUI / ComfyUI Manager / 旧 WAI 面板
连接：16017->6017、16006->6006、16027->6027；Jupyter 尝试自动发现并映射到 18888
安全：SSH 密码使用 Android KeyStore AES-GCM 加密；首次连接采用 TOFU 并固定 SSH SHA-256 主机指纹；后续连接在密码认证前强制校验已固定指纹，变化时直接阻止认证。

五、为什么旧 WAI 仍保留
--------------------
WAI Pad v0.3 使用独立 companion 端口 6027，不替换旧 6017。
即使 WAI Pad companion 出问题，旧网页/ComfyUI 仍是回退入口，降低开发阶段把现有可用环境弄坏的风险。

六、当前构建状态
--------------
代码已做：
- Python py_compile：通过
- shell bash -n：通过
- 前端 app.js Node 语法检查：通过
- JS Native 方法引用一致性检查：通过

当前执行环境没有 Android SDK/Gradle/Maven 网络缓存，因此这里无法实际产出 APK 二进制，也不能假装已经做过平板实机安装测试。
已附 Android Studio 项目和 GitHub Actions 自动构建配置；在具备 Android 构建环境后可直接生成 debug APK。

不要把 SSH 密码、root 密码、私钥放进源码或发给开发者。


【v0.3 修复中心】
- 控制台新增完整诊断、安全修复、深度修复、最近恢复点回滚、修复历史。
- 安全修复会先留恢复点，并且正在生图时不会重启核心服务。
- 深度修复必须在 App 内二次确认。
- 修复不会删除模型、训练图片、本机图库。
- 详见 BUG_AUDIT.md 与 CHANGELOG.md。
