package com.waipad.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import com.jcraft.jsch.Session
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

class TunnelService : Service() {
    companion object {
        const val CHANNEL_ID = "wai_pad_tunnel"
        @Volatile var connected = false
        @Volatile var bridgeReady = false
        @Volatile var stackReady = false
        @Volatile var bootstrapBusy = false
        @Volatile var phase = "idle"
        @Volatile var message = "未连接"
        @Volatile var lastBootstrapOutput = ""
        @Volatile var lastConnectedAt = 0L
        @Volatile var jupyterForwarded = false
        @Volatile var jupyterRemotePort = 0
        @Volatile private var activeSession: Session? = null
        private val sessionGuard = Any()

        fun forceReconnect(reason: String = "请求重建连接") {
            bridgeReady = false; stackReady = false
            phase = "reconnecting"; message = reason
            val s = synchronized(sessionGuard) { activeSession }
            try { s?.disconnect() } catch (_: Exception) {}
        }

        fun start(context: Context) {
            val i = Intent(context, TunnelService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }
        fun stop(context: Context) = context.stopService(Intent(context, TunnelService::class.java))
    }

    private val running = AtomicBoolean(false)
    private val exec = Executors.newSingleThreadExecutor()
    private val bootstrapExec = Executors.newSingleThreadExecutor()
    private val bootstrapRunning = AtomicBoolean(false)
    @Volatile private var ownedSession: Session? = null
    @Volatile private var bootstrapRetryNeeded = true
    @Volatile private var lastBootstrapAttempt = 0L

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "WAI Pad 服务器连接", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        startForeground(17, notification("准备连接 AutoDL…"))
    }

    private fun notification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("WAI Pad").setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).build()
    }

    private fun notifyStatus(text: String) {
        try { getSystemService(NotificationManager::class.java).notify(17, notification(text)) } catch (_: Exception) {}
    }

    private data class Health(val api: Boolean, val stack: Boolean, val detail: String = "")

    private fun localHealth(): Health {
        return try {
            val c = URL("http://127.0.0.1:16027/v1/health").openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 2200; c.readTimeout = 2200; c.setRequestProperty("Connection", "close")
                val code = c.responseCode
                if (code !in 200..299) {
                    Health(false, false, "HTTP $code")
                } else {
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    val o = JSONObject(text)
                    Health(true, o.optBoolean("ready", false), o.optString("detail", ""))
                }
            } finally { c.disconnect() }
        } catch (e: Exception) { Health(false, false, e.message ?: "") }
    }

    private fun remoteApiReady(session: Session): Boolean = try {
        val r = SshClient.exec(session, "curl -fsS --max-time 3 http://127.0.0.1:6027/v1/health >/dev/null 2>&1", 8_000)
        r.first == 0
    } catch (_: Exception) { false }

    private fun detectJupyter(session: Session): Int {
        val cmd = "for p in 8888 8889 8890 8891 8080; do if curl -fsS --max-time 1 http://127.0.0.1:\$p/ >/dev/null 2>&1 || curl -fsS --max-time 1 http://127.0.0.1:\$p/lab >/dev/null 2>&1; then echo \$p; exit 0; fi; done; exit 1"
        val r = SshClient.exec(session, cmd, 12_000)
        return r.second.trim().lineSequence().firstOrNull()?.toIntOrNull() ?: 0
    }

    private fun publishSession(s: Session) {
        ownedSession = s
        synchronized(sessionGuard) { activeSession = s }
    }

    private fun disconnectOwned() {
        val s = ownedSession
        ownedSession = null
        synchronized(sessionGuard) { if (activeSession === s) activeSession = null }
        try { s?.disconnect() } catch (_: Exception) {}
    }

    /**
     * Server installation/recovery is deliberately detached from the tunnel monitor.  A slow
     * service lock, SFTP update, or Panel/Comfy repair must never freeze the SSH connection state.
     */
    private fun triggerBootstrap(session: Session, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && now - lastBootstrapAttempt < 18_000L) return
        if (!bootstrapRunning.compareAndSet(false, true)) return
        lastBootstrapAttempt = now
        bootstrapBusy = true
        bootstrapExec.submit {
            try {
                val out = RemoteBootstrap.installAndStart(this, session)
                lastBootstrapOutput = out.takeLast(16_000)
                bootstrapRetryNeeded = out.contains("WAI_PAD_UPDATE_BUSY=1") || out.contains("WAI_PAD_UPDATE_DEFERRED_ACTIVE_JOB=1")
            } catch (e: Exception) {
                bootstrapRetryNeeded = true
                lastBootstrapOutput = (lastBootstrapOutput + "\n后台初始化：" + (e.message ?: "失败")).takeLast(16_000)
            } finally {
                bootstrapBusy = false
                bootstrapRunning.set(false)
            }
        }
    }

    private fun publishHealth(h: Health) {
        bridgeReady = h.api
        stackReady = h.stack
        when {
            h.api && h.stack -> { phase = "ready"; message = if (jupyterForwarded) "已连接 · WAI/Comfy/Jupyter 正常" else "已连接 · WAI/Comfy 正常" }
            h.api -> { phase = "degraded"; message = "已连接 · companion 正常，Comfy/Panel 后台恢复中" }
            else -> { phase = "repairing"; message = "隧道已连接 · companion 后台启动中" }
        }
        notifyStatus(message)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running.compareAndSet(false, true)) exec.submit { loop() }
        return START_STICKY
    }

    private fun loop() {
        var reconnectFailures = 0
        while (running.get()) {
            val p = SecurePrefs(this)
            if (!p.hasServer()) {
                connected = false; bridgeReady = false; stackReady = false; phase = "setup"
                message = "首次使用：请在设置里填写一次 SSH 密码"
                notifyStatus("等待首次连接设置")
                Thread.sleep(3000); continue
            }
            try {
                phase = "connecting"; message = "正在连接 AutoDL…"; connected = false; bridgeReady = false; stackReady = false
                notifyStatus(message)
                disconnectOwned()
                val s = SshClient.connect(p)
                publishSession(s)
                // Only publish a connection after all required local forwards succeeded.
                s.setPortForwardingL(16017, "127.0.0.1", 6017)
                s.setPortForwardingL(16006, "127.0.0.1", 6006)
                s.setPortForwardingL(16027, "127.0.0.1", 6027)
                connected = true; lastConnectedAt = System.currentTimeMillis(); reconnectFailures = 0
                jupyterRemotePort = 0; jupyterForwarded = false

                // FIRST publish whatever is already reachable.  Never wait synchronously for install.
                publishHealth(localHealth())
                bootstrapRetryNeeded = true
                triggerBootstrap(s, force = true)

                var nextRemoteProbeAt = 0L
                var jupyterChecked = false
                while (running.get() && s.isConnected) {
                    val h = localHealth()
                    if (!h.api) {
                        bridgeReady = false; stackReady = false
                        phase = "repairing"; message = if (bootstrapBusy) "隧道已连接 · companion 正在后台初始化" else "隧道已连接 · companion 后台启动中"
                        notifyStatus(message)

                        val now = System.currentTimeMillis()
                        // Probe remote API at a controlled cadence.  Remote healthy + local dead means
                        // the port forward itself is stale; only that condition warrants SSH rebuild.
                        if (now >= nextRemoteProbeAt) {
                            nextRemoteProbeAt = now + 12_000L
                            if (remoteApiReady(s)) throw IOException("16027 本地转发失效，自动重建 SSH 隧道")
                        }
                        triggerBootstrap(s)
                    } else {
                        nextRemoteProbeAt = 0L
                        bridgeReady = true; stackReady = h.stack
                        if (!jupyterChecked) {
                            jupyterChecked = true
                            val jp = try { detectJupyter(s) } catch (_: Exception) { 0 }
                            jupyterRemotePort = jp; jupyterForwarded = false
                            if (jp > 0) {
                                try { s.setPortForwardingL(18888, "127.0.0.1", jp); jupyterForwarded = true } catch (_: Exception) {}
                            }
                        }
                        publishHealth(h)
                        // Retry only deferred/busy APK updates. Core degradation is guard.sh's job.
                        if (bootstrapRetryNeeded) triggerBootstrap(s)
                    }
                    Thread.sleep(3500)
                }
            } catch (e: Exception) {
                disconnectOwned()
                connected = false; bridgeReady = false; stackReady = false; jupyterForwarded = false; phase = "reconnecting"
                message = "连接中断，正在自动重连：${e.message ?: "未知错误"}"
                notifyStatus("连接中断 · 自动重连中")
                reconnectFailures++
                val delay = min(30_000L, 2_500L * (1L shl min(3, reconnectFailures - 1)))
                Thread.sleep(delay)
            }
        }
    }

    override fun onDestroy() {
        running.set(false)
        disconnectOwned()
        connected = false; bridgeReady = false; stackReady = false; bootstrapBusy = false; jupyterForwarded = false; phase = "stopped"; message = "已停止"
        exec.shutdownNow(); bootstrapExec.shutdownNow(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
