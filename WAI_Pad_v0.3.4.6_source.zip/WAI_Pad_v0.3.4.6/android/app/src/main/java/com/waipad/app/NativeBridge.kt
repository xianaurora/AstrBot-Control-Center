package com.waipad.app

import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.util.Base64
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.io.IOException
import java.util.UUID
import java.util.concurrent.Executors

class NativeBridge(
    private val context: Context,
    private val webView: WebView,
    private val store: LocalImageStore
) {
    private val prefs = SecurePrefs(context)
    private val exec = Executors.newCachedThreadPool()

    @JavascriptInterface fun getConfig(): String = JSONObject()
        .put("host", prefs.get("host", "connect.nmb2.seetacloud.com"))
        .put("port", prefs.get("port", "28823"))
        .put("user", prefs.get("user", "root"))
        .put("autodlUrl", prefs.get("autodlUrl", "https://www.autodl.com/console/instance/list"))
        .put("jupyterUrl", prefs.get("jupyterUrl", ""))
        .put("sshFingerprint", prefs.get("sshFingerprint", ""))
        .put("version", "0.3.4.6")
        .put("hasPassword", prefs.get("password").isNotBlank())
        .toString()

    @JavascriptInterface fun saveConfig(json: String): String {
        val o = JSONObject(json)
        val oldHost = prefs.get("host", "connect.nmb2.seetacloud.com")
        val oldPort = prefs.get("port", "28823")
        val oldUser = prefs.get("user", "root")
        val host = o.optString("host", oldHost).trim()
        val port = o.optString("port", oldPort).trim()
        val user = o.optString("user", oldUser).trim()
        if (host != oldHost || port != oldPort || user != oldUser) prefs.remove("sshFingerprint")
        prefs.put("host", host); prefs.put("port", port); prefs.put("user", user)
        if (o.has("password") && o.optString("password").isNotEmpty()) prefs.put("password", o.optString("password"))
        prefs.put("autodlUrl", o.optString("autodlUrl", "https://www.autodl.com/console/instance/list"))
        prefs.put("jupyterUrl", o.optString("jupyterUrl", ""))
        TunnelService.stop(context); TunnelService.start(context)
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface fun clearFingerprint(): String {
        prefs.remove("sshFingerprint")
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface fun connectionStatus(): String = JSONObject()
        .put("connected", TunnelService.connected)
        .put("bridgeReady", TunnelService.bridgeReady)
        .put("phase", TunnelService.phase)
        .put("message", TunnelService.message)
        .put("fingerprint", prefs.get("sshFingerprint", ""))
        .put("jupyterForwarded", TunnelService.jupyterForwarded)
        .put("jupyterRemotePort", TunnelService.jupyterRemotePort)
        .put("lastConnectedAt", TunnelService.lastConnectedAt)
        .toString()

    @JavascriptInterface fun bootstrapLog(): String = TunnelService.lastBootstrapOutput
    @JavascriptInterface fun startConnection() { TunnelService.start(context) }
    @JavascriptInterface fun stopConnection() { TunnelService.stop(context) }
    @JavascriptInterface fun forceReconnect() { TunnelService.forceReconnect("主界面检测到连接异常") }

    @JavascriptInterface fun listImages(): String = store.list().toString()
    @JavascriptInterface fun localStats(): String {
        val s = store.stats()
        return JSONObject().put("count", s.optInt("count", 0)).put("bytes", s.optLong("used_bytes", 0)).put("free_bytes", s.optLong("free_bytes", 0)).toString()
    }
    @JavascriptInterface fun storageStats(): String = store.stats().toString()
    @JavascriptInterface fun imageMetadata(name: String): String = store.metadata(name).toString()
    @JavascriptInterface fun toggleFavorite(name: String): String = store.toggleFavorite(name).toString()
    @JavascriptInterface fun deleteImage(name: String): Boolean = store.delete(name)
    @JavascriptInterface fun hasLocalJob(jobId: String): Boolean = store.hasJob(jobId)

    @JavascriptInterface fun importLocalAlbum(id: String) {
        exec.submit {
            var ok = false
            val payload = try {
                val result = store.importFromAlbum()
                ok = true
                result.toString()
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "album import failed").toString()
            }
            val js = "window.WAI_NATIVE&&window.WAI_NATIVE.onAlbumImported(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});"
            webView.post { webView.evaluateJavascript(js, null) }
        }
    }

    @JavascriptInterface fun saveImage(dataUrl: String, suggested: String, metadataJson: String): String {
        val meta = try { JSONObject(metadataJson) } catch (_: Exception) { JSONObject() }
        return store.saveDataUrl(dataUrl, suggested, meta).toString()
    }

    @JavascriptInterface fun downloadJobImage(id: String, jobId: String, localMetaJson: String) {
        fetchAndSaveJob(id, jobId, localMetaJson)
    }

    /**
     * Stage reference images over SFTP instead of sending multi-megabyte JSON through
     * the localhost HTTP tunnel. The latter is vulnerable to Android HttpURLConnection
     * "unexpected end of stream" when the SSH port-forward is briefly rebuilt.
     *
     * Only a temporary copy is written to AutoDL under /root/WAI_Pad/runtime/uploads;
     * the existing job API removes it after the job materializes its own ephemeral input.
     */
    @JavascriptInterface fun uploadReferenceSftp(id: String, dataUrl: String, kind: String) {
        exec.submit {
            var ok = false
            val payload = try {
                val comma = dataUrl.indexOf(',')
                if (comma < 6) throw IllegalArgumentException("参考图数据无效")
                val header = dataUrl.substring(0, comma)
                val m = Regex("^data:(image/[^;]+);base64$", RegexOption.IGNORE_CASE).find(header)
                    ?: throw IllegalArgumentException("参考图格式无法识别")
                val mime = m.groupValues[1].lowercase()
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                if (bytes.isEmpty()) throw IllegalArgumentException("参考图为空")
                if (bytes.size > 40 * 1024 * 1024) throw IllegalArgumentException("参考图超过 40MB")

                val uid = UUID.randomUUID().toString().replace("-", "")
                val ext = when {
                    mime.contains("jpeg") || mime.contains("jpg") -> "jpg"
                    mime.contains("webp") -> "webp"
                    else -> "png"
                }
                val remoteDir = "/root/WAI_Pad/runtime/uploads"
                val remoteImage = "$remoteDir/$uid.$ext"
                val remoteMeta = "$remoteDir/$uid.json"
                val meta = JSONObject()
                    .put("id", uid)
                    .put("path", remoteImage)
                    .put("mime", mime)
                    .put("kind", kind.take(32))
                    .put("created_at", System.currentTimeMillis() / 1000.0)
                    .put("size", bytes.size)
                    .toString().toByteArray(Charsets.UTF_8)

                var last: Exception? = null
                for (attempt in 1..2) {
                    var session: com.jcraft.jsch.Session? = null
                    try {
                        session = SshClient.connect(prefs)
                        val mk = SshClient.exec(session, "mkdir -p '$remoteDir'", 12_000)
                        if (mk.first != 0) throw IOException("无法创建远端临时目录：${mk.second.takeLast(240)}")
                        SshClient.putBytesAtomic(session, remoteImage, bytes)
                        SshClient.putBytesAtomic(session, remoteMeta, meta)
                        ok = true
                        session.disconnect()
                        return@submit finishReferenceUpload(id, true, JSONObject()
                            .put("id", uid).put("size", bytes.size).put("kind", kind).put("transport", "sftp").toString())
                    } catch (e: Exception) {
                        last = e
                        try { session?.let { if (it.isConnected) SshClient.exec(it, "rm -f '$remoteImage' '$remoteMeta'", 8_000) } } catch (_: Exception) {}
                        try { session?.disconnect() } catch (_: Exception) {}
                        if (attempt < 2) Thread.sleep(900L)
                    }
                }
                throw last ?: IOException("SFTP 上传失败")
            } catch (e: Exception) {
                JSONObject().put("error", e.message ?: "SFTP 上传失败").toString()
            }
            finishReferenceUpload(id, ok, payload)
        }
    }

    private fun finishReferenceUpload(id: String, ok: Boolean, payload: String) {
        val js = "window.WAI_NATIVE&&window.WAI_NATIVE.onReferenceUploaded(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});"
        webView.post { webView.evaluateJavascript(js, null) }
    }

    @JavascriptInterface fun openTerminal() {
        context.startActivity(Intent(context, TerminalActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    @JavascriptInterface fun openEmbedded(target: String) {
        val url = when (target) {
            "wai" -> "http://127.0.0.1:16017/"
            "comfy", "manager" -> "http://127.0.0.1:16006/"
            "backend" -> "http://127.0.0.1:16027/v1/health"
            "autodl" -> prefs.get("autodlUrl", "https://www.autodl.com/console/instance/list")
            "jupyter" -> {
                val saved = prefs.get("jupyterUrl", "")
                if (TunnelService.jupyterForwarded) "http://127.0.0.1:18888/lab" else saved
            }
            else -> target
        }
        val i = Intent(context, EmbeddedWebActivity::class.java).putExtra("url", url).putExtra("title", target)
        context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private data class TextResp(val ok: Boolean, val code: Int, val text: String)
    private data class BinResp(val ok: Boolean, val code: Int, val bytes: ByteArray, val contentType: String)

    private fun baseFor(path: String) = if (path.startsWith("/v1/")) "http://127.0.0.1:16027" else "http://127.0.0.1:16017"

    private fun http(method: String, path: String, body: String = "", timeoutMs: Int = 120_000): TextResp {
        val conn = URL(baseFor(path) + path).openConnection() as HttpURLConnection
        conn.requestMethod = method.uppercase(); conn.connectTimeout = 8_000; conn.readTimeout = timeoutMs
        conn.setRequestProperty("Content-Type", "application/json"); conn.setRequestProperty("Cache-Control", "no-store"); conn.setRequestProperty("Connection", "close")
        if (method.uppercase() !in listOf("GET", "DELETE") && body.isNotEmpty()) {
            conn.doOutput = true; conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val input = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = BufferedReader(InputStreamReader(input ?: "".byteInputStream())).use { it.readText() }
        conn.disconnect(); return TextResp(code in 200..299, code, text)
    }

    private fun httpBytes(path: String, timeoutMs: Int = 180_000): BinResp {
        val conn = URL(baseFor(path) + path).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"; conn.connectTimeout = 8_000; conn.readTimeout = timeoutMs
        conn.setRequestProperty("Cache-Control", "no-store"); conn.setRequestProperty("Connection", "close")
        val code = conn.responseCode; val ct = conn.contentType ?: "image/png"
        val input = if (code in 200..299) conn.inputStream else conn.errorStream
        val bos = ByteArrayOutputStream(); input?.use { it.copyTo(bos) }; conn.disconnect()
        return BinResp(code in 200..299, code, bos.toByteArray(), ct)
    }

    @JavascriptInterface fun apiRequest(id: String, method: String, path: String, body: String) {
        exec.submit {
            var ok = false
            val payload = try {
                val timeout = when {
                    path == "/v1/images/init" || path.startsWith("/v1/images/") -> 45_000
                    path.startsWith("/v1/images") -> 120_000
                    path.contains("pose/preview") -> 300_000
                    else -> 120_000
                }
                val r = http(method, path, body, timeout)
                ok = r.ok; r.text
            } catch (e: Exception) { JSONObject().put("error", e.message ?: "request failed").toString() }
            val js = "window.WAI_NATIVE&&window.WAI_NATIVE.onApi(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});"
            webView.post { webView.evaluateJavascript(js, null) }
        }
    }

    // Result image goes straight from the SSH-tunnel HTTP stream into Android app-private storage.
    // Only after fsync/write succeeds do we ACK AutoDL, which deletes its temporary generated output.
    @JavascriptInterface fun fetchAndSaveJob(id: String, jobId: String, localMetaJson: String) {
        exec.submit {
            var ok = false
            val payload = try {
                val jr = http("GET", "/v1/jobs/$jobId", "", 30_000)
                if (!jr.ok) throw IllegalStateException("无法读取任务元数据")
                val job = JSONObject(jr.text)
                var img: BinResp? = null
                var lastDownloadError = ""
                for (attempt in 1..3) {
                    try {
                        val one = httpBytes("/v1/jobs/$jobId/image", 180_000)
                        if (one.ok && one.bytes.isNotEmpty()) { img = one; break }
                        val detail = try { String(one.bytes, Charsets.UTF_8).take(240) } catch (_: Exception) { "" }
                        lastDownloadError = "HTTP ${one.code}${if (detail.isNotBlank()) ": $detail" else ""}"
                    } catch (e: Exception) {
                        lastDownloadError = e.message ?: "网络异常"
                    }
                    Thread.sleep(1200L * attempt)
                }
                val imageResp = img ?: throw IllegalStateException("生成已完成，但本机下载失败：$lastDownloadError")
                val meta = try { JSONObject(localMetaJson) } catch (_: Exception) { JSONObject() }
                val req = job.optJSONObject("request")
                val result = job.optJSONObject("result")
                meta.put("job_id", jobId)
                    .put("mode", req?.optString("mode", meta.optString("mode", "txt")) ?: meta.optString("mode", "txt"))
                    .put("seed", job.optLong("seed", -1))
                    .put("steps", job.optInt("steps", 0))
                    .put("cfg", job.optDouble("cfg", 0.0))
                    .put("positive", job.optString("positive", ""))
                    .put("negative", job.optString("negative", ""))
                    .put("server_note", job.optString("note", ""))
                    .put("remote_filename", result?.optString("filename", "") ?: "")
                val saved = store.saveBytes(imageResp.bytes, imageResp.contentType, "wai_${meta.optString("mode","img")}_$jobId", meta)
                // Privacy cleanup is allowed only after a durable local Pictures/WAI Pad copy exists.
                // If album export fails, keep the AutoDL result so the user cannot lose the only copy.
                if (saved.optBoolean("durable_local", false)) {
                    val ack = http("POST", "/v1/jobs/$jobId/ack-local", "{}", 30_000)
                    saved.put("remote_cleanup_ok", ack.ok)
                } else {
                    saved.put("remote_cleanup_ok", false)
                    saved.put("warning", "已写入 App 私有缓存，但本机 Pictures/WAI Pad 落盘失败；AutoDL 成图暂不删除")
                }
                ok = true; saved.toString()
            } catch (e: Exception) { JSONObject().put("error", e.message ?: "save failed").toString() }
            val js = "window.WAI_NATIVE&&window.WAI_NATIVE.onImageSaved(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(payload)});"
            webView.post { webView.evaluateJavascript(js, null) }
        }
    }

    @JavascriptInterface fun bootstrapServer(id: String) {
        exec.submit {
            var ok = false
            val output = try {
                val s = SshClient.connect(prefs); val r = RemoteBootstrap.installAndStart(context, s); s.disconnect(); ok = true; r
            } catch (e: Exception) { e.message ?: "bootstrap failed" }
            val js = "window.WAI_NATIVE&&window.WAI_NATIVE.onBootstrap(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(output)});"
            webView.post { webView.evaluateJavascript(js, null) }
        }
    }

    // Used after a rollback: restart the files already restored on the server without
    // uploading the APK-bundled companion again (which would undo the rollback).
    @JavascriptInterface fun restartServerFromDisk(id: String) {
        exec.submit {
            var ok = false
            val output = try {
                val s = SshClient.connect(prefs)
                val r = SshClient.exec(s, "chmod 700 /root/WAI_Pad/*.sh; bash /root/WAI_Pad/bootstrap.sh", 320_000)
                s.disconnect()
                if (r.first != 0) throw IllegalStateException("恢复后重启失败(${r.first})：${r.second.takeLast(1600)}")
                ok = true; r.second
            } catch (e: Exception) { e.message ?: "restart failed" }
            val js = "window.WAI_NATIVE&&window.WAI_NATIVE.onBootstrap(${JSONObject.quote(id)},${if (ok) "true" else "false"},${JSONObject.quote(output)});"
            webView.post { webView.evaluateJavascript(js, null) }
        }
    }
}
