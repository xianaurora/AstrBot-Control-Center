# Build status — v1.6.0-dev15

- Android App: `1.6.0-dev15` / `161300`
- Embedded Core: `1.6.0-dev11` / `16011` (unchanged)
- AstrBot runtime observed in supplied diagnostics: `4.26.8`

## Source validation

Run:

```bash
bash ./scripts/verify-source.sh
```

The source gate checks the embedded engine SHA/manifests, shell syntax, Android source invariants, version agreement, native QR path, SPA-safe WebView URL handling, dev15 AstrBot WebStorage recovery, and Android 16 compatibility rendering.

This environment does not contain the full Android SDK/Gradle build toolchain, so a successful source gate is not represented as a compiled APK result. The included GitHub Actions workflow performs the Android SDK install, unit tests and `assembleDebug`.
