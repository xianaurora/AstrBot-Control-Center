package com.xianaurora.astrbotcontrol

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.xianaurora.astrbotcontrol.engine.InstallerViewModel
import com.xianaurora.astrbotcontrol.ui.AstrBotControlApp
import com.xianaurora.astrbotcontrol.ui.AstrBotTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Respect the user's system refresh-rate choice. ARR keeps static UI
        // power-efficient and Android's touch/animation boost can use the
        // configured high refresh rate instead of pinning 165 Hz permanently.
        if (Build.VERSION.SDK_INT >= 35) {
            window.isFrameRatePowerSavingsBalanced = true
            window.isFrameRateBoostOnTouchEnabled = true
        }
        setContent {
            AstrBotTheme {
                val vm: InstallerViewModel = viewModel()
                AstrBotControlApp(vm)
            }
        }
    }
}
